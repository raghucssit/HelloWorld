package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.ProfileAccountDao;
import com.capitalone.api.customersaccounts.entity.IntProfileAccountEntity;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.epf.context.model.EPFContext;

@Profile
@Trace
@Named
public class ProfileAccountDaoImpl extends AbstractBaseService implements ProfileAccountDao {

    @Inject
    private ConversionService conversionService;

    @Inject
    private IntProfileAccountEntity intProfileAccountEntity;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;
 /**
     * Getting 360 Accounts
     * 
     * @param context holds the request context
     * @param customerAccountKey holds the list of accounts
     * @return list of accounts details
     * 
     */
    @Override
    @Async
    public Future<REASResponse> retrieve360AccountSummary(EPFContext context, CustomerAccountKey customerAccountKey,boolean is360ApiKeyPresent) {

        logger.debug("Enter -- retrieve360AccountSummary of ProfileAccountDaoImpl");
        logger.debug("In ProfileAccountDaoImpl {}", customerAccountKey);

        List<CustomerAccountsResponse> profileAccountResponesList = new ArrayList<CustomerAccountsResponse>();
        List<AdditionalStat> stat = new ArrayList<AdditionalStat>();
        REASResponse resp = new REASResponse();

        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();

        AdditionalStat addnStat = null;
        CustomerAccountsResponse customerAccountsResponse = null;
        try {

            ProfileAccountDetail profileAccountDetail = intProfileAccountEntity.retiveAccountDetails(
                    customerAccountKey, context, customerAccountKey.getAccountNumber(),
                    String.valueOf(customerAccountKey.getSorId()),is360ApiKeyPresent);

            logger.debug("Profile Account Hash COde value {}", profileAccountDetail);
            if (profileAccountDetail != null) {
                customerAccountsResponse = conversionService.convert(profileAccountDetail,
                        CustomerAccountsResponse.class);
                // Sorid is not provided by the request API
                customerAccountsResponse.setSorId(customerAccountKey.getSorId().toString());

                profileAccountResponesList.add(customerAccountsResponse);
            } else {
                addnStat = new AdditionalStat();
                addnStat.setNativeErrorCd(Constants.API_360_ERROR_CODE);
                addnStat.setStatDesc(Constants.BANK360_API_DOWN.concat(CustomerAccountsUtil.constructAcctSorIDnotfound(
                        customerAccountKey.getAccountNumber(), customerAccountKey.getSorId())));
                addnStat.setAccountId(CustomerAccountsUtil.maskNPI(customerAccountKey.getAccountNumber()));
                stat.add(addnStat);
            }
            resp = mapToREAS(profileAccountResponesList, stat);
        } catch (Exception e) {
            logger.debug("Exception Occurred {}", e.getCause());
            errorWhileRetrieve360Account(customerAccountKey, resp, addnStatFail, addnStatFailList, e);
        }

        logger.debug("Exit -- retrieve360AccountSummary of ProfileAccountDaoImpl");
        return new AsyncResult<REASResponse>(resp);
    }

    private void errorWhileRetrieve360Account(CustomerAccountKey customerAccountKey, REASResponse resp,
            AdditionalStat addnStatFail, List<AdditionalStat> addnStatFailList, Exception e) {
        logger.debug("Enter -- errorWhileRetrieve360Account of ProfileAccountDaoImpl");
        if (e.getCause() instanceof CustomerAPIRESTException) {
            customerAccountsUtil.setCustomerAPIRESTException(customerAccountKey, addnStatFail, e);
        } else {
            addnStatFail.setNativeErrorCd(Constants.API_360_ERROR_CODE);
            addnStatFail.setStatDesc(Constants.BANK360_API_DOWN.concat(CustomerAccountsUtil.constructAcctSorIDnotfound(
                    customerAccountKey.getAccountNumber(), customerAccountKey.getSorId())));
            addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
            addnStatFail.setAccountId(CustomerAccountsUtil.maskNPI(customerAccountKey.getAccountNumber()));
        }
        addnStatFailList.add(addnStatFail);
        resp.setAddStatList(addnStatFailList);
        resp.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));
        logger.debug("Exit -- errorWhileRetrieve360Account of ProfileAccountDaoImpl");
    }

    private REASResponse mapToREAS(List<CustomerAccountsResponse> profileAccountResponesList, List<AdditionalStat> stat) {
        logger.debug("Enter -- mapToREAS of ProfileAccountDaoImpl");
        REASResponse reasResponse = new REASResponse();
        reasResponse.setCustomerAccountsResponseList(profileAccountResponesList);
        reasResponse.setAddStatList(stat);
        logger.debug("Exit -- mapToREAS of ProfileAccountDaoImpl");
        return reasResponse;
    }
}
