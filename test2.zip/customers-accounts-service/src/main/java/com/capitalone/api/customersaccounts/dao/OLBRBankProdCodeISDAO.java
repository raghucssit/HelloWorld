package com.capitalone.api.customersaccounts.dao;

import java.util.List;

import com.capitalone.api.customersaccounts.service.pojo.OLBRRefData;

public interface OLBRBankProdCodeISDAO {
    List<OLBRRefData> getProductInfo();

}
