package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.LoansHomeLoansDao;
import com.capitalone.api.customersaccounts.entity.LoansHomeLoansEntity;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.loans.homeloans.accounts.model.v3.Account;
import com.capitalone.epf.context.model.EPFContext;

/**
 * DAO for retrieving Account NickName from Rest Client
 */

@Profile
@Trace
@Named
public class LoansHomeLoansDaoImpl extends AbstractBaseService implements LoansHomeLoansDao {
    
    @Inject
    private LoansHomeLoansEntity homeLoansEntity;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;



    /**
     * Getting Account of HomeLoans
     * 
     * @param context holds the request context
     * @param customerAccountKey holds the input information
     * @return list of accounts details
     * 
     */


    @Override
    @Async
    public Future<REASResponse> getHomeLoanAccounts(EPFContext context, CustomerAccountKey customerAccountKey) {

        logger.debug("Enter - getHomeLoanAccounts method of LoansHomeLoansDaoImpl class");

        List<CustomerAccountsResponse> homeLoanAccountResponesList = new ArrayList<CustomerAccountsResponse>();

        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();
        List<AdditionalStat> stat = new ArrayList<AdditionalStat>();
        REASResponse resp = new REASResponse();
        AdditionalStat addnStat = null;
        CustomerAccountsResponse customerAccountsResponse = null;
        try {
            Account homeLoanAccount = homeLoansEntity.retiveAccountDetails(customerAccountKey, context,
                    customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()));

            if (null != homeLoanAccount) {
                customerAccountsResponse = conversionService.convert(homeLoanAccount, CustomerAccountsResponse.class);
                homeLoanAccountResponesList.add(customerAccountsResponse);
            } else {
                addnStat = new AdditionalStat();
                addnStat.setNativeErrorCd(Constants.API_HL_ERROR_CODE);
                addnStat.setStatDesc(Constants.HL_API_DOWN.concat(CustomerAccountsUtil.constructAcctSorIDnotfound(
                        customerAccountKey.getAccountNumber(), customerAccountKey.getSorId())));
                addnStat.setAccountId(CustomerAccountsUtil.maskNPI(customerAccountKey.getAccountNumber()));
                stat.add(addnStat);
            }
            resp = mapToREAS(homeLoanAccountResponesList, stat);
            
        }catch (Exception e) {
            setFailAdditionalStat(customerAccountKey, addnStatFail, e);            
            addnStatFailList.add(addnStatFail);
            resp.setAddStatList(addnStatFailList);
            resp.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));
            
        }
        logger.debug("Exit - getHomeLoanAccounts method of LoansHomeLoansDaoImpl class");
        return new AsyncResult<REASResponse>(resp);
    }

    private void setFailAdditionalStat(CustomerAccountKey customerAccountKey, AdditionalStat addnStatFail, Exception e) {
        logger.debug("Enter - setFailAdditionalStat method of LoansHomeLoansDaoImpl class");
        if (e.getCause() instanceof CustomerAPIRESTException) {
            customerAccountsUtil.setCustomerAPIRESTException(customerAccountKey, addnStatFail, e);
        } else {
            addnStatFail.setNativeErrorCd(Constants.API_HL_ERROR_CODE);
            addnStatFail.setStatDesc(Constants.HL_API_DOWN.concat(CustomerAccountsUtil.constructAcctSorIDnotfound(
                    customerAccountKey.getAccountNumber(), customerAccountKey.getSorId())));
            addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
            addnStatFail.setAccountId(CustomerAccountsUtil.maskNPI(customerAccountKey.getAccountNumber()));
        }
        logger.debug("Exit - setFailAdditionalStat method of LoansHomeLoansDaoImpl class");
    }



    

    private REASResponse mapToREAS(List<CustomerAccountsResponse> homeLoanAccountResponesList, List<AdditionalStat> stat) {
        logger.debug("Enter - mapToREAS method of LoansHomeLoansDaoImpl class");
        REASResponse reasResponse = new REASResponse();
        reasResponse.setCustomerAccountsResponseList(homeLoanAccountResponesList);
        reasResponse.setAddStatList(stat);
        logger.debug("Exit - mapToREAS method of LoansHomeLoansDaoImpl class");
        return reasResponse;
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
