package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccount;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsOrchResponse;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.model.id.AccountReferenceId;

@Profile
@Trace
@Named
public class FetchLightWeightECROrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Inject
    private CustomerAccountsOrchService customerAccountsOrchService;

    @Inject
    private CustomerAccountsAggregationService customerAccountsAggregationService;

    /**
     * Method for retrieving Light weight customers accounts
     * 
     * @param customerAccountsRequest input request
     * @param selectOptionList list of query elements
     * @return Customers account response
     * 
     */
    public List<CustomerAccount> fetchLightWeightECRKeyBasedOnResponseListContent(
            CustomerAccountsRequest customerAccountsRequest, List<String> selectOptionList) {
        logger.debug("Entry - fetchLightWeightECRKeyBasedOnResponseListContent method of FetchLightWeightECROrchService class");
        List<CustomerAccount> customerAccountList = new ArrayList<CustomerAccount>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        REASResponse customerAccountsAggregatedResponse = null;
        Map<String, String> map360Accounts = new HashMap<String, String>();
        if (customerAccountsRequest == null) {
            return null;
        }
        customerAccountKeyList.addAll(customerAccountsRequest.getCustomerAccountKeyList());
        List<CustomerAccountKey> accountKeyList = filterProfileAccounts(customerAccountsRequest);
        if (!accountKeyList.isEmpty()) {
            customerAccountsRequest.setCustomerAccountKeyList(accountKeyList);
            CustomerAccountsOrchResponse accountsOrchResponse = customerAccountsOrchService
                    .execute(customerAccountsRequest);
            customerAccountsAggregatedResponse = customerAccountsAggregationService.execute(accountsOrchResponse,
                    false, true,null);
            if (null != customerAccountsAggregatedResponse) {
                map360Accounts = get360Response(customerAccountsAggregatedResponse);
            }
        }

        for (CustomerAccountKey keyList : customerAccountKeyList) {
            CustomerAccount customerAccount = new CustomerAccount();
            if (keyList.getAccountNumber() != null && keyList.getSorId() != null) {

                if (selectOptionList.contains(Constants.FIELD_ACCOUNT_NUMBER)) {
                    customerAccount.setAccountNumber(keyList.getAccountNumber());
                }

                AccountReferenceId accountReferenceId = new AccountReferenceId(keyList.getAccountNumber(), keyList
                        .getSorId().toString());

                customerAccount.setAccountReferenceId(accountReferenceId.getReferenceId());

                selectFieldHavingBussinessLine(selectOptionList, keyList, customerAccount, map360Accounts);

                if (selectOptionList.contains(Constants.FIELD_BANK_NUMBER)) {
                    String bankNumber = customerAccountsRefDataBean.getBankNumberFromSorId(String.valueOf(keyList
                            .getSorId()));
                    setBankNumber(customerAccount, bankNumber);
                }
                logger.debug("Value for BUSINESSLINE: {}", customerAccount.getBusinessLine());
                logger.debug("Value for SORID: {}", keyList.getSorId());
                //Adding version number to auditable field Version
                customerAccount.setVersion(customerAccountsRequest.getAppVersion());
                customerAccountList.add(customerAccount);
                logger.debug("Exit - fetchLightWeightECRKeyBasedOnResponseListContent method of FetchLightWeightECROrchService class");
            }
        }
        return customerAccountList;
    }

    private void setBankNumber(CustomerAccount customerAccount, String bankNumber) {
        if (bankNumber != null && StringUtils.isNotEmpty(bankNumber.trim())) {
            customerAccount.setBankNumber(bankNumber);

        }
    }

    private List<CustomerAccountKey> filterProfileAccounts(CustomerAccountsRequest customerAccountsRequest) {
        List<CustomerAccountKey> accountKeyList = new ArrayList<CustomerAccountKey>();
        for (CustomerAccountKey listCreditCardAccounts : customerAccountsRequest.getCustomerAccountKeyList()) {
            if (listCreditCardAccounts.getSorId().equals(Short.valueOf(Constants.PROFILE_SOR_ID_INT))) {
                accountKeyList.add(listCreditCardAccounts);

            }
        }
        return accountKeyList;
    }

    private void selectFieldHavingBussinessLine(List<String> selectOptionList, CustomerAccountKey keyList,
            CustomerAccount customerAccount, Map<String, String> map360Accounts) {
        logger.debug("Enter - selectFieldHavingBussinessLine method of FetchLightWeightECROrchService class");
        String productTypeCode = null;
        if (selectOptionList.contains(Constants.FIELD_BUSINESS_LINE)) {
            if (keyList.getSorId().equals(Short.valueOf(Constants.SORID_360))) {

                productTypeCode = map360Accounts.get(keyList.getAccountNumber());
            }
            customerAccount.setBusinessLine(customerAccountsRefDataBean.getBusinessLineBasedOnSORID(
                    String.valueOf(keyList.getSorId()), productTypeCode));
        }
        logger.debug("Exit - selectFieldHavingBussinessLine method of FetchLightWeightECROrchService class");
    }

    private Map<String, String> get360Response(REASResponse reasResponse) {
        Map<String, String> map360Account = new HashMap<String, String>();
        if (null != reasResponse && null != reasResponse.getCustomerAccountsResponseList()) {
            for (CustomerAccountsResponse customerAccountResponse : reasResponse.getCustomerAccountsResponseList()) {
                map360Account.put(customerAccountResponse.getAccountNumber(),
                        customerAccountResponse.getProductTypeCode());
            }
        }
        return map360Account;
    }
}
