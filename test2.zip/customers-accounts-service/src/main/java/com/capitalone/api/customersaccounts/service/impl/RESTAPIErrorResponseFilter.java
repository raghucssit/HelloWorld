package com.capitalone.api.customersaccounts.service.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientResponseContext;
import javax.ws.rs.client.ClientResponseFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.Provider;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.exception.ApiSystemException;
import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;

@Provider
@Named
@Trace
@Profile
public class RESTAPIErrorResponseFilter implements ClientResponseFilter {

    @Inject
    private MessageBodyReader<ErrorResponse> autoLoanAccountErrorMessageBodyReader;
    
    @Inject
    @Named("upf-app-config")
    private Configuration config;

    private Logger logger = LoggerFactory.getLogger(getClass());  
    
     
    /**
     * Method for handling exception for API to API Calls
     * 
     * @param requestContext request context
     * @param responseContext response context
     */
    @Override
    public void filter(ClientRequestContext requestContext, ClientResponseContext responseContext) throws IOException {
        logger.debug("Enter - filter method of RESTAPIErrorResponseFilter class");
        // lets do this only when individual api is interested in translation and when we are dealing with error.
        if (responseContext.getStatusInfo().getFamily() != Response.Status.Family.SUCCESSFUL
                && responseContext.getStatusInfo().getFamily() != Response.Status.Family.INFORMATIONAL) {
            InputStream inputStream = responseContext.getEntityStream();
            if (inputStream != null) {
                byte[] inputStreamContents = IOUtils.toByteArray(inputStream);
                // we will create two copies of this input stream
                ByteArrayInputStream responseInputStream = new ByteArrayInputStream(inputStreamContents);
                ByteArrayInputStream copyOfResponseInputStream = new ByteArrayInputStream(inputStreamContents);

                ErrorResponse errorResponse = autoLoanAccntErrMessageBodyReader(responseContext, responseInputStream,
                        copyOfResponseInputStream);
                setErrorResponse(responseContext, copyOfResponseInputStream, errorResponse);

            }

        }
        logger.debug("Exit - filter method of RESTAPIErrorResponseFilter class");
    }

    private void setErrorResponse(ClientResponseContext responseContext,
            ByteArrayInputStream copyOfResponseInputStream, ErrorResponse errorResponse) {
        
        List<String> entitlementAllowMessageErrorCode = config.getList(Constants.ENTITLEMENT_ALLOW_MSG_ERRORCODE);
        logger.debug("entitlementAllowMessageErrorCode: {}", entitlementAllowMessageErrorCode);
        if (errorResponse != null && errorResponse.getId() != null && !entitlementAllowMessageErrorCode.contains(errorResponse.getId())) {
            throw new CustomerAPIRESTException(responseContext.getStatus(), errorResponse);
        } else if (errorResponse != null && errorResponse.getId() != null
                && entitlementAllowMessageErrorCode.contains(errorResponse.getId())) {
            // This for entitlement when Multiple ESCID happens & No accounts found for the SSOID. We return the message to entitlement to display
            responseContext.setEntityStream(copyOfResponseInputStream);
        }
    }

    private ErrorResponse autoLoanAccntErrMessageBodyReader(ClientResponseContext responseContext,
            ByteArrayInputStream responseInputStream, ByteArrayInputStream copyOfResponseInputStream)
            throws IOException {
        logger.debug("Enter - autoLoanAccntErrMessageBodyReader method of RESTAPIErrorResponseFilter class");
        ErrorResponse errorResponse = null;
        try {
            errorResponse = (ErrorResponse) autoLoanAccountErrorMessageBodyReader.readFrom(ErrorResponse.class,
                    ErrorResponse.class, null, responseContext.getMediaType(), responseContext.getHeaders(),
                    responseInputStream);
        } catch (Exception e) {
            logger.warn(" could not marshall error response, may be its not in eApi error format ", e);
            throw new ApiSystemException(IOUtils.toString(copyOfResponseInputStream), e);
        }
        logger.debug("Exit - autoLoanAccntErrMessageBodyReader method of RESTAPIErrorResponseFilter class");
        return errorResponse;
    }

}
