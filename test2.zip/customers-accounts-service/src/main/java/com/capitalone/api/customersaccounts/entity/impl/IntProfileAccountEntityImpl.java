package com.capitalone.api.customersaccounts.entity.impl;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractRestBaseService;
import com.capitalone.api.customersaccounts.entity.IntProfileAccountEntity;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.model.EndpointProperties;

@Profile
@Trace
@Named
public class IntProfileAccountEntityImpl extends AbstractRestBaseService<Client, ProfileAccountDetail> implements
        IntProfileAccountEntity {

    private static final String userId360 = "9222";

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private Client eapiRestClient;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    private static final String INT_PROFILE_ACCOUNTS_API_ROOT_RESOURCE_URL = "int-profile-accounts-Service";

    private static final String APPLICATION_JSON_V_3 = "application/json; v=3";

    private static final String USERID = "User-Id";

    private static final String ENTITLED = "entitled";

    /**
     * Creating builder to point 360 API url
     * 
     * @param customerAccountKey holds input information
     * @param epfContext holds the request context
     * @param accountNumber account information
     * @param sorId sor id of account
     * @return list of 360 accounts
     * 
     */

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    // @Cacheable(value = "eapi-shortterm-integrationprofileaccountsdao-retrieveAccountDetails", key =
    // "#accountNumber.concat(#sorId)")
    public ProfileAccountDetail retiveAccountDetails(CustomerAccountKey customerAccountKey, EPFContext epfContext,
            String accountNumber, String sorId, boolean is360ApiKeyPresent) throws Exception {
        logger.debug("Enter - retiveAccountDetails method of IntProfileAccountEntityImpl class");
       
        EndpointProperties endpointProperties = customerAccountsUtil
                .getEndpointProperties(INT_PROFILE_ACCOUNTS_API_ROOT_RESOURCE_URL);

        String url = endpointProperties.getUrl();

        UriBuilder uri = UriBuilder.fromUri(url).path(customerAccountKey.getAccountNumber());
        WebTarget requestPath = eapiRestClient.target(uri);
        Builder buildrequest = null;
        if (is360ApiKeyPresent) {
            buildrequest = requestPath.request().accept(APPLICATION_JSON_V_3)
                    .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V_3).header("entitled", ENTITLED)
                    .header(USERID, epfContext.getUserId());
            
        } else {
            buildrequest = requestPath.request().accept(APPLICATION_JSON_V_3)
                    .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V_3).header("entitled", ENTITLED)
                    .header(USERID, userId360);

           
        }

        logger.debug("Int profile accounts entity");

        return buildrequest.get(ProfileAccountDetail.class);
    }

}