package com.capitalone.api.customersaccounts.dao;

import java.util.List;
import java.util.concurrent.Future;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.epf.context.model.EPFContext;

public interface MongoOecpPreferencesHystrixDAO {

	@SuppressWarnings("PMD.SignatureDeclareThrowsException")
    Future<List<String>> getCustomSortOrderDetails(CustomerAccountsRequest request,EPFContext context) throws Exception;

}
