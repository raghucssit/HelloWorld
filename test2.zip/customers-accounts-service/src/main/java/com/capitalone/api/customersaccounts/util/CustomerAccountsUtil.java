/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.util;

import static org.joda.time.DateTimeFieldType.dayOfMonth;
import static org.joda.time.DateTimeFieldType.monthOfYear;
import static org.joda.time.DateTimeFieldType.year;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Instant;
import org.joda.time.LocalDate;
import org.springframework.http.HttpMethod;

import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.services.util.ApiExceptionService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccount;
import com.capitalone.api.customersaccounts.model.v1.CustomerApiErrorCode;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.service.pojo.SevrtyType;
import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.api.model.link.Link;
import com.capitalone.api.model.link.LinkBuilder;
import com.capitalone.api.model.product.Product;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;
import com.capitalone.epf.servicelocator.EndpointManager;
import com.capitalone.epf.servicelocator.model.EndpointProperties;
import com.capitalone.xmlmsgset._2004._07.eil.HdrType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType.AddnStat;

/**
 * @author BYQ461
 */
@Named
public class CustomerAccountsUtil {

    private static final String API_KEY = "Api-Key";

    private static final String EPF_X_MESSAGE_ID = "epf_X-Message-ID";

    private static final String PERF_LOG = "PerfLog";

    @Inject
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Inject
    private ApiExceptionService apiExceptionService;

    @Inject
    private LinkBuilder linkBuilder;

    @Inject
    private EndpointManager endpointManager;

    private static String accountNumberPadding = "0";

    @Inject
    @Named("upf-app-config")
    private Configuration config;

    /**
     * Retrieve SoRIDs Based On BusinessLine And ProductType
     * 
     * @param businessLineSet Business Line Set
     * @param productTypeSet Product Tyoe Set
     * @return List of Sor Id
     */

    public Set<String> retrieveSoRIDsBasedOnBusinessLineAndProductType(Set<String> businessLineSet,
            Set<String> productTypeSet) {
        Set<String> filteredSoRIDSet = null;
        if ((businessLineSet != null && !businessLineSet.isEmpty())
                || (productTypeSet != null && !productTypeSet.isEmpty())) {
            filteredSoRIDSet = new TreeSet<String>();
            Set<String> filteredSoRIDSetbyBusinessLine = null;
            Set<String> filteredSoRIDSetbyProductType = null;

            filteredSoRIDSetbyBusinessLine = customerAccountsRefDataBean.getSoRIDBasedOnBusinessline(businessLineSet);
            if (filteredSoRIDSetbyBusinessLine != null && !filteredSoRIDSetbyBusinessLine.isEmpty()) {
                filteredSoRIDSet.addAll(filteredSoRIDSetbyBusinessLine);
            }

            filteredSoRIDSetbyProductType = customerAccountsRefDataBean.getSoRIDBasedOnProductType(productTypeSet);
            if (filteredSoRIDSetbyProductType != null && !filteredSoRIDSetbyProductType.isEmpty()) {
                filteredSoRIDSet.addAll(filteredSoRIDSetbyProductType);
            }
        }
        return filteredSoRIDSet;
    }

    /**
     * Getting Account Details Link
     * 
     * @param productTypeDescription Product Type Description
     * @param accountReferenceId Account Number and Sor ID
     * @return Account Link URL
     */

    public Link getAccountDetailsLink(String productTypeCode, String sorID, AccountReferenceId accountReferenceId) {
        String accountDetailsURLTemplate = null;
        accountDetailsURLTemplate = customerAccountsRefDataBean.getAccountDetailsURL(productTypeCode, sorID);
        if (StringUtils.isBlank(accountDetailsURLTemplate)
                || Constants.NOT_AVAILABLE_CD.equalsIgnoreCase(accountDetailsURLTemplate)) {
            return null;
        }
        Link link = linkBuilder.buildLink(EPFContextContainer.getContext(), accountDetailsURLTemplate,
                new String[] {"{0}"}, new ReferenceId[] {accountReferenceId.getReferenceId()}, HttpMethod.GET);
        return link;
    }

    /**
     * filtering by SoRID
     * 
     * @param customerAccountKeyList List of Accounts
     * @param soRIDSet Set of Sor ID
     * @return Account list based on Sor ID
     */

    public List<CustomerAccountKey> filterbySoRID(List<CustomerAccountKey> customerAccountKeyList, Set<String> soRIDSet) {
        if (soRIDSet == null || soRIDSet.isEmpty()) {
            return customerAccountKeyList;
        }

        List<CustomerAccountKey> filteredCustomerAccountKeyList = null;
        filteredCustomerAccountKeyList = new ArrayList<CustomerAccountKey>();
        for (CustomerAccountKey customerAccountKey : customerAccountKeyList) {
            if (customerAccountKey.getSorId() != null && soRIDSet.contains(customerAccountKey.getSorId().toString())) {
                filteredCustomerAccountKeyList.add(customerAccountKey);
            }
        }
        return filteredCustomerAccountKeyList;
    }

    /**
     * Checking Response For Errors
     * 
     * @param responseStatus Response Status
     */

    public void checkResponseForErrors(StatType responseStatus) {

        if (responseStatus.getStatCd() != 0) {
            switch (responseStatus.getSevrty()) {
                case ERROR:
                    apiExceptionService.mapException("CustomerAccounts", "retrieveCustomerAccounts", responseStatus,
                            "999999");
                    break;
                case INFO:
                    apiExceptionService.mapException("CustomerAccounts", "retrieveCustomerAccounts", responseStatus,
                            "999999");
                    break;
                case WARNING:
                    if (responseStatus.getStatCd() == com.capitalone.api.customersaccounts.constant.Constants.RECORDS_EXCEED_LIMIT) {
                        apiExceptionService.mapException("CustomerAccounts", "retrieveCustomerAccounts",
                                responseStatus, "999999");
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Construction of ApiErrorCode
     * 
     * @param errorId Error ID
     * @param messageParms Message Parameters
     * @param developerText Developer Text
     * @return Api Error Code
     */

    public ApiErrorCode constructApiErrorCode(Integer errorId, List<String> messageParms, String developerText) {
        ApiErrorCode error = new ApiErrorCode();
        error.setId(errorId.toString());
        if (StringUtils.isNotBlank(developerText)) {
            // error.setDeveloperTextId(String.valueOf(errorId));
            error.setDeveloperText(developerText);
        }
        if (messageParms != null) {
            error.setMessageParms(messageParms);
        }
        return error;
    }

    /**
     * Mapping to Final Response
     * 
     * @param reponse List of Accounts Response
     * @param appversion App Version
     * @param customerAccountKeyList List of customers Account
     * @return List of customers Account
     */

    public List<CustomerAccount> maptoFinalResponse(List<CustomerAccountsResponse> reponse, String appversion,
            List<CustomerAccountKey> customerAccountKeyList) {

        List<CustomerAccount> customerAccountList = null;
        if (reponse == null) {
            return customerAccountList;
        }
        customerAccountList = new ArrayList<CustomerAccount>();
        for (CustomerAccountsResponse customerAccountsResponse : reponse) {

            CustomerAccount customerAccount = new CustomerAccount();

            if (customerAccountsResponse != null) {

                if (null != customerAccountsResponse.getRetirementIndicator()) {
                    customerAccount.setRetirementIndicator(customerAccountsResponse.getRetirementIndicator());
                }

                setAcctNumber(appversion, customerAccountsResponse, customerAccount);
                setBusinessDetails(customerAccountsResponse, customerAccount);
                setProductDetail(customerAccountsResponse, customerAccount);
                // }

                AccountReferenceId accountReferenceId = null;
                // if (customerAccountsResponse != null) {

                if (!appversion.equalsIgnoreCase(Constants.APP_VERSION5)
                        && customerAccountsResponse.getSorId().equalsIgnoreCase(Constants.AUTO_LOAN_SORID)
                        && customerAccountsResponse.getLoanSeqNum() != null) {
                    customerAccountsResponse.setAccountId(customerAccountsResponse.getAccountId().concat(
                            customerAccountsResponse.getLoanSeqNum()));
                }

                accountReferenceId = new AccountReferenceId(customerAccountsResponse.getAccountId(),
                        customerAccountsResponse.getSorId());

                if (customerAccountsResponse.getSorId().equalsIgnoreCase(Constants.SOR_ID_COI)) {
                    customerAccount.setValidAsOfTimestamp(customerAccountsResponse.getValidAsOfTimestamp());
                }

                customerAccount.setAccountReferenceId(accountReferenceId.getReferenceId());
                customerAccount.setBankNumber(customerAccountsResponse.getBankNumber());
                customerAccount.setBankNumberDescription(customerAccountsResponse.getBankNumberDescription());
                customerAccount.setAccountStatus(customerAccountsResponse.getAccountStatusDescription());
                // / this is temporary code, need to removed once all the client started using
                setAcctNickName(appversion, customerAccountsResponse, customerAccount);
                customerAccount.setOpenDate(customerAccountsResponse.getOpenDate());
                customerAccount.setClosedDate(customerAccountsResponse.getClosedDate());
                customerAccount.setCurrencyCode(customerAccountsResponse.getCurrencyCode());
                customerAccount.setCustomerRole(customerAccountsResponse.getCustomerRole());
                customerAccount.setAccountDetailsURL(getAccountDetailsLink(
                        customerAccountsResponse.getProductTypeCode(), customerAccountsResponse.getSorId(),
                        accountReferenceId));

                if (Constants.SOR_ID_COI.equalsIgnoreCase(customerAccountsResponse.getSorId())
                		&& customerAccountsResponse.getCoiAccountURL() != null) {
                    URI uri = null;
                    Link accountDetailsURL = null;
                    try {
                        uri = new URI(customerAccountsResponse.getCoiAccountURL());
                        accountDetailsURL = new Link(uri, HttpMethod.GET);
                        customerAccount.setAccountDetailsURL(accountDetailsURL);
                    } catch (URISyntaxException e) {
                        uri = null;
                    }                    
                }
                setAccountUseType(customerAccountKeyList, customerAccountsResponse, customerAccount);

                setCardDetails(customerAccountsResponse, customerAccount);
                // Setting customer role for auto loan
                if (customerAccountsResponse.getSorId().equalsIgnoreCase(Constants.AUTO_LOAN_SORID)) {
                    setAutoLoanCustomerRole(customerAccountKeyList, customerAccountsResponse, customerAccount);
                }
                // Adding version number to auditable field Version
                customerAccount.setVersion(appversion);
            }

            customerAccountList.add(customerAccount);
        }
        return customerAccountList;
    }

    private void setAcctNickName(String appversion, CustomerAccountsResponse customerAccountsResponse,
            CustomerAccount customerAccount) {
        if ((customerAccountsResponse.getAccountNickname() != null)
                && (!customerAccountsResponse.getAccountNickname().isEmpty())) {
            if (appversion.equalsIgnoreCase(Constants.APP_VERSION3)) {
                customerAccount.setAccountNickName(customerAccountsResponse.getAccountNickname());
            } else {
                customerAccount.setAccountNickname(customerAccountsResponse.getAccountNickname());
            }
        }
    }

    private void setProductDetail(CustomerAccountsResponse customerAccountsResponse, CustomerAccount customerAccount) {
        Product product = new Product();
        product.setProductId(customerAccountsResponse.getProductId()); // product.setProductCode();
        product.setProductName(customerAccountsResponse.getProductName());
        product.setProductTypeCode(customerAccountsResponse.getProductTypeCode());
        product.setProductTypeDescription(customerAccountsResponse.getProductTypeDescription());
        if (customerAccountsResponse.getSorId() != null
                && customerAccountsResponse.getSorId().equalsIgnoreCase(Constants.CREDIT_CARD_SORID.toString())
                && customerAccountsResponse.getProductImageId() != null) {
            product.setProductImageId(customerAccountsResponse.getProductImageId());
        }
        if (customerAccountsResponse.getProductTypeCode() != null
                && customerAccountsResponse.getProductTypeCode().equalsIgnoreCase(Constants.AUTO_LOAN_PRODUCT_CD)) {
            product.setProductName(customerAccountsResponse.getProductTypeDescription());
        }
        // product.setProductClassCode(productClassCode);
        // product.setProductClassDescription(productClassDescription);
        customerAccount.setProduct(product);
    }

    private void setBusinessDetails(CustomerAccountsResponse customerAccountsResponse, CustomerAccount customerAccount) {
        if (customerAccountsResponse.getBusinessLine() != null) {

            customerAccount.setBusinessLine(customerAccountsResponse.getBusinessLine());
        }

        customerAccount.setBusinessLine(customerAccountsResponse.getBusinessLine());
    }

    private void setAcctNumber(String appversion, CustomerAccountsResponse customerAccountsResponse,
            CustomerAccount customerAccount) {

        if (appversion.equalsIgnoreCase(Constants.APP_VERSION5)) {
            customerAccount.setAccountNumber(customerAccountsResponse.getAccountNumber());
            customerAccount.setDisplayAccountNumber(customerAccountsResponse.getDisplayAccountNumber());
        } else {
            String loanSeqNumber = customerAccountsResponse.getLoanSeqNum();
            if (loanSeqNumber != null) {
                customerAccount.setAccountNumber(customerAccountsResponse.getAccountNumber().concat(loanSeqNumber));
                if (appversion.equalsIgnoreCase(Constants.APP_VERSION3)) {
                    customerAccount.setDisplayAccountNumber(customerAccountsResponse.getDisplayAccountNumber().concat(
                            loanSeqNumber));
                } else {
                    customerAccount.setDisplayAccountNumber(customerAccountsResponse.getDisplayAccountNumber());
                }

            } else {
                customerAccount.setAccountNumber(customerAccountsResponse.getAccountNumber());
                customerAccount.setDisplayAccountNumber(customerAccountsResponse.getDisplayAccountNumber());
            }
        }
    }

    private void setAccountUseType(List<CustomerAccountKey> customerAccountKeyList,
            CustomerAccountsResponse customerAccountsResponse, CustomerAccount customerAccount) {
        for (CustomerAccountKey customerAccountKey : customerAccountKeyList) {
            if (StringUtils.stripStart(customerAccountKey.getAccountNumber(), accountNumberPadding).equalsIgnoreCase(
                    StringUtils.stripStart(customerAccountsResponse.getAccountId(), accountNumberPadding))) {
                if (Constants.PER_ACCOUNTUSECODE.equalsIgnoreCase(customerAccountKey.getAccountUseType())) {
                    customerAccount.setAccountUseType(Constants.ACCOUNTUSECODE_PERSONAL);
                } else if (Constants.BUS_ACCOUNTUSECODE.equalsIgnoreCase(customerAccountKey.getAccountUseType())) {
                    customerAccount.setAccountUseType(Constants.ACCOUNTUSECODE_BUSINESS);
                } else if (Constants.EXP_ACCOUNTUSECODE.equalsIgnoreCase(customerAccountKey.getAccountUseType())) {
                    customerAccount.setAccountUseType(Constants.ACCOUNTUSECODE_EXPENSE);
                } else {
                    customerAccount.setAccountUseType(Constants.ACCOUNTUSECODE_UNKNOWN);
                }

            }
        }
    }

    private void setAutoLoanCustomerRole(List<CustomerAccountKey> customerAccountKeyList,
            CustomerAccountsResponse customerAccountsResponse, CustomerAccount customerAccount) {
        for (CustomerAccountKey customerAccountKey : customerAccountKeyList) {
            if (customerAccountKey.getAccountNumber().equalsIgnoreCase(
                    StringUtils.stripStart(customerAccountsResponse.getAccountNumber(), accountNumberPadding))) {
                if (Constants.PER_ACCOUNTUSECODE.equalsIgnoreCase(customerAccountKey.getAccountUseType())) {
                    customerAccount.setAccountUseType(Constants.ACCOUNTUSECODE_PERSONAL);
                } else if (Constants.BUS_ACCOUNTUSECODE.equalsIgnoreCase(customerAccountKey.getAccountUseType())) {
                    customerAccount.setAccountUseType(Constants.ACCOUNTUSECODE_BUSINESS);
                } else if (Constants.EXP_ACCOUNTUSECODE.equalsIgnoreCase(customerAccountKey.getAccountUseType())) {
                    customerAccount.setAccountUseType(Constants.ACCOUNTUSECODE_EXPENSE);
                } else {
                    customerAccount.setAccountUseType(Constants.ACCOUNTUSECODE_UNKNOWN);
                }
                if (null != customerAccountsResponse.getAppnId()) {
                    if (customerAccountsResponse.getAppnId().equalsIgnoreCase(customerAccountKey.getConsumerId())) {
                        customerAccount.setCustomerRole("Primary Borrower");
                    } else if (customerAccountKey.getConsumerId().equalsIgnoreCase(
                            Constants.COBORROWER_CODE.concat(customerAccountsResponse.getAppnId()))) {
                        customerAccount.setCustomerRole("Co-Borrower");
                    }
                }

            }
        }
    }

    /**
     * Setting of CardDetails
     * 
     * @param customerAccountsResponse Response of Customers Accounts
     * @param customerAccount Customer Account
     */

    public void setCardDetails(CustomerAccountsResponse customerAccountsResponse, CustomerAccount customerAccount) {
        if (customerAccountsResponse.getSorId() != null
                && customerAccountsResponse.getSorId().equalsIgnoreCase(
                        String.valueOf(Constants.CREDIT_CARD_SORID.toString()))) {
            customerAccount.setMarketingReferneceNumber(customerAccountsResponse.getMarketingReferneceNumber());
            customerAccount.setIsHighAvailabilityEnabled(customerAccountsResponse.getIsHighAvailabilityEnabled());
            customerAccount.setValidAsOfTimestamp(customerAccountsResponse.getValidAsOfTimestamp());
        }

        // if (customerAccountsResponse != null) {

        BigDecimal currentBalance = customerAccountsResponse.getCurrentBalance();
        setBalanceDetails(customerAccountsResponse, customerAccount, currentBalance);
        BigDecimal paymentDueAmount = customerAccountsResponse.getPaymentDueAmount();
        if (paymentDueAmount != null) {
            // customerAccount.setPaymentDueAmount(conversionService.convert(customerAccountsResponse.getPaymentDueAmount(),
            // Money.class));
            customerAccount.setPaymentDueAmount(paymentDueAmount);
        }
        customerAccount.setPaymentDueDate(customerAccountsResponse.getPaymentDueDate());
        customerAccount.setCardFirstSix(customerAccountsResponse.getCardFirstSix());
        // }
    }

    private void setBalanceDetails(CustomerAccountsResponse customerAccountsResponse, CustomerAccount customerAccount,
            BigDecimal currentBalance) {
        if (currentBalance != null) {
            // customerAccount.setCurrentBalance(conversionService.convert(customerAccountsResponse.getCurrentBalance(),
            // Money.class));
            customerAccount.setCurrentBalance(currentBalance);
        }
        BigDecimal availableBalance = customerAccountsResponse.getAvailableBalance();
        if (availableBalance != null) {
            // customerAccount.setAvailableBalance(conversionService.convert(customerAccountsResponse.getAvailableBalance(),
            // Money.class));
            customerAccount.setAvailableBalance(availableBalance);
        }
        BigDecimal principalBalance = customerAccountsResponse.getPrincipalBalance();
        if (principalBalance != null) {
            // customerAccount.setCurrentPrincipal(conversionService.convert(customerAccountsResponse.getPrincipalBalance(),
            // Money.class));
            customerAccount.setCurrentPrincipal(principalBalance);
        }
        BigDecimal currentPrincipal = customerAccountsResponse.getCurrentPrincipal();
        if (currentPrincipal != null) {
            // customerAccount.setCurrentPrincipal(conversionService.convert(customerAccountsResponse.getPrincipalBalance(),
            // Money.class));
            customerAccount.setCurrentPrincipal(currentPrincipal);
        }
        BigDecimal presentBalance = customerAccountsResponse.getPresentBalance();
        if (presentBalance != null) {
            // customerAccount.setPresentBalance(conversionService.convert(customerAccountsResponse.getPresentBalance(),
            // Money.class));
            customerAccount.setPresentBalance(presentBalance);
        }
    }

    public void setCustomerAccountsRefDataBean(CustomerAccountsRefDataBean customerAccountsRefDataBean) {
        this.customerAccountsRefDataBean = customerAccountsRefDataBean;
    }

    /**
     * Parsing AdditionalStatus To ApiException
     * 
     * @param additionalStatList Additional Status List
     * @return Api Error Code
     */

    public static CustomerApiErrorCode parseAdditionalStatusToApiException(List<AdditionalStat> additionalStatList) {

        if (additionalStatList != null) {
            CustomerApiErrorCode apiAdditionalStatList = new CustomerApiErrorCode();
            apiAdditionalStatList.setMessageParms(null);
            for (AdditionalStat addnStat : additionalStatList) {
                ApiErrorCode errorCode = new ApiErrorCode();
                String devTextID = addnStat.getNativeErrorCd() != null ? addnStat.getNativeErrorCd() : addnStat
                        .getSrvrStatCd();
                String devTextIDString = (String) (devTextID != null ? devTextID
                        : (addnStat.getStatCd() != null ? addnStat.getStatCd().toString() : ""));
                errorCode.setDeveloperTextId(devTextIDString);
                errorCode.setDeveloperText(maskNPI(addnStat.getStatDesc()));
                errorCode.setErrorDetails(null);
                errorCode.setMessageParms(null);
                errorCode.setId(null);
                apiAdditionalStatList.getErrorDetails().add(errorCode);
            }
            return apiAdditionalStatList;
        }
        return null;
    }

    /**
     * Mask NPI Data
     * 
     * @param devText Developer text
     * @return Masked Account Number
     */

    public static String maskNPI(String devText) {

        String trnDescMasked = devText;

        Pattern pattern10 = Pattern.compile("(\\d{17}|\\d{16}|\\d{15}|\\d{14}|\\d{13}|\\d{12}|\\d{11}|\\d{10})");
        if (devText != null) {
            Matcher matcher = pattern10.matcher(devText);
            if (matcher.find()) {
                trnDescMasked = devText.replace(devText.substring(matcher.start(), matcher.end()),
                        Constants.ACCOUNT_MASK_10 + devText.substring(matcher.end() - 4, matcher.end()));
            }

        }

        if (devText != null) {
            String pattern = "(, SOR_ID)(.+?)(\\d{3}|\\d{2}|\\d{1})";
            Pattern pattern2 = Pattern.compile(pattern);
            Matcher matcher = pattern2.matcher(devText);
            if (matcher.find()) {
                trnDescMasked = devText.replace(devText.substring(matcher.start(), matcher.end()), "");
            }
        }
        return trnDescMasked;
    }

    /**
     * Setting header param
     * 
     * @return header type
     */

    public static HdrType createSoapHdr() {
        HdrType hdr = new HdrType();
        hdr.setSrcLgclId("RTM");
        hdr.setCretTS(new Instant());
        hdr.setMsgId(String.valueOf(System.currentTimeMillis()));
        hdr.setVers(1.0f);
        return hdr;
    }

    /**
     * Converts a date represented by a XMLGregorianCalendar or Instant to an Instant object without timezone.
     * 
     * @param date Date Object
     * @return Date to Instant Time Zone
     */
    public Instant convertDateToInstantNoTimezone(Instant date) {
        if (date != null) {
            // return DateTimeFormat.forPattern("yyyy-MM-dd").parseDateTime(date.toString()).toInstant();
            return new DateTime(date.get(year()), date.get(monthOfYear()), date.get(dayOfMonth()), 0, 0,
                    DateTimeZone.UTC).toInstant();
        }
        return null;
    }

    /**
     * Convert a local date to ZULU time zone as YYYY-MM-DDT04:00:00.000Z
     * 
     * @param date Date Object
     * @return Convert date to Instant
     */

    public Instant convertLocalDateToInstant(LocalDate date) {
        // return localDate != null ? new Instant(localDate.toDateTimeAtStartOfDay()) : null;
        return new DateTime(date.get(year()), date.get(monthOfYear()), date.get(dayOfMonth()), 16, 0, DateTimeZone.UTC)
                .toInstant();
    }

    public <T> List<List<T>> split(List<T> list, final int splitSize) {
        List<List<T>> parts = new ArrayList<List<T>>();
        int masterListSize = list.size();
        for (int i = 0; i < masterListSize; i += splitSize) {
            parts.add(new ArrayList<T>(list.subList(i, Math.min(masterListSize, i + splitSize))));

        }

        return parts;

    }

    public Boolean findSORID(CustomerAccountsRequest list, final int sorid) {
        for (final CustomerAccountKey key : list.getCustomerAccountKeyList()) {
            if (key.getSorId().equals((short) sorid)) {
                return true;
            }
        }

        return false;
    }

    public Boolean findSORIDList(CustomerAccountsRequest list, List<Short> listSorid) {
        for (final CustomerAccountKey key : list.getCustomerAccountKeyList()) {
            if (listSorid.contains(key.getSorId())) {
                return true;
            }
        }

        return false;
    }

    public REASResponse merge(REASResponse finalREASResponse, REASResponse reasResponses) {
        REASResponse response = finalREASResponse;

        if (finalREASResponse.getCustomerAccountsResponseList() == null
                && reasResponses.getCustomerAccountsResponseList() != null) {
            response.setCustomerAccountsResponseList(reasResponses.getCustomerAccountsResponseList());
        } else if (finalREASResponse.getCustomerAccountsResponseList() != null
                && reasResponses.getCustomerAccountsResponseList() != null) {
            response.getCustomerAccountsResponseList().addAll(reasResponses.getCustomerAccountsResponseList());
        }
        if (finalREASResponse.getAddStatList() == null && reasResponses.getAddStatList() != null) {
            response.setAddStatList(reasResponses.getAddStatList());
        } else if (finalREASResponse.getAddStatList() != null && reasResponses.getAddStatList() != null) {
            response.getAddStatList().addAll(reasResponses.getAddStatList());
        }
        return response;
    }

    public List<AdditionalStat> addnStatConverter(List<AddnStat> addnStatList, int responsecode) {

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();

        for (AddnStat addnStat : addnStatList) {
            AdditionalStat additionalStat = new AdditionalStat();
            if (null != addnStat.getNativeErrorCd()) {
                additionalStat.setNativeErrorCd(addnStat.getNativeErrorCd());
            }
            if (null != addnStat.getSrvrStatCd()) {
                additionalStat.setSrvrStatCd(addnStat.getSrvrStatCd());
            }
            if (null != addnStat.getStatCd()) {
                additionalStat.setStatCd(addnStat.getStatCd());
            }
            if (null != addnStat.getStatDesc()) {
                additionalStat.setStatDesc(addnStat.getStatDesc());
            }
            additionalStat.setHttpStatus(responsecode);
            if (null != addnStat.getSevrty()) {
                switch (addnStat.getSevrty()) {
                    case WARNING:
                        additionalStat.setSevrty(SevrtyType.WARNING);
                        break;
                    case ERROR:
                        additionalStat.setSevrty(SevrtyType.ERROR);
                        break;
                    case INFO:
                        additionalStat.setSevrty(SevrtyType.INFO);
                        break;
                    default:
                        break;

                }
            }
            additionalStatList.add(additionalStat);

        }

        return additionalStatList;

    }

    public void setCustomerAPIRESTException(CustomerAccountKey customerAccountKey, AdditionalStat addnStatFail,
            Exception e) {
        CustomerAPIRESTException errorResponse = (CustomerAPIRESTException) e.getCause();
        if (errorResponse.getErrorResponse() != null && !StringUtils.isBlank(errorResponse.getErrorResponse().getId())) {
            addnStatFail.setNativeErrorCd(errorResponse.getErrorResponse().getId());
        }
        if (!errorResponse.getErrorResponse().getDeveloperText().isEmpty()) {
            addnStatFail.setStatDesc(errorResponse
                    .getErrorResponse()
                    .getDeveloperText()
                    .concat(CustomerAccountsUtil.constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(),
                            customerAccountKey.getSorId())));
        } else {
            addnStatFail.setStatDesc(errorResponse
                    .getErrorResponse()
                    .getText()
                    .concat(CustomerAccountsUtil.constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(),
                            customerAccountKey.getSorId())));
        }
        if (errorResponse.getHttpStatus() != null) {
            addnStatFail.setHttpStatus(errorResponse.getHttpStatus());
        }
        if (errorResponse.getErrorResponse().getId() != null) {
            addnStatFail.setNativeErrorCd(errorResponse.getErrorResponse().getId());
        }
        addnStatFail.setAccountId(CustomerAccountsUtil.maskNPI(customerAccountKey.getAccountNumber()));
    }

    public List<AdditionalStat> getAdditionalStat(StatType responseStatus, CustomerAccountKey customerAccountKey) {

        if (responseStatus == null) {
            return null;
        }
        // I am assuming we will never exceed int range for stat codes
        if (Long.valueOf(responseStatus.getStatCd()) != null) {
            int intStatCode = (int) (responseStatus.getStatCd());
            if (responseStatus.getSevrty() != null) {
                switch (responseStatus.getSevrty()) {
                    case ERROR:
                        if (Constants.SERVER_STAT_CODE_TP2006.equalsIgnoreCase(responseStatus.getSrvrStatCd())) {
                            return addnStatConverter(responseStatus.getAddnStat(), Constants.ERROR_CODE_400);
                        } else {
                            return getAddnStatCaseError(responseStatus, intStatCode, customerAccountKey);
                        }
                    default:
                        return null;

                }
            }
        }
        return null;
    }

    public List<AdditionalStat> getAddnStatCaseError(StatType responseStatus, int intStatCode,
            CustomerAccountKey customerAccountKey) {
        if (Constants.XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.contains(String.valueOf(intStatCode))) {

            return addnStatConverter(responseStatus.getAddnStat(), Constants.INTERNAL_SERVER_ERROR_CODE);

        } else {
            List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
            AdditionalStat additionalStat = new AdditionalStat();
            additionalStat.setNativeErrorCd(String.valueOf(responseStatus.getStatCd()));
            additionalStat.setStatDesc(responseStatus.getStatDesc().concat(
                    CustomerAccountsUtil.constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(),
                            customerAccountKey.getSorId())));
            additionalStatList.add(additionalStat);
            return additionalStatList;
        }
    }

    public static String constructAcctSorIDnotfound(String accoutnumber, Short sorID) {
        return " [".concat(Constants.ACCOUNT_NUMBER_STRING).concat(maskNPI(accoutnumber)).concat(", ")
                .concat(Constants.SORID_STRING).concat(sorID.toString().concat("]"));
    }

    /**
     * Getting Endpoint by passing restApiUrl(String)
     * 
     * @param restApiUrl Rest API end point
     * @return End Point Properties
     * 
     */

    public EndpointProperties getEndpointProperties(String restApiUrl) {

        return endpointManager.getWSProperties(StringUtils.EMPTY, restApiUrl, null);

    }

    public void setPartialStatus(REASResponse response, long statCd, List<CustomerAccountKey> customerAccountsRequest) {
        boolean isAccountPresent = false;
        if (response.getAddStatList() == null) {
            response.setAddStatList(new ArrayList<AdditionalStat>());
        }

        for (CustomerAccountKey key : customerAccountsRequest) {
            isAccountPresent = false;
            for (CustomerAccountsResponse customerAccountsResponse : response.getCustomerAccountsResponseList()) {
                if (StringUtils.stripStart(customerAccountsResponse.getAccountId(), "0").equalsIgnoreCase(
                        StringUtils.stripStart(key.getAccountNumber(), "0"))) {
                    isAccountPresent = true;
                    break;
                }
            }
            if (!isAccountPresent) {
                AdditionalStat additionalStat = new AdditionalStat();
                additionalStat.setNativeErrorCd(String.valueOf(statCd));
                additionalStat.setStatDesc(Constants.CARD_PARTIAL_SUCCESS_MSG_START.concat(CustomerAccountsUtil
                        .maskNPI(key.getAccountNumber()).concat(Constants.CARD_PARTIAL_SUCCESS_MSG_END)));
                response.getAddStatList().add(additionalStat);
            }
        }

    }

    public void generateCustomPerfLog(EPFContext context, long responseTime, String statCode, String severity,
            String statDesc, String serviceName, int httpstatus) {

        final Log perfLog = LogFactory.getLog(PERF_LOG);
        String messageId = context.getAttribute(EPF_X_MESSAGE_ID);
        String apiKey = context.getRequestHeader(API_KEY);
        StringBuffer sbf = new StringBuffer(500);
        sbf.append("Service:").append(serviceName).append("|Operation:NA|Version:1.0|Client:customers-accounts-")
                .append(apiKey).append("|ResponseTime:");
        sbf.append(responseTime);
        sbf.append("|Status:").append(statCode);
        sbf.append("|Severity:").append(severity);
        sbf.append("|HttpStatus:").append(httpstatus);
        sbf.append("|StatusDescription:").append(statDesc);
        sbf.append("|MessageID:").append(messageId);
        perfLog.info(sbf.toString());
    }

    @PostConstruct
    public CustomerAccountsRequest loadConfigDetails() {

        List<String> reasSupportedSorIds;
        List<String> enableModifiedSafeDepositBox;
        boolean enableModifiedREAS = false;
        boolean enableErrorHandlingSwitch = false;
        boolean enableOECPPreferenceSwitch = false;
        boolean enableSortByOpenDateSwitch = false;
        boolean enableOlbrAccountNicknameSwitch = false;
        boolean enableOECPSortOrderSwitch = false;
        List<String> enableXESDDAISCache;
        String enableappVersionV4;
        List<String> coiSwitch;
        boolean custInfoDLSSwitch = false;
        List<String> ccOnlineCachedConfigValue;
        List<String> ecrCachedConfig = null;
        boolean isSortOrderHystrixEnabled = false;
        boolean isAccountNickNameHystrixEnabled = false;

        reasSupportedSorIds = config.getList(Constants.REAS_SUPPORTED_SORID);
        enableModifiedREAS = config.getBoolean(Constants.BY_PASS_REAS);
        enableModifiedSafeDepositBox = config.getList(Constants.SAFE_DEPOSIT_BOX);
        enableErrorHandlingSwitch = config.getBoolean(Constants.ENABLE_ERROR_HANDLING);
        enableOECPPreferenceSwitch = config.getBoolean(Constants.ENABLE_OECP_CALL);
        enableSortByOpenDateSwitch = config.getBoolean(Constants.SORT_BY_OPEN_DATE);
        enableOlbrAccountNicknameSwitch = config.getBoolean(Constants.OLBR_ACCT_NICKNAME);
        enableOECPSortOrderSwitch = config.getBoolean(Constants.OECP_SORT_ORDER);
        enableappVersionV4 = config.getString(Constants.APP_VERSION);
        enableXESDDAISCache = config.getList(Constants.XESDDAIS_CACHE);
        coiSwitch = config.getList(Constants.COI_CALL);
        custInfoDLSSwitch = config.getBoolean(Constants.CUST_INFO_DLS_CALL);
        ccOnlineCachedConfigValue = config.getList(Constants.CCONLINESERVICINGDLS_VERSION_SWITCH);
        ecrCachedConfig = config.getList(Constants.ECR_CACHED_CONFIG);
        isAccountNickNameHystrixEnabled = config.getBoolean(Constants.ACCOUNT_NICKNAME_HYSTRIX_ENABLED);
        isSortOrderHystrixEnabled = config.getBoolean(Constants.SORT_ORDER_HYSTRIX_ENABLED);

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(enableModifiedREAS);
        customerAccountsRequest.setEnableModifiedSafeDepositBoxSwitch(enableModifiedSafeDepositBox);
        customerAccountsRequest.setEnableErrorHandlingSwitch(enableErrorHandlingSwitch);
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSorIds);
        customerAccountsRequest.setEnableOECPPreferenceSwitch(enableOECPPreferenceSwitch);
        customerAccountsRequest.setSortByOpenDate(enableSortByOpenDateSwitch);
        customerAccountsRequest.setEnableOlbrAccountNickname(enableOlbrAccountNicknameSwitch);
        customerAccountsRequest.setEnableOecpSortOrder(enableOECPSortOrderSwitch);
        customerAccountsRequest.setEnableappVersionV4(enableappVersionV4);
        customerAccountsRequest.setCoiSwitch(coiSwitch);
        customerAccountsRequest.setEnableXESDDAISCache(enableXESDDAISCache);
        customerAccountsRequest.setCustInfoDlsSwitch(custInfoDLSSwitch);
        customerAccountsRequest.setCcOnlineCachedConfig(ccOnlineCachedConfigValue);
        customerAccountsRequest.setEcrCachedConfig(ecrCachedConfig);
        customerAccountsRequest.setAccountNickNameHystrixEnabled(isAccountNickNameHystrixEnabled);
        customerAccountsRequest.setSortOrderHystrixEnabled(isSortOrderHystrixEnabled);
        return customerAccountsRequest;
    }

    public CustomerAccountsRequest getIntProfileSwithDetails(CustomerAccountsRequest customerAccountsRequest) {

        List<String> intProfileSupportedVersion;
        String apiKey = EPFContextContainer.getContext().getRequestHeader(API_KEY);
        intProfileSupportedVersion = config.getList(Constants.INT_PROFILE_VERSION);

        if (intProfileSupportedVersion.contains(customerAccountsRequest.getAppVersion())) {
            customerAccountsRequest.setApi360AllowedClient(true);
            customerAccountsRequest.setIs360ApiKeyPresent(true);
            return customerAccountsRequest;
        } else {
            Boolean is360ApiKeyPresent = Boolean.TRUE;
            Map<String, Boolean> map360Clients = (customerAccountsRefDataBean.getApiKeySupportedFor360(apiKey,
                    is360ApiKeyPresent));
            customerAccountsRequest.setApi360AllowedClient(map360Clients.get(Constants.API360_ALLOWED_CLIENT));

            customerAccountsRequest.setIs360ApiKeyPresent(map360Clients.get(Constants.IS360_API_KEY_PRESENT));
        }

        return customerAccountsRequest;
    }
}