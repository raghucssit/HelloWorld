package com.capitalone.api.customersaccounts.service.pojo;

import java.io.Serializable;

public class OLBAttributes  implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String ceSegmentationCd;

    private String oFXAcctCatgyDesc;

    private String prodNm;

    private Boolean checkCopyRqstAllwdInd;

    private Boolean checkImgAllwdInd;

    private Boolean checkReorderAllwdInd;

    private Boolean fundsTrnsfrDstntnAcctInd;

    private Boolean fundsTrnsfrSrcAcctInd;

    private Boolean ovrdrftOptInElgblAcctInd;

    private Boolean pprLssStmtElgblAcctInd;

    private Boolean rwrdsElgblAcctInd;

    private Boolean stmtCopyRqstAllwdInd;

    private Boolean stopPmtRqstAllwdInd;

    private Boolean rDCEligibleInd;

    private Boolean billPayAllwdInd;

    public String getCeSegmentationCd() {
        return ceSegmentationCd;
    }

    public void setCeSegmentationCd(String ceSegmentationCd) {
        this.ceSegmentationCd = ceSegmentationCd;
    }

    public String getoFXAcctCatgyDesc() {
        return oFXAcctCatgyDesc;
    }

    public void setoFXAcctCatgyDesc(String oFXAcctCatgyDesc) {
        this.oFXAcctCatgyDesc = oFXAcctCatgyDesc;
    }

    public String getProdNm() {
        return prodNm;
    }

    public void setProdNm(String prodNm) {
        this.prodNm = prodNm;
    }

    public Boolean getCheckCopyRqstAllwdInd() {
        return checkCopyRqstAllwdInd;
    }

    public void setCheckCopyRqstAllwdInd(Boolean checkCopyRqstAllwdInd) {
        this.checkCopyRqstAllwdInd = checkCopyRqstAllwdInd;
    }

    public Boolean getCheckImgAllwdInd() {
        return checkImgAllwdInd;
    }

    public void setCheckImgAllwdInd(Boolean checkImgAllwdInd) {
        this.checkImgAllwdInd = checkImgAllwdInd;
    }

    public Boolean getCheckReorderAllwdInd() {
        return checkReorderAllwdInd;
    }

    public void setCheckReorderAllwdInd(Boolean checkReorderAllwdInd) {
        this.checkReorderAllwdInd = checkReorderAllwdInd;
    }

    public Boolean getFundsTrnsfrDstntnAcctInd() {
        return fundsTrnsfrDstntnAcctInd;
    }

    public void setFundsTrnsfrDstntnAcctInd(Boolean fundsTrnsfrDstntnAcctInd) {
        this.fundsTrnsfrDstntnAcctInd = fundsTrnsfrDstntnAcctInd;
    }

    public Boolean getFundsTrnsfrSrcAcctInd() {
        return fundsTrnsfrSrcAcctInd;
    }

    public void setFundsTrnsfrSrcAcctInd(Boolean fundsTrnsfrSrcAcctInd) {
        this.fundsTrnsfrSrcAcctInd = fundsTrnsfrSrcAcctInd;
    }

    public Boolean getOvrdrftOptInElgblAcctInd() {
        return ovrdrftOptInElgblAcctInd;
    }

    public void setOvrdrftOptInElgblAcctInd(Boolean ovrdrftOptInElgblAcctInd) {
        this.ovrdrftOptInElgblAcctInd = ovrdrftOptInElgblAcctInd;
    }

    public Boolean getPprLssStmtElgblAcctInd() {
        return pprLssStmtElgblAcctInd;
    }

    public void setPprLssStmtElgblAcctInd(Boolean pprLssStmtElgblAcctInd) {
        this.pprLssStmtElgblAcctInd = pprLssStmtElgblAcctInd;
    }

    public Boolean getRwrdsElgblAcctInd() {
        return rwrdsElgblAcctInd;
    }

    public void setRwrdsElgblAcctInd(Boolean rwrdsElgblAcctInd) {
        this.rwrdsElgblAcctInd = rwrdsElgblAcctInd;
    }

    public Boolean getStmtCopyRqstAllwdInd() {
        return stmtCopyRqstAllwdInd;
    }

    public void setStmtCopyRqstAllwdInd(Boolean stmtCopyRqstAllwdInd) {
        this.stmtCopyRqstAllwdInd = stmtCopyRqstAllwdInd;
    }

    public Boolean getStopPmtRqstAllwdInd() {
        return stopPmtRqstAllwdInd;
    }

    public void setStopPmtRqstAllwdInd(Boolean stopPmtRqstAllwdInd) {
        this.stopPmtRqstAllwdInd = stopPmtRqstAllwdInd;
    }

    public Boolean getrDCEligibleInd() {
        return rDCEligibleInd;
    }

    public void setrDCEligibleInd(Boolean rDCEligibleInd) {
        this.rDCEligibleInd = rDCEligibleInd;
    }

    public Boolean getBillPayAllwdInd() {
        return billPayAllwdInd;
    }

    public void setBillPayAllwdInd(Boolean billPayAllwdInd) {
        this.billPayAllwdInd = billPayAllwdInd;
    }

}
