/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.convert.response;

import javax.inject.Named;

import org.apache.commons.lang.StringUtils;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails;

/**
 * This class is the response Converter for ECRCustomerRelationshipIS
 * 
 */

@Profile
@Trace
@Named
public class ECRCustomerRelationshipISResponseConverter extends
        ConversionServiceAwareConverter<AcctDetails, CustomerAccountKey> {

    /**
     * Converts ECR acctDetails to CustomerAccountKey type
     * 
     * @param acctDetails list of accounts
     * @return customers accounts list
     */


    @Override
    public CustomerAccountKey convert(AcctDetails acctDetails) {

        logger.debug("ECRCustomerRelationshipISResponseConverter  : convert -> Start");
        CustomerAccountKey customerAccountKey = null;
        if (acctDetails != null) {
            customerAccountKey = new CustomerAccountKey();
            customerAccountKey.setConsumerId(acctDetails.getSORCnsmrID());            
            customerAccountKey.setSorId(acctDetails.getSoRID());
            if(Constants.CREDIT_CARD_SORID.equals(acctDetails.getSoRID())){
            	customerAccountKey.setAccountNumber(StringUtils.leftPad(acctDetails.getApplctnAcctID(), 11, "0"));
            }else{
            	customerAccountKey.setAccountNumber(acctDetails.getApplctnAcctID());
            }
            customerAccountKey.setAccountUseType(acctDetails.getAcctUseCd());
        }
        logger.debug("ECRCustomerRelationshipISResponseConverter  : convert -> End");
        return customerAccountKey;
    }
}