package com.capitalone.api.customersaccounts.service.convert.response;

import javax.annotation.Resource;
import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xesloanacctis.v1.AcctInqISRs;

@Profile
@Trace
@Named
public class XESLoanAcctISResponseConverter extends
        ConversionServiceAwareConverter<AcctInqISRs, CustomerAccountsResponse> {

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;
    /**
     * Converts native response of XESLoanAcctIS to customer account Response type
     * 
     * @param nativeResponse response of XESLoanAcctIS
     * @return retails accounts response
     */
    @Override
    public CustomerAccountsResponse convert(AcctInqISRs nativeResponse) {
        logger.debug("Entry - convert method of XESLoanAcctISResponseConverter class");
        CustomerAccountsResponse response = null;

        if (nativeResponse != null && nativeResponse.getCmd() != null
                && nativeResponse.getCmd().getLoanAcctInfo() != null) {
            response = new CustomerAccountsResponse();
            if (nativeResponse.getCmd().getLoanAcctInfo().getProdID() != null) {
                response.setProductId(nativeResponse.getCmd().getLoanAcctInfo().getProdID());
            }
            if (nativeResponse.getCmd().getLoanAcctInfo().getProdDesc() != null) {
                response.setProductName(nativeResponse.getCmd().getLoanAcctInfo().getProdDesc());
            }
            setLoanAcctInfo(nativeResponse, response);

        }
        logger.debug("Exit - convert method of XESLoanAcctISResponseConverter class {}", response);
        return response;
    }

    private void setLoanAcctInfo(AcctInqISRs nativeResponse, CustomerAccountsResponse response) {
        logger.debug("Enter - setLoanAcctInfo method of XESLoanAcctISResponseConverter class {}", response);
        setLoanAcctBalancesInfo(nativeResponse, response);

        if (nativeResponse.getCmd().getLoanAcctInfo().getAcctID() != null) {
            response.setAccountNumber(nativeResponse.getCmd().getLoanAcctInfo().getAcctID());
            response.setDisplayAccountNumber(nativeResponse.getCmd().getLoanAcctInfo().getAcctID());
            response.setAccountId(nativeResponse.getCmd().getLoanAcctInfo().getAcctID());
        }

        if (nativeResponse.getCmd().getLoanAcctInfo().getBankNum() != null) {
            response.setBankNumber(nativeResponse.getCmd().getLoanAcctInfo().getBankNum());
            response.setBankNumberDescription(customerAccountsRefDataBean.getBankNumberDescription(nativeResponse
                    .getCmd().getLoanAcctInfo().getBankNum()));
        }
        if (nativeResponse.getCmd().getLoanAcctInfo().getBankAcctStatusDesc() != null) {
            response.setAccountStatusDescription(nativeResponse.getCmd().getLoanAcctInfo().getBankAcctStatusDesc());
        }
        if (nativeResponse.getCmd().getLoanAcctInfo().getOpenDt() != null) {
            response.setOpenDate(nativeResponse.getCmd().getLoanAcctInfo().getOpenDt());
        }

        if (nativeResponse.getCmd().getLoanAcctInfo().getNextPaymentDt() != null) {
            response.setPaymentDueDate(nativeResponse.getCmd().getLoanAcctInfo().getNextPaymentDt());
        }
        if (nativeResponse.getCmd().getLoanAcctInfo().getClosedDate() != null) {
            response.setClosedDate(nativeResponse.getCmd().getLoanAcctInfo().getClosedDate());
        }
        response.setCurrencyCode(Constants.CURRENCY_CODE_USA);
        logger.debug("Exit - setLoanAcctInfo method of XESLoanAcctISResponseConverter class {}", response);
    }

    private void setLoanAcctBalancesInfo(AcctInqISRs nativeResponse, CustomerAccountsResponse response) {
        logger.debug("Enter - setLoanAcctBalancesInfo method of XESLoanAcctISResponseConverter class {}", response);
        if (nativeResponse.getCmd().getLoanAcctInfo().getLoanAcctBalancesInfo().getCurrentBal() != null) {
            response.setCurrentBalance(nativeResponse.getCmd().getLoanAcctInfo().getLoanAcctBalancesInfo()
                    .getCurrentBal());
        }
        if (nativeResponse.getCmd().getLoanAcctInfo().getLoanAcctBalancesInfo().getAvailableBal() != null) {
            response.setAvailableBalance(nativeResponse.getCmd().getLoanAcctInfo().getLoanAcctBalancesInfo()
                    .getAvailableBal());
        }
        if (nativeResponse.getCmd().getLoanAcctInfo().getLoanAcctBalancesInfo().getPrinBal() != null) {
            response.setPrincipalBalance(nativeResponse.getCmd().getLoanAcctInfo().getLoanAcctBalancesInfo()
                    .getPrinBal());
        }
        if (nativeResponse.getCmd().getLoanAcctInfo().getLoanAcctBalancesInfo().getNextPaymentAmt() != null) {
            response.setPaymentDueAmount(nativeResponse.getCmd().getLoanAcctInfo().getLoanAcctBalancesInfo()
                    .getNextPaymentAmt());
        }
        logger.debug("Exit - setLoanAcctBalancesInfo method of XESLoanAcctISResponseConverter class {}", response);
    }
}