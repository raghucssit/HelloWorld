package com.capitalone.api.customersaccounts.service.pojo;

public class AdditionalStat {

    private Long statCd;

    private String srvrStatCd;

    private SevrtyType sevrty;

    private String statDesc;

    private String nativeErrorCd;

    private String accountId;

    private String sorId;

    private Integer httpStatus;

    public Integer getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(Integer httpStatus) {
        this.httpStatus = httpStatus;
    }

    public Long getStatCd() {
        return statCd;
    }

    public void setStatCd(Long statCd) {
        this.statCd = statCd;
    }

    public String getSrvrStatCd() {
        return srvrStatCd;
    }

    public void setSrvrStatCd(String srvrStatCd) {
        this.srvrStatCd = srvrStatCd;
    }

    public SevrtyType getSevrty() {
        return sevrty;
    }

    public void setSevrty(SevrtyType sevrty) {
        this.sevrty = sevrty;
    }

    public String getStatDesc() {
        return statDesc;
    }

    public void setStatDesc(String statDesc) {
        this.statDesc = statDesc;
    }

    public String getNativeErrorCd() {
        return nativeErrorCd;
    }

    public void setNativeErrorCd(String nativeErrorCd) {
        this.nativeErrorCd = nativeErrorCd;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
