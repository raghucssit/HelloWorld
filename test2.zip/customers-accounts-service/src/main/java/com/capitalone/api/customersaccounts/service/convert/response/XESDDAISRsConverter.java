package com.capitalone.api.customersaccounts.service.convert.response;

import javax.annotation.Resource;
import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xesddais.v1.AcctInqISRs;

@Profile
@Trace
@Named
public class XESDDAISRsConverter extends ConversionServiceAwareConverter<AcctInqISRs, CustomerAccountsResponse> {

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    /**
     * Converts native response of XESDDAIS to customer account Response type
     * 
     * @param nativeResponse response of XESDDAIS
     * @return retails accounts response
     */
    @Override
    public CustomerAccountsResponse convert(AcctInqISRs nativeResponse) {
        logger.debug("Enter - convert method of XESDDAISRsConverter class");
        CustomerAccountsResponse response = null;
        if (nativeResponse != null && nativeResponse.getCmd() != null
                && nativeResponse.getCmd().getDemandDepositAcctInfo() != null) {
            response = new CustomerAccountsResponse();
            if (nativeResponse.getCmd().getDemandDepositAcctInfo().getProdID() != null) {
                response.setProductId(nativeResponse.getCmd().getDemandDepositAcctInfo().getProdID());
            }
           

            if (nativeResponse.getCmd().getDemandDepositAcctInfo().getProdDesc() != null) {
                response.setProductName(nativeResponse.getCmd().getDemandDepositAcctInfo().getProdDesc());
            }
            

            response.setRetirementIndicator(Boolean.FALSE);
            setDemandDepositeAcctInfo(nativeResponse, response);
        }
        logger.debug("Exit - convert method of XESDDAISRsConverter class");
        return response;
    }

    private void setDemandDepositeAcctInfo(AcctInqISRs nativeResponse, CustomerAccountsResponse response) {
        logger.debug("Enter - setDemandDepositeAcctInfo method of XESDDAISRsConverter class");
        if (nativeResponse.getCmd().getDemandDepositAcctInfo().getDemandDepAcctBalancesInfo().getCapOneCurrentBal() != null) {
            response.setCurrentBalance(nativeResponse.getCmd().getDemandDepositAcctInfo()
                    .getDemandDepAcctBalancesInfo().getCapOneCurrentBal());
        }

        if (nativeResponse.getCmd().getDemandDepositAcctInfo().getDemandDepAcctBalancesInfo().getAvailableBal() != null) {
            response.setAvailableBalance(nativeResponse.getCmd().getDemandDepositAcctInfo()
                    .getDemandDepAcctBalancesInfo().getAvailableBal());
        }
        if (nativeResponse.getCmd().getDemandDepositAcctInfo().getAcctID() != null) {
            response.setAccountNumber(nativeResponse.getCmd().getDemandDepositAcctInfo().getAcctID());
            response.setDisplayAccountNumber(nativeResponse.getCmd().getDemandDepositAcctInfo().getAcctID());
            response.setAccountId(nativeResponse.getCmd().getDemandDepositAcctInfo().getAcctID());
        }

        if (nativeResponse.getCmd().getDemandDepositAcctInfo().getBankNum() != null) {
            response.setBankNumber(nativeResponse.getCmd().getDemandDepositAcctInfo().getBankNum());
            response.setBankNumberDescription(customerAccountsRefDataBean.getBankNumberDescription(nativeResponse
                    .getCmd().getDemandDepositAcctInfo().getBankNum()));
        }
        if (nativeResponse.getCmd().getDemandDepositAcctInfo().getBankAcctStatusDesc() != null) {
            response.setAccountStatusDescription(nativeResponse.getCmd().getDemandDepositAcctInfo()
                    .getBankAcctStatusDesc());
        }
        if (nativeResponse.getCmd().getDemandDepositAcctInfo().getOpenDt() != null) {
            response.setOpenDate(nativeResponse.getCmd().getDemandDepositAcctInfo().getOpenDt());
        }
        if (nativeResponse.getCmd().getDemandDepositAcctInfo().getClosedDate() != null) {
            response.setClosedDate(nativeResponse.getCmd().getDemandDepositAcctInfo().getClosedDate());
        }
        response.setCurrencyCode(Constants.CURRENCY_CODE_USA);
        logger.debug("Exit - setDemandDepositeAcctInfo method of XESDDAISRsConverter class");
    }

}
