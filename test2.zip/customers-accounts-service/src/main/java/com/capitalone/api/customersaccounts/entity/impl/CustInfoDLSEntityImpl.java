package com.capitalone.api.customersaccounts.entity.impl;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.cache.annotation.Cacheable;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.entity.CustInfoDLSEntity;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRq;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs;
import com.capitalone.customerinformationdls.v1.CustomerInformationDLSSoap;

@Profile
@Trace
@Named
public class CustInfoDLSEntityImpl implements CustInfoDLSEntity {

    @Inject
    private CustomerInformationDLSSoap customerInformationDLSSoap;

    /**
     * Getting Account details linked to the SSOID
     * 
     * @param custIdentityMatchedAccountsInqRq holds the request
     * @param userId holds the user Id
     * @return list of accounts related to the SSOID
     * 
     */
    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    @Cacheable(value = "eapi-mediumterm-customerInformationEntity-customerInformationInq", key = "#userId")
    public CustInfoDLSInqRs retiveAccountDetails(CustInfoDLSInqRq custInfoDLSInqRq, String userId) throws Exception {

        return customerInformationDLSSoap.customerInformationInq(custInfoDLSInqRq);

    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
