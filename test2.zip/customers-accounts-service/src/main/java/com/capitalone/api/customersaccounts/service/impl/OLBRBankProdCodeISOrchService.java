package com.capitalone.api.customersaccounts.service.impl;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.dao.OLBRBankProdCodeISDAO;
import com.capitalone.api.customersaccounts.service.pojo.OLBRRefData;

@Profile
@Trace
@Named
public class OLBRBankProdCodeISOrchService {

    @Inject
    private OLBRBankProdCodeISDAO olbrBankProdCodeISDAO;

    public List<OLBRRefData> execute() {

        return getProductName();
    }

    public List<OLBRRefData> getProdRefData()  {

        List<OLBRRefData> impl = olbrBankProdCodeISDAO.getProductInfo();

        return impl;
    }

    public List<OLBRRefData> getProductName() {
       
            return getProdRefData();
        
    }
}
