package com.capitalone.api.customersaccounts.entity;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.loans.homeloans.accounts.model.v3.Account;
import com.capitalone.epf.context.model.EPFContext;

public interface LoansHomeLoansEntity {
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    Account retiveAccountDetails(CustomerAccountKey customerAccountKey,
            EPFContext epfContext, String accountNumber,String sorId) throws Exception;

}
