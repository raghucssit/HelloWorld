/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;

import com.capitalone.api.commons.model.referencedata.ReferenceDataEntity;
import com.capitalone.api.commons.services.referencedata.ReferenceDataCategoryService;
import com.capitalone.api.commons.services.referencedata.ReferenceDataService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;

@Named
public class CustomerAccountsRefDataBean {

    private static final String SWITCH = "Switch";

    private static final String csvAccountCategories = "AccountCategories";

    private static final String csvProductTypeCodeRetail = "ProductTypeCodeRetail";

    private static final String csvAcctCategory = "AcctCategory";

    private static final String csvBankRefData = "BankRefData";

    private static final String csvCustAcctRelationshipDesc360 = "CustAcctRelationshipDesc360";

    private static final String csvCustAcctRelationshipDescAll = "CustAcctRelationshipDescAllV2";

    private static final String csvCustAcctRelationshipDescIm = "CustAcctRelationshipDescIMSTV2";

    private static final String csvProfileProductRefData = "ProfileProductTypes";

    private static final String csvSupportedEnterpriseAccounts = "SupportedEnterpriseAccounts";// 'AccountUse'

    private static final String csvRetailSORIDLookup = "RetailSORIDLookup";

    private static final String csvSorIdToBusinessLine = "SoRIDtoBusinessLine";

    private static final String csvSorIdToSorIdDetail = "SoRIDtoSoRDetail";

    private static final String csvSoRIDtoSoRProductType = "SoRIDtoSoRProductType";

    private static final String csvDefaultCustomerAccountSortOrder = "DefaultCustAcntSortOrdr";

    private static final String csvAllowableClient360 = "AllowedClientsto360API";

    private static final String Splitter = "\\|";

    @Inject
    private ReferenceDataService<String> referenceDataService;

    @Inject
    private ReferenceDataCategoryService<String> refernceDataCategoryService;

    @Inject
    private ReferenceDataCategoryService<OLBAttributes> olbRefernceDataCategoryService;

    public Map<String, Map<String, OLBAttributes>> getRetailProductDescriptionOLBR() {
        List<ReferenceDataEntity<OLBAttributes>> entityList = null;
        Map<String, Map<String, OLBAttributes>> map = new HashMap<String, Map<String, OLBAttributes>>();
        entityList = olbRefernceDataCategoryService.getCategory("RetailProdDesRefData", 1).getEntities();
        for (ReferenceDataEntity<OLBAttributes> dataEntity : entityList) {
            map.put(dataEntity.getEntityName(), dataEntity.getAttributeMap());
        }
        return map;
    }

    /**
     * @param productTypeCode Account Product Type code
     * @return Account Type
     * 
     *         This method returns Account Type like CHECKING, SAVING etc from Reference data based on ProductType.
     * 
     *         There is no reference data for BROKERAGE accounts, therefore this method will return "NOT AVAILABLE"
     * 
     *         360 accounts do not have FeatureType available.
     */

    public String getProductTypeDescription(String productTypeCode) {

        Map<String, String> entityMap = null;
        String productTypeDescription = Constants.NOT_AVAILABLE_CD;
        Map<String, String> entityFilterMap = new HashMap<String, String>();

        if (StringUtils.isNotBlank(productTypeCode)) {
            entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, productTypeCode.toUpperCase());

            ReferenceDataEntity<String> referenceDataEntity = referenceDataService.getEntity(csvAccountCategories, 1,
                    entityFilterMap);

            entityMap = referenceDataEntity.getAttributeMap();

            if (entityMap != null && !entityMap.isEmpty()) {
                productTypeDescription = entityMap.get(Constants.KEY_PROD_TYPE_DESC);
            }
        }
        return productTypeDescription;
    }

    /**
     * @param sorId SOR ID
     * @param bankAcctTypeCd Bank Account Type Code
     * @return Product Type code
     * 
     *         This method returns product Type code like SA DDA MMA CD LOC ILA from Reference data based on SORID and
     *         bankAcctTypeCd.
     * 
     * 
     */

    public String getProductTypeCode(Short sorId, String bankAcctTypeCd) {

        String productTypeCode = Constants.NOT_AVAILABLE_CD;

        if (StringUtils.isNotBlank(bankAcctTypeCd)) {
            String rawSoRIDs = null;
            List<ReferenceDataEntity<String>> entityList = referenceDataService.getEntities(csvProductTypeCodeRetail,
                    1, Constants.KEY_BANK_ACCT_TYPE_CD, bankAcctTypeCd);

            for (ReferenceDataEntity<String> entityInList : entityList) {
                Map<String, String> entityMap = entityInList.getAttributeMap();

                if (entityMap != null && !entityMap.isEmpty()) {
                    rawSoRIDs = entityMap.get(Constants.KEY_SORID);
                    productTypeCode = setRawSoRIDs(sorId, rawSoRIDs, entityMap);
                }
            }

        }

        return productTypeCode;
    }

    private String setRawSoRIDs(Short sorId, String rawSoRIDs, Map<String, String> entityMap) {
        String productTypeCode = Constants.NOT_AVAILABLE_CD;
        if (rawSoRIDs != null) {
            List<String> tempSoRIDList = Arrays.asList(rawSoRIDs.split(Splitter));
            if (tempSoRIDList.contains(String.valueOf(sorId))) {
                productTypeCode = entityMap.get(Constants.KEY_PROD_TYPE_CD);
            }

        }

        return productTypeCode;
    }

    /**
     * This method returns the list of Accounts Supported by this service.
     * 
     * @param accountsList Account List
     * @return List of Customer Accounts
     */

    public List<CustomerAccountKey> getSupportedAccountsList(List<CustomerAccountKey> accountsList) {
        Map<String, String> entityMap = null;
        List<CustomerAccountKey> supportedSORList = null;

        if (accountsList != null) {
            supportedSORList = new ArrayList<CustomerAccountKey>();
            for (CustomerAccountKey customerAccountKey : accountsList) {
                if (customerAccountKey.getSorId() != null) {
                    ReferenceDataEntity<String> referenceDataEntity = referenceDataService.getEntity(
                            csvSupportedEnterpriseAccounts, 1, Constants.KEY_SOR_ID, customerAccountKey.getSorId()
                                    .toString());

                    entityMap = referenceDataEntity.getAttributeMap();

                    prepareSupportedAccountList(entityMap, supportedSORList, customerAccountKey);
                }
            }
        }
        return supportedSORList;
    }

    private void prepareSupportedAccountList(Map<String, String> entityMap, List<CustomerAccountKey> supportedSORList,
            CustomerAccountKey customerAccountKey) {
        if (entityMap != null && !entityMap.isEmpty()) {
            supportedSORList.add(customerAccountKey);
        }
    }

    /**
     * This method returns Business Line given a SOR id. This method will return the data for only SOR's supported by
     * this service.
     * 
     * @param productType Product Type
     * @return Business Line
     */

    public String getBusinessLine(String productTypeCode, String sorID) {
        String businessLine = Constants.NOT_AVAILABLE_CD;
        List<String> tempSorIdList = null;
        if (StringUtils.isNotBlank(productTypeCode) && StringUtils.isNotBlank(sorID)) {

            Map<String, String> entityFilterMap = new HashMap<String, String>();
            entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, productTypeCode);
            List<ReferenceDataEntity<String>> referenceDataEntity = referenceDataService.getEntities(
                    csvAccountCategories, 1, Constants.KEY_PROD_TYPE_CD, productTypeCode);

            for (ReferenceDataEntity<String> entityInList : referenceDataEntity) {
                Map<String, String> entityMap = entityInList.getAttributeMap();

                if (entityMap != null && !entityMap.isEmpty()) {
                    String referenceSorId = entityMap.get(Constants.KEY_SOR_ID);
                    tempSorIdList = Arrays.asList(referenceSorId.split(Splitter));
                }
                if (tempSorIdList != null && tempSorIdList.contains(sorID)) {
                    return entityMap.get(Constants.KEY_BUSINESS_LINE);
                }

            }

        }

        return businessLine;
    }

    /**
     * This method returns Business Line given a SOR id for fetchLightWeightECRKeyBasedOnResponseListContent method.
     * This method will return the data for only SOR's supported by this service.
     * 
     * @param sorId SOR ID
     * @param productTypeCode Product Type Code
     * @return Business Line Based on SORID
     */

    public String getBusinessLineBasedOnSORID(String sorId, String productTypeCode) {
        String businessLine = Constants.NOT_AVAILABLE_CD;
        String referenceProductTypeCode = null;
        List<String> tempProdTypeCodeList = null;
        if (StringUtils.isNotBlank(sorId) && sorId.equalsIgnoreCase(Constants.SORID_360)) {
            List<ReferenceDataEntity<String>> referenceDataEntity = referenceDataService.getEntities(
                    csvSorIdToBusinessLine, 1, Constants.KEY_SOR_ID, sorId);
            if (productTypeCode != null) {

                for (ReferenceDataEntity<String> entityInList : referenceDataEntity) {
                    Map<String, String> entityMap = entityInList.getAttributeMap();

                    if (entityMap != null && !entityMap.isEmpty()) {
                        referenceProductTypeCode = entityMap.get("ProductTypeCode");
                        tempProdTypeCodeList = Arrays.asList(referenceProductTypeCode.split(Splitter));
                    }
                    if (tempProdTypeCodeList != null && tempProdTypeCodeList.contains(productTypeCode)) {
                        return entityMap.get("BusinessLine");
                    }

                }
                if (businessLine.equalsIgnoreCase(Constants.NOT_AVAILABLE_CD)) {
                    return Constants.PROFILE_DEPOSITS_BUSINESS_LINE;
                }
            } else {
                return null;
            }

        } else {
            businessLine = getBusinessLineBasedOnOtherSORID(sorId);
        }
        return businessLine;
    }

    private String getBusinessLineBasedOnOtherSORID(String sorId) {
        ReferenceDataEntity<String> referenceDataEntity = referenceDataService.getEntity(csvSorIdToBusinessLine, 1,
                Constants.KEY_SOR_ID, sorId);
        String businessLine = Constants.NOT_AVAILABLE_CD;
        Map<String, String> entityMap = referenceDataEntity.getAttributeMap();

        if (entityMap != null && !entityMap.isEmpty()) {
            // logger.debug("entityMap:", entityMap);
            businessLine = entityMap.get(Constants.KEY_BUSINESS_LINE);
        }
        return businessLine;
    }

    /**
     * This method returns accountDetailsURL. This method will return the url for given productType
     * 
     * @param productType Product Type
     * @return Account url
     */

    public String getAccountDetailsURL(String productTypeCode, String sorID) {
        Map<String, String> entityMap = null;
        List<String> tempSorIdList = null;
        String accountDetailsURL = Constants.NOT_AVAILABLE_CD;

        if (StringUtils.isNotEmpty(productTypeCode) && StringUtils.isNotEmpty(sorID)) {
            Map<String, String> entityFilterMap = new HashMap<String, String>();
            entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, productTypeCode);
            List<ReferenceDataEntity<String>> referenceDataEntity = referenceDataService.getEntities(
                    csvAccountCategories, 1, Constants.KEY_PROD_TYPE_CD, productTypeCode);

            for (ReferenceDataEntity<String> entityInList : referenceDataEntity) {
                entityMap = entityInList.getAttributeMap();

                if (entityMap != null && !entityMap.isEmpty()) {
                    String referenceSorId = entityMap.get(Constants.KEY_SOR_ID);
                    tempSorIdList = Arrays.asList(referenceSorId.split(Splitter));
                }
                if (tempSorIdList != null && tempSorIdList.contains(sorID)) {
                    accountDetailsURL = entityMap.get(Constants.KEY_ACCOUNT_DETAILS_URL);
                    if (Constants.NOT_AVAILABLE_CD.equalsIgnoreCase(accountDetailsURL)) {
                        return null;
                    } else {
                        return accountDetailsURL;
                    }
                }

            }

        }

        return null;
    }

    /**
     * This method returns bankNumberDescription. This method will return the url for given bankNumber
     * 
     * @param bankNumber Bank Number
     * @return BankNumber Description
     */

    public String getBankNumberDescription(String bankNumber) {
        Map<String, String> entityMap = null;
        String bankNumberDescription = Constants.NOT_AVAILABLE_CD;

        if (StringUtils.isNotBlank(bankNumber)) {
            entityMap = referenceDataService.getEntity(csvBankRefData, 1, Constants.KEY_BANK_NUM, bankNumber)
                    .getAttributeMap();
            if (entityMap != null && !entityMap.isEmpty()) {
                bankNumberDescription = entityMap.get(Constants.KEY_BANK_NUM_DESC);
            }
        }
        return bankNumberDescription;
    }

    /**
     * This method returns SoRID. This method will return the url for given businessLine
     * 
     * @param businessLineSet Business Line Set
     * @return List of SorID
     */

    public Set<String> getSoRIDBasedOnBusinessline(Set<String> businessLineSet) {
        Map<String, String> entityMap = null;
        Set<String> tempSoRIDSet = null;
        Set<String> soRIDSet = null;
        String rawSoRIDs = null;
        soRIDSet = new TreeSet<String>();
        List<ReferenceDataEntity<String>> entityList = null;
        if (businessLineSet == null || businessLineSet.isEmpty()) {
            return null;
        }
        for (String businessLine : businessLineSet) {
            entityList = referenceDataService.getEntities(csvAccountCategories, 1, Constants.KEY_BUSINESS_LINE,
                    businessLine);

            for (ReferenceDataEntity<String> entityInList : entityList) {
                entityMap = entityInList.getAttributeMap();

                if (entityMap != null && !entityMap.isEmpty()) {
                    rawSoRIDs = entityMap.get(Constants.KEY_SOR_ID);
                    if (rawSoRIDs != null) {
                        tempSoRIDSet = new TreeSet<String>(Arrays.asList(rawSoRIDs.split(Splitter)));
                        soRIDSet.addAll(tempSoRIDSet);
                    }
                }
            }
        }
        return soRIDSet;
    }

    /**
     * This method returns SoRID. This method will return the url for given productTypeSet
     * 
     * @param productTypeSet Product Type
     * @return SoR ID
     */

    public Set<String> getSoRIDBasedOnProductType(Set<String> productTypeSet) {
        Map<String, String> entityMap = null;
        Set<String> tempSoRIDSet = null;
        Set<String> soRIDSet = null;
        String rawSoRIDs = null;
        soRIDSet = new TreeSet<String>();
        if (productTypeSet == null || productTypeSet.isEmpty()) {
            return null;
        }
        for (String productType : productTypeSet) {            
            List<ReferenceDataEntity<String>> referenceDataEntity = referenceDataService.getEntities(
                    csvAccountCategories, 1, Constants.KEY_PROD_TYPE_CD, productType);

            for (ReferenceDataEntity<String> entityInList : referenceDataEntity) {
                entityMap = entityInList.getAttributeMap();
                if (entityMap != null && !entityMap.isEmpty()) {
                    rawSoRIDs = entityMap.get(Constants.KEY_SOR_ID);
                    if (rawSoRIDs != null) {
                        tempSoRIDSet = new TreeSet<String>(Arrays.asList(rawSoRIDs.split(Splitter)));
                        soRIDSet.addAll(tempSoRIDSet);
                    }
                }
            }
        }
        return soRIDSet;
    }

    /**
     * @return Product Type
     */

    public Set<String> getAllProductTypes() {
        List<ReferenceDataEntity<String>> entityList = null;
        Set<String> productTypeSet = null;
        String rawproductType = null;

        entityList = refernceDataCategoryService.getCategory(csvAccountCategories, 1).getEntities();
        if (entityList != null && !entityList.isEmpty()) {
            productTypeSet = new TreeSet<String>();
            for (ReferenceDataEntity<String> entityInList : entityList) {
                rawproductType = entityInList.getAttributeMap().get(Constants.KEY_PROD_TYPE_CD);
                if (StringUtils.isNotBlank(rawproductType)) {
                    productTypeSet.add(rawproductType);
                }
            }
        }
        return productTypeSet;
    }

    /**
     * @return Business Line Set
     */

    public Set<String> getAllBusinessLines() {
        List<ReferenceDataEntity<String>> entityList = null;
        Set<String> businessLineSet = null;
        String rawBusinessLine = null;

        entityList = refernceDataCategoryService.getCategory(csvAccountCategories, 1).getEntities();
        if (entityList != null && !entityList.isEmpty()) {
            businessLineSet = new TreeSet<String>();
            for (ReferenceDataEntity<String> entityInList : entityList) {
                rawBusinessLine = entityInList.getAttributeMap().get(Constants.KEY_BUSINESS_LINE);
                if (StringUtils.isNotBlank(rawBusinessLine)) {
                    businessLineSet.add(rawBusinessLine);
                }
            }
        }
        return businessLineSet;
    }

    /**
     * @param pProductCd Product Code
     * @return COF Product Type
     */
    public String getCOFProductType(String pProductCd) {
        String productCd = pProductCd;
        Map<String, String> entityMap = null;
        if (StringUtils.isNotBlank(productCd)) {
            // Reference data lookup for Product Types
            entityMap = referenceDataService.getEntity(csvProfileProductRefData, 1, Constants.KEY_PROFILE_PROD_TYPE_CD,
                    productCd).getAttributeMap();
            if (entityMap != null && !entityMap.isEmpty()) {
                productCd = entityMap.get(Constants.KEY_COF_PROD_TYPE_CD);
            }
        }
        return productCd;
    }

    /**
     * Returns the CustAcctRelationshipDescAll from CustAcctRelationshipDescAll reference data
     * 
     * @param pRelFromCd Rel code
     * @param pRelToCd Rel Code
     * @return Map of customer Relationship
     */

    public Map<String, String> getCustRelationshipDesc(String pRelFromCd, String pRelToCd) {
        String relFromCd = pRelFromCd;
        String relToCd = pRelToCd;
        String defaultRelationshipFromToCode = "---";

        Map<String, String> entityMap = null;

        if (StringUtils.isBlank(relFromCd)) {
            relFromCd = defaultRelationshipFromToCode;
        }
        if (StringUtils.isBlank(relToCd)) {
            relToCd = defaultRelationshipFromToCode;
        }
        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.CUST_REL_FROM_CODE, relFromCd.toUpperCase());
        entityFilterMap.put(Constants.CUST_REL_TO_CODE, relToCd.toUpperCase());

        entityMap = referenceDataService.getEntity(csvCustAcctRelationshipDescAll, 1, entityFilterMap)
                .getAttributeMap();
        return entityMap;
    }

    /**
     * Returns the CustAcctRelationship(Im) from CustAcctRelationship(Im) reference data
     * 
     * @param pRelFromCd Rel from Code
     * @param pRelToCd Rel to Code
     * @param pApplCd Application Code
     * @param pBankMarketCd Bank Market code
     * @return Map of customer Relationship
     */

    public Map<String, String> getCustRelationshipDesc(String pRelFromCd, String pRelToCd, String pApplCd,
            String pBankMarketCd) {
        String relFromCd = pRelFromCd;
        String relToCd = pRelToCd;
        String applCd = pApplCd;
        String bankMarketCd = pBankMarketCd;
        Map<String, String> entityMap = null;
        Map<String, String> entityFilterMap = new HashMap<String, String>();

        if (StringUtils.isNotBlank(relFromCd)) {
            relFromCd = relFromCd.toUpperCase();
        }
        if (StringUtils.isNotBlank(relToCd)) {
            relToCd = relToCd.toUpperCase();
        }
        if (StringUtils.isNotBlank(applCd)) {
            applCd = applCd.toUpperCase();
        }
        if (StringUtils.isNotBlank(bankMarketCd)) {
            bankMarketCd = bankMarketCd.toUpperCase();
        }

        entityFilterMap.put(Constants.CUST_REL_FROM_CODE, relFromCd);
        entityFilterMap.put(Constants.CUST_REL_TO_CODE, relToCd);
        entityFilterMap.put(Constants.APPL_SYS_CD, applCd);
        entityFilterMap.put(Constants.BANK_MKT_CD, bankMarketCd);

        entityMap = referenceDataService.getEntity(csvCustAcctRelationshipDescIm, 1, entityFilterMap).getAttributeMap();
        return entityMap;
    }

    /**
     * Returns the CustAcctRelationship(360) from CustAcctRelationship(360) reference data
     * 
     * @param pCustomerAccountRelationshipCode customer account Relation ship code
     * @param pOwnershipType Owner Ship Type
     * @param pTrustAcctIndicator Trust Account Indicator
     * @return customer relations ship
     */

    public String getCustRelationshipDesc(String pCustomerAccountRelationshipCode, String pOwnershipType,
            String pTrustAcctIndicator) {
        String customerAccountRelationshipCode = pCustomerAccountRelationshipCode;
        String ownershipType = pOwnershipType;
        String trustAcctIndicator = pTrustAcctIndicator;
        Map<String, String> entityMap = null;
        Map<String, String> entityFilterMap = new HashMap<String, String>();

        if (StringUtils.isNotBlank(customerAccountRelationshipCode)) {
            customerAccountRelationshipCode = customerAccountRelationshipCode.toUpperCase();
        }
        if (StringUtils.isNotBlank(ownershipType)) {
            ownershipType = ownershipType.toUpperCase();
        }
        if (StringUtils.isNotBlank(trustAcctIndicator)) {
            trustAcctIndicator = trustAcctIndicator.toUpperCase();
        }

        entityFilterMap.put(Constants.CUST_REL_CODE, customerAccountRelationshipCode);
        entityFilterMap.put(Constants.CUST_REL_ROLE_CODE, ownershipType);
        entityFilterMap.put(Constants.CUST_REL_TRUST_CODE, trustAcctIndicator);

        entityMap = referenceDataService.getEntity(csvCustAcctRelationshipDesc360, 1, entityFilterMap)
                .getAttributeMap();
        return entityMap.get(Constants.CUST_REL_ROLE_DESC);
    }

    /**
     * Returns the AcctCategory from AcctCategory reference data
     * 
     * @param aProdClassCd Product class
     * @param aProdTypeCd Product Type Code
     * @param aRtirmntAcctInd Retirement account Indicator
     * @param aFeturTypeCd Type code
     * @param aAcctUseCd Account use Code
     * @return account Type
     */

    public String getAcctType(String aProdClassCd, String aProdTypeCd, String aRtirmntAcctInd, String aFeturTypeCd,
            String aAcctUseCd) {
        String prodClassCd = Constants.NILL;
        String prodTypeCd = Constants.NILL;
        String rtirmntAcctInd = Constants.FALSE;
        String feturTypeCd = Constants.NILL;
        String acctUseCd = Constants.NILL;
        Map<String, String> entityMap = null;
        Map<String, String> entityFilterMap = new HashMap<String, String>();

        if (StringUtils.isNotBlank(aProdClassCd)) {
            prodClassCd = aProdClassCd.toUpperCase();
        }
        if (StringUtils.isNotBlank(aProdTypeCd)) {
            prodTypeCd = aProdTypeCd.toUpperCase();
        }
        if (StringUtils.isNotBlank(aRtirmntAcctInd)) {
            rtirmntAcctInd = aRtirmntAcctInd.toUpperCase();
        }
        if (StringUtils.isNotBlank(aFeturTypeCd)) {
            feturTypeCd = aFeturTypeCd.toUpperCase();
        }
        if (StringUtils.isNotBlank(aAcctUseCd)) {
            acctUseCd = acctUseCd.toUpperCase();
        }

        entityFilterMap.put("ProdClassCd", prodClassCd);
        entityFilterMap.put("ProdTypeCd", prodTypeCd);
        entityFilterMap.put("RtirmntAcctInd", rtirmntAcctInd);
        entityFilterMap.put("AcctUseCd", acctUseCd);
        entityFilterMap.put("FeturTypeCd", feturTypeCd);

        entityMap = referenceDataService.getEntity(csvAcctCategory, 1, entityFilterMap).getAttributeMap();
        // logger.debug("Reference data entry for AcctCategory= {}", entityMap.get("AcctCategory"));
        return entityMap.get("AcctCategory");
    }

    public String getBankNumberRetail(String sorID) {

        Map<String, String> entityMap = null;
        Map<String, String> entityFilterMap = new HashMap<String, String>();

        entityFilterMap.put(Constants.SOR_ID_KEY, sorID);

        entityMap = referenceDataService.getEntity(csvRetailSORIDLookup, 1, entityFilterMap).getAttributeMap();
        return entityMap.get(Constants.BANK_GRP_NUM_KEY);
    }

    /**
     * Returns the BankNumber from SorIdToSorIdDetail reference data
     * 
     * @param sorId SOR ID
     * @return Bank Number from SorID
     */
    public String getBankNumberFromSorId(String sorId) {

        Map<String, String> entityMap = null;
        Map<String, String> entityFilterMap = new HashMap<String, String>();

        entityFilterMap.put(Constants.SOR_ID_KEY_2, sorId);

        entityMap = referenceDataService.getEntity(csvSorIdToSorIdDetail, 1, entityFilterMap).getAttributeMap();
        return entityMap.get(Constants.BANK_NUM_KEY);
    }

    public String getSorProductTypeFromSorId(List<CustomerAccountKey> unsupportedSorIdList) {

        Map<String, String> entityMap = null;
        Map<String, String> entityFilterMap = new HashMap<String, String>();
        StringBuilder builder = new StringBuilder();
        Iterator<CustomerAccountKey> itUnsupportedSorIdList = unsupportedSorIdList.iterator();
        List<String> sorProductTypeFilterList = new ArrayList<String>();
        while (itUnsupportedSorIdList.hasNext()) {
            CustomerAccountKey customerAccountKey = itUnsupportedSorIdList.next();

            entityFilterMap.put(Constants.KEY_SORID, String.valueOf(customerAccountKey.getSorId()));
            entityMap = referenceDataService.getEntity(csvSoRIDtoSoRProductType, 1, entityFilterMap).getAttributeMap();
            String sorProductType = entityMap.get(Constants.SOR_PRODUCT_TYPE_KEY);
            if (!sorProductTypeFilterList.contains(sorProductType)) {
                sorProductTypeFilterList.add(sorProductType);
                builder.append(sorProductType).append(", ");
            }
        }
        return builder.deleteCharAt(builder.lastIndexOf(", ")).append(". ").toString();
    }

    public List<String> getSortKey(String sortKeyFieldValue) {

        Map<String, String> entityMap = null;
        List<String> sortKeyList = new ArrayList<String>();
        if (StringUtils.isNotBlank(sortKeyFieldValue)) {
            List<ReferenceDataEntity<String>> referenceDataEntity = referenceDataService.getEntities(
                    csvDefaultCustomerAccountSortOrder, 1, Constants.SORT_KEY, sortKeyFieldValue);

            for (ReferenceDataEntity<String> referenceData : referenceDataEntity) {
                entityMap = referenceData.getAttributeMap();
                if (entityMap != null && !entityMap.isEmpty()) {
                    sortKeyList.add(entityMap.get(Constants.SORT_KEY_FIELD_VALUE));
                }
            }
        }
        return sortKeyList;
    }

    public Map<String, String> getTertiarySortKey(String sortKeyFieldValue) {
        Map<String, String> entityMap = null;
        Map<String, String> entityFilterMap = new HashMap<String, String>();

        if (StringUtils.isNotBlank(sortKeyFieldValue)) {
            List<ReferenceDataEntity<String>> referenceDataEntity = referenceDataService.getEntities(
                    csvDefaultCustomerAccountSortOrder, 1, Constants.SORT_KEY, sortKeyFieldValue);
            for (ReferenceDataEntity<String> referenceData : referenceDataEntity) {
                entityMap = referenceData.getAttributeMap();
                if (entityMap != null && !entityMap.isEmpty()) {
                    entityFilterMap.put(entityMap.get(Constants.SORT_KEY_FIELD), entityMap.get(Constants.SORT_ORDER));
                }
            }
        }
        return entityFilterMap;
    }

    public Map<String, Boolean> getApiKeySupportedFor360(String apiKey, Boolean is360ApiKeyPresent) {
        Map<String, String> entityMap = null;
        Map<String, String> entityFilterMap = new HashMap<String, String>();
        Map<String, Boolean> map360Accounts = new HashMap<String, Boolean>();
        entityFilterMap.put(Constants.API_KEY, apiKey);

        entityMap = referenceDataService.getEntity(csvAllowableClient360, 1, entityFilterMap).getAttributeMap();
        if (entityMap != null && (!entityMap.isEmpty())) {
            map360Accounts.put(Constants.IS360_API_KEY_PRESENT, is360ApiKeyPresent);
            map360Accounts.put(Constants.API360_ALLOWED_CLIENT, Boolean.valueOf(entityMap.get(SWITCH)));
            return map360Accounts;
        } else {
            // is360ApiKeyPresent = Boolean.FALSE;
            map360Accounts.put(Constants.IS360_API_KEY_PRESENT, Boolean.FALSE);
            map360Accounts.put(Constants.API360_ALLOWED_CLIENT, Boolean.FALSE);
            return map360Accounts;
        }
    }

}