package com.capitalone.api.customersaccounts.entity;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.epf.context.model.EPFContext;

public interface IntProfileAccountEntity {
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    ProfileAccountDetail retiveAccountDetails(CustomerAccountKey customerAccountKey, EPFContext epfContext,
            String accountNumber, String sorId,boolean is360ApiKeyPresent) throws Exception;
}
