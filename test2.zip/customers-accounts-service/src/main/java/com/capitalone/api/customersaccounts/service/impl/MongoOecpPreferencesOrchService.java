package com.capitalone.api.customersaccounts.service.impl;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.dao.MongoOecpPreferencesDefaultDAO;
import com.capitalone.api.customersaccounts.service.api.HystrixCommandService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.epf.context.model.EPFContext;

/**
 * Service Implementation for retrieving Custom Sort Order
 * 
 */

@Profile
@Trace
@Named
public class MongoOecpPreferencesOrchService {

    private static final int WAIT_TIME = 500;

    private static final TimeUnit WAIT_UNIT = TimeUnit.MILLISECONDS;

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private MongoOecpPreferencesDefaultDAO mongoOecpPreferencesDefaultDAO;

    @Inject
    private HystrixCommandService hystrixCommandService;

    /**
     * Method for retrieving Account Sort order
     * 
     * @param customerAccountsRequest input request
     * @param context holds the user Context
     * @return Customers account response
     * 
     */
    @Async
    public Future<List<String>> execute(CustomerAccountsRequest customerAccountsRequest, EPFContext context) {

        logger.debug("Enter -- execute method of MongoOecpPreferencesOrchService");
        Future<List<String>> acctSortOrderListFuture = null;
        try {

            if (customerAccountsRequest.isAccountNickNameHystrixEnabled()) {
                // Call Hystrix DAO Impl
                logger.debug("Proceeding to hystrix for oecp sort");
                acctSortOrderListFuture = hystrixCommandService.retriveCustomSortOrderDetails(customerAccountsRequest,
                        context);
            } else {
                // Call default DAO Imp.
                logger.debug("Skipping hystrix for oecp sort");
                acctSortOrderListFuture = mongoOecpPreferencesDefaultDAO.getCustomSortOrderDetails(
                        customerAccountsRequest, context);
            }

        } catch (Exception e) {
            logger.debug("Error in Int-Mongo-Oecp");
        }

        logger.debug("Exit - execute method of MongoOecpPreferencesOrchService");

        List<String> acctSortOrderList = null;
        if(acctSortOrderListFuture != null)
        {
        acctSortOrderList = getList(acctSortOrderListFuture);
        }
        return new AsyncResult<List<String>>(acctSortOrderList);
    }

    private List<String> getList(Future<List<String>> acctSortOrderListFuture) {
        List<String> acctSortOrderList = null;
        try {
            acctSortOrderList = acctSortOrderListFuture.get(WAIT_TIME, WAIT_UNIT);
        } catch (InterruptedException e) {
            logger.error(" Interupted Exception", e);
            acctSortOrderListFuture.cancel(true);
        } catch (ExecutionException e) {
            logger.error(" Execution Exception", e);
            acctSortOrderListFuture.cancel(true);
        } catch (TimeoutException e) {
            logger.error(" TimeoutException Exception", e);
            acctSortOrderListFuture.cancel(true);
        }
        return acctSortOrderList;
    }
}
