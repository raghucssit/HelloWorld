package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.LoanAccountSummaryDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;

@Profile
@Trace
@Named
public class LoanAccountSummaryOrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private LoanAccountSummaryDao loanAccountSummaryDao;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;
    /**
     * Method for retrieving LOAN Accounts Summary
     * 
     * @param customerAccountsRequest input request
     * @param context holds the user Context
     * @return Customers account response
     * 
     */
    @Async
    public Future<REASResponse> execute(CustomerAccountsRequest customerAccountsRequest, EPFContext context) {

        logger.debug("Enter -- execute method of LoanAccountSummaryOrchService");
        REASResponse finalReas = new REASResponse();

        List<REASResponse> loanAccountSummaryRes = new ArrayList<REASResponse>();

        List<Future<REASResponse>> loanAccountSummaryResResponesFutures = new ArrayList<Future<REASResponse>>();

        if (customerAccountsRequest != null
                && customerAccountsRequest.getReasSupportedSORID() != null
                && !((customerAccountsRequest.getReasSupportedSORID().contains(Constants.AUTO_LOAN_SORID_38)) || (customerAccountsRequest
                        .getReasSupportedSORID().contains(Constants.AUTO_LOAN_SORID_39)))) {

            for (final CustomerAccountKey key : customerAccountsRequest.getCustomerAccountKeyList()) {
                if (Constants.AUTO_LOAN_SORID_38.equalsIgnoreCase(String.valueOf(key.getSorId()))
                        || Constants.AUTO_LOAN_SORID_39.equalsIgnoreCase(String.valueOf(key.getSorId()))) {
                    loanAccountSummaryResResponesFutures.add(loanAccountSummaryDao.retrieveLoanAccountummary(context,
                            key));
                }
            }

            populateLoanAccountSummary(loanAccountSummaryRes, loanAccountSummaryResResponesFutures);

            for (REASResponse repo : loanAccountSummaryRes) {
                finalReas = customerAccountsUtil.merge(finalReas, repo);
            }

        }
        logger.debug("Exit -- execute method of LoanAccountSummaryOrchService");
        return new AsyncResult<REASResponse>(finalReas);
    }

    private void populateLoanAccountSummary(List<REASResponse> loanAccountSummaryRes,
            List<Future<REASResponse>> loanAccountSummaryResResponesFutures) {
        for (Future<REASResponse> res : loanAccountSummaryResResponesFutures) {
            try {
                loanAccountSummaryRes.add(res.get(Constants.WAIT_TIME, Constants.WAIT_UNIT));
            } catch (ExecutionException ex) {
                logger.error(" Execution Exception", ex);
                res.cancel(true);
            } catch (InterruptedException ex) {
                logger.error(" Interupted Exception", ex);
                res.cancel(true);
            } catch (TimeoutException ex) {
                logger.error(" TimeoutException Exception", ex);
                res.cancel(true);
            }
        }
    }

}
