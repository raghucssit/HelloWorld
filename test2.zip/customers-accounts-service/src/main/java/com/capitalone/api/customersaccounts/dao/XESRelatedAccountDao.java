/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.dao;

import java.util.List;
import java.util.concurrent.Future;

import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.api.commons.services.api.HealthCheckableService;

public interface XESRelatedAccountDao extends HealthCheckableService {

    Future<List<XESRelationshipResponseBean>> retrieve(EPFContext context, String custID, String accountId,
            String apiKey);

    Future<REASResponse> retrieve(EPFContext context, String custID, List<String> accountId, Short sorId);

}