/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.pojo;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

/**
 * @author rqa254
 * 
 */
public class CustomerAccountsOrchResponse {

    private Future<REASResponse> futureReasResponse;

    private Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse;

    private Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse;

    private Future<REASResponse> futureAutoLoansAccountsResponse;

    private Future<REASResponse> futureProfileCustomerAccountsResponse;

    private Future<REASResponse> futureCreditCardAccountSummary;

    private Future<REASResponse> futureSafeDepositeBoxSummary;

    private Future<REASResponse> futureHomeLoanSummary;

    private Future<REASResponse> futureXESDDAIS;

    private Future<REASResponse> futureXESTDAIS;

    private Future<REASResponse> futureLoanAcctIS;

    private Future<REASResponse> futureODSBrokerageAcctIS;

    private Future<List<OecpPreferResponse>> futureOecpPrefResponse;

    private Future<List<OLBResponse>> futureOLBAccountsResponse;

    private Future<REASResponse> futureCOIAcctResponse;

    private Future<List<String>> futureMongoOecpPreferencesResponse;
	
	    private Future<Map<String, String>> futureCustInfoDLSRes;

    public Future<REASResponse> getFutureCOIAcctResponse() {
        return futureCOIAcctResponse;
    }

    public void setFutureCOIAcctResponse(Future<REASResponse> futureCOIAcctResponse) {
        this.futureCOIAcctResponse = futureCOIAcctResponse;
    }

    public Future<REASResponse> getFutureHomeLoanSummary() {
        return futureHomeLoanSummary;
    }

    public void setFutureHomeLoanSummary(Future<REASResponse> futureHomeLoanSummary) {
        this.futureHomeLoanSummary = futureHomeLoanSummary;
    }

    public Future<REASResponse> getFutureAutoLoansAccountsResponse() {
        return futureAutoLoansAccountsResponse;
    }

    public void setFutureAutoLoansAccountsResponse(Future<REASResponse> futureAutoLoansAccountsResponse) {
        this.futureAutoLoansAccountsResponse = futureAutoLoansAccountsResponse;
    }

    public Future<REASResponse> getFutureProfileCustomerAccountsResponse() {
        return futureProfileCustomerAccountsResponse;
    }

    public void setFutureProfileCustomerAccountsResponse(Future<REASResponse> futureProfileCustomerAccountsResponse) {
        this.futureProfileCustomerAccountsResponse = futureProfileCustomerAccountsResponse;
    }

    public Future<REASResponse> getFutureCreditCardAccountSummary() {
        return futureCreditCardAccountSummary;
    }

    public void setFutureCreditCardAccountSummary(Future<REASResponse> futureCreditCardAccountSummary) {
        this.futureCreditCardAccountSummary = futureCreditCardAccountSummary;
    }

    public Future<REASResponse> getFutureSafeDepositeBoxSummary() {
        return futureSafeDepositeBoxSummary;
    }

    public void setFutureSafeDepositeBoxSummary(Future<REASResponse> futureSafeDepositeBoxSummary) {
        this.futureSafeDepositeBoxSummary = futureSafeDepositeBoxSummary;
    }

    /**
     * @return the futureReasResponse
     */
    public Future<REASResponse> getFutureReasResponse() {
        return futureReasResponse;
    }

    /**
     * @param futureReasResponse the futureReasResponse to set
     */
    public void setFutureReasResponse(Future<REASResponse> futureReasResponse) {
        this.futureReasResponse = futureReasResponse;
    }

    /**
     * @return the futureXESRelatedAcctResponse
     */
    public Future<List<XESRelationshipResponseBean>> getFutureXESRelatedAcctResponse() {
        return futureXESRelatedAcctResponse;
    }

    /**
     * @param futureXESRelatedAcctResponse the futureXESRelatedAcctResponse to set
     */
    public void setFutureXESRelatedAcctResponse(Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse) {
        this.futureXESRelatedAcctResponse = futureXESRelatedAcctResponse;
    }

    /**
     * @return the futureProfileAccountRelationshipsResponse
     */
    public Future<List<ProfileRelationshipLookup>> getFutureProfileAccountRelationshipsResponse() {
        return futureProfileAccountRelationshipsResponse;
    }

    /**
     * @param futureProfileAccountRelationshipsResponse the futureProfileAccountRelationshipsResponse to set
     */
    public void setFutureProfileAccountRelationshipsResponse(
            Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse) {
        this.futureProfileAccountRelationshipsResponse = futureProfileAccountRelationshipsResponse;
    }

    public Future<List<OecpPreferResponse>> getFutureOecpPrefResponse() {
        return futureOecpPrefResponse;
    }

    public void setFutureOecpPrefResponse(Future<List<OecpPreferResponse>> futureOecpPrefResponse) {
        this.futureOecpPrefResponse = futureOecpPrefResponse;
    }

    public Future<REASResponse> getFutureXESDDAIS() {
        return futureXESDDAIS;
    }

    public void setFutureXESDDAIS(Future<REASResponse> futureXESDDAIS) {
        this.futureXESDDAIS = futureXESDDAIS;
    }

    public Future<REASResponse> getFutureXESTDAIS() {
        return futureXESTDAIS;
    }

    public void setFutureXESTDAIS(Future<REASResponse> futureXESTDAIS) {
        this.futureXESTDAIS = futureXESTDAIS;
    }

    public Future<REASResponse> getFutureLoanAcctIS() {
        return futureLoanAcctIS;
    }

    public void setFutureLoanAcctIS(Future<REASResponse> futureLoanAcctIS) {
        this.futureLoanAcctIS = futureLoanAcctIS;
    }

    public Future<REASResponse> getFutureODSBrokerageAcctIS() {
        return futureODSBrokerageAcctIS;
    }

    public void setFutureODSBrokerageAcctIS(Future<REASResponse> futureODSBrokerageAcctIS) {
        this.futureODSBrokerageAcctIS = futureODSBrokerageAcctIS;
    }

    public Future<List<OLBResponse>> getFutureOLBAccountsResponse() {
        return futureOLBAccountsResponse;
    }

    public void setFutureOLBAccountsResponse(Future<List<OLBResponse>> futureOLBAccountsResponse) {
        this.futureOLBAccountsResponse = futureOLBAccountsResponse;
    }

    public Future<List<String>> getFutureMongoOecpPreferencesResponse() {
        return futureMongoOecpPreferencesResponse;
    }

    public void setFutureMongoOecpPreferencesResponse(Future<List<String>> futureMongoOecpPreferencesResponse) {
        this.futureMongoOecpPreferencesResponse = futureMongoOecpPreferencesResponse;
    }
	
	    public Future<Map<String, String>> getFutureCustInfoDLSRes() {
        return futureCustInfoDLSRes;
    }

    public void setFutureCustInfoDLSRes(Future<Map<String, String>> futureCustInfoDLSRes) {
        this.futureCustInfoDLSRes = futureCustInfoDLSRes;
    }
}
