package com.capitalone.api.customersaccounts.entity;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.epf.context.model.EPFContext;

public interface LoansAutoLoansEntity {
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    AutoLoanAccount retiveAccountDetails(CustomerAccountKey customerAccountKey, EPFContext epfContext,
            String accountNumber, String sorId,String ssoid) throws Exception;
}
