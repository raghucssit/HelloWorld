package com.capitalone.api.customersaccounts.service.convert.response;

import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs.AcctListInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is the response Converter for XESRelatedAcctIS
 * 
 */

@Profile
@Trace
@Named
public class XESRelatedAcctISResponseConverter extends
        ConversionServiceAwareConverter<AcctListInfo, XESRelationshipResponseBean> {

    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Converts native XES response to XESRelationshipResponseBean type
     * 
     * @param response XESRelatedAcctIS response
     * @return customer role
     */


    @Override
    public XESRelationshipResponseBean convert(AcctListInfo response) {

        logger.debug("XESRelatedAcctISResponseConverter  : convert -> Start");
        logger.debug("XESRelatedAcctISResponseConverter : getCustAcctFromRelationshipCd :: {}",
                response.getCustAcctFromRelationshipCd());
        logger.debug("XESRelatedAcctISResponseConverter : getCustAcctToRelationshipCd :: {}",
                response.getCustAcctToRelationshipCd());
        logger.debug("XESRelatedAcctISResponseConverter : getFISApplicationSystemCd :: {}",
                response.getFISApplicationSystemCd());
        logger.debug("XESRelatedAcctISResponseConverter : getAcctID :: {}", response.getAcctID());
        XESRelationshipResponseBean xesRelationshipAcct = new XESRelationshipResponseBean();
        xesRelationshipAcct.setCustAcctFromRelationshipCd(response.getCustAcctFromRelationshipCd());
        xesRelationshipAcct.setCustAcctToRelationshipCd(response.getCustAcctToRelationshipCd());
        xesRelationshipAcct.setfISApplicationSystemCd(response.getFISApplicationSystemCd());
        xesRelationshipAcct.setAccountNumber(response.getAcctID());
        logger.debug("XESRelatedAcctISResponseConverter  : convert -> End");
        return xesRelationshipAcct;
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
