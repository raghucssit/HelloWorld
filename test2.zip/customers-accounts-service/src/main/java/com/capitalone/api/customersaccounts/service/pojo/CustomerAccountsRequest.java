package com.capitalone.api.customersaccounts.service.pojo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.capitalone.api.model.id.CustomerReferenceId;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.epf.audit.annotation.Audited;

@Audited
public class CustomerAccountsRequest {
    private CustomerReferenceId customerReferenceId = null;

    private ProfileReferenceId profileReferenceId = null;

    private String apiKey = null;

    private Set<String> businessLineSet = null;

    private Set<String> productTypeSet = null;

    private String appVersion = "V4";

    private boolean enableModifiedOrchestrationSwitch;

    private List<String> enableModifiedSafeDepositBoxSwitch;

    private boolean enableOECPPreferenceSwitch;

    private boolean enableErrorHandlingSwitch;

    private List<String> enableXESDDAISCache;

    private String enableappVersionV4;

    private List<String> supportedSorID = null;

    private List<String> reasSupportedSORID = null;

    private List<CustomerAccountKey> customerAccountKeyList = null;

    private List<CustomerAccountKey> servicableAccountKeyList = null;

    private List<CustomerAccountKey> unSupportedAccountKeyList = null;

    private boolean sortByOpenDate;

    private String customerESCID = null;

    private boolean enableOlbrAccountNickname = false;

    private boolean enableOecpSortOrder = false;

    private boolean api360AllowedClient;

    private List<String> coiSwitch;

    private boolean is360ApiKeyPresent = false;

    private boolean custInfoDlsSwitch = false;

    private List<String> ccOnlineCachedConfig = null;

    private List<String> ecrCachedConfig = null;

    private boolean isSortOrderHystrixEnabled = false;

    private boolean isAccountNickNameHystrixEnabled = false;

    public String getCustomerESCID() {
        return customerESCID;
    }

    public void setCustomerESCID(String customerESCID) {
        this.customerESCID = customerESCID;
    }

    public List<CustomerAccountKey> getServicableAccountKeyList() {
        return servicableAccountKeyList;
    }

    public void setServicableAccountKeyList(List<CustomerAccountKey> servicableAccountKeyList) {
        this.servicableAccountKeyList = servicableAccountKeyList;
    }

    public List<String> getReasSupportedSORID() {
        return reasSupportedSORID;
    }

    public void setReasSupportedSORID(List<String> reasSupportedSORID) {
        this.reasSupportedSORID = reasSupportedSORID;
    }

    public boolean isEnableModifiedOrchestrationSwitch() {
        return enableModifiedOrchestrationSwitch;
    }

    public boolean isEnableErrorHandlingSwitch() {
        return enableErrorHandlingSwitch;
    }

    public void setEnableErrorHandlingSwitch(boolean enableErrorHandlingSwitch) {
        this.enableErrorHandlingSwitch = enableErrorHandlingSwitch;
    }

    public void setEnableModifiedOrchestrationSwitch(boolean enableModifiedOrchestrationSwitch) {
        this.enableModifiedOrchestrationSwitch = enableModifiedOrchestrationSwitch;
    }

    public List<String> getSupportedSorID() {
        return supportedSorID;
    }

    public void setSupportedSorID(List<String> supportedSorID) {
        this.supportedSorID = supportedSorID;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public List<CustomerAccountKey> getCustomerAccountKeyList() {
        if (this.customerAccountKeyList == null) {
            customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        }

        return customerAccountKeyList;
    }

    public void setCustomerAccountKeyList(List<CustomerAccountKey> customerAccountKeyList) {
        this.customerAccountKeyList = customerAccountKeyList;
    }

    public Set<String> getBusinessLineSet() {
        return businessLineSet;
    }

    public void setBusinessLineSet(Set<String> businessLineSet) {
        this.businessLineSet = businessLineSet;
    }

    public Set<String> getProductTypeSet() {
        return productTypeSet;
    }

    public void setProductTypeSet(Set<String> productTypeSet) {
        this.productTypeSet = productTypeSet;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    public CustomerReferenceId getCustomerReferenceId() {
        return customerReferenceId;
    }

    public void setCustomerReferenceId(CustomerReferenceId customerReferenceId) {
        this.customerReferenceId = customerReferenceId;
    }

    public ProfileReferenceId getProfileReferenceId() {
        return profileReferenceId;
    }

    public void setProfileReferenceId(ProfileReferenceId profileReferenceId) {
        this.profileReferenceId = profileReferenceId;
    }

    public boolean isEnableOECPPreferenceSwitch() {
        return enableOECPPreferenceSwitch;
    }

    public void setEnableOECPPreferenceSwitch(boolean enableOECPPreferenceSwitch) {
        this.enableOECPPreferenceSwitch = enableOECPPreferenceSwitch;
    }

    public List<CustomerAccountKey> getUnSupportedAccountKeyList() {
        return unSupportedAccountKeyList;
    }

    public void setUnSupportedAccountKeyList(List<CustomerAccountKey> unSupportedAccountKeyList) {
        this.unSupportedAccountKeyList = unSupportedAccountKeyList;
    }

    public boolean isSortByOpenDate() {
        return sortByOpenDate;
    }

    public void setSortByOpenDate(boolean sortByOpenDate) {
        this.sortByOpenDate = sortByOpenDate;
    }

    public boolean isEnableOlbrAccountNickname() {
        return enableOlbrAccountNickname;
    }

    public void setEnableOlbrAccountNickname(boolean enableOlbrAccountNickname) {
        this.enableOlbrAccountNickname = enableOlbrAccountNickname;
    }

    public List<String> getEnableXESDDAISCache() {
        return enableXESDDAISCache;
    }

    public void setEnableXESDDAISCache(List<String> enableXESDDAISCache) {
        this.enableXESDDAISCache = enableXESDDAISCache;
    }

    public boolean isEnableOecpSortOrder() {
        return enableOecpSortOrder;
    }

    public void setEnableOecpSortOrder(boolean enableOecpSortOrder) {
        this.enableOecpSortOrder = enableOecpSortOrder;
    }

    public boolean isApi360AllowedClient() {
        return api360AllowedClient;
    }

    public void setApi360AllowedClient(boolean api360AllowedClient) {
        this.api360AllowedClient = api360AllowedClient;
    }

    public String getEnableappVersionV4() {
        return enableappVersionV4;
    }

    public void setEnableappVersionV4(String enableappVersionV4) {
        this.enableappVersionV4 = enableappVersionV4;
    }

    public boolean isIs360ApiKeyPresent() {
        return is360ApiKeyPresent;
    }

    public void setIs360ApiKeyPresent(boolean is360ApiKeyPresent) {
        this.is360ApiKeyPresent = is360ApiKeyPresent;
    }

    public List<String> getCoiSwitch() {
        return coiSwitch;
    }

    public void setCoiSwitch(List<String> coiSwitch) {
        this.coiSwitch = coiSwitch;
    }

    public boolean isCustInfoDlsSwitch() {
        return custInfoDlsSwitch;
    }

    public void setCustInfoDlsSwitch(boolean custInfoDlsSwitch) {
        this.custInfoDlsSwitch = custInfoDlsSwitch;
    }

    public List<String> getEcrCachedConfig() {
        return ecrCachedConfig;
    }

    public void setEcrCachedConfig(List<String> ecrCachedConfig) {
        this.ecrCachedConfig = ecrCachedConfig;
    }

    public List<String> getCcOnlineCachedConfig() {
        return ccOnlineCachedConfig;
    }

    public void setCcOnlineCachedConfig(List<String> ccOnlineCachedConfig) {
        this.ccOnlineCachedConfig = ccOnlineCachedConfig;
    }

    public List<String> getEnableModifiedSafeDepositBoxSwitch() {
        return enableModifiedSafeDepositBoxSwitch;
    }

    public void setEnableModifiedSafeDepositBoxSwitch(List<String> enableModifiedSafeDepositBoxSwitch) {
        this.enableModifiedSafeDepositBoxSwitch = enableModifiedSafeDepositBoxSwitch;
    }

    public boolean isSortOrderHystrixEnabled() {
        return isSortOrderHystrixEnabled;
    }

    public void setSortOrderHystrixEnabled(boolean isSortOrderHystrixEnabled) {
        this.isSortOrderHystrixEnabled = isSortOrderHystrixEnabled;
    }

    public boolean isAccountNickNameHystrixEnabled() {
        return isAccountNickNameHystrixEnabled;
    }

    public void setAccountNickNameHystrixEnabled(boolean isAccountNickNameHystrixEnabled) {
        this.isAccountNickNameHystrixEnabled = isAccountNickNameHystrixEnabled;
    }

}
/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
