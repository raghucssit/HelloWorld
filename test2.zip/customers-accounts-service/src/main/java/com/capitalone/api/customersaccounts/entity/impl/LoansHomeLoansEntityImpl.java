package com.capitalone.api.customersaccounts.entity.impl;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractRestBaseService;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.entity.LoansHomeLoansEntity;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.loans.homeloans.accounts.model.v3.Account;
import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.model.EndpointProperties;

@Profile
@Trace
@Named
public class LoansHomeLoansEntityImpl extends AbstractRestBaseService<Client, Account> implements LoansHomeLoansEntity {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private Client eapiRestClient;    

    @Inject
    private ReferenceIdEncoder encoder;

    private static final String LOAN_HOMELOAN_ACCOUNTS_API_ROOT_RESOURCE_URL = "loans-homeloans-accounts-Service";

    private static final String ENTITLED = "entitled";

    private static final String APPLICATION_JSON_V_3 = "application/json; v=3";
    
    @Inject
    private CustomerAccountsUtil customerAccountsUtil;
   /**
     * Calling HL API and caching the result.
     * 
     * @param customerAccountKey holds input information
     * @param epfContext holds the request context
     * @param accountNumber account information
     * @param sorId sor ID of the account
     * @return home loan account
     */

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    //@Cacheable(value = "eapi-shortterm-loanshomeloansentity-getAccount", key = "#accountNumber.concat(#sorId)")
    public Account retiveAccountDetails(CustomerAccountKey customerAccountKey, EPFContext epfContext,
            String accountNumber, String sorId) throws Exception {
        logger.debug("Enter - retiveAccountDetails method of LoansHomeLoansEntityImpl class");
        EndpointProperties endpointProperties = customerAccountsUtil.getEndpointProperties(LOAN_HOMELOAN_ACCOUNTS_API_ROOT_RESOURCE_URL);

        String url = endpointProperties.getUrl();

        AccountReferenceId accountRefID = new AccountReferenceId(customerAccountKey.getAccountNumber(),
                customerAccountKey.getSorId().toString());
        String acountReferenceId = encoder.encode(accountRefID.getReferenceId());
        UriBuilder uri = UriBuilder.fromUri(url).path(acountReferenceId)
                .queryParam("customerNumber", customerAccountKey.getConsumerId());
        WebTarget requestPath = eapiRestClient.target(uri);
        Builder buildrequest = requestPath.request().accept(APPLICATION_JSON_V_3)
                .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V_3).header("entitled", ENTITLED);
        logger.debug("Build Request {} ", buildrequest.toString());
       
        logger.debug("Exit - retiveAccountDetails method of LoansHomeLoansEntityImpl class");
        return  buildrequest.get(Account.class);
    }
    

}
