/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.XESRelatedAccountDao;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerInfoBean;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRq;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs.AcctListInfo;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs.PagingRsInfo;
import com.capitalone.xesrelatedacctis.v1.XESRelatedAcctISSoap;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

/**
 * DAO for retrieving XES Related Acct data from XESRelatedAcctIS
 * 
 */

@Profile
@Trace
@Named
public class XESRelatedAccountDaoImpl extends AbstractBaseService implements XESRelatedAccountDao {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private XESRelatedAcctISSoap xesRelatedAcctISSoap;

    @Inject
    private ConversionService conversionService;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Inject
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    /**
     * Retrieving XES Related Acct from XESRelatedAcctIS
     * 
     * @param context holds the request context
     * @param custId Sor cust ID of user
     * @param accountId account information
     * @param apiKey client Key
     * @return list of customers role and safe deposit accounts
     * 
     */

    @Async
    @Override
    public Future<List<XESRelationshipResponseBean>> retrieve(EPFContext context, String custId, String accountId,
            String apiKey) {

        logger.debug("Enter - retrieve method of XESRelatedAccountDaoImpl class");

        AcctListInqRs nativeResponse = null;
        int loopCount = 1;

        // Convert the request into back-end native
        AcctListInqRq nativeRequest = null;
        List<AcctListInfo> acctList;
        List<XESRelationshipResponseBean> xesResponseList;
        List<XESRelationshipResponseBean> finalXESResponseList = new ArrayList<XESRelationshipResponseBean>();
        XESRelationshipResponseBean xesResponse;
        AcctListInqRs.Cmd resCmd;
        // StatType stat = null;
        boolean isMoreRecordsPresent = true;
        CustomerInfoBean xesRelationshipInfo = new CustomerInfoBean();
        xesRelationshipInfo.setCustomerId(custId);
        nativeRequest = conversionService.convert(xesRelationshipInfo, AcctListInqRq.class);
        logger.debug("NativeRequest", nativeRequest);
        if (null != nativeRequest && null != nativeRequest.getHdr()) {
            nativeRequest.getHdr().setSesnId(null);
        }
        while (isMoreRecordsPresent && loopCount <= 20) {
            loopCount++;
            xesResponseList = new ArrayList<XESRelationshipResponseBean>();
            try {
                nativeResponse = (AcctListInqRs) xesRelatedAcctISSoap.acctListInq(nativeRequest);
            } catch (Exception ex) {
                logger.error("Exception while making call to XESRelatedAcctIS {} {}", logger.getClass(), ex);
                xesResponse = new XESRelationshipResponseBean();
                xesResponse.setAccountNumber(accountId);
                xesResponse.setErrorCd(Constants.XES_EXCEPTION);
                finalXESResponseList.add(xesResponse);
            }

            if (nativeResponse != null && nativeResponse.getCmd() != null) {
                resCmd = nativeResponse.getCmd();
                // logger.debug("Received response from XESRelatedAcctIS {}", nativeResponse.getCmd().toString());
                acctList = (null != resCmd.getAcctListRs()) ? resCmd.getAcctListRs().getAcctListInfo() : null;
                retrieveConvertedRs(custId, acctList, xesResponseList);
            }

            // Getting PagingRsInfo from the previous
            // AcctListInq Response
            isMoreRecordsPresent = getPagingRsInfo(nativeResponse, nativeRequest, xesResponseList, finalXESResponseList);
        }
        logger.debug("Exit - retrieve method of XESRelatedAccountDaoImpl class");
        return new AsyncResult<List<XESRelationshipResponseBean>>(finalXESResponseList);
    }

    private void retrieveConvertedRs(String custId, List<AcctListInfo> acctList,
            List<XESRelationshipResponseBean> xesResponseList) {
        logger.debug("Enter - retrieveConvertedRs method of XESRelatedAccountDaoImpl class");
        XESRelationshipResponseBean xesResponse;
        if (acctList != null && !acctList.isEmpty()) {
            for (AcctListInfo acctInfo : acctList) {
                xesResponse = conversionService.convert(acctInfo, XESRelationshipResponseBean.class);
                xesResponse.setCustomerId(custId);
                xesResponseList.add(xesResponse);
            }
        }
        logger.debug("Exit - retrieveConvertedRs method of XESRelatedAccountDaoImpl class");
    }

    private boolean getPagingRsInfo(AcctListInqRs nativeResponse, AcctListInqRq nativeRequest,
            List<XESRelationshipResponseBean> xesResponseList, List<XESRelationshipResponseBean> finalXESResponseList) {
        logger.debug("Enter - getPagingRsInfo method of XESRelatedAccountDaoImpl class");
        PagingRsInfo pagingRsInfo;
        boolean isMoreRecordsPresent;
        if (nativeResponse != null && nativeResponse.getCmd() != null
                && nativeResponse.getCmd().getAcctListRs() != null) {
            pagingRsInfo = nativeResponse.getCmd().getAcctListRs().getPagingRsInfo();

            if (nativeResponse.getCmd().getAcctListRs().getAcctListInfo() != null && nativeRequest != null
                    && nativeRequest.getCmd() != null && nativeRequest.getCmd().getPagingRqInfo() != null) {
                nativeRequest
                        .getCmd()
                        .getPagingRqInfo()
                        .setRecordControlReturnRecordCnt(
                                nativeResponse.getCmd().getAcctListRs().getAcctListInfo().size());
            }
            if (pagingRsInfo != null && pagingRsInfo.getCursor() != null) {
                nativeRequest.getCmd().getPagingRqInfo().setCursor(pagingRsInfo.getCursor());
            }
            finalXESResponseList.addAll(xesResponseList);
            isMoreRecordsPresent = isMoreRecordsPresent(nativeResponse);
        } else {
            isMoreRecordsPresent = false;
        }
        return isMoreRecordsPresent;
    }

    /**
     * This method checks the response It checks whether the response has reached the last page If LastPage is True
     * means There are no more records else there are records in Xpress
     * 
     * @param acctListInqRs request input of IS
     * @return sat code status
     */

    protected boolean isMoreRecordsPresent(AcctListInqRs acctListInqRs) {

        logger.debug("Enter - isMoreRecordsPresent method of XESRelatedAccountDaoImpl class");
        if (acctListInqRs.getCmd().getStat() != null
                && Constants.SUCCESS_STAT_CD == acctListInqRs.getCmd().getStat().getStatCd()
                && acctListInqRs.getCmd().getAcctListRs().getPagingRsInfo() != null) {
            return !(acctListInqRs.getCmd().getAcctListRs().getPagingRsInfo().isLastPageInd());
        } else {
            return false;
        }

    }

    /**
     * Retrieving Safe Deposit Box Accounts from XESRelatedAcctIS
     * 
     * @param context holds the request context
     * @param custId sor cust ID
     * @param accountId account information
     * @param sorId sor id
     * @return list of safe deposit account
     * 
     */

    @Async
    @Override
    public Future<REASResponse> retrieve(EPFContext context, String custId, List<String> accountId, Short sorId) {

        logger.debug("Enter - retrieve method of XESRelatedAccountDaoImpl class for Safe deposite Box");

        AcctListInqRs nativeResponse = null;
        AcctListInqRq nativeRequest = null;
        List<AcctListInfo> acctList;

        REASResponse sdbResponse = new REASResponse();

        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();

        AcctListInqRs.Cmd resCmd;

        CustomerInfoBean relationshipInfo = new CustomerInfoBean();
        relationshipInfo.setCustomerId(custId);
        nativeRequest = conversionService.convert(relationshipInfo, AcctListInqRq.class);
        logger.debug("NativeRequest", nativeRequest);
        if (null != nativeRequest && null != nativeRequest.getHdr()) {
            nativeRequest.getHdr().setSesnId(null);
        }

        try {
            nativeResponse = (AcctListInqRs) xesRelatedAcctISSoap.acctListInq(nativeRequest);

        } catch (Exception ex) {
            logger.error("Exception while making call to XESRelatedAcctIS {} {}", logger.getClass(), ex);
            addnStatFail.setNativeErrorCd(Constants.SDB_ERROR_CODE);
            addnStatFail.setStatDesc(Constants.SDB_SERVICE_DOWN);
            addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
            addnStatFailList.add(addnStatFail);
            sdbResponse.setAddStatList(addnStatFailList);
            sdbResponse.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));
            logger.debug("List<AdditionalStat> size {}", addnStatFailList.size());
        }

        if (nativeResponse != null && nativeResponse.getCmd() != null) {
            resCmd = nativeResponse.getCmd();
            logger.debug("Received response from XESRelatedAcctIS {}", nativeResponse.getCmd().toString());
            acctList = (null != resCmd.getAcctListRs()) ? resCmd.getAcctListRs().getAcctListInfo() : null;
            if (acctList != null && !acctList.isEmpty()) {

                sdbResponse = prepareResponse(accountId, acctList, sorId);
            }
            sdbResponse.setAddStatList(getAdditionalStat(nativeResponse.getCmd().getStat()));
        }

        logger.debug("Exit - retrieve method of XESRelatedAccountDaoImpl class {}", sdbResponse.toString());

        return new AsyncResult<REASResponse>(sdbResponse);

    }

    private REASResponse prepareResponse(List<String> accountIdList, List<AcctListInfo> acctList, Short sorId) {
        REASResponse sdbResponsefinal = new REASResponse();
        logger.debug("Enter - prepareResponse method of XESRelatedAccountDaoImpl class");
        for (String acctId : accountIdList) {
            REASResponse sdbResponse = new REASResponse();
            for (AcctListInfo acctInfo : acctList) {
                boolean prodIDCheck = (acctInfo.getProdID() != null && acctInfo.getProdID().equalsIgnoreCase(
                        Constants.PRODUCT_ID_SDB));
                boolean bankAcctTypeCd = (acctInfo.getBankAcctTypeCd() != null && acctInfo.getBankAcctTypeCd()
                        .equalsIgnoreCase(Constants.PRODUCT_ID_SDB));
                boolean acctid = acctInfo.getAcctID() != null && acctId.equals(acctInfo.getAcctID());
                if (((prodIDCheck) || (bankAcctTypeCd))
                        && ((acctid) || acctId.equals(acctInfo.getAcctID().substring(0,
                                (acctInfo.getAcctID().length() - Constants.SAFE_DEPOST_BOX_ACCOUNT_LENGTH))))) {

                    sdbResponse = conversionService.convert(acctInfo, REASResponse.class);
                    setSDBResponse(sorId, acctId, sdbResponse);

                }
            }
            customerAccountsUtil.merge(sdbResponsefinal, sdbResponse);
        }
        logger.debug("Exit - prepareResponse method of XESRelatedAccountDaoImpl class");
        return sdbResponsefinal;
    }

    private void setSDBResponse(Short sorId, String acctId, REASResponse sdbResponse) {
        logger.debug("Enter - setSDBResponse method of XESRelatedAccountDaoImpl class");
        if (null != sdbResponse.getCustomerAccountsResponseList()
                && !sdbResponse.getCustomerAccountsResponseList().isEmpty()) {

            sdbResponse.getCustomerAccountsResponseList().get(0).setAccountId(acctId);
            sdbResponse.getCustomerAccountsResponseList().get(0).setAccountNumber(acctId);
            sdbResponse.getCustomerAccountsResponseList().get(0).setSorId(String.valueOf(sorId));
            sdbResponse
                    .getCustomerAccountsResponseList()
                    .get(0)
                    .setBusinessLine(
                            customerAccountsRefDataBean.getBusinessLine(sdbResponse.getCustomerAccountsResponseList()
                                    .get(0).getProductTypeCode(), String.valueOf(sorId)));
        }
        logger.debug("Exit - setSDBResponse method of XESRelatedAccountDaoImpl class");
    }

    protected List<AdditionalStat> getAdditionalStat(StatType responseStatus) {

        logger.debug("Enter - getAdditionalStat method of SDB_XESRELATED_ACCOUNTIS class {}", responseStatus);
        if (responseStatus == null) {
            return null;
        }
        // I am assuming we will never exceed int range for stat codes
        int intStatCode = (int) responseStatus.getStatCd();
        if (responseStatus.getSevrty() != null) {
            switch (responseStatus.getSevrty()) {
                case INFO:
                    logger.debug("Response Sevrty INFO {},", responseStatus.getSevrty());
                    return getAddnStatCaseInfo(intStatCode);
                case ERROR:
                    logger.debug("Response Sevrty ERROR {},", responseStatus.getSevrty());
                    return getAddnStatCaseError(intStatCode);
                default:
                    return null;

            }
        }
        logger.debug("Exit - getAdditionalStat method of SDB_XESRELATED_ACCOUNT_IS class ");
        return null;
    }

    private List<AdditionalStat> getAddnStatCaseInfo(int intStatCode) {
        logger.debug("Exit - getAddnStatCaseInfo method of SDB_XESRELATED_ACCOUNT_IS class ");
        switch (intStatCode) {
            case Constants.NO_RECORDS_MATCH_SELECTION_CRITERIA_SDB:
                List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();

                AdditionalStat addnStat = new AdditionalStat();
                addnStat.setNativeErrorCd(Constants.INVALID_CUSTOMER_ID_SDB);
                addnStat.setStatDesc(Constants.SDB_NO_RECORDS_STAT_DESC);
                addnStat.setHttpStatus(Constants.SUCCESS_STATUS_CODE);
                addnStatList.add(addnStat);
                logger.debug("List<AdditionalStat> size{}", addnStatList.size());
                if ((null != addnStatList) && (!addnStatList.isEmpty())) {
                    return addnStatList;
                }
                return null;

                // TODO: handle all error code
            default:
                return null;

        }
    }

    private List<AdditionalStat> getAddnStatCaseError(int intStatCode) {
        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        logger.debug("Exit - getAddnStatCaseError method of SDB_XESRELATED_ACCOUNT_IS class ");
        AdditionalStat addnStat = new AdditionalStat();
        switch (intStatCode) {
            case Constants.CUSTOMER_IDENTIFIER_INVALID:
                addnStat.setNativeErrorCd(Constants.INVALID_CUSTOMER_ID_SDB);
                addnStat.setStatDesc(Constants.SDB_NO_RECORDS_STAT_DESC);
                addnStat.setHttpStatus(Constants.SUCCESS_STATUS_CODE);
                addnStatList.add(addnStat);
                logger.debug("List<AdditionalStat> size{}", addnStatList.size());
                return addnStatList;
                // 500
            case Constants.ERR_CUSTOMER_NOT_FOUND:
                addnStat.setNativeErrorCd(Constants.INVALID_CUSTOMER_ID_SDB);
                addnStat.setStatDesc(Constants.SDB_NO_RECORDS_STAT_DESC);
                addnStat.setHttpStatus(Constants.SUCCESS_STATUS_CODE);
                addnStatList.add(addnStat);
                logger.debug("List<AdditionalStat> size{}", addnStatList.size());
                return addnStatList;

                // 500

            default:
                return null;

        }
    }
}