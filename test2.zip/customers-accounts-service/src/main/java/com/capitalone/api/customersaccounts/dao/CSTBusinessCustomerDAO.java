package com.capitalone.api.customersaccounts.dao;

import com.capitalone.api.customersaccounts.service.pojo.CSTBusinessCustomerResponse;
import com.capitalone.api.commons.services.api.HealthCheckableService;

public interface CSTBusinessCustomerDAO extends HealthCheckableService {
	CSTBusinessCustomerResponse getAccountRelationships(String bif);
}
