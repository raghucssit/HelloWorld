package com.capitalone.api.customersaccounts.service.convert.response;

import javax.annotation.Resource;
import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.loans.homeloans.accounts.model.v3.Account;

@Profile
@Trace
@Named
public class HomeloanAPIResponseConverter extends ConversionServiceAwareConverter<Account, CustomerAccountsResponse> {

    private static final String BANKRUPTCY_STATUSCODE = "A";

    private static final String CHAPTER7DISCHARGE_STATUSCODE = "Y";

    private static final String DELINQUENCY_STATUSCODE = "RG";

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    /**
     * Converts homeLoanAccount to CustomerAccountKey type
     * 
     * @param homeLoanAccount homeloan account details
     * @return customer accounts response
     */
    @Override
    public CustomerAccountsResponse convert(Account homeLoanAccount) {
        logger.debug("Enter - convert method of HomeloanAPIResponseConverter class");
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        if (homeLoanAccount != null) {

            setHomeLoanAccountResponse(homeLoanAccount, response);

            // Account Status code
            setHomeLoanAccountStatusDescription(homeLoanAccount, response);

        }
        logger.debug("Exit - convert method of HomeloanAPIResponseConverter class");
        return response;
    }

    private void setHomeLoanAccountStatusDescription(Account homeLoanAccount, CustomerAccountsResponse response) {
        logger.debug("Enter - setHomeLoanAccountStatusDescription method of HomeloanAPIResponseConverter class");
        if (homeLoanAccount.getReoStatusCode() != null
                || (homeLoanAccount.getPaidInFullStopCode() != null && !(homeLoanAccount.getPaidInFullStopCode()
                        .equalsIgnoreCase("0")))) {
            response.setAccountStatusDescription(Constants.ACCOUNT_STATUS_CLOSED);
            if (homeLoanAccount.getPaidInFullDate() != null) {
                response.setClosedDate(homeLoanAccount.getPaidInFullDate());

            } else if (homeLoanAccount.getReoSetUpDate() != null) {
                response.setClosedDate(homeLoanAccount.getReoSetUpDate());
            } else if (homeLoanAccount.getServicingSoldDate() != null) {
                response.setClosedDate(homeLoanAccount.getServicingSoldDate());
            }
        } else {
            response.setAccountStatusDescription(Constants.ACCOUNT_STATUS_OPEN);
        }
        setHomeLoanOpenAcctStatusDescription(homeLoanAccount, response);
        logger.debug("Exit - setHomeLoanAccountStatusDescription method of HomeloanAPIResponseConverter class");
    }

    private void setHomeLoanOpenAcctStatusDescription(Account homeLoanAccount, CustomerAccountsResponse response) {
        logger.debug("Enter - setHomeLoanOpenAcctStatusDescription method of HomeloanAPIResponseConverter class");
        if (!response.getAccountStatusDescription().equalsIgnoreCase(Constants.ACCOUNT_STATUS_CLOSED)) {
            boolean bankruptcyStatus = homeLoanAccount.getBankruptcyStatusCode() != null
                    && homeLoanAccount.getBankruptcyStatusCode().equalsIgnoreCase(BANKRUPTCY_STATUSCODE);
            boolean chatper7DischargeStatusCode = homeLoanAccount.getChapter7DischargeStatusCode() != null
                    && homeLoanAccount.getChapter7DischargeStatusCode().equalsIgnoreCase(CHAPTER7DISCHARGE_STATUSCODE);
            if ((bankruptcyStatus)
                    || (chatper7DischargeStatusCode)
                    || (homeLoanAccount.getDelinquencyStatusCode() != null && homeLoanAccount
                            .getDelinquencyStatusCode().equalsIgnoreCase(DELINQUENCY_STATUSCODE))) {
                response.setAccountStatusDescription(Constants.ACCOUNT_STATUS_BANKRUPTCY);
            }
        }
        logger.debug("Exit - setHomeLoanOpenAcctStatusDescription method of HomeloanAPIResponseConverter class");
    }

    private void setHomeLoanAccountResponse(Account homeLoanAccount, CustomerAccountsResponse response) {
        logger.debug("Enter - setHomeLoanAccountResponse method of HomeloanAPIResponseConverter class");
        setProductDetailsHomeLoanAPI(homeLoanAccount, response);

        if (homeLoanAccount.getAvailableCreditLimit() != null) {
            response.setAvailableBalance(homeLoanAccount.getAvailableCreditLimit());
        }
        if (homeLoanAccount.getPrincipalBalance() != null) {
            response.setCurrentPrincipal(homeLoanAccount.getPrincipalBalance());
        }
        if (homeLoanAccount.getAccountOpenDate() != null) {
            response.setOpenDate(homeLoanAccount.getAccountOpenDate());
        }

        // Account Number is given in getDisplayAccountNumber() field

        if (homeLoanAccount.getDisplayAccountNumber() != null) {
            response.setAccountNumber(homeLoanAccount.getDisplayAccountNumber());
            response.setDisplayAccountNumber(homeLoanAccount.getDisplayAccountNumber());
            response.setSorId(Constants.HOME_LOAN_SORID);
            response.setAccountId(homeLoanAccount.getDisplayAccountNumber());
        }

        response.setCurrencyCode(Constants.CURRENCY_CODE_USA);

        if (homeLoanAccount.getNextPaymentDueDate() != null) {
            response.setPaymentDueDate(homeLoanAccount.getNextPaymentDueDate());
        }
        if (response.getProductTypeCode() != null) {
            response.setBusinessLine(customerAccountsRefDataBean.getBusinessLine(response.getProductTypeCode(),
                    Constants.HOME_LOAN_SORID));
        }
        if (homeLoanAccount.getBorrowerType() != null) {
            response.setCustomerRole(homeLoanAccount.getBorrowerType());
        }
        logger.debug("Exit - setHomeLoanAccountResponse method of HomeloanAPIResponseConverter class");
    }

    private void setProductDetailsHomeLoanAPI(Account homeLoanAccount, CustomerAccountsResponse response) {
        logger.debug("Enter - setProductDetailsHomeLoanAPI method of HomeloanAPIResponseConverter class");
        if (homeLoanAccount.getProductName() != null) {
            // as per mapping doc - Lien Type will be exposed separately
            // which needs to be concatenated
            response.setProductName(homeLoanAccount.getProductName());
        }

        if (homeLoanAccount.getProductTypeCode() != null) {
            // as per mappping doc Make sure HIL, HLC and MLA are derived
            // fine.
            response.setProductTypeCode(homeLoanAccount.getProductTypeCode());
        }
        if (response.getProductTypeCode() != null) {
            response.setProductTypeDescription(customerAccountsRefDataBean.getProductTypeDescription(response
                    .getProductTypeCode()));
        }
        logger.debug("Exit - setProductDetailsHomeLoanAPI method of HomeloanAPIResponseConverter class");
    }

}
