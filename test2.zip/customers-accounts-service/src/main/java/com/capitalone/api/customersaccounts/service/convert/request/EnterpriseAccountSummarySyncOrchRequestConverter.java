/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.convert.request;

import java.util.List;

import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountApplicantKey;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRq;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRq.Cmd;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRq.Cmd.AcctSummaryInputKey;

/**
 * This class is the Converter for CustomerAccountsRequest To AcctSummaryInq Request
 * 
 */

@Profile
@Trace
@Named
public class EnterpriseAccountSummarySyncOrchRequestConverter extends
        ConversionServiceAwareConverter<CustomerAccountsRequest, AcctSummaryInqRq> {

    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Converts CustomerAccountsRequest To AcctSummaryInq Request
     * 
     * @param request customers accounts information
     * @return inputRq for REAS
     */

    @Override
    public AcctSummaryInqRq convert(CustomerAccountsRequest request) {
        logger.debug("Client Request : CustomerAccountsRequest={} --Start", request);

        if (request.getCustomerAccountKeyList() == null || request.getCustomerAccountKeyList().isEmpty()) {
            return null;
        }

        AcctSummaryInqRq acctSummaryInqRq = new AcctSummaryInqRq();

        String profileReferenceId = "";
        if ((null != request.getProfileReferenceId())
                && (StringUtils.isNotBlank(request.getProfileReferenceId().getSSOID()))) {
            profileReferenceId = request.getProfileReferenceId().getSSOID();
        }
        // acctSummaryInqRq.setHdr(CustomerAccountsUtil.createHeader(request.getApiKey()));
        Cmd cmd = new Cmd();
        // cmd.setName(OPERATION_NAME);
        //AccountApplicantKey accountApplicantKey = null;
        AcctSummaryInputKey acctSummaryInputKey = new AcctSummaryInputKey();

        List<CustomerAccountKey> customerAccountsKeyList = request.getCustomerAccountKeyList();

        enterpriseAcctSummarySyncOrchReqMapping(request, profileReferenceId, acctSummaryInputKey,
                customerAccountsKeyList);
        cmd.setAcctSummaryInputKey(acctSummaryInputKey);
        acctSummaryInqRq.setCmd(cmd);
        logger.debug("EnterpriseAccountSummarySyncOrchRequestConverter  : convert -> End");
        return acctSummaryInqRq;
    }

    private void enterpriseAcctSummarySyncOrchReqMapping(CustomerAccountsRequest request, String profileReferenceId,
            AcctSummaryInputKey acctSummaryInputKey, List<CustomerAccountKey> customerAccountsKeyList) {
        AccountApplicantKey accountApplicantKey;
        for (CustomerAccountKey customerAccountKey : customerAccountsKeyList) {
            boolean supportedSORID = request.getReasSupportedSORID() != null && request.getReasSupportedSORID().contains(customerAccountKey.getSorId().toString());
            
            if (supportedSORID || (request.isEnableModifiedOrchestrationSwitch() && !request.isApi360AllowedClient() && String
                            .valueOf(customerAccountKey.getSorId()).equalsIgnoreCase(Constants.SORID_360))) {
                accountApplicantKey = new AccountApplicantKey();
                accountApplicantKey.setSORCnsmrID(customerAccountKey.getConsumerId());
                accountApplicantKey.setApplctnAcctID(customerAccountKey.getAccountNumber());
                accountApplicantKey.setSoRID(customerAccountKey.getSorId());
                acctSummaryInputKey.getAccountApplicantKey().add(accountApplicantKey);
            }

        }

        if (StringUtils.isNotBlank(profileReferenceId)) {
            acctSummaryInputKey.setPermLginTxt(profileReferenceId);
        }
    }
}
/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
