/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.exception.ApiBusinessException;
import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.exception.ApiSystemException;
import com.capitalone.api.commons.exception.NotFoundException;
import com.capitalone.api.commons.exception.TimeOutException;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsOrchResponse;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;

/**
 * @author rqa254
 * 
 */

@Profile
@Trace
@Named
public class CustomerAccountsAggregationService {

    @Inject
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    private Logger logger = LoggerFactory.getLogger(getClass());

    private static final String ACCOUNT_NUMBER_PADDING = "0";

    private static final int WAIT_TIME = 30;

    private static final TimeUnit WAIT_UNIT = TimeUnit.SECONDS;

    private static final int OECP_WAIT_TIME = 500;

    private static final TimeUnit OECP_WAIT_UNIT = TimeUnit.MILLISECONDS;

    private static final int XES_WAIT_TIME = 5;

    private static final TimeUnit XES_WAIT_UNIT = TimeUnit.SECONDS;

    private static final int PROFILE_WAIT_TIME = 5;

    private static final TimeUnit PROFILE_WAIT_UNIT = TimeUnit.SECONDS;

    private static final String INTERRUPTED_EXCEPTION = "InterruptedException in Class {}";

    private static final String EXECUTION_EXCEPTION = "ExecutionException in Class {}";

    private static final String TIMEOUT_EXCEPTION = "TimeoutException in Class {}";

    private static final String CANCELLATION_EXCEPTION = "CancellationException in Class {}";

    private static final String NO_DATA_FOUND = "No data found";

    private static final String REAS_1420 = "REAS returned 1420";

    private static final long CARD_WAIT_TIME = 2;

    /**
     * This Method calls mapCustomerRelationToAccount method intern for getting Role for accounts
     * 
     * @param customerAccountsOrchResponse customers accounts Response
     * @param enableErrorHandlingSwitch Error Handling Switch
     * @return customers account response
     * 
     */

    public REASResponse execute(CustomerAccountsOrchResponse customerAccountsOrchResponse,
            boolean enableErrorHandlingSwitch, boolean isCallFromLightWeightAPI,
            List<CustomerAccountKey> listCustomerAccountKey) {

        logger.debug("Enter - execute method of CustomerAccountsAggregationService class");
        REASResponse reasResponsesfromBackend = null;
        if (customerAccountsOrchResponse != null && customerAccountsOrchResponse.getFutureReasResponse() != null) {
            if (enableErrorHandlingSwitch) {
                reasResponsesfromBackend = getREASResponse(customerAccountsOrchResponse);

            } else {
                reasResponsesfromBackend = getREASErrorResponse(customerAccountsOrchResponse, isCallFromLightWeightAPI);

            }
        } else {
            throw new NotFoundException();
        }
        if (isCallFromLightWeightAPI) {
            return reasResponsesfromBackend;
        }
        REASResponse responseWithRelation = mapCustomerRelationToAccount(reasResponsesfromBackend,
                customerAccountsOrchResponse.getFutureXESRelatedAcctResponse(),
                customerAccountsOrchResponse.getFutureProfileAccountRelationshipsResponse(), listCustomerAccountKey,
                customerAccountsOrchResponse.getFutureCustInfoDLSRes());
        logger.debug("Exit - execute method of CustomerAccountsAggregationService class");

        return responseWithRelation;
    }

    private REASResponse getREASErrorResponse(CustomerAccountsOrchResponse customerAccountsOrchResponse,
            boolean isCallFromLightWeightAPI) {
        logger.debug("Inside CustomerAccountsAggregationService getREASErrorResponse");
        REASResponse reasResponsesfromBackend = null;
        try {
            reasResponsesfromBackend = customerAccountsOrchResponse.getFutureReasResponse().get(WAIT_TIME, WAIT_UNIT);
            if ((reasResponsesfromBackend == null || reasResponsesfromBackend.getCustomerAccountsResponseList() == null || reasResponsesfromBackend
                    .getCustomerAccountsResponseList().isEmpty()) && !isCallFromLightWeightAPI) {
                logger.debug("If reasResponse or Response List is empty or null");
                throw new NotFoundException();
            }
        } catch (InterruptedException e) {
            logger.error(INTERRUPTED_EXCEPTION, logger.getClass(), e);
            customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
            throw new ApiSystemException(e);
        } catch (ExecutionException e) {
            logger.error(EXECUTION_EXCEPTION, logger.getClass(), e);
            customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
            if (e.getCause().getClass().isAssignableFrom(NotFoundException.class)) {
                logger.error("No data found");
                customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
                throw new NotFoundException(REAS_1420, e);
            } else {
                throw new ApiSystemException(e);
            }
        } catch (TimeoutException e) {
            logger.error(TIMEOUT_EXCEPTION, logger.getClass(), e);
            customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
            throw new TimeOutException(e);
        } catch (NotFoundException e) {
            customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
            throw new NotFoundException("No data found", e);
        }
        return reasResponsesfromBackend;
    }

    private REASResponse getREASResponse(CustomerAccountsOrchResponse customerAccountsOrchResponse) {
        REASResponse reasResponsesfromBackend = null;
        try {
            reasResponsesfromBackend = customerAccountsOrchResponse.getFutureReasResponse().get(WAIT_TIME, WAIT_UNIT);

            logger.debug("Inside CustomerAccountsAggregationService getREASResponse");

            if (reasResponsesfromBackend == null) {
                logger.debug("reasResponsesfromBackend is null");
                throw new NotFoundException();
            } else if (reasResponsesfromBackend.getCustomerAccountsResponseList() == null
                    || reasResponsesfromBackend.getCustomerAccountsResponseList().isEmpty()) {
                getREASResponseAddnStat(reasResponsesfromBackend);
            }

        } catch (InterruptedException e) {
            logger.error(INTERRUPTED_EXCEPTION, logger.getClass(), e);
            customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
            throw new ApiSystemException(e);
        } catch (ExecutionException e) {
            logger.error(EXECUTION_EXCEPTION, logger.getClass(), e);
            customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
            if (e.getCause().getClass().isAssignableFrom(NotFoundException.class)) {
                logger.error(NO_DATA_FOUND);
                customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
                throw new NotFoundException(REAS_1420, e);
            } else {
                throw new ApiSystemException(e);
            }
        } catch (TimeoutException e) {
            logger.error(TIMEOUT_EXCEPTION, logger.getClass(), e);
            customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
            throw new TimeOutException(e);
        } catch (NotFoundException e) {
            customerAccountsOrchResponse.getFutureReasResponse().cancel(true);
            throw new NotFoundException(NO_DATA_FOUND, e);
        }
        return reasResponsesfromBackend;
    }

    private void getREASResponseAddnStat(REASResponse reasResponsesfromBackend) {
        if (reasResponsesfromBackend.getAddStatList() == null || reasResponsesfromBackend.getAddStatList().isEmpty()) {
            logger.debug(" reasResponsesfromBackend : NO DATA found");
            throw new NotFoundException();
        } else {
            logger.debug("reasResponsesfromBackend has NO DATA but has Addn Stat");
            ApiErrorCode error = new ApiErrorCode();
            int responseStatusCode = 404;
            for (AdditionalStat stat : reasResponsesfromBackend.getAddStatList()) {
                logger.debug("Inside CustomerAccountsAggregationService getREASResponse : stat - StatDesc - {}",
                        stat.getStatDesc());
                if (stat.getHttpStatus() != null && stat.getHttpStatus().equals(Constants.INTERNAL_SERVER_ERROR_CODE)) {
                    responseStatusCode = Constants.INTERNAL_SERVER_ERROR_CODE;
                }
                if ((stat.getNativeErrorCd() != null)
                        && (Constants.SORID_ERROR_HANDLING.contains(stat.getNativeErrorCd()))) {
                    logger.debug(
                            "Inside CustomerAccountsAggregationService getREASResponse : Valid error code stat - {}",
                            stat.getNativeErrorCd());
                    List<String> messageParms = new ArrayList<String>();

                    messageParms.add(stat.getAccountId());
                    messageParms.add(stat.getSorId());
                    if (!stat.getStatDesc().isEmpty()) {
                        error.getErrorDetails().add(
                                customerAccountsUtil.constructApiErrorCode(Integer.parseInt(stat.getNativeErrorCd()),
                                        messageParms, stat.getStatDesc()));
                    } else {
                        error.getErrorDetails().add(
                                customerAccountsUtil.constructApiErrorCode(Integer.parseInt(stat.getNativeErrorCd()),
                                        messageParms, null));
                    }

                } else {
                    logger.debug(" CustomerAccountsAggregationService getREASResponse : NO Vaild error code - ");
                    if (stat.getStatDesc() != null) {
                        addErrorCode(error, stat);
                    } else {
                        logger.debug(" CustomerAccountsAggregationService getREASResponse : NativeErrorCd is null - Seting response to NO DATA FOUND");
                        throw new NotFoundException();
                    }

                }
            }
            throw new ApiBusinessException(error, responseStatusCode);
        }
    }

    private void addErrorCode(ApiErrorCode error, AdditionalStat stat) {
        ApiErrorCode errorCode = new ApiErrorCode();
        errorCode.setDeveloperText(stat.getStatDesc());
        if (stat.getNativeErrorCd() != null
                && !Constants.INVALID_CARD_ERROR_CD.contains(String.valueOf(stat.getNativeErrorCd()))) {
            errorCode.setDeveloperTextId(stat.getNativeErrorCd());
            // errorCode.addErrorDetail(stat.getNativeErrorCd(), "", "", stat.getStatDesc());
        }
        error.getErrorDetails().add(errorCode);
    }

    /**
     * 
     * Method for mapping Customer Relation To Account(Setting up AddnStat in case of role not found)
     * 
     * @param REASResponse ALL LOB response
     * @param xesRelactedAcctList xes accounts response
     * @param relation360AcctList profile accounts response
     * @param Future<List<AutoLoansAccountsBean>>
     * @return customers accounts response
     */

    private REASResponse mapCustomerRelationToAccount(REASResponse reasResponsesfromBackend,
            Future<List<XESRelationshipResponseBean>> xesRelactedAcctList,
            Future<List<ProfileRelationshipLookup>> relation360AcctList,
            List<CustomerAccountKey> listCustomerAccountKey, Future<Map<String, String>> cardCustRole) {
        logger.debug("Enter - mapCustomerRelationToAccount method of CustomerAccountsAggregationService class");
        logger.debug("CustomerAccountsAggregationService : mapCustomerRelationToAccount - AddnStat List From REAS {}",
                reasResponsesfromBackend.getAddStatList());

        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();

        if (null != reasResponsesfromBackend.getAddStatList()) {
            for (AdditionalStat addnStat : reasResponsesfromBackend.getAddStatList()) {
                if (!(null != addnStat.getSrvrStatCd() && Constants.INVALID_ERROR_CD.contains(addnStat.getSrvrStatCd()))) {
                    addnStatList.add(addnStat);
                }
            }
        }
        List<String> cstRoleNotFoundAccounts = new ArrayList<String>();
        List<String> profileRoleNotFoundAccounts = new ArrayList<String>();
        List<String> xesRoleNotFoundAccounts = new ArrayList<String>();

        for (CustomerAccountsResponse reasResp : reasResponsesfromBackend.getCustomerAccountsResponseList()) {

            // Creditcards had no customer role so we are ignoring for it
            // Removing the condition to block card accounts for role information
            if (reasResp.getProductTypeCode() != null) {
                logger.debug(
                        "CustomerAccountsAggregationService : mapCustomerRelationToAccount - Find Customer Role SOR ID {} ",
                        reasResp.getSorId());
                mapRoleToAccount(xesRelactedAcctList, relation360AcctList, cstRoleNotFoundAccounts,
                        profileRoleNotFoundAccounts, xesRoleNotFoundAccounts, reasResp, listCustomerAccountKey,
                        cardCustRole);

            }

        }

        checkRoleNotFound(reasResponsesfromBackend, addnStatList, cstRoleNotFoundAccounts, profileRoleNotFoundAccounts,
                xesRoleNotFoundAccounts);
        logger.debug("Exit - mapCustomerRelationToAccount method of CustomerAccountsAggregationService class");
        return reasResponsesfromBackend;
    }

    private void checkRoleNotFound(REASResponse reasResponsesfromBackend, List<AdditionalStat> addnStatList,
            List<String> cstRoleNotFoundAccounts, List<String> profileRoleNotFoundAccounts,
            List<String> xesRoleNotFoundAccounts) {
        if (!cstRoleNotFoundAccounts.isEmpty()) {
            logger.debug("CustomerAccountsAggregationService : mapCustomerRelationToAccount - Setting Addn Stat CST : ");
            AdditionalStat roleNotFound = new AdditionalStat();
            roleNotFound.setNativeErrorCd(Constants.CST_ACCOUNT_EXCEPTION);
            roleNotFound.setStatDesc(Constants.CST_ROLE_NOT_FOUND + cstRoleNotFoundAccounts.toString());
            addnStatList.add(roleNotFound);

        }
        if (!profileRoleNotFoundAccounts.isEmpty()) {
            logger.debug("CustomerAccountsAggregationService : mapCustomerRelationToAccount - Setting Addn Stat Profile : ");
            AdditionalStat roleNotFound = new AdditionalStat();
            roleNotFound.setNativeErrorCd(Constants.PROFILE_ACCOUNT_EXCEPTION);
            roleNotFound.setStatDesc(Constants.PROFILE_ROLE_NOT_FOUND + profileRoleNotFoundAccounts.toString());
            addnStatList.add(roleNotFound);

        }
        if (!xesRoleNotFoundAccounts.isEmpty()) {
            logger.debug("CustomerAccountsAggregationService : mapCustomerRelationToAccount - Setting Addn Stat XES : ");
            AdditionalStat roleNotFound = new AdditionalStat();
            roleNotFound.setNativeErrorCd(Constants.XES_EXCEPTION);
            roleNotFound.setStatDesc(Constants.XES_ROLE_NOT_FOUND + xesRoleNotFoundAccounts.toString());
            addnStatList.add(roleNotFound);

        }
        if (!addnStatList.isEmpty()) {
            reasResponsesfromBackend.setPartialError(CustomerAccountsUtil
                    .parseAdditionalStatusToApiException(addnStatList));
        }
    }

    private void mapRoleToAccount(Future<List<XESRelationshipResponseBean>> xesRelactedAcctList,
            Future<List<ProfileRelationshipLookup>> relation360AcctList, List<String> cstRoleNotFoundAccounts,
            List<String> profileRoleNotFoundAccounts, List<String> xesRoleNotFoundAccounts,
            CustomerAccountsResponse reasResp, List<CustomerAccountKey> listCustomerAccountKey,
            Future<Map<String, String>> cardCustRole) {
        if (String.valueOf(Constants.CREDIT_CARD_SORID).equals(reasResp.getSorId()) && cardCustRole != null) {
            CustomerAccountKey customerAccountKey = (CustomerAccountKey) CollectionUtils.find(listCustomerAccountKey,
                    getCardRolePredicate(reasResp.getAccountId()));
            logger.debug("The customerKey for card is {}", customerAccountKey);

            fetchCardCustRole(reasResp, cardCustRole, customerAccountKey);
        }

        else if (Constants.SORIDLIST_360.contains(Short.valueOf(reasResp.getSorId()))) {
            logger.debug("CustomerAccountsAggregationService : mapCustomerRelationToAccount - Ckecking for role in Profile ");
            String profileRoleErrorCode = map360CustomerRelationToAccount(reasResp, relation360AcctList);
            if (null != profileRoleErrorCode
                    && Constants.PROFILE_ACCOUNT_EXCEPTION.equalsIgnoreCase(profileRoleErrorCode)) {

                logger.debug("CustomerAccountsAggregationService : mapCustomerRelationToAccount - profile Error {} ",
                        profileRoleErrorCode, " - Acct no. {} ", reasResp.getAccountNumber());

                profileRoleNotFoundAccounts.add(reasResp.getAccountNumber());

            } else if (null != profileRoleErrorCode
                    && Constants.CST_ACCOUNT_EXCEPTION.equalsIgnoreCase(profileRoleErrorCode)) {
                logger.debug("CustomerAccountsAggregationService : mapCustomerRelationToAccount - CST Error {} ",
                        profileRoleErrorCode, " - Acct no. {} ", reasResp.getAccountNumber());
                cstRoleNotFoundAccounts.add(reasResp.getAccountNumber());
            }//
        }

        else {
            logger.debug("CustomerAccountsAggregationService : mapCustomerRelationToAccount - Ckecking for role in XES ");
            String xesRoleFoundError = mapXESCustomerRelationToAccount(reasResp, xesRelactedAcctList);

            if (null != xesRoleFoundError && Constants.XES_EXCEPTION.equalsIgnoreCase(xesRoleFoundError)) {
                logger.debug("CustomerAccountsAggregationService : mapCustomerRelationToAccount - CST Error {} ",
                        xesRoleFoundError, " - Acct no. {} ", reasResp.getAccountNumber());
                xesRoleNotFoundAccounts.add(reasResp.getAccountNumber());
            }//
        }
    }

    private void fetchCardCustRole(CustomerAccountsResponse reasResp, Future<Map<String, String>> cardCustRole,
            CustomerAccountKey customerAccountKey) {
        Map<String, String> mapCardCustRole = new HashMap<String, String>();
        mapCardCustRole = getCardCustRole(cardCustRole, mapCardCustRole);
        if (customerAccountKey != null && mapCardCustRole != null) {
            String key = StringUtils.join(
                    new String[] {StringUtils.stripStart(customerAccountKey.getConsumerId(), "0"),
                            StringUtils.stripStart(customerAccountKey.getAccountNumber(), "0")}, "|");
            reasResp.setCustomerRole(mapCardCustRole.get(key));
        }
    }

    private Predicate getCardRolePredicate(final String accountId) {
        Predicate predicate = new Predicate() {

            @Override
            public boolean evaluate(Object customerAccountKey) {
                return (((CustomerAccountKey) customerAccountKey).getAccountNumber().equals(accountId));
            }

        };
        return predicate;
    }

    /**
     * this method is setting up the role description as 'Sole Owner' or 'Primary Joint' or 'Secondary Joint' for SOR ID
     * = 56
     * 
     * @param reasResponseObj REAS Response
     * @param futureProfileAccountRelationshipsResponse 360 accounts reletion ship
     * @return 360 accounts customer Role
     */

    private String map360CustomerRelationToAccount(CustomerAccountsResponse reasResponseObj,
            Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse) {

        logger.debug("Enter - map360CustomerRelationToAccount method of CustomerAccountsAggregationService class");
        if (futureProfileAccountRelationshipsResponse != null && reasResponseObj != null) {
            List<ProfileRelationshipLookup> relation360AcctList = null;
            relation360AcctList = getRelation360AccountList(futureProfileAccountRelationshipsResponse,
                    relation360AcctList);

            if (relation360AcctList != null) {
                for (ProfileRelationshipLookup relation360 : relation360AcctList) {
                    if (reasResponseObj.getAccountNumber() != null && relation360 != null
                            && reasResponseObj.getAccountNumber().equals(relation360.getAccountNumber())) {

                        if (null != relation360.getErrorCd()
                                && Constants.PROFILE_ACCOUNT_EXCEPTION.equalsIgnoreCase(relation360.getErrorCd())) {

                            logger.debug(" map360CustomerRelationToAccount ROLE NOT FOUND - ACT id {} ",
                                    relation360.getAccountNumber());

                            return relation360.getErrorCd();

                        } else {
                            set360CustomerRole(reasResponseObj, relation360);

                        }
                    }
                }
            }
        }
        logger.debug("Exit - map360CustomerRelationToAccount method of CustomerAccountsAggregationService class");
        return null;
    }

    private List<ProfileRelationshipLookup> getRelation360AccountList(
            Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse,
            List<ProfileRelationshipLookup> relation360AcctList) {
        List<ProfileRelationshipLookup> newRelation360AcctList = relation360AcctList;
        try {
            newRelation360AcctList = futureProfileAccountRelationshipsResponse
                    .get(PROFILE_WAIT_TIME, PROFILE_WAIT_UNIT);
        } catch (InterruptedException e) {
            logger.error(INTERRUPTED_EXCEPTION, logger.getClass(), e);
            futureProfileAccountRelationshipsResponse.cancel(true);
        } catch (ExecutionException e) {
            logger.error(EXECUTION_EXCEPTION, logger.getClass(), e);
            futureProfileAccountRelationshipsResponse.cancel(true);
        } catch (TimeoutException e) {
            logger.error(TIMEOUT_EXCEPTION, logger.getClass(), e);
            futureProfileAccountRelationshipsResponse.cancel(true);
        }
        return newRelation360AcctList;
    }

    private Map<String, String> getCardCustRole(Future<Map<String, String>> futureMapCardCustRole,
            Map<String, String> mapCardCustRole) {
        Map<String, String> newCardCustRoleMap = mapCardCustRole;
        try {
            newCardCustRoleMap = futureMapCardCustRole.get(CARD_WAIT_TIME, Constants.WAIT_UNIT);
        } catch (InterruptedException e) {
            logger.error(INTERRUPTED_EXCEPTION, logger.getClass(), e);
            futureMapCardCustRole.cancel(Boolean.TRUE);
        } catch (ExecutionException e) {
            logger.error(EXECUTION_EXCEPTION, logger.getClass(), e);
            futureMapCardCustRole.cancel(Boolean.TRUE);
        } catch (TimeoutException e) {
            logger.error(TIMEOUT_EXCEPTION, logger.getClass(), e);
            futureMapCardCustRole.cancel(Boolean.TRUE);
        } catch (CancellationException e) {
            logger.error(CANCELLATION_EXCEPTION, logger.getClass(), e);
            futureMapCardCustRole.cancel(Boolean.TRUE);
        }
        return newCardCustRoleMap;
    }

    private void set360CustomerRole(CustomerAccountsResponse reasResponseObj, ProfileRelationshipLookup relation360) {
        String roleDesc = customerAccountsRefDataBean.getCustRelationshipDesc(
                relation360.getCustomerAccountRelationshipCode(), relation360.getOwnershipType(),
                (relation360.getTrustAccountInd() ? "Y" : "F"));
        if (reasResponseObj.getSorId() != null
                && reasResponseObj.getSorId().equalsIgnoreCase(Constants.HOME_LOAN_SORID)) {
            roleDesc = mapOwnershipTypeToRole(relation360);
        }
        if (roleDesc != null) {
            logger.debug(" map360CustomerRelationToAccount SETTING RORE - ACT id {} ", relation360.getAccountNumber(),
                    " setCustomerRole {} ", roleDesc);
            reasResponseObj.setCustomerRole(roleDesc);
            // return true;
        }

    }

    private String mapOwnershipTypeToRole(ProfileRelationshipLookup relation360) {
        String roleDesc = null;
        if (relation360.getCustomerCount() == 1 && relation360.getOwnershipType() != null
                && relation360.getOwnershipType().equalsIgnoreCase("1")) {
            roleDesc = "Sole Owner";
        } else if (relation360.getCustomerCount() == 2 && relation360.getOwnershipType() != null
                && relation360.getOwnershipType().equalsIgnoreCase("1")) {
            roleDesc = "Primary Joint";
        } else if (relation360.getCustomerCount() == 2 && relation360.getOwnershipType() != null
                && !(relation360.getOwnershipType().equalsIgnoreCase("1"))) {
            roleDesc = "Secondary Joint";
        }
        return roleDesc;
    }

    /**
     * Method sets Customer Role for XES Related Acct
     * 
     * @param reasResponseObj REAS response
     * @param futureXESRelatedAcctResponse xes accounts reponse
     * @return xes accounts customer Role
     */

    private String mapXESCustomerRelationToAccount(CustomerAccountsResponse reasResponseObj,
            Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse) {

        logger.debug("Enter - mapXESCustomerRelationToAccount method of CustomerAccountsAggregationService class");
        // boolean accountRoleFound = false;
        if (futureXESRelatedAcctResponse != null && reasResponseObj != null) {
            List<XESRelationshipResponseBean> xesRelatedAcctResponse = null;
            xesRelatedAcctResponse = getXESRelatedAcctResponse(futureXESRelatedAcctResponse, xesRelatedAcctResponse);
            if (xesRelatedAcctResponse != null) {
                String acctNum = (reasResponseObj.getAccountNumber());
                for (XESRelationshipResponseBean xesRelatedAcct : xesRelatedAcctResponse) {
                    if (reasResponseObj.getAccountNumber() != null && xesRelatedAcct != null) {
                        String xesAcctNum = xesRelatedAcct.getAccountNumber();
                        // Removes leading zeros if any
                        acctNum = acctNum.replaceAll("^0+", "");
                        xesAcctNum = xesAcctNum.replaceAll("^0+", "");

                        if (acctNum.equalsIgnoreCase(xesAcctNum)) {

                            if (null != xesRelatedAcct.getErrorCd()
                                    && Constants.XES_EXCEPTION.equalsIgnoreCase(xesRelatedAcct.getErrorCd())) {

                                logger.debug(" mapXESCustomerRelationToAccount ROLE NOT FOUND - ACT id {} ", xesAcctNum);

                                return xesRelatedAcct.getErrorCd();

                            } else {
                                setXESCustomerRole(reasResponseObj, xesRelatedAcct, xesAcctNum);
                            }
                        }

                    }

                }
            }
        }
        logger.debug("Exit - mapXESCustomerRelationToAccount method of CustomerAccountsAggregationService class");
        return null;
    }

    private List<XESRelationshipResponseBean> getXESRelatedAcctResponse(
            Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse,
            List<XESRelationshipResponseBean> xesRelatedAcctResponse) {
        List<XESRelationshipResponseBean> newXESRelatedAcctResponse = xesRelatedAcctResponse;
        try {
            newXESRelatedAcctResponse = futureXESRelatedAcctResponse.get(XES_WAIT_TIME, XES_WAIT_UNIT);
        } catch (InterruptedException e) {
            logger.error(INTERRUPTED_EXCEPTION, logger.getClass(), e);
            futureXESRelatedAcctResponse.cancel(true);
        } catch (ExecutionException e) {
            logger.error(EXECUTION_EXCEPTION, logger.getClass(), e);
            futureXESRelatedAcctResponse.cancel(true);
        } catch (TimeoutException e) {
            logger.error(TIMEOUT_EXCEPTION, logger.getClass(), e);
            futureXESRelatedAcctResponse.cancel(true);
        }
        return newXESRelatedAcctResponse;
    }

    private void setXESCustomerRole(CustomerAccountsResponse reasResponseObj,
            XESRelationshipResponseBean xesRelatedAcct, String xesAcctNum) {
        Map<String, String> relationShip = null;
        logger.debug("reasResponseObj for setXESCustomerRole sor id {}", reasResponseObj.getSorId());

        if (Constants.APPL_CD_ST.equals(xesRelatedAcct.getCustAcctToRelationshipCd())
                || Constants.APPL_CD_IM.equals(xesRelatedAcct.getCustAcctToRelationshipCd())) {
            logger.debug("CustAcctToRelationshipCd {}", xesRelatedAcct.getCustAcctToRelationshipCd());
            logger.debug("getCustAcctFromRelationshipCd {}", xesRelatedAcct.getCustAcctFromRelationshipCd());

            relationShip = customerAccountsRefDataBean.getCustRelationshipDesc(
                    xesRelatedAcct.getCustAcctFromRelationshipCd(), xesRelatedAcct.getCustAcctToRelationshipCd(),
                    xesRelatedAcct.getfISApplicationSystemCd(), reasResponseObj.getBankMarketCd());
        } else {
            logger.debug("CustAcctToRelationshipCd {}", xesRelatedAcct.getCustAcctToRelationshipCd());
            logger.debug("getCustAcctFromRelationshipCd {}", xesRelatedAcct.getCustAcctFromRelationshipCd());
            relationShip = customerAccountsRefDataBean.getCustRelationshipDesc(
                    xesRelatedAcct.getCustAcctFromRelationshipCd(), xesRelatedAcct.getCustAcctToRelationshipCd());
            logger.debug("relationShip {}", relationShip);
        }
        if (relationShip != null && relationShip.get(Constants.CUST_REL_DESC) != null) {

            logger.debug(" mapXESCustomerRelationToAccount SETTING RORE - ACT id {} ", xesAcctNum,
                    " setCustomerRole {} ", relationShip.get(Constants.CUST_REL_DESC));
            reasResponseObj.setCustomerRole(relationShip.get(Constants.CUST_REL_DESC));
        }
        logger.debug("Exit - setXESCustomerRole method of CustomerAccountsAggregationService class");
    }

    public REASResponse retrieveNicknameFromOLBR(REASResponse aggregatedReasResponse,
            Future<List<OLBResponse>> listOLBRResponse) {
        logger.debug("Enter - retrieveNicknameFromOLBR method of CustomerAccountsAggregationService class");
        List<OLBResponse> olbrResponse = getOLBRResponse(listOLBRResponse);

        if (aggregatedReasResponse != null && olbrResponse != null && !olbrResponse.isEmpty()) {
            for (CustomerAccountsResponse customerAccountResponse : aggregatedReasResponse
                    .getCustomerAccountsResponseList()) {
                for (OLBResponse nicknameResponse : olbrResponse) {
                    if ((StringUtils.stripStart(customerAccountResponse.getAccountId(), ACCOUNT_NUMBER_PADDING).equals(
                            StringUtils.stripStart(nicknameResponse.getAccountId(), ACCOUNT_NUMBER_PADDING)) && customerAccountResponse
                            .getSorId().equalsIgnoreCase(nicknameResponse.getSorId()))
                            && (StringUtils.isNotEmpty(nicknameResponse.getOlbAccountNickname()) && (StringUtils
                                    .isEmpty(customerAccountResponse.getAccountNickname())))) {

                        customerAccountResponse.setAccountNickname(nicknameResponse.getOlbAccountNickname());

                    }
                }

            }

        }
        logger.debug("Exit - retrieveNicknameFromOLBR method of CustomerAccountsAggregationService class");
        return aggregatedReasResponse;

    }

    private List<OLBResponse> getOLBRResponse(Future<List<OLBResponse>> listOLBRResponse) {
        logger.debug("Enter - getOLBRResponse method of CustomerAccountsAggregationService class");
        List<OLBResponse> responsefromOLBR = null;

        try {
            responsefromOLBR = listOLBRResponse.get(WAIT_TIME, WAIT_UNIT);

        } catch (InterruptedException e) {
            logger.error(INTERRUPTED_EXCEPTION, logger.getClass(), e);
            listOLBRResponse.cancel(true);
        } catch (ExecutionException e) {
            logger.error(EXECUTION_EXCEPTION, logger.getClass(), e);
            listOLBRResponse.cancel(true);
        } catch (TimeoutException e) {
            logger.error(TIMEOUT_EXCEPTION, logger.getClass(), e);
            listOLBRResponse.cancel(true);
        } catch (NotFoundException e) {
            listOLBRResponse.cancel(true);
        }
        logger.debug("Exit - getOLBRResponse method of CustomerAccountsAggregationService class");
        return responsefromOLBR;

    }

    /**
     * Method sets Account Nickname for ALL LOBs
     * 
     * @param aggregatedReasResponse REAS response
     * @param listOecpPrefResponse list of nicknames from oECP
     * @return customers accounts response with Nickname
     */

    public REASResponse retrieveNicknameFromOecp(REASResponse aggregatedReasResponse,
            Future<List<OecpPreferResponse>> listOecpPrefResponse) {
        logger.debug("Enter - retrieveNicknameFromOecp method of CustomerAccountsAggregationService class");
        List<OecpPreferResponse> oecpResponse = getOECPResponse(listOecpPrefResponse);

        if (aggregatedReasResponse != null && oecpResponse != null && !oecpResponse.isEmpty()) {
            for (CustomerAccountsResponse customerAccountResponse : aggregatedReasResponse
                    .getCustomerAccountsResponseList()) {

                for (OecpPreferResponse oecpPrefResponse : oecpResponse) {
                    if ((StringUtils.stripStart(customerAccountResponse.getAccountId(), ACCOUNT_NUMBER_PADDING)
                            .equals(StringUtils.stripStart(oecpPrefResponse.getAccountId(), ACCOUNT_NUMBER_PADDING)))
                            && (customerAccountResponse.getSorId().equals(oecpPrefResponse.getSorId()))
                            && (StringUtils.isNotEmpty(oecpPrefResponse.getAccountNickname()))) {

                        customerAccountResponse.setAccountNickname(oecpPrefResponse.getAccountNickname());

                    }
                }

            }

        }
        logger.debug("Exit - retrieveNicknameFromOecp method of CustomerAccountsAggregationService class");
        return aggregatedReasResponse;
    }

    private List<OecpPreferResponse> getOECPResponse(Future<List<OecpPreferResponse>> listOECPResponse) {
        logger.debug("Enter - getOECPResponse method of CustomerAccountsAggregationService class");
        List<OecpPreferResponse> responsefromOECP = null;

        try {
            responsefromOECP = listOECPResponse.get(OECP_WAIT_TIME, OECP_WAIT_UNIT);

        } catch (InterruptedException e) {
            logger.error(INTERRUPTED_EXCEPTION, logger.getClass(), e);
            listOECPResponse.cancel(true);
        } catch (ExecutionException e) {
            logger.error(EXECUTION_EXCEPTION, logger.getClass(), e);
            listOECPResponse.cancel(true);
        } catch (TimeoutException e) {
            logger.error(TIMEOUT_EXCEPTION, logger.getClass(), e);
            listOECPResponse.cancel(true);
        } catch (NotFoundException e) {
            listOECPResponse.cancel(true);
        }
        logger.debug("Exit - getOECPResponse method of CustomerAccountsAggregationService class");
        return responsefromOECP;

    }
}
