package com.capitalone.api.customersaccounts.service.pojo;

import java.util.List;

import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRoleTypes;

public class CSTBusinessCustomerResponse {

    private List<BusinessCustomerRoleTypes> role;

    private String relationshipCode;

    private String trustIndicator;

    public List<BusinessCustomerRoleTypes> getRole() {
        return role;
    }

    public void setRole(List<BusinessCustomerRoleTypes> role) {
        this.role = role;
    }

    public String getRelationshipCode() {
        return relationshipCode;
    }

    public void setRelationshipCode(String relationshipCode) {
        this.relationshipCode = relationshipCode;
    }

    public String getTrustIndicator() {
        return trustIndicator;
    }

    public void setTrustIndicator(String trustIndicator) {
        this.trustIndicator = trustIndicator;
    }

}
