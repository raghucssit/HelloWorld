package com.capitalone.api.customersaccounts.service.convert.response;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs.AcctListInfo;

/**
 * This class is the response Converter for XESRelatedAcctIS for Safe Deposit Box
 * 
 */

@Profile
@Trace
@Named
public class SafeDepositeBoxResponseConverter extends ConversionServiceAwareConverter<AcctListInfo, REASResponse> {
    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    private static final int START_OF_REGION = 17;

    private static final int END_OF_REGION = 20;
    
    private static final int START_OF_TRADEAREA = 28;
    
    private static final int END_OF_TRADEAREA = 31;

    private static final int START_OF_SAFEBOXNUMBER = 46;
    /**
     * Converts native response of safeDepositIS to REASResponse type
     * 
     * @param acctListInfo response of safeDepositIS
     * @return safe deposit response
     */
    @Override
    public REASResponse convert(AcctListInfo acctListInfo) {
        logger.debug("SafeDepositeBoxResponseConverter  : convert -> Start");
        REASResponse response = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();

        List<CustomerAccountsResponse> responseList = new ArrayList<CustomerAccountsResponse>();

        customerAccountsResponse.setSorId(Constants.SOR_ID_SDB.toString());
        if (null != acctListInfo.getProdID()) {
            customerAccountsResponse.setProductTypeCode(acctListInfo.getProdID());
        }
        if (null != acctListInfo.getProdDesc()) {
            customerAccountsResponse.setProductTypeDescription(acctListInfo.getProdDesc());
        }

        // confirm the length
        if (acctListInfo.getAccountRelationshipID() != null
                && acctListInfo.getAccountRelationshipID().length() >= END_OF_TRADEAREA) {
            logger.debug("SafeDepositeBoxResponseConverter  : AcctId  {}", acctListInfo.getAcctID());
            StringBuilder displayAccountNumber = new StringBuilder(acctListInfo.getAccountRelationshipID().substring(
                    START_OF_REGION, END_OF_REGION));
            displayAccountNumber.append(acctListInfo.getAccountRelationshipID().substring(
            		START_OF_TRADEAREA, END_OF_TRADEAREA));
            if (acctListInfo.getAccountRelationshipID().length() >= START_OF_SAFEBOXNUMBER) {
                displayAccountNumber.append(acctListInfo.getAccountRelationshipID().substring(START_OF_SAFEBOXNUMBER,
                        acctListInfo.getAccountRelationshipID().length()));
            }

            customerAccountsResponse.setDisplayAccountNumber(displayAccountNumber.toString());
        }
        if (acctListInfo.getBankNum() != null) {
            customerAccountsResponse.setBankNumber(acctListInfo.getBankNum());
            customerAccountsResponse.setBankNumberDescription(acctListInfo.getBankNum());
        }
        customerAccountsResponse.setCurrencyCode(Constants.CURRENCY_CODE_USA);

        Map<String, String> relationShip = customerAccountsRefDataBean.getCustRelationshipDesc(
                acctListInfo.getCustAcctFromRelationshipCd(), acctListInfo.getCustAcctToRelationshipCd());
        logger.debug("relationShip {}", relationShip);
        if (relationShip != null && relationShip.get(Constants.CUST_REL_DESC) != null) {

            logger.debug(" mapXESCustomerRelationToAccount SETTING ROLE - ACT id : {} ", acctListInfo.getAcctID()
                    + " setCustomerRole : " + relationShip.get(Constants.CUST_REL_DESC));
            customerAccountsResponse.setCustomerRole(relationShip.get(Constants.CUST_REL_DESC));
        }

        responseList.add(customerAccountsResponse);

        response.setCustomerAccountsResponseList(responseList);
        logger.debug("SafeDepositeBoxResponseConverter  : convert -> Exit");
        return response;
    }

}
