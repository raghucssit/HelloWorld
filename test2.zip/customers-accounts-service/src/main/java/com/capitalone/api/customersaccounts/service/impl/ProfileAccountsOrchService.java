/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.ProfileAccountRelationshipsDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

/**
 * @author RQA254
 * 
 *         This class is calling DAO impl of ProfileAccountRelationships after filtering for SOR ID's 56 or 185
 * 
 */

@Profile
@Trace
@Named
public class ProfileAccountsOrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    private static final int WAIT_TIME = 5;

    private static final TimeUnit WAIT_UNIT = TimeUnit.SECONDS;

    @Inject
    private ProfileAccountRelationshipsDao profileAccountRelationshipsDAO;

    /**
     * Method for retrieving ProfileRelationshipLookup objects for SOR IDs 56 or 185
     * 
     * @param customerAccountsRequest input request
     * @param context holds the user Context
     * @return Customers account response
     * 
     */


    @Async
    public Future<List<ProfileRelationshipLookup>> execute(final CustomerAccountsRequest customerAccountsRequest,
            EPFContext context) {

        logger.debug("Enter - execute method of ProfileAccountsOrchService class");
        List<Future<ProfileRelationshipLookup>> futureList = new ArrayList<Future<ProfileRelationshipLookup>>();
        List<ProfileRelationshipLookup> finalResponseList = new ArrayList<ProfileRelationshipLookup>();
        List<String> repeatitionFilter = new ArrayList<String>();

        for (final CustomerAccountKey key : customerAccountsRequest.getCustomerAccountKeyList()) {
            if ((Constants.SORIDLIST_360.contains(key.getSorId()))
                    && (!repeatitionFilter.contains(key.getAccountNumber()))) {
                // Filter out the calls for same account
                Future<ProfileRelationshipLookup> profileAcctResponse = profileAccountRelationshipsDAO.retrieve(
                        EPFContextContainer.getContext(), key.getConsumerId(), key.getAccountNumber(),
                        customerAccountsRequest.getApiKey());
                futureList.add(profileAcctResponse);
                repeatitionFilter.add(key.getAccountNumber());

            }
        }

        for (Future<ProfileRelationshipLookup> futureProfileAcctResponse : futureList) {
            try {
                ProfileRelationshipLookup res = (ProfileRelationshipLookup) futureProfileAcctResponse.get(WAIT_TIME,
                        WAIT_UNIT);
                finalResponseList.add(res);
            } catch (InterruptedException ex) {
                logger.error("InterruptedException in Class {}", logger.getClass(), ex);
                futureProfileAcctResponse.cancel(true);
            } catch (ExecutionException ex) {
                logger.error("ExecutionException in Class {}", logger.getClass(), ex);
                futureProfileAcctResponse.cancel(true);
            } catch (TimeoutException ex) {
                logger.error("TimeoutException in Class {}", logger.getClass(), ex);
                futureProfileAcctResponse.cancel(true);
            }
        }
        logger.debug("Exit - execute method of ProfileAccountsOrchService class");
        return new AsyncResult<List<ProfileRelationshipLookup>>(finalResponseList);
    }
}