/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.dao.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.exception.ApiBusinessException;
import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.exception.ApiSystemException;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.commons.services.util.EPFContextAssist;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.CustomerAccountsKeyDao;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.entity.ECRCustomerRelationshipsEntity;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.CustomerReferenceId;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRq;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails;
import com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs;
import com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd;
import com.capitalone.ecrcustomerrelationshipsisv2.v2.ECRCustomerRelationshipsISV2Soap;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

/**
 * DAO for ECR Calls.
 * 
 * @author Generated
 * @since 1.0
 */
@Profile
@Trace
@Named
public class ECRDaoImpl extends AbstractBaseService implements CustomerAccountsKeyDao {

    @Inject
    private ConversionService conversionService;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Inject
    private ReferenceIdEncoder encoder;


    @Inject
    private ECRCustomerRelationshipsEntity ecrCustomerRelationshipsEntity;

	@Inject
	private ECRCustomerRelationshipsISV2Soap ecrCustomerRelationshipISV2;

	private static final String ACCOUNT_NUMBER_PADDING = "0";

    /**
     * Retrieving CustomerAccountsKey Based On ProfileReferenceId
     * 
     * @param request customerReferenceID or profileReferenceID
     * @return List of CustomerAccountKey
     * 
     */


    @Override
    public List<CustomerAccountKey> retrieveCustomerAccountsKeyBasedOnProfileReferenceId(CustomerAccountsRequest request) {
        
        logger.debug("Enter - retrieveCustomerAccountsKeyBasedOnProfileReferenceId method of ECRDaoImpl class");
        List<CustomerAccountKey> customerAccountsKeyList = null;

		String detailId = null;
		detailId = ApiErrorCode.CONFLICT;
		ApiErrorCode error = new ApiErrorCode();
		error.setId(detailId);
		logger.debug("Calling convert method of ConversionService class");
		String ssoid = "";
		if (null != request.getProfileReferenceId()
				&& StringUtils.isNotBlank(request.getProfileReferenceId()
						.getSSOID())) {
			ssoid = request.getProfileReferenceId().getSSOID();
		}

		CustIdentityMatchedAccountsInqRs.Cmd resCmd = null;
		Cmd v2ResCmd = null;
		CustIdentityMatchedAccountsInqRs nativeResponse = null;
		CustIdentityMatchedAccountsDetailsInqRs nativeResponseV2=null;
		StatType stat = null;
		
		boolean isCachedVersion=request.getEcrCachedConfig().contains(request.getAppVersion());
			
		if (!isCachedVersion) {
		    logger.debug("Invoking ECRCustomerRelationshipIS");
			CustIdentityMatchedAccountsInqRq nativereq = conversionService
					.convert(request, CustIdentityMatchedAccountsInqRq.class);
			nativeResponse = ecrCustomerRelationshipsEntity
					.custIdentityMatchedAccountsInq(nativereq, ssoid);
			resCmd = nativeResponse.getCmd();
			stat = resCmd.getStat();	
		} else {
		    logger.debug("Invoking ECRCustomerRelationshipISV2");
			com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRq nativeRequestV2 = conversionService.convert(request,com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRq.class);
			nativeResponseV2 = ecrCustomerRelationshipISV2.custIdentityMatchedAccountsDetailsInq(nativeRequestV2);
			v2ResCmd = nativeResponseV2.getCmd();
			stat = v2ResCmd.getStat();		
		}

		if (resCmd == null && v2ResCmd==null) {
			return customerAccountsKeyList;
		}

		if (stat == null) {
			return customerAccountsKeyList;
		}

		logger.debug("stat.getStatCd() {}",stat.getStatCd());
		if (stat.getStatCd() == Constants.NO_RECORDS_MATCH_SELECTION_CRITERIA_1) {
			logger.debug("No Accounts found in ECR");
			error.setId(Constants.ERROR_NO_ACCOUNTS_FOUND);
			error.setDeveloperText(Constants.NO_ACCOUNT_FOUND_IN_ECR_201934);
			ApiBusinessException ex = new ApiBusinessException(error,
					Constants.INTERNAL_SERVER_ERROR_CODE);
			throw ex;
		}

		customerAccountsUtil.checkResponseForErrors(stat);
		
		
		if (!isCachedVersion) {
			customerAccountsKeyList = retrieveECRMatchedAccountsV1(request, error, resCmd,
                    nativeResponse);
		} else {
			customerAccountsKeyList = retrieveECRMatchedAccountsV2(request, error, v2ResCmd,
                    nativeResponseV2);
		}		
		
		logger.debug("Exit - retrieveCustomerAccountsKeyBasedOnProfileReferenceId method of ECRDaoImpl class");
		return customerAccountsKeyList;
	}

    private List<CustomerAccountKey> retrieveECRMatchedAccountsV2(CustomerAccountsRequest request,
            ApiErrorCode error, Cmd v2ResCmd,
            com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs nativeResponseV2) {
        List<CustomerAccountKey> customerAccountsKeyList = null;
        if (v2ResCmd.getECRMatchedAccounts() != null
        		&& v2ResCmd.getECRMatchedAccounts().getEntSvcgGrping() != null) {
        	if (v2ResCmd.getECRMatchedAccounts().getEntSvcgGrping().size() > 1) {
        		error.setId(Constants.ERROR_MULTIPLE_ESCID_BLOCKS_FOUND);
        		error.setDeveloperText(Constants.MULTIPLE_ESCID_BLOCKS_FOUND_MSG_200900);
        		ApiBusinessException ex = new ApiBusinessException(error,
        				Constants.INTERNAL_SERVER_ERROR_CODE);
        		throw ex;
        	} else {
        		getNativeCustIdForV2(request, error, nativeResponseV2);

        		customerAccountsKeyList = getEntSvcgGrpingSingleItemForV2(
        				request, nativeResponseV2);
        	}
        }
        return customerAccountsKeyList;
    }

    private List<CustomerAccountKey> retrieveECRMatchedAccountsV1(CustomerAccountsRequest request,
            ApiErrorCode error,
            CustIdentityMatchedAccountsInqRs.Cmd resCmd, CustIdentityMatchedAccountsInqRs nativeResponse) {
        List<CustomerAccountKey> customerAccountsKeyList = null;
        if (resCmd.getECRMatchedAccounts() != null
        		&& resCmd.getECRMatchedAccounts().getEntSvcgGrping() != null) {

        	if (resCmd.getECRMatchedAccounts().getEntSvcgGrping().size() > 1) {
        		error.setId(Constants.ERROR_MULTIPLE_ESCID_BLOCKS_FOUND);
        		error.setDeveloperText(Constants.MULTIPLE_ESCID_BLOCKS_FOUND_MSG_200900);
        		ApiBusinessException ex = new ApiBusinessException(error,
        				Constants.INTERNAL_SERVER_ERROR_CODE);
        		throw ex;
        	} else {
        		getNativeCustId(request, error, nativeResponse);

        		customerAccountsKeyList = getEntSvcgGrpingSingleItem(
        				request, nativeResponse);
        	}
        }
        return customerAccountsKeyList;
    }

	private List<CustomerAccountKey> getEntSvcgGrpingSingleItemForV2(
			CustomerAccountsRequest request,
			com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs nativeResponseV2) {
		logger.debug("Enter - getEntSvcgGrpingSingleItemForV2 method of ECRDaoImpl class");
		List<CustomerAccountKey> customerAccountsKeyList = null;
		com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping entSvcgGrpingSingleItem = nativeResponseV2.getCmd()
				.getECRMatchedAccounts().getEntSvcgGrping().get(0);
		if (entSvcgGrpingSingleItem != null
				&& CollectionUtils.isNotEmpty(entSvcgGrpingSingleItem
						.getAcctDetails())) {
			customerAccountsKeyList = extractAccountDetailsV2(request,
					entSvcgGrpingSingleItem,
					request.getServicableAccountKeyList());
		}
		logger.debug("Exit - getEntSvcgGrpingSingleItemForV2 method of ECRDaoImpl class");
		return customerAccountsKeyList;
	}

	private List<CustomerAccountKey> extractAccountDetailsV2(
			CustomerAccountsRequest request,
			com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping entSvcgGrpingSingleItem,
			List<CustomerAccountKey> servicableAccountKeyList) {
		logger.debug("Enter - extractAccountDetailsV2 method of ECRDaoImpl class");
		List<CustomerAccountKey> customerAccountsKeyList = new ArrayList<CustomerAccountKey>();

		CustomerAccountKey customerAccountKey = null;
		if (entSvcgGrpingSingleItem.getEntSvcgCustID() !=null) {
			createCustomerReferenceURL(new CustomerReferenceId(
					entSvcgGrpingSingleItem.getEntSvcgCustID()));
			request.setCustomerESCID(entSvcgGrpingSingleItem.getEntSvcgCustID());
		}

		for (com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails acctDetails : entSvcgGrpingSingleItem.getAcctDetails()) {
			customerAccountKey = conversionService.convert(acctDetails,
					CustomerAccountKey.class);
			if (request.getAppVersion()
					.equalsIgnoreCase(Constants.APP_VERSION3)) {
				customerAccountsKeyList.add(customerAccountKey);
			} else {
				if (acctDetails.isDrvrAcctInd()
						&& verifywithServiceableaccounts(customerAccountKey,
								servicableAccountKeyList)) {

					customerAccountsKeyList.add(customerAccountKey);

				}
			}
		}

		logger.debug("Exit - extractAccountDetailsV2 method of ECRDaoImpl class {}",customerAccountsKeyList);
		return customerAccountsKeyList;
	}

	private void getNativeCustIdForV2(
			CustomerAccountsRequest request,
			ApiErrorCode error,
			com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs nativeResponseV2) {
		logger.debug("Enter - getNativeCustIdForV2 method of ECRDaoImpl class");
		String nativeCustId = CollectionUtils.isNotEmpty(nativeResponseV2
				.getCmd().getECRMatchedAccounts().getEntSvcgGrping()) ? nativeResponseV2
				.getCmd().getECRMatchedAccounts().getEntSvcgGrping().get(0)
				.getEntSvcgCustID()
				: null;

		if (nativeCustId != null
				&& (request.getCustomerReferenceId() !=null)
				&& !nativeCustId.equalsIgnoreCase(request
						.getCustomerReferenceId()
						.getEnterpriseServicingCustomerId())) {
			error.getErrorDetails()
					.add(customerAccountsUtil
							.constructApiErrorCode(
									Constants.ProfileReferenceID_CustomerReferenceID_DIFFER,
									null,
									Constants.REQUEST_VALIDATION_INVALID_INPUT_MSG_120768));
			logger.debug("Exit - getNativeCustIdForV2 method of ECRDaoImpl class");
			throw new ApiBusinessException(error);
		}
	}

	private List<CustomerAccountKey> getEntSvcgGrpingSingleItem(
			CustomerAccountsRequest request,
			CustIdentityMatchedAccountsInqRs nativeResponse) {
		logger.debug("Enter - getEntSvcgGrpingSingleItem method of ECRDaoImpl class");
		List<CustomerAccountKey> customerAccountsKeyList = null;
		EntSvcgGrping entSvcgGrpingSingleItem = nativeResponse.getCmd()
				.getECRMatchedAccounts().getEntSvcgGrping().get(0);

		if (entSvcgGrpingSingleItem != null
				&& CollectionUtils.isNotEmpty(entSvcgGrpingSingleItem
						.getAcctDetails())) {
			customerAccountsKeyList = extractAccountDetails(request,
					entSvcgGrpingSingleItem,
					request.getServicableAccountKeyList());
		}
		logger.debug("Exit - getEntSvcgGrpingSingleItem method of ECRDaoImpl class {}",customerAccountsKeyList);
		return customerAccountsKeyList;
	}

	private void getNativeCustId(CustomerAccountsRequest request,
			ApiErrorCode error, CustIdentityMatchedAccountsInqRs nativeResponse) {
		logger.debug("Enter - getNativeCustId method of ECRDaoImpl class");
		String nativeCustId = CollectionUtils.isNotEmpty(nativeResponse
				.getCmd().getECRMatchedAccounts().getEntSvcgGrping()) ? nativeResponse
				.getCmd().getECRMatchedAccounts().getEntSvcgGrping().get(0)
				.getEntSvcgCustID()
				: null;

        if (nativeCustId != null && (request.getCustomerReferenceId() != null)
                && !nativeCustId.equalsIgnoreCase(request.getCustomerReferenceId().getEnterpriseServicingCustomerId())) {
            error.getErrorDetails().add(
                    customerAccountsUtil.constructApiErrorCode(Constants.ProfileReferenceID_CustomerReferenceID_DIFFER,
                            null, Constants.REQUEST_VALIDATION_INVALID_INPUT_MSG_120768));
            logger.debug("Exit - getNativeCustId method of ECRDaoImpl class");
            throw new ApiBusinessException(error);
        }
    }

    private List<CustomerAccountKey> extractAccountDetails(CustomerAccountsRequest request,
            EntSvcgGrping entSvcgGrpingSingleItem, List<CustomerAccountKey> serviceableaccounts) {
        logger.debug("Enter - extractAccountDetails method of ECRDaoImpl class");
        List<CustomerAccountKey> customerAccountsKeyList = new ArrayList<CustomerAccountKey>();
        
        CustomerAccountKey customerAccountKey = null;
        if (entSvcgGrpingSingleItem.getEntSvcgCustID() != null) {
            createCustomerReferenceURL(new CustomerReferenceId(entSvcgGrpingSingleItem.getEntSvcgCustID()));
            request.setCustomerESCID(entSvcgGrpingSingleItem.getEntSvcgCustID());
        }

        for (AcctDetails acctDetails : entSvcgGrpingSingleItem.getAcctDetails()) {
        	customerAccountKey = conversionService.convert(acctDetails, CustomerAccountKey.class);
        	if (request.getAppVersion().equalsIgnoreCase(Constants.APP_VERSION3)) {                
                customerAccountsKeyList.add(customerAccountKey);
            } else {
                if (acctDetails.isDrvrAcctInd()
                        && verifywithServiceableaccounts(customerAccountKey, serviceableaccounts)) {

                    customerAccountsKeyList.add(customerAccountKey);

                }
            }
        }
       
        logger.debug("Exit - extractAccountDetails method of ECRDaoImpl class");
        return customerAccountsKeyList;
    }

    private Boolean verifywithServiceableaccounts(CustomerAccountKey customerAccountKey,
            List<CustomerAccountKey> servicableaccounts) {
        
        logger.debug("Enter - verifywithServiceableaccounts method of ECRDaoImpl class");
       if (CollectionUtils.isEmpty(servicableaccounts)){ 
            return true;
        }
        for (CustomerAccountKey servicableaccount : servicableaccounts) {
            if ((StringUtils.stripStart(customerAccountKey.getAccountNumber(), ACCOUNT_NUMBER_PADDING)
                    .equals(StringUtils.stripStart(servicableaccount.getAccountNumber(), ACCOUNT_NUMBER_PADDING)))
                    && customerAccountKey.getSorId().equals(servicableaccount.getSorId())) {
                return true;
            }
        }
        logger.debug("Exit - verifywithServiceableaccounts method of ECRDaoImpl class");
        return false;
    }

    
    /**
     * Creating of CustomerReferenceURL
     * 
     * @param customerRefID customerReference ID
     * 
     */


    @Override
    public void createCustomerReferenceURL(CustomerReferenceId customerRefID) {
        logger.debug("Enter - createCustomerReferenceURL method of ECRDaoImpl class");
        logger.debug("createCustomerReferenceURL : customerRefID is {} ", customerRefID);

        // Use ReferenceIdEncoder
        String encodedCustomerReferenceId = encodeCustomerReferenceId(customerRefID);
        String url = "/customers/" + encodedCustomerReferenceId + "/accounts";

        EPFContextAssist.getContext().setAttribute("EntSvcgCustID", url);
        EPFContextAssist.getContext().setAttribute("CustID", encodedCustomerReferenceId);

        logger.debug("Exit - createCustomerReferenceURL method of ECRDaoImpl class");
    }

    private String encodeCustomerReferenceId(CustomerReferenceId customerReferenceId) {
        // TODO: Hack Alert: Need another method in {@link com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder}
        // that does not URL encode.
        try {
            return URLDecoder.decode(encoder.encode(customerReferenceId.getReferenceId()), "UTF-8");

        } catch (UnsupportedEncodingException e) {
            logger.error("Could not URL decode encoded customer reference ID", e);
            throw new ApiSystemException(e);
        }
    }


}