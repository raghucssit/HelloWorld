package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.XESTDAISDAO;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.xestdais.v1.AcctInqISRq;
import com.capitalone.xestdais.v1.AcctInqISRs;
import com.capitalone.xestdais.v1.XESTDAISSoap;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Profile
@Trace
@Named
public class XESTDAISDAOImpl extends AbstractBaseService implements XESTDAISDAO {

    @Inject
    private XESTDAISSoap xestdaisSoap;

    @Inject
    private ConversionService conversionService;

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    /**
     * Getting Retail ST Accounts
     * 
     * @param context holds the request context
     * @param customerAccountKey holds the list of accounts
     * @return list of accounts details
     * 
     */
    @Override
    @Async
    public Future<REASResponse> getSTAccountDetails(EPFContext context, CustomerAccountKey customerAccountKey) {
        logger.debug("Enter - getSTAccountDetails method of XESTDAISDAO");
        REASResponse response = new REASResponse();
        AcctInqISRs acctInqISRs = null;
        List<CustomerAccountsResponse> listCustomerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = null;
        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();
        StatType stat = null;
        AcctInqISRq acctInqISRq = conversionService.convert(customerAccountKey, AcctInqISRq.class);
        try {
            acctInqISRs = xestdaisSoap.acctInq(acctInqISRq);
        }

        catch (Exception ex) {
            logger.error("Exception while making call to XESTDAIS {}", ex);
            addnStatFail.setNativeErrorCd(Constants.XPRESS_CONNECT_ERROR);
            addnStatFail.setStatDesc(Constants.XPRESS_SERVICE_DOWN_STAT_DESC.concat(CustomerAccountsUtil
                    .constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(), customerAccountKey.getSorId())));
            addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
            addnStatFail.setAccountId(customerAccountKey.getAccountNumber());
            addnStatFailList.add(addnStatFail);
            response.setAddStatList(addnStatFailList);
            response.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));

        }
        if (null != acctInqISRs && null != acctInqISRs.getCmd()) {
            customerAccountsResponse = conversionService.convert(acctInqISRs, CustomerAccountsResponse.class);

            if (customerAccountsResponse != null) {
                customerAccountsResponse.setSorId(customerAccountKey.getSorId().toString());
                customerAccountsResponse.setProductTypeCode(customerAccountsRefDataBean.getProductTypeCode(
                        Short.valueOf(customerAccountsResponse.getSorId()), acctInqISRs.getCmd()
                                .getTimeDepositAcctInq().getBankAcctTypeCd()));
                customerAccountsResponse.setProductTypeDescription(customerAccountsRefDataBean
                        .getProductTypeDescription(customerAccountsResponse.getProductTypeCode()));

                customerAccountsResponse.setBusinessLine(customerAccountsRefDataBean.getBusinessLine(
                        customerAccountsResponse.getProductTypeCode(), String.valueOf(customerAccountKey.getSorId())));
                listCustomerAccountsResponses.add(customerAccountsResponse);
            }

            stat = acctInqISRs.getCmd().getStat();

            response.setCustomerAccountsResponseList(listCustomerAccountsResponses);
            response.setAddStatList(customerAccountsUtil.getAdditionalStat(stat, customerAccountKey));
        }
        logger.debug("Exit - getSTAccountDetails method of XESTDAISDAO {}", response.getAddStatList());
        return new AsyncResult<REASResponse>(response);

    }

}
