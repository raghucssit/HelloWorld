package com.capitalone.api.customersaccounts.service.convert.request;

import javax.annotation.Resource;
import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xestdais.v1.AcctInqISRq;

@Profile
@Trace
@Named
public class XESTDAISRqConverter extends ConversionServiceAwareConverter<CustomerAccountKey, AcctInqISRq> {

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;
    /**
     * Converts the CustomerAccountskey to AcctInqISRq(XES req) type
     * 
     * @param request customers accounts information
     * @return input Request for XES
     */
    @Override
    public AcctInqISRq convert(CustomerAccountKey request) {
        logger.debug("Enter - convert method of XESTDAISRqConverter class");
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        AcctInqISRq.Cmd cmd = new AcctInqISRq.Cmd();

        cmd.setAcctID(request.getAccountNumber());
        // REQUIRED field for schema, Must pass empty string. Verified in BankDepositAccountBLS
        cmd.setBankAcctTypeCd("");
        cmd.setBankNum(customerAccountsRefDataBean.getBankNumberRetail(String.valueOf(request.getSorId())));

        acctInqISRq.setCmd(cmd);
        logger.debug("Enter - convert method of XESTDAISRqConverter class");
        return acctInqISRq;
    }
}
