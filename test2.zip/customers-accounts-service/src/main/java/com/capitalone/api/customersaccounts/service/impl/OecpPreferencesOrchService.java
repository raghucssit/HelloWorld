package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.dao.OecpPreferencesDefaultDao;
import com.capitalone.api.customersaccounts.service.api.HystrixCommandService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.epf.context.model.EPFContext;

@Profile
@Trace
@Named
public class OecpPreferencesOrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private HystrixCommandService hystrixCommandService;

    private static final int WAIT_TIME = 500;

    private static final TimeUnit WAIT_UNIT = TimeUnit.MILLISECONDS;

    @Inject
    private OecpPreferencesDefaultDao oecpPreferencesDefaultDAO;

    /**
     * Method for retrieving oECP Nickname
     * 
     * @param customerAccountsRequest input request
     * @param context holds the user Context
     * @return oECP Nickname response
     * 
     */
    @Async
    public Future<List<OecpPreferResponse>> execute(CustomerAccountsRequest customerAccountsRequest, EPFContext context) {

        logger.debug("Enter -- execute method of OecpPreferencesOrchService");

        List<Future<List<OecpPreferResponse>>> oecpPreferResponse = new ArrayList<Future<List<OecpPreferResponse>>>();
        List<OecpPreferResponse> oecpPreferFuturesResponse = new ArrayList<OecpPreferResponse>();
        if (!StringUtils.isEmpty(customerAccountsRequest.getCustomerESCID())) {
            try {
                if (customerAccountsRequest.isAccountNickNameHystrixEnabled()) {
                    // Call Hystrix DAO Impl
                    logger.debug("Proceeding to hystrix for oecp nickname");
                    oecpPreferResponse.add(hystrixCommandService.retrieveAccountNickname(context,
                            customerAccountsRequest));
                } else {
                    // Call default DAO Impl.
                    logger.debug("Skipping hystrix for oecp nickname");
                    oecpPreferResponse.add(oecpPreferencesDefaultDAO.retrieveAccountNickname(context,
                            customerAccountsRequest.getCustomerESCID()));
                }
                
            } catch (Exception e) {
                logger.debug("Error in OecpPreferencesOrchService");
            }
        }

                populateoecpPreferFuturesRes(oecpPreferFuturesResponse, oecpPreferResponse);
                
        logger.debug("Exit - execute method of OecpPreferencesOrchService class oecpPreferFuturesResponse");

        return new AsyncResult<List<OecpPreferResponse>>(oecpPreferFuturesResponse);
    }

    private void populateoecpPreferFuturesRes(List<OecpPreferResponse> oecpResponseList,
            List<Future<List<OecpPreferResponse>>> oecpPreferResponse) {
        for (Future<List<OecpPreferResponse>> oecpresponse : oecpPreferResponse) {

            try {
                oecpResponseList.addAll(oecpresponse.get(WAIT_TIME, WAIT_UNIT));

            } catch (InterruptedException ex) {
                logger.error("InterruptedException in Class {}", logger.getClass(), ex);
                oecpresponse.cancel(true);
            } catch (ExecutionException ex) {
                logger.error("ExecutionException in Class {}", logger.getClass(), ex);
                oecpresponse.cancel(true);
            } catch (TimeoutException ex) {
                logger.error("TimeoutException in Class {}", logger.getClass(), ex);
                oecpresponse.cancel(true);
            }

        }

    }

}
