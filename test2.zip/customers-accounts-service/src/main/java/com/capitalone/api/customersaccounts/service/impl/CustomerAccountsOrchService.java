/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.impl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.dao.CustomerAccountSummaryDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsOrchResponse;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.epf.context.model.EPFContextContainer;

/**
 * @author RQA254
 * 
 */
@Profile
@Trace
@Named
public class CustomerAccountsOrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private CustomerAccountSummaryDao enterpriseAccountSummarySyncOrchDAO;

    @Inject
    private ProfileAccountsOrchService profileAccountsOrchService;

    @Inject
    private XESRelatedAccountsOrchService xesRelatedAccountsOrchService;

    @Inject
    private AutoLoansAccountsOrchService autoLoansAccountsOrchService;

    @Inject
    private ProfileAccount360OrchService profileAccount360OrchService;

    @Inject
    private CreditCardAccountSummaryOrchService creditCardAccountSummaryOrchService;

    @Inject
    private SafeDepoBoxAccountSummaryOrchService safeDepoBoxAccountSummaryOrchService;

    @Inject
    private HomeLoansAccountsOrchService homeLoansAccountsOrchService;

    @Inject
    private OecpPreferencesOrchService oecpPreferencesOrchService;

    @Inject
    private XESDDAISOrchService xesDDAISOrchService;

    @Inject
    private XESTDAISOrchService xesTDAISOrchService;

    @Inject
    private LoanAccountSummaryOrchService loanAccountSummaryOrchService;

    @Inject
    private ODSBrokerageAccountsISOrchService odsBrokerageAccountsISOrchService;

    @Inject
    private OLBAccountPreferencesISOrchService accountPreferencesISOrchService;

    @Inject
    private CapitalOneInvestingAccountOrchService capitalOneInvestingAccountOrchService;

    @Inject
    private MongoOecpPreferencesOrchService mongoOecpPreferencesOrchService;

    @Inject
    private CustInfoDLSOrchService custInfoDLSOrchService;

    private static final int WAIT_TIME = 30;

    private static final TimeUnit WAIT_UNIT = TimeUnit.SECONDS;

    /**
     * This Method is calling all service implementation class and setting Future responses to
     * CustomerAccountsOrchResponse
     * 
     * @param customerAccountsRequest customers accounts input
     * @return All LOB ORCH Response
     * 
     */

    public CustomerAccountsOrchResponse execute(CustomerAccountsRequest customerAccountsRequest) {

        logger.debug("Enter - execute method of CustomerAccountsOrchService class");
        Future<REASResponse> futureReasResponse = null;
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = null;
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = null;
        Future<Map<String, String>> futureCustInfoDLSRes = null;
        Future<REASResponse> futureCOIAccountResponse = null;
        Future<List<String>> futureMongoOECPPreferencesResponses = null;

        logger.debug("Calling retrieveAccountSummary of CustomerAccountSummaryDao class ");
        futureReasResponse = enterpriseAccountSummarySyncOrchDAO.retrieveAccountSummary(
                EPFContextContainer.getContext(), customerAccountsRequest);

        logger.debug("Calling execute of XESRelatedAccountsOrchService class ");
        futureXESRelatedAcctResponse = xesRelatedAccountsOrchService.execute(customerAccountsRequest,
                EPFContextContainer.getContext());

        logger.debug("Calling execute of ProfileAccountsOrchService class ");
        futureProfileAccountRelationshipsResponse = profileAccountsOrchService.execute(customerAccountsRequest,
                EPFContextContainer.getContext());

        // Call for CustomerInformationDLS

        if (customerAccountsRequest.isCustInfoDlsSwitch()) {
            logger.debug("Calling execute of CustInfoDLS class ");
            futureCustInfoDLSRes = custInfoDLSOrchService
                    .execute(customerAccountsRequest, EPFContextContainer.getContext());
            logger.debug("The custInfoDLS response is {}", futureCustInfoDLSRes);
        }

        if (customerAccountsRequest.isEnableOecpSortOrder()) {
            logger.debug("Calling execute of MongoOecpPreferencesOrchService class ");
            futureMongoOECPPreferencesResponses = mongoOecpPreferencesOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());
        }

        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);
        orchResponse.setFutureMongoOecpPreferencesResponse(futureMongoOECPPreferencesResponses);

        orchResponse.setFutureCustInfoDLSRes(futureCustInfoDLSRes);
        setSafeDepositeBoxResponse(customerAccountsRequest, orchResponse);

        enableModifiedOrchestrationSwitch(customerAccountsRequest, orchResponse);

        if (CollectionUtils.isNotEmpty(customerAccountsRequest.getCoiSwitch())
                && customerAccountsRequest.getCoiSwitch().contains(customerAccountsRequest.getAppVersion())) {
            logger.debug("Calling execute of capitalOneInvestingAccountOrchService class ");
            futureCOIAccountResponse = capitalOneInvestingAccountOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());
            orchResponse.setFutureCOIAcctResponse(futureCOIAccountResponse);
        }

        REASResponse reasResponsesfromBackend = getReasResponse(orchResponse);

        if (reasResponsesfromBackend == null) {
            reasResponsesfromBackend = new REASResponse();
        }

        if (null != orchResponse.getFutureAutoLoansAccountsResponse()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureAutoLoansAccountsResponse(),
                    reasResponsesfromBackend);
            logger.debug("autoLoansAccountsOrchService reasResponsesfromBackend : {} ", reasResponsesfromBackend);
        }

        if (null != orchResponse.getFutureProfileCustomerAccountsResponse()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureProfileCustomerAccountsResponse(),
                    reasResponsesfromBackend);
            logger.debug("ProfileAccount360OrchService reasResponsesfromBackend : {} ", reasResponsesfromBackend);
        }

        if (null != orchResponse.getFutureCreditCardAccountSummary()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureCreditCardAccountSummary(), reasResponsesfromBackend);
            logger.debug("creditCardAccountSummaryOrchService reasResponsesfromBackend : {}", reasResponsesfromBackend);
        }

        if (null != orchResponse.getFutureSafeDepositeBoxSummary()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureSafeDepositeBoxSummary(), reasResponsesfromBackend);
            logger.debug("SafeDepoBoxAccountSummaryOrchService reasResponsesfromBackend : {} ",
                    reasResponsesfromBackend);
        }

        if (null != orchResponse.getFutureHomeLoanSummary()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureHomeLoanSummary(), reasResponsesfromBackend);
            logger.debug("SafeDepoBoxAccountSummaryOrchService reasResponsesfromBackend : {} ",
                    reasResponsesfromBackend);
        }

        if (null != orchResponse.getFutureXESDDAIS()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureXESDDAIS(), reasResponsesfromBackend);
            logger.debug("XESDDAIS reasResponsesfromBackend : {} ", reasResponsesfromBackend);
        }

        if (null != orchResponse.getFutureXESTDAIS()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureXESTDAIS(), reasResponsesfromBackend);
            logger.debug("XESTDAIS reasResponsesfromBackend : {} ", reasResponsesfromBackend);
        }

        if (null != orchResponse.getFutureLoanAcctIS()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureLoanAcctIS(), reasResponsesfromBackend);
            logger.debug("LoanAcctIS reasResponsesfromBackend : {} ", reasResponsesfromBackend);
        }

        if (null != orchResponse.getFutureODSBrokerageAcctIS()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureODSBrokerageAcctIS(), reasResponsesfromBackend);
            logger.debug("ODSBrokerageAcctIS reasResponsesfromBackend : {} ", reasResponsesfromBackend);
        }

        if (null != orchResponse.getFutureCOIAcctResponse()) {
            reasResponsesfromBackend = merge(orchResponse.getFutureCOIAcctResponse(), reasResponsesfromBackend);
            logger.debug("COIAcctResponse reasResponsesfromBackend : {} ", reasResponsesfromBackend);
        }

        // futureCOIAccountResponse

        orchResponse.setFutureReasResponse(new AsyncResult<REASResponse>(reasResponsesfromBackend));

        logger.debug("Exit - execute method of CustomerAccountsOrchService class");
        return orchResponse;
    }

    private void enableModifiedOrchestrationSwitch(CustomerAccountsRequest customerAccountsRequest,
            CustomerAccountsOrchResponse orchResponse) {
        logger.debug("Enter - enableModifiedOrchestrationSwitch method of CustomerAccountsOrchService class");
        Future<REASResponse> futureAutoLoansAccountsResponse;
        Future<REASResponse> futureProfileCustomerAccountsResponse;
        Future<REASResponse> futureCreditCardAccountSummary;
        Future<REASResponse> futureXESDDAIS;
        Future<REASResponse> futureXESTDAIS;
        Future<REASResponse> futureLoanAcctIS;
        Future<REASResponse> futureHomeLoanSummary;
        Future<REASResponse> futureODSAccountResponse;
        Future<List<OLBResponse>> futureOLBAccountResponse;
        if (customerAccountsRequest.isEnableModifiedOrchestrationSwitch()) {

            logger.debug("Calling execute of autoLoansAccountsOrchService class ");
            futureAutoLoansAccountsResponse = autoLoansAccountsOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());

            orchResponse.setFutureAutoLoansAccountsResponse(futureAutoLoansAccountsResponse);

            logger.debug("Calling execute of ProfileAccount360OrchService class ");
            futureProfileCustomerAccountsResponse = profileAccount360OrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());

            orchResponse.setFutureProfileCustomerAccountsResponse(futureProfileCustomerAccountsResponse);

            logger.debug("Calling execute of creditCardAccountSummaryOrchService class ");
            futureCreditCardAccountSummary = creditCardAccountSummaryOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());

            orchResponse.setFutureCreditCardAccountSummary(futureCreditCardAccountSummary);

            logger.debug("Calling execute of homeLoansAccountsOrchService class ");
            futureHomeLoanSummary = homeLoansAccountsOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());

            orchResponse.setFutureHomeLoanSummary(futureHomeLoanSummary);

            logger.debug("Calling execute of XESDDAIS class ");
            futureXESDDAIS = xesDDAISOrchService.execute(customerAccountsRequest, EPFContextContainer.getContext());

            orchResponse.setFutureXESDDAIS(futureXESDDAIS);

            logger.debug("Calling execute of XESTDAIS class ");
            futureXESTDAIS = xesTDAISOrchService.execute(customerAccountsRequest, EPFContextContainer.getContext());
            orchResponse.setFutureXESTDAIS(futureXESTDAIS);

            logger.debug("Calling execute of XESLoanAcctIS class");
            futureLoanAcctIS = loanAccountSummaryOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());

            orchResponse.setFutureLoanAcctIS(futureLoanAcctIS);

            logger.debug("Calling execute of ODSBrokerageAccntIS class");
            futureODSAccountResponse = odsBrokerageAccountsISOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());

            orchResponse.setFutureODSBrokerageAcctIS(futureODSAccountResponse);

            setOecpPrefResponse(customerAccountsRequest, orchResponse);

            logger.debug("Calling execute of OLBAccountPreferencesISOrchService class");
            futureOLBAccountResponse = accountPreferencesISOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());
            orchResponse.setFutureOLBAccountsResponse(futureOLBAccountResponse);
            logger.debug("Exit - enableModifiedOrchestrationSwitch method of CustomerAccountsOrchService class");
        }
    }

    private void setOecpPrefResponse(CustomerAccountsRequest customerAccountsRequest,
            CustomerAccountsOrchResponse orchResponse) {
        Future<List<OecpPreferResponse>> futureOecpPreferResponse;
        if (customerAccountsRequest.isEnableOECPPreferenceSwitch()) {

            logger.debug("Calling execute of oecpPreferencesOrchService class ");
            futureOecpPreferResponse = oecpPreferencesOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());
            orchResponse.setFutureOecpPrefResponse(futureOecpPreferResponse);
        }
    }

    private void setSafeDepositeBoxResponse(CustomerAccountsRequest customerAccountsRequest,
            CustomerAccountsOrchResponse orchResponse) {
        Future<REASResponse> futureSafeDepositeBoxSummary;

          logger.debug("Values of EnableModifiedSafeDepositBoxSwitch {}",customerAccountsRequest.getEnableModifiedSafeDepositBoxSwitch());
        logger.debug("Value of getAppVersion {}",customerAccountsRequest.getAppVersion());
        if (customerAccountsRequest.getEnableModifiedSafeDepositBoxSwitch().contains(customerAccountsRequest.getAppVersion())){

            logger.debug("Calling execute of SafeDepoBoxAccountSummaryOrchService class ");
            futureSafeDepositeBoxSummary = safeDepoBoxAccountSummaryOrchService.execute(customerAccountsRequest,
                    EPFContextContainer.getContext());

            orchResponse.setFutureSafeDepositeBoxSummary(futureSafeDepositeBoxSummary);
        }
    }

    private REASResponse merge(Future<REASResponse> futureLobResponse, REASResponse reasResponses) {
        logger.debug("ENTRY - merge method of CustomerAccountsOrchService class");
        REASResponse lobResponse = getLobBackendResponse(futureLobResponse);

        if (null != lobResponse) {
            logger.debug("reasResponses - size : {}", lobResponse.getCustomerAccountsResponseList());
            if (reasResponses.getCustomerAccountsResponseList() == null
                    && lobResponse.getCustomerAccountsResponseList() != null) {
                reasResponses.setCustomerAccountsResponseList(lobResponse.getCustomerAccountsResponseList());
            } else if (lobResponse.getCustomerAccountsResponseList() != null) {
                reasResponses.getCustomerAccountsResponseList().addAll(lobResponse.getCustomerAccountsResponseList());
            }
            if (reasResponses.getAddStatList() == null && lobResponse.getAddStatList() != null) {
                reasResponses.setAddStatList(lobResponse.getAddStatList());
            } else if (lobResponse.getAddStatList() != null) {
                reasResponses.getAddStatList().addAll(lobResponse.getAddStatList());
            }
        }
        logger.debug("EXIT - merge method of CustomerAccountsOrchService class");
        return reasResponses;
    }

    private REASResponse getReasResponse(CustomerAccountsOrchResponse orchResponse) {
        REASResponse reasResponsesfromBackend = new REASResponse();
        try {
            reasResponsesfromBackend = orchResponse.getFutureReasResponse().get(WAIT_TIME, WAIT_UNIT);
        } catch (InterruptedException e) {
            logger.error(e.getMessage());
            orchResponse.getFutureReasResponse().cancel(true);
        } catch (ExecutionException e) {
            logger.error(e.getMessage());
            orchResponse.getFutureReasResponse().cancel(true);
        } catch (TimeoutException e) {
            logger.error(e.getMessage());
            orchResponse.getFutureReasResponse().cancel(true);
        }
        return reasResponsesfromBackend;
    }

    private REASResponse getLobBackendResponse(Future<REASResponse> futureReasResponse) {
        logger.debug("ENTRY - getLobBackendResponse method of CustomerAccountsOrchService class");
        REASResponse lobResponse = null;
        try {

            lobResponse = futureReasResponse.get(WAIT_TIME, WAIT_UNIT);
        } catch (InterruptedException e) {
            logger.error(e.getMessage());
            futureReasResponse.cancel(true);
        } catch (ExecutionException e) {
            logger.error(e.getMessage());
            futureReasResponse.cancel(true);
        } catch (TimeoutException e) {
            logger.error(e.getMessage());
            futureReasResponse.cancel(true);
        }
        logger.debug("EXIT - getLobBackendResponse method of CustomerAccountsOrchService class");
        return lobResponse;
    }

}
