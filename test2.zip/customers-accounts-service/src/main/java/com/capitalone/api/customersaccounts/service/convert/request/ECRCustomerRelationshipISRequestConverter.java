/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.convert.request;

import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRq;
import com.capitalone.ecrcustomerrelationshipsis.v1.RegisteredItem3PartKey;

/**
 * This class is Converter for CustomerAccountsRequest to ECR Request
 * 
 */

@Profile
@Trace
@Named
public class ECRCustomerRelationshipISRequestConverter extends
        ConversionServiceAwareConverter<CustomerAccountsRequest, CustIdentityMatchedAccountsInqRq> {

    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Converts the CustomerAccountsRequest to CustIdentityMatchedAccountsInqRq(ECR req) type
     * 
     * @param request customers accounts information
     * @return input Request for ECR
     */

    @Override
    public CustIdentityMatchedAccountsInqRq convert(CustomerAccountsRequest request) {
        logger.debug("CustIdentityMatchedAccountsInqRq  : convert -> Start");
        logger.debug("Client Request : CustomerAccountsRequest={}", request);

        CustIdentityMatchedAccountsInqRq ecrISRequest = null;

        ecrISRequest = new CustIdentityMatchedAccountsInqRq();
        ecrISRequest.setCmd(new CustIdentityMatchedAccountsInqRq.Cmd());
        ecrISRequest.getCmd().setECRLookUpKey(new CustIdentityMatchedAccountsInqRq.Cmd.ECRLookUpKey());

        RegisteredItem3PartKey registeredItem3partKey = new RegisteredItem3PartKey();

        if ((null != request.getProfileReferenceId())
                && (StringUtils.isNotBlank(request.getProfileReferenceId().getSSOID()))) {
            logger.debug("Client Request : setRgstryRltnshpID={} : ProfileReferenceId", request.getProfileReferenceId());

            registeredItem3partKey.setRgstryRltnshpID(request.getProfileReferenceId().getSSOID());
            // Hardcoding below three fields as per ECR team request.
            registeredItem3partKey.setRgstryRltnshpAssociationTypeCd(Constants.PROFILE_TYPE);
            registeredItem3partKey.setRgstryRltnshpAssociationSORID(Constants.PROFILE_SORID);
        } else if (null != request.getCustomerReferenceId()
                && null != request.getCustomerReferenceId().getEnterpriseServicingCustomerId()) {
            logger.debug("Client Request : setRgstryRltnshpID={} : CustomerReferenceId",
                    request.getCustomerReferenceId());
            registeredItem3partKey.setRgstryRltnshpID(request.getCustomerReferenceId()
                    .getEnterpriseServicingCustomerId());
            // Hardcoding below three fields as per ECR team request.
            registeredItem3partKey.setRgstryRltnshpAssociationTypeCd(Constants.ECR_REGISTRY_TYPE_CD);
            registeredItem3partKey.setRgstryRltnshpAssociationSORID(Short.valueOf(Constants.ECR_REGISTRY_SORID));
        }

        ecrISRequest.getCmd().getECRLookUpKey().setRegisteredItem3PartKey(registeredItem3partKey);

        logger.debug("CustIdentityMatchedAccountsInqRq  : convert -> End");
        return ecrISRequest;
    }
}