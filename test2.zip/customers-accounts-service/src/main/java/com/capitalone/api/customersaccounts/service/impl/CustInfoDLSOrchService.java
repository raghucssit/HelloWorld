package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.CustInfoDLSDAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;

/**
 * 
 * 
 */

@Profile
@Trace
@Named
public class CustInfoDLSOrchService {

    private static final long WAIT_TIME = 2;

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private CustInfoDLSDAO custInfoDLSDAO;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Async
    public Future<Map<String, String>> execute(final CustomerAccountsRequest customerAccountsRequest, EPFContext context) {
        logger.debug("Enter - execute method of CustInfoDLSOrchService");
        List<String> repeatitionFilter = new ArrayList<String>();
        List<Future<Map<String, String>>> listCustInfoDLS = new ArrayList<Future<Map<String, String>>>();
        Map<String, String> listCustInfoDLSRes = new HashMap<String, String>();

        if (customerAccountsRequest != null
                && customerAccountsUtil.findSORID(customerAccountsRequest, Constants.CREDIT_CARD_SORID)) {

            for (final CustomerAccountKey key : customerAccountsRequest.getCustomerAccountKeyList()) {
                if ((Constants.CREDIT_CARD_SORID.equals(key.getSorId()))
                        && (!repeatitionFilter.contains(key.getAccountNumber()))) {

                    listCustInfoDLS.add(custInfoDLSDAO.getCustomerRole(context, key));

                    repeatitionFilter.add(key.getAccountNumber());

                }

            }
            populateCustInfoDLSFutureRes(listCustInfoDLSRes, listCustInfoDLS);
        }

        logger.debug("The DLSresponse map is {}", listCustInfoDLSRes);
        logger.debug("Exit - execute method of CustInfoDLSOrchService");
        return new AsyncResult<Map<String, String>>(listCustInfoDLSRes);
    }

    private void populateCustInfoDLSFutureRes(Map<String, String> listCustInfoDLSRes,
            List<Future<Map<String, String>>> listCustInfoDLSResponses) {
        for (Future<Map<String, String>> res : listCustInfoDLSResponses) {
            try {
                Map<String, String> map = res.get(WAIT_TIME, Constants.WAIT_UNIT);
                if (map != null) {
                    listCustInfoDLSRes.putAll(map);
                }
            } catch (ExecutionException ex) {
                logger.error(" Execution Exception", ex);                
                	res.cancel(Boolean.TRUE);                
            } catch (InterruptedException ex) {
                logger.error(" Interupted Exception", ex);                
                	res.cancel(Boolean.TRUE);
            } catch (TimeoutException ex) {
                logger.error(" TimeoutException Exception", ex);                
                	res.cancel(Boolean.TRUE);                 
            }
        }
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
