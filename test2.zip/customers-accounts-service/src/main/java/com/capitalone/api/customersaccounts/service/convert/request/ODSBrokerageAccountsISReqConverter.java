package com.capitalone.api.customersaccounts.service.convert.request;

import java.util.List;

import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRq;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRq.Cmd;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRq.Cmd.AccountsArray;

@Profile
@Trace
@Named
public class ODSBrokerageAccountsISReqConverter extends
        ConversionServiceAwareConverter<List<CustomerAccountKey>, BalancesInqRq> {

	/**
     * Converts the list of CustomerAccountsRequest to ODSBrokerageAccountsISReqConverter(ODS req) type
     * 
     * @param request customers accounts information
     * @return input Request for ODS
     */
    @Override
    public BalancesInqRq convert(List<CustomerAccountKey> request) {
        logger.debug("Entry -  ODSBrokerageAccountsISReqConverter {}", request);
        if (request == null || request.isEmpty()) {
            logger.debug("Customer Account Key List Empty", request);
            return null;
        }

        BalancesInqRq balancesInqRq = new BalancesInqRq();
        Cmd cmd = new Cmd();
        AccountsArray accountsArray = null;

        for (CustomerAccountKey listBrokerageAccounts : request) {
            accountsArray = new AccountsArray();
            
            accountsArray.setAcctID(listBrokerageAccounts.getAccountNumber());
            accountsArray.setSoRID(listBrokerageAccounts.getSorId());
            cmd.getAccountsArray().add(accountsArray);

        }

        balancesInqRq.setCmd(cmd);
        logger.debug("Exit -  ODSBrokerageAccountsISReqConverter {}");
        return balancesInqRq;
    }
}
