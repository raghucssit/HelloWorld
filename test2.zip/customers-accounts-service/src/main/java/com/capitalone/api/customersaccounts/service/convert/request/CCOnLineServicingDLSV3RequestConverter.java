package com.capitalone.api.customersaccounts.service.convert.request;

import java.math.BigInteger;
import java.util.List;

import javax.inject.Named;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRq;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRq.Cmd.AcctArray;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRq.Cmd.AcctArray.Acct;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRq.Cmd.AcctArray.SoR;


@Profile
@Trace
@Named
@SuppressWarnings("CPD-START")
public class CCOnLineServicingDLSV3RequestConverter extends
ConversionServiceAwareConverter<List<CustomerAccountKey>, AcctSumryDLSInqRq> {
    
    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Converts List of CustomerAccountKey to AcctSumryDLSInqRq
     * 
     * @param request List of card accounts
     * @return inputRq
     */
    @Override
    public AcctSumryDLSInqRq convert(List<CustomerAccountKey> request) {
        logger.debug("Entry -  CCOnLineServicingDLSV3RequestConverter RqConverter {}", request);
        if (request == null || request.isEmpty()) {
            logger.debug("Customer Account Key List Empty", request);
            return null;
        }       
        
        AcctSumryDLSInqRq acctSumryDLSInqRq = new AcctSumryDLSInqRq();
        AcctSumryDLSInqRq.Cmd cmd = new AcctSumryDLSInqRq.Cmd();
        acctSumryDLSInqRq.setCmd(cmd);

        for (CustomerAccountKey customerAccountKey : request) {

            if ((Constants.CREDIT_CARD_SORID).equals(customerAccountKey.getSorId())) {

                AcctArray acctArray = new AcctArray();
                Acct acct = new Acct();
                acct.setAcctID(StringUtils.leftPad(customerAccountKey.getAccountNumber(), Constants.SIZE_TO_PAD, Constants.ACCOUNT_NUMBER_PADDING));
                SoR soR = new SoR();
                soR.setSoRID(new BigInteger(customerAccountKey.getSorId().toString()));
                acctArray.setAcct(acct);
                acctArray.setSoR(soR);                
                acctSumryDLSInqRq.getCmd().getAcctArray().add(acctArray);
            }
        }
        logger.debug("Exit -  CCOnLineServicingDLSV3RequestConverter RqConverter");

        return acctSumryDLSInqRq;
    }

}
