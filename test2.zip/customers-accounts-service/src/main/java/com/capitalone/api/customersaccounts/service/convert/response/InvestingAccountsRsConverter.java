
package com.capitalone.api.customersaccounts.service.convert.response;

import java.util.ArrayList;

import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.model.v1.GetAccountResponse;
import com.capitalone.api.customersaccounts.model.v1.InvestingAccounts;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;

@Profile
@Trace
@Named
public class InvestingAccountsRsConverter extends ConversionServiceAwareConverter<InvestingAccounts, REASResponse> {
	private Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * Converts investingAccounts to REASResponse type
	 * 
	 * @param investingAccounts
	 * @return reasResponse
	 */

	@Override
	public REASResponse convert(InvestingAccounts investingAccounts) {
		logger.debug("InvestingAccountsRsConverter  : convert -> Start");
		REASResponse reasResponse = new REASResponse();
		if (investingAccounts.getAccount() != null) {
			for (GetAccountResponse getAccountResponse : investingAccounts.getAccount()) {
				if (getAccountResponse != null && StringUtils.isEmpty(getAccountResponse.getError())) {
					CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
					setAccountDetails(reasResponse, getAccountResponse, customerAccountsResponse);
					reasResponse.getCustomerAccountsResponseList().add(customerAccountsResponse);
				} else {
					if (reasResponse.getAddStatList() == null) {
						reasResponse.setAddStatList(new ArrayList<AdditionalStat>());
					}
					AdditionalStat addnStat = new AdditionalStat();
					addnStat.setNativeErrorCd(Constants.API_COI_ERROR_CODE);
					addnStat.setStatDesc(getAccountResponse.getError());
					reasResponse.getAddStatList().add(addnStat);
				}
			}
		}
		logger.debug("InvestingAccountsRsConverter  : convert -> Exit");
		return reasResponse;
	}

	private void setAccountDetails(REASResponse reasResponse, GetAccountResponse getAccountResponse,
								   CustomerAccountsResponse customerAccountsResponse) {

		if (getAccountResponse.getAccountDetailsUrl() != null) {
			customerAccountsResponse.setCoiAccountURL(getAccountResponse.getAccountDetailsUrl());
		}

		if (getAccountResponse.getAccountType() != null) {
			customerAccountsResponse.setProductName(Constants.COI_PRODUCT_NAME);
			customerAccountsResponse.setProductTypeDescription(getAccountResponse.getAccountType());
		}
		customerAccountsResponse.setProductTypeCode(Constants.COI);

		setAcctBalanceDetails(getAccountResponse, customerAccountsResponse);
		if (getAccountResponse.getBusinessLine() != null) {
			customerAccountsResponse.setBusinessLine(getAccountResponse.getBusinessLine());
		}
		if (getAccountResponse.getAccountNumber() != null) {
			customerAccountsResponse.setAccountNumber(getAccountResponse.getAccountNumber());
			customerAccountsResponse.setDisplayAccountNumber(getAccountResponse.getAccountNumber());
			customerAccountsResponse.setAccountId(getAccountResponse.getAccountNumber());
		}
		if (getAccountResponse.getEntitled() != null && getAccountResponse.getEntitled()) {
			customerAccountsResponse.setAccountStatusDescription(Constants.ACCOUNT_STATUS_OPEN);
		}

		if (getAccountResponse.getAccountNickname() != null) {
			customerAccountsResponse.setAccountNickname(getAccountResponse.getAccountNickname());
		}

		if (getAccountResponse.getCustomerRole() != null) {
			customerAccountsResponse.setCustomerRole(String.valueOf(getAccountResponse.getCustomerRole()));
		}
		// to be discussed
		// if (getAccountResponse.getAccountDetailsUrl() != null) {
		// customerAccountsResponse.setAcc
		// }
		customerAccountsResponse.setCurrencyCode(Constants.CURRENCY_CODE_USA);
		customerAccountsResponse.setSorId(Constants.SOR_ID_COI);

		if (getAccountResponse.getLastUpdateDate() != null) {
			customerAccountsResponse.setValidAsOfTimestamp(getAccountResponse.getLastUpdateDate());
		}

		if (reasResponse.getCustomerAccountsResponseList() == null) {
			reasResponse.setCustomerAccountsResponseList(new ArrayList<CustomerAccountsResponse>());
		}
	}

	private void setAcctBalanceDetails(GetAccountResponse getAccountResponse,
									   CustomerAccountsResponse customerAccountsResponse) {
		if (getAccountResponse.getTotalAccountValue() != null) {
			customerAccountsResponse.setCurrentBalance(getAccountResponse.getTotalAccountValue());
		}
		if (getAccountResponse.getAvailableBalance() != null) {
			customerAccountsResponse.setAvailableBalance(getAccountResponse.getAvailableBalance());
		}

		if (getAccountResponse.getOpenDate() != null) {
			customerAccountsResponse.setOpenDate(getAccountResponse.getOpenDate());
		}
	}

}
