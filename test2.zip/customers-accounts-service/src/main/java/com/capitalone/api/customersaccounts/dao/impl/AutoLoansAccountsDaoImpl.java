package com.capitalone.api.customersaccounts.dao.impl;
 
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;

import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractRestBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.AutoLoansAccountsDAO;
import com.capitalone.api.customersaccounts.entity.LoansAutoLoansEntity;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.impl.RESTAPIErrorResponseFilter;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.epf.context.model.EPFContext;

/**
 * DAO for retrieving Account NickName from Rest Client
 */

@Profile
@Trace
@Named
public class AutoLoansAccountsDaoImpl extends AbstractRestBaseService<Client, AutoLoanAccount> implements
        AutoLoansAccountsDAO {

    @Inject
    private LoansAutoLoansEntity autoLoansEntity;

    @Inject
    private RESTAPIErrorResponseFilter autoErrorResponseFilter;

    @PostConstruct
    public void init() {
        // set up the client with appropriate messageBodyReader/messageBodyWriter
        // Note if you have multiple rest backend, you may want to use multiple clients
        service.register(messageBodyReader).register(autoErrorResponseFilter);
    }

    /**
     * Getting COAF Account details and  NickName of AutoLoans
     * 
     * @param context holds the request context
     * @param customerAccountKey holds the input information
     * @param ssoid single sign of customer
     * @return list of accounts details
     * 
     */


    @Override
    @Async
    public Future<REASResponse> getCOAFAccounts(EPFContext context, CustomerAccountKey customerAccountKey, String ssoid) {

        logger.debug("Entry - getCOAFAccounts method of AutoLoansAccountsDaoImpl class");

        List<CustomerAccountsResponse> autoLoanAccountResponesList = new ArrayList<CustomerAccountsResponse>();
        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();
        List<AdditionalStat> stat = new ArrayList<AdditionalStat>();
        AdditionalStat addnStat = null;
        REASResponse resp = new REASResponse();

        CustomerAccountsResponse customerAccountsResponse = null;

        try {
            AutoLoanAccount autoLoanAccount = autoLoansEntity.retiveAccountDetails(customerAccountKey, context,
                    customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()), ssoid);
            if (autoLoanAccount != null) {
                customerAccountsResponse = conversionService.convert(autoLoanAccount, CustomerAccountsResponse.class);
                autoLoanAccountResponesList.add(customerAccountsResponse);
            } else {
                logger.debug("Inside else of Loan Account");
                addnStat = new AdditionalStat();
                addnStat.setNativeErrorCd(Constants.API_COAF_ERROR_CODE);
                addnStat.setStatDesc(Constants.LOANACCOUNTS_API_DOWN.concat(CustomerAccountsUtil
                        .constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(),
                                customerAccountKey.getSorId())));
                addnStat.setAccountId(CustomerAccountsUtil.maskNPI(customerAccountKey.getAccountNumber()));
                stat.add(addnStat);
            }

            resp = mapToREAS(autoLoanAccountResponesList, stat);

        } catch (Exception e) {
            logger.debug("Exception Occurred {}", e.getCause());
            errorWhileRetrieveCOAFAccount(customerAccountKey, resp, addnStatFail, addnStatFailList, e);
        }

        logger.debug("Exit - getCOAFAccounts method of AutoLoansAccountsDaoImpl class resp : {} ", resp);
        return new AsyncResult<REASResponse>(resp);
    }

    private void errorWhileRetrieveCOAFAccount(CustomerAccountKey customerAccountKey, REASResponse resp,
            AdditionalStat addnStatFail, List<AdditionalStat> addnStatFailList, Exception e) {
        logger.debug("Entry - errorWhileRetrieveCOAFAccount method of AutoLoansAccountsDaoImpl class");
        if (e.getCause() instanceof CustomerAPIRESTException) {
            CustomerAPIRESTException errorResponse = (CustomerAPIRESTException) e.getCause();
            if (errorResponse.getErrorResponse() != null
                    && !StringUtils.isBlank(errorResponse.getErrorResponse().getId())) {
                addnStatFail.setNativeErrorCd(errorResponse.getErrorResponse().getId());
            }
            if (!StringUtils.isBlank(errorResponse.getErrorResponse().getDeveloperText())) {
                addnStatFail.setStatDesc(errorResponse
                        .getErrorResponse()
                        .getDeveloperText()
                        .concat(CustomerAccountsUtil.constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(),
                                customerAccountKey.getSorId())));
            } else {
                addnStatFail.setStatDesc(errorResponse
                        .getErrorResponse()
                        .getText()
                        .concat(CustomerAccountsUtil.constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(),
                                customerAccountKey.getSorId())));
            }
            if (errorResponse.getErrorResponse().getId() != null) {
                addnStatFail.setNativeErrorCd(errorResponse.getErrorResponse().getId());
            }
            if (errorResponse.getHttpStatus() != null) {
                addnStatFail.setHttpStatus(errorResponse.getHttpStatus());
            }
            addnStatFail.setAccountId(CustomerAccountsUtil.maskNPI(customerAccountKey.getAccountNumber()));
        } else {
            addnStatFail.setNativeErrorCd(Constants.API_COAF_ERROR_CODE);
            addnStatFail.setStatDesc(Constants.LOANACCOUNTS_API_DOWN.concat(CustomerAccountsUtil
                    .constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(), customerAccountKey.getSorId())));
            addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
            addnStatFail.setAccountId(CustomerAccountsUtil.maskNPI(customerAccountKey.getAccountNumber()));
        }
        addnStatFailList.add(addnStatFail);
        resp.setAddStatList(addnStatFailList);
        resp.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));
        logger.debug("Exit - errorWhileRetrieveCOAFAccount method of AutoLoansAccountsDaoImpl class");
    }

    private REASResponse mapToREAS(List<CustomerAccountsResponse> profileAccountResponesList, List<AdditionalStat> stat) {
        logger.debug("Entry - mapToREAS method of AutoLoansAccountsDaoImpl class");
        REASResponse reasResponse = new REASResponse();
        reasResponse.setCustomerAccountsResponseList(profileAccountResponesList);
        reasResponse.setAddStatList(stat);
        logger.debug("Exit - mapToREAS method of AutoLoansAccountsDaoImpl class");
        return reasResponse;
    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
