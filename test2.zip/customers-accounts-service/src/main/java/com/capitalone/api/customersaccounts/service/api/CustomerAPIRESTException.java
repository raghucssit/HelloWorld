package com.capitalone.api.customersaccounts.service.api;

import com.capitalone.api.commons.model.error.ErrorResponse;

/**
 * Indicates error from eAPI compliant REST backend <br>
 * 
 */
public class CustomerAPIRESTException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private Integer httpStatus;

    private ErrorResponse errorResponse;

    public CustomerAPIRESTException(Integer httpStatus, ErrorResponse errorResponse) {
        super();
        this.httpStatus = httpStatus;
        this.errorResponse = errorResponse;
    }

    public Integer getHttpStatus() {
        return httpStatus;
    }

    public ErrorResponse getErrorResponse() {
        return errorResponse;
    }

}
