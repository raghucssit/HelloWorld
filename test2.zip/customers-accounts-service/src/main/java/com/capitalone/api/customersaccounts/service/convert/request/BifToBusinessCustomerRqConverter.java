package com.capitalone.api.customersaccounts.service.convert.request;

import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRq;

/**
 * This class Converts form String To BusinessCustomerRq
 * 
 */

@Profile
@Trace
@Named
public class BifToBusinessCustomerRqConverter extends ConversionServiceAwareConverter<String, BusinessCustomerRq> {

    /**
     * Converts the given ID a string to BusinessCustomerRq
     * 
     * @param bif bussiness ID
     * @return input for IS
     */


    @Override
    public BusinessCustomerRq convert(String bif) {
        logger.debug("BifToBusinessCustomerRqConverter  : convert -> Start");
        BusinessCustomerRq businessCustomerRq = new BusinessCustomerRq();
        businessCustomerRq.setHdr(CustomerAccountsUtil.createSoapHdr());
        BusinessCustomerRq.Cmd cmd = new BusinessCustomerRq.Cmd();
        cmd.setPrimaryCustomerID(bif);
        cmd.setName("businessCustomerRqCmd");
        businessCustomerRq.setCmd(cmd);
        logger.debug("BifToBusinessCustomerRqConverter  : convert -> End");
        return businessCustomerRq;

    }

}
