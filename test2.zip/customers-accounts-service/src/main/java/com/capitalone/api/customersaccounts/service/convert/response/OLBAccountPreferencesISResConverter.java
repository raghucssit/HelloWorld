package com.capitalone.api.customersaccounts.service.convert.response;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferenceInfo;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRs;

@Profile
@Trace
@Named
public class OLBAccountPreferencesISResConverter extends
        ConversionServiceAwareConverter<AccountPreferencesInqRs, List<OLBResponse>> {

	/**
     * Converts OLB nativeResponse to OLB Response type
     * 
     * @param nativeResponse ODS Response
     * @return OLB customers accounts list
     */
    @Override
    public List<OLBResponse> convert(AccountPreferencesInqRs nativeResponse) {

        List<OLBResponse> listOlbNicknames = new ArrayList<OLBResponse>();

        for (AccountPreferenceInfo accountPreferenceInfo : nativeResponse.getCmd().getAccountPreferenceInfo()) {
            OLBResponse olbResponse = new OLBResponse();
            if (accountPreferenceInfo.getAcctID() != null) {
                olbResponse.setAccountId(accountPreferenceInfo.getAcctID());
            }
            if (accountPreferenceInfo.getAcctNknmNm() != null) {
                olbResponse.setOlbAccountNickname(accountPreferenceInfo.getAcctNknmNm());
            }
            if (accountPreferenceInfo.getSoRID() != 0) {
                olbResponse.setSorId(String.valueOf(accountPreferenceInfo.getSoRID()));
            }
            listOlbNicknames.add(olbResponse);

        }

        return listOlbNicknames;
    }

}
