package com.capitalone.api.customersaccounts.service.impl;

import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.scheduling.annotation.Async;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.OLBAccountPreferencesISDAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.epf.context.model.EPFContext;

@Profile
@Trace
@Named
public class OLBAccountPreferencesISOrchService {

    @Inject
    private OLBAccountPreferencesISDAO accountPreferencesISDAO;

    /**
     * Method calls DAO of OLBAccountPreferencesIS
     * 
     * @param customerAccountsRequest customers account input data
     * @param context holds the user Context
     * @return List of OLBAccountPreferencesIS response
     */
    @Async
    public Future<List<OLBResponse>> execute(CustomerAccountsRequest customerAccountsRequest, EPFContext context) {
        boolean isRetailAccountPresent = false;
        Future<List<OLBResponse>> olbrResponse = null;

        if (customerAccountsRequest.isEnableOlbrAccountNickname()
                && (!CollectionUtils.containsAny(customerAccountsRequest.getReasSupportedSORID(),
                        Constants.SORIDLIST_RETAIL_STRING) || !customerAccountsRequest.getReasSupportedSORID()
                        .contains(String.valueOf(Constants.BROKERAGE_SORID)))) {

            for (CustomerAccountKey customerAccountKey : customerAccountsRequest.getCustomerAccountKeyList()) {
                if (Constants.SORIDLIST_RETAIL.contains(customerAccountKey.getSorId())
                        || Constants.BROKERAGE_SORID.equals(customerAccountKey.getSorId())) {
                    isRetailAccountPresent = true;
                    break;
                }
            }
            if (isRetailAccountPresent && customerAccountsRequest.getProfileReferenceId() != null) {
                olbrResponse = accountPreferencesISDAO.getAccountNickname(context, customerAccountsRequest);
            }
        }
        return olbrResponse;
    }

}
