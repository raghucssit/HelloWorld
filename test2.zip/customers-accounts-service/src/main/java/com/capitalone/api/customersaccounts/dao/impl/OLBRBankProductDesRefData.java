package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.model.referencedata.ReferenceDataCategory;
import com.capitalone.api.commons.model.referencedata.ReferenceDataEntity;
import com.capitalone.api.commons.services.referencedata.dao.ReferenceDataDao;
import com.capitalone.api.customersaccounts.service.impl.OLBRBankProdCodeISOrchService;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;
import com.capitalone.api.customersaccounts.service.pojo.OLBRRefData;

@Named
@Profile
@Trace
public class OLBRBankProductDesRefData implements ReferenceDataDao<OLBAttributes> {

    private static final String RETAIL_PROD_DES_REF_DATA = "RetailProdDesRefData";

    @Inject
    private OLBRBankProdCodeISOrchService olbrBankProdCodeISOrchService;

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Override    
    public ReferenceDataCategory<OLBAttributes> getCategory(String categoryName, int categoryVersion) {
        List<OLBRRefData> prodrefData1 = new ArrayList<OLBRRefData>();
        try {
            prodrefData1 = olbrBankProdCodeISOrchService.execute();
        } catch (Exception e) {
            logger.debug("Data not retruned from OLBR ProdcutCodeIS");
        }

        List<ReferenceDataEntity<OLBAttributes>> listRefDataEntity = new ArrayList<ReferenceDataEntity<OLBAttributes>>();
        for (OLBRRefData olbrRefData : prodrefData1) {            
            listRefDataEntity.add(new ReferenceDataEntity<OLBAttributes>(olbrRefData.getKey(), olbrRefData
                    .getAttributes()));
        }
        ReferenceDataCategory<OLBAttributes> category = new ReferenceDataCategory<OLBAttributes>(
                RETAIL_PROD_DES_REF_DATA, 1, listRefDataEntity);
        return category;
    }
    
    @Override
    //@CacheEvict(value = "api-ref-data-categories-dao-alt-bank-thing")
    public void clear() {
        // intentionally left blank

    }

}
