package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.AutoLoansAccountsDAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;

/**
 * Service Implementation for retrieving Account NickName
 * 
 */

@Profile
@Trace
@Named
public class AutoLoansAccountsOrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private AutoLoansAccountsDAO autoLoansAccountsDAO;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    /**
     * Method for retrieving COAF Account and COAF NickName
     * 
     * @param customerAccountsRequest input request
     * @param context holds the user Context
     * @return Customers account response
     * 
     */ 


    @Async
    public Future<REASResponse> execute(final CustomerAccountsRequest customerAccountsRequest, EPFContext context) {
        REASResponse finalReas = new REASResponse();
        logger.debug("Enter - execute method of AutoLoanOrchService");
        List<REASResponse> autoLoansAccountsRes = new ArrayList<REASResponse>();

        List<Future<REASResponse>> autoLoansAccountsResponesFutures = new ArrayList<Future<REASResponse>>();
        List<String> repeatitionFilter = new ArrayList<String>();

        if (customerAccountsRequest != null && customerAccountsRequest.getReasSupportedSORID() != null
                && !(customerAccountsRequest.getReasSupportedSORID().contains(Constants.AUTO_LOAN_SORID))) {
            String ssoid = "";
            if (null != customerAccountsRequest.getProfileReferenceId()
                    && StringUtils.isNotBlank(customerAccountsRequest.getProfileReferenceId().getSSOID())) {
                ssoid = customerAccountsRequest.getProfileReferenceId().getSSOID();
            }

            for (final CustomerAccountKey key : customerAccountsRequest.getCustomerAccountKeyList()) {
                if ((Constants.AUTO_LOAN_SORID_INT.equals(key.getSorId()))
                        && (!repeatitionFilter.contains(key.getAccountNumber()))) {

                    autoLoansAccountsResponesFutures.add(autoLoansAccountsDAO.getCOAFAccounts(context, key, ssoid));
                    repeatitionFilter.add(key.getAccountNumber());

                }

            }

            populateAutoLoansAccounts(autoLoansAccountsRes, autoLoansAccountsResponesFutures);

            for (REASResponse repo : autoLoansAccountsRes) {
                finalReas = customerAccountsUtil.merge(finalReas, repo);
            }

        }

        logger.debug("Exit - execute method of AutoLoanOrchService");
        return new AsyncResult<REASResponse>(finalReas);
    }

    private void populateAutoLoansAccounts(List<REASResponse> autoLoansAccountsRes,
            List<Future<REASResponse>> autoLoansAccountsResponesFutures) {
        for (Future<REASResponse> res : autoLoansAccountsResponesFutures) {
            try {
                autoLoansAccountsRes.add(res.get(Constants.WAIT_TIME, Constants.WAIT_UNIT));
            } catch (ExecutionException ex) {
                logger.error(" Execution Exception", ex);
                res.cancel(true);

            } catch (InterruptedException ex) {
                logger.error(" Interupted Exception", ex);
                res.cancel(true);
            } catch (TimeoutException ex) {
                logger.error(" TimeoutException Exception", ex);
                res.cancel(true);
            }
        }
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
