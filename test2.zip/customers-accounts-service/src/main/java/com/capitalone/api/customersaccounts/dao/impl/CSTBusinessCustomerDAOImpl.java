package com.capitalone.api.customersaccounts.dao.impl;

import javax.inject.Inject;

import org.apache.commons.lang3.tuple.Pair;

import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.dao.CSTBusinessCustomerDAO;
import com.capitalone.api.customersaccounts.service.convert.request.CSTBusinessCustomerRqConverter;
import com.capitalone.api.customersaccounts.service.convert.response.CSTBusinessCustomerRsConverter;
import com.capitalone.api.customersaccounts.service.pojo.CSTBusinessCustomerResponse;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRq;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerSignersRs;
import com.capitalone.cstbusinesscustomeris.v1.BusinessDetailsRs;
import com.capitalone.cstbusinesscustomeris.v1.CSTBusinessCustomerSignersISSOAP;

/**
 * DAO for retrieving Account Relationships from CSTBusinessCustomerSignersISSOAP
 * 
 */

public class CSTBusinessCustomerDAOImpl extends AbstractBaseService implements CSTBusinessCustomerDAO {

    @Inject
    private CSTBusinessCustomerSignersISSOAP cstBusinessCustomerISService;

    @Inject
    private CSTBusinessCustomerRqConverter cSTBusinessCustomerRqConverter;

    @Inject
    private CSTBusinessCustomerRsConverter cSTBusinessCustomerRsConverter;

  /**
     * Getting Account Relationships from CSTBusinessCustomerSignersIS
     * 
     * @param customerId a unique ID of customer
     * @return CSTBusinessCustomerResponse
     * 
     */


    public CSTBusinessCustomerResponse getAccountRelationships(String customerId) {

        logger.debug("Enter - getAccountRelationships method of CSTBusinessCustomerDAOImpl class");
        BusinessCustomerRq businessCustomerRq = cSTBusinessCustomerRqConverter.convert(customerId);
        CSTBusinessCustomerResponse response = null;
        BusinessCustomerSignersRs businessCustomerSignersRs = null;
        BusinessDetailsRs businessDetailsRs = null;

        businessCustomerSignersRs = cstBusinessCustomerISService.businessCustomerSignersInq(businessCustomerRq);
        businessDetailsRs = cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq);

        if ((businessCustomerSignersRs != null && businessDetailsRs != null)
                && (businessCustomerSignersRs.getCmd() != null && businessCustomerSignersRs.getCmd().getStat() != null
                        && businessDetailsRs.getCmd() != null && businessDetailsRs.getCmd().getStat() != null)) {

            Pair<BusinessCustomerSignersRs, BusinessDetailsRs> inputPair = Pair.of(businessCustomerSignersRs,
                    businessDetailsRs);
            response = cSTBusinessCustomerRsConverter.convert(inputPair);

        }
        logger.debug("Exit - getAccountRelationships method of CSTBusinessCustomerDAOImpl class");
        return response;

    }

}
