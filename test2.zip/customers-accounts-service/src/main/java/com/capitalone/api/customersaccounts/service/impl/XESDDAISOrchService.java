package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.XESDDAISDAO;
import com.capitalone.api.customersaccounts.dao.XESDDAISV2DAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;

@Profile
@Trace
@Named
public class XESDDAISOrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private XESDDAISDAO xesDDAISDAO;
    
    @Inject
    private XESDDAISV2DAO xesDDAISV2DAO;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Inject
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    /**
     * Method calls DAO of XESDDAIS
     * 
     * @param customerAccountsRequest customers account input data
     * @param context holds the user Context
     * @return List of Retail accounts response
     */
    @Async
    public Future<REASResponse> execute(CustomerAccountsRequest customerAccountsRequest, EPFContext context) {

        logger.debug("Enter - execute method of xesDDAISResponse");

        REASResponse xesDDAOSummary = new REASResponse();
        List<REASResponse> xesDDAResp = new ArrayList<REASResponse>();

        List<Future<REASResponse>> xesDDAResponesFutures = new ArrayList<Future<REASResponse>>();

        if (customerAccountsRequest != null && customerAccountsRequest.getReasSupportedSORID() != null
                && !(customerAccountsRequest.getReasSupportedSORID().containsAll(Constants.SORID_IM))
                && customerAccountsUtil.findSORIDList(customerAccountsRequest, Constants.SORIDLIST_IM)) {

            Map<String, Map<String, OLBAttributes>> mapProdDesc = customerAccountsRefDataBean
                    .getRetailProductDescriptionOLBR();

            retrieveXESDDAISResponse(customerAccountsRequest, context, xesDDAResponesFutures, mapProdDesc);
            
            populateXESDDAISRespones(xesDDAResp, xesDDAResponesFutures);

            for (REASResponse repo : xesDDAResp) {
                xesDDAOSummary = customerAccountsUtil.merge(xesDDAOSummary, repo);
            }

        }
        logger.debug("Exit - execute method of xesDDAISResponse");
        return new AsyncResult<REASResponse>(xesDDAOSummary);
    }

    private void retrieveXESDDAISResponse(CustomerAccountsRequest customerAccountsRequest, EPFContext context,
            List<Future<REASResponse>> xesDDAResponesFutures, Map<String, Map<String, OLBAttributes>> mapProdDesc) {
        if(customerAccountsRequest.getEnableXESDDAISCache().contains(customerAccountsRequest.getAppVersion()))
        {
             for (CustomerAccountKey customerAccountKey : customerAccountsRequest.getCustomerAccountKeyList()) {
                 if (Constants.SORIDLIST_IM.contains(customerAccountKey.getSorId())) {
                    Future<REASResponse> futureCall = xesDDAISV2DAO.getIMAccountDetails(context, customerAccountKey, mapProdDesc);
                    xesDDAResponesFutures.add(futureCall);
                 }
             }
        }
        else
        {
             for (CustomerAccountKey customerAccountKey : customerAccountsRequest.getCustomerAccountKeyList()) {
                 if (Constants.SORIDLIST_IM.contains(customerAccountKey.getSorId())) {
                    Future<REASResponse> futureCall = xesDDAISDAO.getIMAccountDetails(context, customerAccountKey, mapProdDesc);
                    xesDDAResponesFutures.add(futureCall);
                 }
             }
        }
    }

    private void populateXESDDAISRespones(List<REASResponse> xesDDAResp,
            List<Future<REASResponse>> xesDDAResponesFutures) {
        for (Future<REASResponse> res : xesDDAResponesFutures) {
            try {
                REASResponse response = res.get(Constants.WAIT_TIME, Constants.WAIT_UNIT);
                xesDDAResp.add(response);
            } catch (ExecutionException ex) {
                logger.error(" Execution Exception {}", ex);
                res.cancel(true);
            } catch (InterruptedException ex) {
                logger.error(" Interupted Exception {}", ex);
                res.cancel(true);
            } catch (TimeoutException ex) {
                logger.error(" TimeoutException Exception {}", ex);
                res.cancel(true);
            }
        }
    }

}
