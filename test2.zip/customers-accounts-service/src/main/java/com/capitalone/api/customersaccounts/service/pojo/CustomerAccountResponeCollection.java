package com.capitalone.api.customersaccounts.service.pojo;

import java.util.List;

import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccount;

public class CustomerAccountResponeCollection {
    private List<CustomerAccount> customerAccount = null;

    private ApiErrorCode reasErrorResponse = null;

    public ApiErrorCode getReasErrorResponse() {
        return reasErrorResponse;
    }

    public void setReasErrorResponse(ApiErrorCode reasErrorResponse) {
        this.reasErrorResponse = reasErrorResponse;
    }

    public List<CustomerAccount> getCustomerAccount() {
        return customerAccount;
    }

    public void setCustomerAccount(List<CustomerAccount> customerAccount) {
        this.customerAccount = customerAccount;
    }

}
