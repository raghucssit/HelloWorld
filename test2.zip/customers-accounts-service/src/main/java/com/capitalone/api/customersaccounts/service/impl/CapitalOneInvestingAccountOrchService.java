package com.capitalone.api.customersaccounts.service.impl;

import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.CapitalOneInvestingAccountDAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;

/**
 * Service Implementation for COI Accounts
 * 
 */

@Profile
@Trace
@Named
public class CapitalOneInvestingAccountOrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private CapitalOneInvestingAccountDAO capitalOneInvestingAccountDAO;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;
    
    @Async
    public Future<REASResponse> execute(CustomerAccountsRequest customerAccountsRequest, EPFContext context) {

        Future<REASResponse> finalReas = null;

        logger.debug("Enter -- execute method of CapitalOneInvestingAccountOrchService");
        if (customerAccountsUtil.findSORID(customerAccountsRequest, Integer.valueOf(Constants.SOR_ID_COI))) {
            finalReas = capitalOneInvestingAccountDAO.getInvestingAccount(context, customerAccountsRequest);
        }
        return finalReas;

    }

}
