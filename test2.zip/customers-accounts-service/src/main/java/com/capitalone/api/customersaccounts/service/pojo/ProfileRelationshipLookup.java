/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.pojo;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author rqa254
 * 
 */
public class ProfileRelationshipLookup extends CustomerInfoBean {

    private String customerAccountRelationshipCode;

    private boolean trustAccountInd;

    private String ownershipType;

    private String errorCd;

    // //Default 1 as it is for sole owner, we will change this only when the customerCount is more than1
    private int customerCount = 1;

    public int getCustomerCount() {
        return customerCount;
    }

    public void setCustomerCount(int customerCount) {
        this.customerCount = customerCount;
    }

    public String getCustomerAccountRelationshipCode() {
        return customerAccountRelationshipCode;
    }

    public void setCustomerAccountRelationshipCode(String customerAccountRelationshipCode) {
        this.customerAccountRelationshipCode = customerAccountRelationshipCode;
    }

    public boolean getTrustAccountInd() {
        return trustAccountInd;
    }

    public void setTrustAccountInd(boolean trustAccountInd) {
        this.trustAccountInd = trustAccountInd;
    }

    public String getOwnershipType() {
        return ownershipType;
    }

    public void setOwnershipType(String ownershipType) {
        this.ownershipType = ownershipType;
    }

    public String getErrorCd() {
        return errorCd;
    }

    public void setErrorCd(String errorCd) {
        this.errorCd = errorCd;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object rhs) {
        return EqualsBuilder.reflectionEquals(this, rhs, false);
    }
}