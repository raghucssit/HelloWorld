/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.convert.request;

import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRq;
import com.capitalone.ecrcustomerrelationshipsisv2.v2.RegisteredItem3PartKey;


/**
 * This class is Converter for CustomerAccountsRequest to ECR Request for V2
 * 
 */

@Profile
@Trace
@Named
public class ECRCustomerRelationshipISV2RequestConverter extends
        ConversionServiceAwareConverter<CustomerAccountsRequest, CustIdentityMatchedAccountsDetailsInqRq> {

    private Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * Converts the CustomerAccountsRequest to CustIdentityMatchedAccountsInqRqV2(ECR req) type
     * 
     * @param request customers accounts information
     * @return input Request for ECR
     */

    @Override
    public CustIdentityMatchedAccountsDetailsInqRq convert(CustomerAccountsRequest request) {
        logger.debug("CustIdentityMatchedAccountsInqRqForV2  : convert -> Start");
        logger.debug("Client Request for V2 : CustomerAccountsRequest={}", request);

        CustIdentityMatchedAccountsDetailsInqRq ecrISV2Request = null;

        ecrISV2Request = new CustIdentityMatchedAccountsDetailsInqRq();
        ecrISV2Request.setCmd(new CustIdentityMatchedAccountsDetailsInqRq.Cmd());
        ecrISV2Request.getCmd().setECRLookUpKey(new CustIdentityMatchedAccountsDetailsInqRq.Cmd.ECRLookUpKey());

        RegisteredItem3PartKey registeredItem3partKeyForV2 = new RegisteredItem3PartKey();

        if ((null != request.getProfileReferenceId())
                && (StringUtils.isNotBlank(request.getProfileReferenceId().getSSOID()))) {
            logger.debug("Client Request For V2 : setRgstryRltnshpID={} : ProfileReferenceId", request.getProfileReferenceId());

            registeredItem3partKeyForV2.setRgstryRltnshpID(request.getProfileReferenceId().getSSOID());
            // Hardcoding below three fields as per ECR team request.
            registeredItem3partKeyForV2.setRgstryRltnshpAssociationTypeCd(Constants.PROFILE_TYPE);
            registeredItem3partKeyForV2.setRgstryRltnshpAssociationSORID(Constants.PROFILE_SORID);
        } else if (null != request.getCustomerReferenceId()
                && null != request.getCustomerReferenceId().getEnterpriseServicingCustomerId()) {
            logger.debug("Client Request : setRgstryRltnshpID={} : CustomerReferenceId",
                    request.getCustomerReferenceId());
            registeredItem3partKeyForV2.setRgstryRltnshpID(request.getCustomerReferenceId()
                    .getEnterpriseServicingCustomerId());
            // Hardcoding below three fields as per ECR team request.
            registeredItem3partKeyForV2.setRgstryRltnshpAssociationTypeCd(Constants.ECR_REGISTRY_TYPE_CD);
            registeredItem3partKeyForV2.setRgstryRltnshpAssociationSORID(Short.valueOf(Constants.ECR_REGISTRY_SORID));
        }

        ecrISV2Request.getCmd().getECRLookUpKey().setRegisteredItem3PartKey(registeredItem3partKeyForV2);

        logger.debug("CustIdentityMatchedAccountsInqRqForV2  : convert -> End");
        return ecrISV2Request;
    }
}