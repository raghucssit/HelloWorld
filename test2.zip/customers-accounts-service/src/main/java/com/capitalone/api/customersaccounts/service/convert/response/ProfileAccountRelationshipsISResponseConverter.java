/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.convert.response;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.convert.request.BifToBusinessCustomerRqConverter;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRoleTypes;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRq;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerSignersRs;
import com.capitalone.cstbusinesscustomeris.v1.BusinessDetailsRs;
import com.capitalone.cstbusinesscustomeris.v1.CSTBusinessCustomerSignersISSOAP;
import com.capitalone.profileaccountrelationshipsis.v1.AccountRelationshipRs;
import com.capitalone.profileaccountrelationshipsis.v1.DepositAccountCustomerRoleTypes;

/**
 * This class is the response Converter for ProfileAccountRelationshipsIS
 * 
 */

@Profile
@Trace
@Named
public class ProfileAccountRelationshipsISResponseConverter {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private CSTBusinessCustomerSignersISSOAP cstBusinessCustomerISService;

    @Inject
    private BifToBusinessCustomerRqConverter bifToBusinessCustomerRqConverter;

    /**
     * Converts native response of profileaccountrelationshipsis to ProfileRelationshipLookup type
     * 
     * @param acctListInqRs response of profileIS
     * @param customerID customer ID
     * @param acctNum account information
     * @return customer role
     */

    public ProfileRelationshipLookup convert(AccountRelationshipRs acctListInqRs, String customerID, String acctNum) {
        ProfileRelationshipLookup profileRelationshipLookup = null;

        logger.debug("ProfileAccountRelationshipsISResponseConverter  : convert -> Start");
        if (customerID != null && acctListInqRs != null && acctListInqRs.getCmd() != null
                && acctListInqRs.getCmd().getDepositAccountCustomerRoleTypes() != null) {
            // TODO:
            // customerAccountsUtil.checkResponseStatus(acctListInqRs.getAccountRelationshipRs().getCmd().getStat(),
            // true);
            profileRelationshipLookup = new ProfileRelationshipLookup();
            profileRelationshipLookup.setCustomerId(customerID);
            profileRelationshipLookup.setAccountNumber(acctNum);

            BusinessCustomerRq businessCustomerRq = null;
            BusinessDetailsRs businessDetailsRs = null;
            BusinessCustomerSignersRs businessCustomerSignersRs = null;
            String bifwithownerShipValueONE = "";
            bifwithownerShipValueONE = fetchCustomerInformation(acctListInqRs, customerID, profileRelationshipLookup);
            if ((!bifwithownerShipValueONE.equalsIgnoreCase(customerID)) && (!bifwithownerShipValueONE.isEmpty())) {
                try {
                    logger.debug("ProfileAccountRelationshipsISResponseConverter : Calling CST  with BIS {} ",
                            bifwithownerShipValueONE);
                    businessCustomerRq = bifToBusinessCustomerRqConverter.convert(bifwithownerShipValueONE);
                    businessDetailsRs = cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq);
                    businessCustomerSignersRs = cstBusinessCustomerISService
                            .businessCustomerSignersInq(businessCustomerRq);

                    logger.debug("CustomerAccountRelationshipCode is  {} ", businessDetailsRs.getCmd()
                            .getCustomerAccountRelationshipCode());
                    profileRelationshipLookup.setCustomerAccountRelationshipCode(businessDetailsRs.getCmd()
                            .getCustomerAccountRelationshipCode());
                    profileRelationshipLookup.setTrustAccountInd(false);

                    setCustomerRole(customerID, profileRelationshipLookup, businessCustomerSignersRs);

                    profileRelationshipLookup.setCustomerId(customerID);
                    profileRelationshipLookup.setAccountNumber(acctNum);
                } catch (Exception ex) {
                    logger.error("Exception while making call to cstBusinessCustomerIS {} {}", logger.getClass(), ex);

                    profileRelationshipLookup.setErrorCd(Constants.CST_ACCOUNT_EXCEPTION);
                }
            }
        }

        logger.debug("ProfileAccountRelationshipsISResponseConverter  : convert -> END");
        return profileRelationshipLookup;
    }

    private void setCustomerRole(String customerID, ProfileRelationshipLookup profileRelationshipLookup,
            BusinessCustomerSignersRs businessCustomerSignersRs) {
        for (BusinessCustomerRoleTypes role : businessCustomerSignersRs.getCmd().getBusinessCustomerRoleTypes()) {
            if (null != role.getPrimaryCustomerID() && role.getPrimaryCustomerID().equalsIgnoreCase(customerID)) {
                profileRelationshipLookup.setOwnershipType(role.getOwnershipType());
            }
        }
    }

    private String fetchCustomerInformation(AccountRelationshipRs acctListInqRs, String customerID,
            ProfileRelationshipLookup profileRelationshipLookup) {
        String bifwithownerShipValueONE = "";
        for (DepositAccountCustomerRoleTypes custRole : acctListInqRs.getCmd().getDepositAccountCustomerRoleTypes()) {
            if (null != custRole.getOwnershipType() && custRole.getOwnershipType().equalsIgnoreCase("1")) {
                bifwithownerShipValueONE = custRole.getCustomerID();
            }
            if (customerID.equalsIgnoreCase(custRole.getCustomerID())) {

                if (acctListInqRs.getCmd().getDepositAccountCustomerRoleTypes().size() > 1) {
                    profileRelationshipLookup.setCustomerCount(acctListInqRs.getCmd()
                            .getDepositAccountCustomerRoleTypes().size());
                }
                logger.debug("ProfileAccountRelationshipsISResponseConverter : ProductType is {}", acctListInqRs
                        .getCmd().getProductType(), "  :: for customerID {} ", customerID);
                if ((acctListInqRs.getCmd().getProductType() != null)
                        && (acctListInqRs.getCmd().getProductType().equalsIgnoreCase("3200")
                                || acctListInqRs.getCmd().getProductType().equalsIgnoreCase("3600") || acctListInqRs
                                .getCmd().getProductType().equalsIgnoreCase("4500"))) {
                    boolean ownership = (null != custRole.getOwnershipType() && custRole.getOwnershipType().equalsIgnoreCase("1"));
                    if ((ownership)
                            && (custRole.getCustomerID().equalsIgnoreCase(customerID)
                                    && null != custRole.getOwnershipType() && custRole.getOwnershipType()
                                    .equalsIgnoreCase("1"))) {
                        logger.debug("ProfileAccountRelationshipsISResponseConverter : OwnershipType is : 1");

                        map360BusinessAccountRelationship(customerID, profileRelationshipLookup, custRole);
                        break;

                    }

                } else {
                    setCustomerRelationshipCode(acctListInqRs, profileRelationshipLookup);
                    profileRelationshipLookup.setOwnershipType(custRole.getOwnershipType());
                    profileRelationshipLookup.setTrustAccountInd(acctListInqRs.getCmd().isTrustAccountInd());
                    logger.debug("OwnershipTyp is  {} ", custRole.getOwnershipType());
                    break;
                }
                break;
            }
        }
        return bifwithownerShipValueONE;
    }

    private void setCustomerRelationshipCode(AccountRelationshipRs acctListInqRs,
            ProfileRelationshipLookup profileRelationshipLookup) {
        if (acctListInqRs.getCmd().getCustomerAccountRelationshipCode() != null) {
            profileRelationshipLookup.setCustomerAccountRelationshipCode(acctListInqRs.getCmd()
                    .getCustomerAccountRelationshipCode());
        }
    }

    private void map360BusinessAccountRelationship(String customerID,
            ProfileRelationshipLookup profileRelationshipLookup, DepositAccountCustomerRoleTypes custRole) {
        BusinessCustomerRq businessCustomerRq;
        BusinessDetailsRs businessDetailsRs;
        try {
            logger.debug("ProfileAccountRelationshipsISResponseConverter : Calling CST  with customerID {} ",
                    customerID);
            businessCustomerRq = bifToBusinessCustomerRqConverter.convert(customerID);
            businessDetailsRs = cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq);
            logger.debug("Received Resopnse from  cstBusinessCustomerISService.businessDetailsInq {} ",
                    businessDetailsRs);
            logger.debug("CustomerAccountRelationshipCode is  {} ", businessDetailsRs.getCmd()
                    .getCustomerAccountRelationshipCode());
            profileRelationshipLookup.setCustomerAccountRelationshipCode(businessDetailsRs.getCmd()
                    .getCustomerAccountRelationshipCode());
            profileRelationshipLookup.setTrustAccountInd(false);

            profileRelationshipLookup.setOwnershipType(Constants.TRUST_CODE_X);
            logger.debug("OwnershipTyp is  {} ", custRole.getOwnershipType());
        } catch (Exception ex) {
            logger.error("Exception while making call to cstBusinessCustomerIS {} {}", logger.getClass(), ex);

            profileRelationshipLookup.setErrorCd(Constants.CST_ACCOUNT_EXCEPTION);
        }
    }
}