package com.capitalone.api.customersaccounts.dao.impl;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.lang.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.OecpPreferencesDefaultDao;
import com.capitalone.api.customersaccounts.model.v1.Account;
import com.capitalone.api.customersaccounts.model.v1.Accounts;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.EndpointManager;
import com.capitalone.epf.servicelocator.model.EndpointProperties;
import com.google.common.net.HttpHeaders;

@Profile
@Trace
@Named
public class OecpPreferencesDefaultDaoImpl extends AbstractBaseService implements OecpPreferencesDefaultDao {

    private static final String ERR_GENERAL_ERROR_IN_PERF_LOG = "ERR_GENERAL_ERROR in Perf Log";

    private static final String ERROR = "SOAP-FAULT";
    
    private static final String INFO = "INFO";

    private static final String ESCID = "escid=";

    private static final String PREFERENCES = "preferences";

    private static final String ACCOUNTS = "accounts";

    @Inject
    private Client eapiRestClient;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Inject
    private EndpointManager endpointManager;

    private static final String INT_MONGO_OECP_PREFERENCES_RESOURCE_URL = "ec-preference-accounts";

    private static final String APPLICATION_JSON_V_3 = "application/json;charset=UTF-8";

    /**
     * Getting account nickname
     * 
     * @param context holds the request context
     * @param consumerId holds customerReferenceID
     * @return list of accountnicknames
     * 
     */
    @Override
    @Async
    public Future<List<OecpPreferResponse>> retrieveAccountNickname(EPFContext context, String consumerId) {
        logger.debug("Enter - retrieveAccountNickname method of OecpPreferencesDaoImpl class");
        List<OecpPreferResponse> oecpPreferResponseList = new ArrayList<OecpPreferResponse>();

        EndpointProperties endpointProperties = getDefaultEndpointProperties(INT_MONGO_OECP_PREFERENCES_RESOURCE_URL);

        String url = endpointProperties.getUrl();

        long startTime = 0;
        long responseTime = 0;

        try {

            Builder buildrequest = constructDefaultBuilder(consumerId, url);
            startTime = System.currentTimeMillis();
            Accounts accountPreferences = buildrequest.get(Accounts.class);
            responseTime = System.currentTimeMillis() - startTime;
            
            setDefaultOecpAccountPreferencesDetails(oecpPreferResponseList, accountPreferences);
            
            customerAccountsUtil.generateCustomPerfLog(context, responseTime,
                    String.valueOf(Constants.SUCCESS_STAT_CD), INFO, Constants.SUCCESS_RESPONSE,
                    INT_MONGO_OECP_PREFERENCES_RESOURCE_URL,Constants.ERROR_CODE_200);

        } catch (Exception e) {
            logger.debug("Exception Occurred {}", e);
            responseTime = System.currentTimeMillis() - startTime;
            String errocode = String.valueOf(Constants.ERROR_CODE_100);
            String statusDescription = ERR_GENERAL_ERROR_IN_PERF_LOG;
            int httpstatusCode = Constants.ERROR_CODE_400;
            String sevirity = ERROR;
            if (e.getCause() instanceof CustomerAPIRESTException) {
                CustomerAPIRESTException errorResponse = (CustomerAPIRESTException) e.getCause();
                if (errorResponse.getErrorResponse() != null
                        && !StringUtils.isBlank(errorResponse.getErrorResponse().getId())) {
                	errocode = errorResponse.getErrorResponse().getId();
                }
                if (!StringUtils.isBlank(errorResponse.getErrorResponse().getDeveloperText())) {
                	statusDescription = errorResponse.getErrorResponse().getDeveloperText();
                } else {
                	statusDescription = errorResponse.getErrorResponse().getText();
                }
                if (errorResponse.getHttpStatus() != null) {
                	httpstatusCode= errorResponse.getHttpStatus();
                }
                if(errorResponse.getHttpStatus().equals(Constants.HTTP_404)){
                	sevirity = INFO;
                }
            }
            customerAccountsUtil.generateCustomPerfLog(context, responseTime, errocode,
            		sevirity, statusDescription, INT_MONGO_OECP_PREFERENCES_RESOURCE_URL,httpstatusCode);
        }
        logger.debug("Exit - retrieveAccountNickname method of OecpPreferencesDaoImpl class");
        return new AsyncResult<List<OecpPreferResponse>>(oecpPreferResponseList);
    }

    private void setDefaultOecpAccountPreferencesDetails(List<OecpPreferResponse> oecpPreferResponseList,
            Accounts accountPreferences) {
        logger.debug("Enter - setDefaultOecpAccountPreferencesDetails method of OecpPreferencesDaoImpl class");
        for (Account account : accountPreferences.getAccounts()) {
            if (account != null) {
                logger.debug("Account in oecp {}", account);
                OecpPreferResponse oecpPreferResponse = new OecpPreferResponse();
                if (account.getPreferences() != null && account.getPreferences().getAccountNickname() != null) {
                    oecpPreferResponse.setAccountNickname(account.getPreferences().getAccountNickname());
                }
                oecpPreferResponse.setAccountId(account.getAccountId());
                oecpPreferResponse.setSorId(account.getSorId());
                oecpPreferResponseList.add(oecpPreferResponse);
            }
        }
        logger.debug("Enter - setDefaultOecpAccountPreferencesDetails method of OecpPreferencesDaoImpl class");
    }

    @SuppressWarnings("deprecation")
    private Builder constructDefaultBuilder(String consumerId, String url) {
        logger.debug("Enter - constructDefaultBuilder method of OecpPreferencesDaoImpl class");
        String esicddetails = ESCID.concat(consumerId);
       
        WebTarget requestPath = null;
        
        UriBuilder uri = UriBuilder.fromUri(url).path(URLEncoder.encode(esicddetails)).path(ACCOUNTS)
                .path(Constants.TILDE).path(PREFERENCES);
        requestPath = eapiRestClient.target(uri);

        Builder buildrequest = requestPath.request().accept(APPLICATION_JSON_V_3)
                .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V_3);
        logger.debug("build request for OECP {} ", buildrequest);
        logger.debug("Exit - constructDefaultBuilder method of OecpPreferencesDaoImpl class");
        return buildrequest;
    }

    private EndpointProperties getDefaultEndpointProperties(String restApiUrl) {
        logger.debug("Enter - getEndpointProperties method of OecpPreferencesDaoImpl class");
        EndpointProperties endpointProperties = endpointManager.getWSProperties(StringUtils.EMPTY, restApiUrl, null);
        logger.debug("Exit - getEndpointProperties method of OecpPreferencesDaoImpl class");
        return endpointProperties;

    }

}
