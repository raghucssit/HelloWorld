package com.capitalone.api.customersaccounts.dao.impl;

import java.util.Map;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.dao.CustInfoDLSDAO;
import com.capitalone.api.customersaccounts.entity.CustInfoDLSEntity;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRq;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs;
import com.capitalone.epf.context.model.EPFContext;

/**
 *
 */

@Profile
@Trace
@Named
public class CustInfoDLSDaoImpl extends AbstractBaseService implements CustInfoDLSDAO {

    @Inject
    private CustInfoDLSEntity custInfoDLSEntity;

    @SuppressWarnings("unchecked")
    @Override
    @Async
    public Future<Map<String, String>> getCustomerRole(EPFContext context, CustomerAccountKey customerAccountKey) {

        CustInfoDLSInqRq custInfoDLSInqRq = conversionService.convert(customerAccountKey, CustInfoDLSInqRq.class);
        CustInfoDLSInqRs custInfoDLSInqRs = null;
        Map<String, String> custInfoDLSRes = null;
        if (custInfoDLSInqRq != null) {
            try {
                custInfoDLSInqRs = custInfoDLSEntity.retiveAccountDetails(custInfoDLSInqRq,
                        context.getUserId().concat(customerAccountKey.getAccountNumber()));
                logger.debug("custInfoDLSRes {}", custInfoDLSInqRs);
            } catch (Exception e) {
                logger.debug("Exception occurred while calling Customer information DLS {}", e.getCause());
            }
        }

        if (custInfoDLSInqRs != null && custInfoDLSInqRs.getCmd() != null
                && custInfoDLSInqRs.getCmd().getCustInformation() != null
                && custInfoDLSInqRs.getCmd().getCustInformation().getCustInfo() != null) {
            custInfoDLSRes = conversionService.convert(custInfoDLSInqRs.getCmd().getCustInformation().getCustInfo(),
                    Map.class);
        }
        if (custInfoDLSRes != null) {
            return new AsyncResult<Map<String, String>>(custInfoDLSRes);
        } else {
            return null;
        }
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
