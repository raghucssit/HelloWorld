package com.capitalone.api.customersaccounts.dao;

import java.util.List;
import java.util.concurrent.Future;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.epf.context.model.EPFContext;

public interface OLBAccountPreferencesISDAO {
    Future<List<OLBResponse>> getAccountNickname(EPFContext context, CustomerAccountsRequest customerAccountsRequest);

}
