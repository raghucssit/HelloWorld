package com.capitalone.api.customersaccounts.service.convert.request;

import javax.inject.Named;

import org.apache.commons.lang.StringUtils;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRq;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRq.Cmd.Acct;

/**
 * This class Converts form String To CustInfoDLSRqConverter Request
 * 
 */
@Profile
@Trace
@Named
public class CustInfoDLSRqConverter extends ConversionServiceAwareConverter<CustomerAccountKey, CustInfoDLSInqRq> {

    @Override
    public CustInfoDLSInqRq convert(CustomerAccountKey key) {
        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();

        Acct acct = new Acct();

        acct.setAcctID(StringUtils.leftPad(key.getAccountNumber(), 11, "0"));
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        return custInfoDLSInqRq;

    }

}
