package com.capitalone.api.customersaccounts.service.convert.response;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRs;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRs.Cmd.AccountsBalancesArray;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Profile
@Trace
@Named
public class ODSBrokerageAccountsISRespConverter extends ConversionServiceAwareConverter<BalancesInqRs, REASResponse> {

	/**
     * Converts ODS nativeResponse to REAS Response type
     * 
     * @param nativeResponse ODS Response
     * @return ODS customers accounts list
     */
    @Override
    public REASResponse convert(BalancesInqRs nativeResponse) {

        logger.debug("ODSBrokerageAccountsISRespConverter  : convert -> Start");
        REASResponse response = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();

        if (nativeResponse != null && nativeResponse.getCmd() != null) {
            if (nativeResponse.getCmd().getAccountsBalancesArray() != null) {
                List<AccountsBalancesArray> odsBrokerageaccountslist = nativeResponse.getCmd()
                        .getAccountsBalancesArray();

                setBalancesInq(customerAccountsResponseList, odsBrokerageaccountslist);
            }
            response.setAddStatList(getAdditionalStat(nativeResponse.getCmd().getStat()));

        }
        response.setCustomerAccountsResponseList(customerAccountsResponseList);

        logger.debug("ODSBrokerageAccountsISRespConverter  : convert -> End");
        return response;
    }

    private void setBalancesInq(List<CustomerAccountsResponse> customerAccountsResponseList,
            List<AccountsBalancesArray> odsBrokerageaccountslist) {
        logger.debug("ODSBrokerageAccountsISRespConverter  : setBalancesInq -> Start");
        CustomerAccountsResponse responseBean;

        for (AccountsBalancesArray odsBrokerageaccounts : odsBrokerageaccountslist) {
            responseBean = new CustomerAccountsResponse();
            populateBalanceInq(responseBean, customerAccountsResponseList, odsBrokerageaccounts);
        }
        logger.debug("ODSBrokerageAccountsISRespConverter  : setBalancesInq -> End");

    }

    private void populateBalanceInq(CustomerAccountsResponse responseBean,
            List<CustomerAccountsResponse> customerAccountsResponseList, AccountsBalancesArray odsBrokerageaccounts) {
        logger.debug("ODSBrokerageAccountsISRespConverter  : populateBalanceInq -> Start");
 
        if (odsBrokerageaccounts.getRecCntlStatDesc() != null && StringUtils.equalsIgnoreCase(odsBrokerageaccounts.getRecCntlStatDesc(), Constants.SUCCESS_RESPONSE)){
            
        if (StringUtils.isNotBlank(odsBrokerageaccounts.getAcctID())) {
            
            responseBean.setAccountId(StringUtils.stripStart((odsBrokerageaccounts.getAcctID()),"0"));
            responseBean.setAccountNumber(StringUtils.stripStart((odsBrokerageaccounts.getAcctID()),"0"));
            responseBean.setDisplayAccountNumber(StringUtils.stripStart((odsBrokerageaccounts.getAcctID()),"0"));
        }
        responseBean.setBusinessLine(Constants.BUSSINESSLINE_BROKERAGE);

        responseBean.setCurrencyCode(Constants.CURRENCY_CODE_USA);
        if (odsBrokerageaccounts.getOpenDate() != null) {
            responseBean.setOpenDate(odsBrokerageaccounts.getOpenDate());
        }
        if (odsBrokerageaccounts.getAggMktVal() != null) {
            responseBean.setAvailableBalance(odsBrokerageaccounts.getAggMktVal());
        }

        if (StringUtils.isNotBlank(String.valueOf(odsBrokerageaccounts.getSoRID()))) {
            responseBean.setSorId(String.valueOf(odsBrokerageaccounts.getSoRID()));
        }
        customerAccountsResponseList.add(responseBean);
        logger.debug("ODSBrokerageAccountsISRespConverter  : populateBalanceInq -> End");
 }
    }

    private List<AdditionalStat> getAdditionalStat(StatType stat) {

        logger.debug("Enter - getAdditionalStat method of ODSBrokerageAccountsISRespConverter class");
        if (stat == null) {
            return null;
        }
        // I am assuming we will never exceed int range for stat codes
        if (Long.valueOf(stat.getStatCd()) != null) {
            int intStatCode = (int) stat.getStatCd();
            if (stat.getSevrty() != null) {
                switch (stat.getSevrty()) {
                    case ERROR:
                        return getAddnStatCaseError(intStatCode);
                    default:
                        return null;

                }
            }
        }
        logger.debug("Exit - getAdditionalStat method of ODSBrokerageAccountsISRespConverter class");
        return null;
    }

    private List<AdditionalStat> getAddnStatCaseError(int intStatCode) {
        AdditionalStat addnStat = null;
        List<AdditionalStat> stat = new ArrayList<AdditionalStat>();
        switch (intStatCode) {
            case Constants.NO_RECORDS_MATCH_SELECTION_CRITERIA_2:
                addnStat = new AdditionalStat();
                addnStat.setNativeErrorCd(Constants.ODS_DATA_NOT_FOUND);
                addnStat.setStatDesc(Constants.ODS_DATA_NOT_FOUND_MSG);
                addnStat.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
                stat.add(addnStat);

                return stat;
            case Constants.ODS_GENERAL_ERROR:
                addnStat = new AdditionalStat();
                addnStat.setNativeErrorCd(Constants.ODS_GEN_ERROR_API_CODE);
                addnStat.setStatDesc(Constants.ODS_GEN_ERROR_STAT);
                addnStat.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
                stat.add(addnStat);
                // 500
                return stat;
            default:
                return null;

        }
    }
}
