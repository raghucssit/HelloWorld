package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.XESRelatedAccountDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;

/**
 * Service Implementation for Safe Deposit Box Accounts
 * 
 */

@Profile
@Trace
@Named
public class SafeDepoBoxAccountSummaryOrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private XESRelatedAccountDao xesRelatedAccountDao;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    /**
     * Method for retrieving Safe Deposit Box Accounts
     * 
     * @param customerAccountsRequest customers account input data
     * @param context holds the user Context
     * @return List of response of safe deposit accounts
     * 
     */


    @Async
    public Future<REASResponse> execute(CustomerAccountsRequest customerAccountsRequest, EPFContext context) {

        List<REASResponse> safeDepoBoxResponeFuturesRes = new ArrayList<REASResponse>();
        List<Future<REASResponse>> safeDepoBoxResponse = new ArrayList<Future<REASResponse>>();
        REASResponse finalReas = new REASResponse();

        logger.debug("Enter - execute method of SafeDepoBoxAccountSummaryOrchService class");
        List<String> repeatitionFilter = new ArrayList<String>();

        for (final CustomerAccountKey key : customerAccountsRequest.getCustomerAccountKeyList()) {
            if (Constants.SOR_ID_SDB.contains(key.getSorId())) {
                List<String> accountKeyList = new ArrayList<String>();

                if (!repeatitionFilter.contains(key.getConsumerId())) {
                    for (final CustomerAccountKey customerAccountKey : customerAccountsRequest
                            .getCustomerAccountKeyList()) {
                        addSDBAccounts(key, accountKeyList, customerAccountKey);
                    }
                    safeDepoBoxResponse.add(xesRelatedAccountDao.retrieve(context, key.getConsumerId(), accountKeyList,
                            key.getSorId()));
                    repeatitionFilter.add(key.getConsumerId());
                }
            }
        }

        populateSafeDepoBoxFuturesRes(safeDepoBoxResponeFuturesRes, safeDepoBoxResponse);

        for (REASResponse repo : safeDepoBoxResponeFuturesRes) {
            finalReas = customerAccountsUtil.merge(finalReas, repo);
        }

        logger.debug("Exit - execute method of SafeDepoBoxAccountSummaryOrchService class");
        return new AsyncResult<REASResponse>(finalReas);
    }

    private void addSDBAccounts(final CustomerAccountKey key, List<String> accountKeyList,
            final CustomerAccountKey customerAccountKey) {
        if (key.getConsumerId().equals(customerAccountKey.getConsumerId())
                && Constants.SOR_ID_SDB.contains(customerAccountKey.getSorId())) {
            accountKeyList.add(customerAccountKey.getAccountNumber());
        }
    }

    private void populateSafeDepoBoxFuturesRes(List<REASResponse> safeDepoBoxResponeFuturesRes,
            List<Future<REASResponse>> safeDepoBoxResponse) {
        for (Future<REASResponse> futureSDBResponse : safeDepoBoxResponse) {
            try {
                safeDepoBoxResponeFuturesRes.add(futureSDBResponse.get(Constants.WAIT_TIME, Constants.WAIT_UNIT));
            } catch (InterruptedException ex) {
                logger.error("InterruptedException in Class {}", logger.getClass(), ex);
                futureSDBResponse.cancel(true);
            } catch (ExecutionException ex) {
                logger.error("ExecutionException in Class {}", logger.getClass(), ex);
                futureSDBResponse.cancel(true);
            } catch (TimeoutException ex) {
                logger.error("TimeoutException in Class {}", logger.getClass(), ex);
                futureSDBResponse.cancel(true);
            }
        }
    }

}
