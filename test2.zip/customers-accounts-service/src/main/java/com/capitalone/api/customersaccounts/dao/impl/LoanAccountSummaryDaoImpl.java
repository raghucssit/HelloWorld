package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.LoanAccountSummaryDao;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.xesloanacctis.v1.AcctInqISRq;
import com.capitalone.xesloanacctis.v1.AcctInqISRs;
import com.capitalone.xesloanacctis.v1.XESLoanAcctISSoap;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Profile
@Trace
@Named
public class LoanAccountSummaryDaoImpl extends AbstractBaseService implements LoanAccountSummaryDao {

    @Inject
    private ConversionService conversionService;

    @Inject
    private XESLoanAcctISSoap xesLoanAcctISSoap;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    /**
     * This method returns list of loan accounts
     * 
     * @param context holds the request context
     * @param customerAccountKey holds the input information for REAS
     * @return list of accounts details
     */
    @Override
    @Async
    public Future<REASResponse> retrieveLoanAccountummary(EPFContext context, CustomerAccountKey customerAccountKey) {

        logger.debug("Entry - retrieve method of LoanAccountSummaryDaoImpl class");

        REASResponse response = new REASResponse();
        List<CustomerAccountsResponse> listCustomerAccountsResponses = new ArrayList<CustomerAccountsResponse>();

        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();
        AcctInqISRq nativeRequest = conversionService.convert(customerAccountKey, AcctInqISRq.class);

        AcctInqISRs acctInqISRs = null;

        try {
            acctInqISRs = (AcctInqISRs) xesLoanAcctISSoap.acctInq(nativeRequest);
        } catch (Exception ex) {
            logger.error("Exception while making call to xesLoanAcctISSoap {}", ex);
            addnStatFail.setNativeErrorCd(Constants.XES_LOANACNT_CONNECT_ERROR);
            addnStatFail.setStatDesc(Constants.XPRESS_LENDING_SERVICE_DOWN_STAT_DESC.concat(CustomerAccountsUtil
                    .constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(), customerAccountKey.getSorId())));
            addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
            addnStatFail.setAccountId(customerAccountKey.getAccountNumber());
            addnStatFailList.add(addnStatFail);
            response.setAddStatList(addnStatFailList);
            response.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));
            logger.debug("CATCH - AdditionalStat method of xesLoanAcctISDAO {}", response);

        }

        setLoanAccountSummaryDetails(response, listCustomerAccountsResponses, customerAccountKey, acctInqISRs);

        response.setCustomerAccountsResponseList(listCustomerAccountsResponses);

        logger.debug("Exit - retrieve method of LoanAccountSummaryDaoImpl class");
        return new AsyncResult<REASResponse>(response);

    }

    private void setLoanAccountSummaryDetails(REASResponse response,
            List<CustomerAccountsResponse> listCustomerAccountsResponses, CustomerAccountKey key,
            AcctInqISRs acctInqISRs) {
        CustomerAccountsResponse customerAccountsResponse;
        logger.debug("Enter setLoanAccountSummaryDetails method of LoanAcctIS DAO Impl");
        customerAccountsResponse = conversionService.convert(acctInqISRs, CustomerAccountsResponse.class);
        if (customerAccountsResponse != null) {
            customerAccountsResponse.setSorId(String.valueOf(key.getSorId()));

            customerAccountsResponse.setProductTypeCode(customerAccountsRefDataBean.getProductTypeCode(
                    Short.valueOf(customerAccountsResponse.getSorId()), acctInqISRs.getCmd().getLoanAcctInfo()
                            .getBankAcctTypeCd()));

            customerAccountsResponse.setProductTypeDescription(customerAccountsRefDataBean
                    .getProductTypeDescription(customerAccountsResponse.getProductTypeCode()));

            customerAccountsResponse.setBusinessLine(customerAccountsRefDataBean.getBusinessLine(
                    customerAccountsResponse.getProductTypeCode(), String.valueOf(key.getSorId())));

            listCustomerAccountsResponses.add(customerAccountsResponse);
        }
        if (null != acctInqISRs && null != acctInqISRs.getCmd()) {
            response.setAddStatList(getAdditionalStat(acctInqISRs.getCmd().getStat(), key));
        }
        logger.debug("Exit setLoanAccountSummaryDetails method of LoanAcctIS DAO Impl");
    }

    protected List<AdditionalStat> getAdditionalStat(StatType responseStatus, CustomerAccountKey customerAccountKey) {

        logger.debug("Enter - getAdditionalStat method of LoanAccountSummaryDaoImpl class");
        if (responseStatus == null) {
            return null;
        }
        // I am assuming we will never exceed int range for stat codes

        if (Long.valueOf(responseStatus.getStatCd()) != null) {
            int intStatCode = (int) responseStatus.getStatCd();
            if (responseStatus.getSevrty() != null) {
                switch (responseStatus.getSevrty()) {

                    case INFO:
                        return getAddnStatCaseInfo(responseStatus, intStatCode);
                    case ERROR:

                        return getAddnStatCaseError(responseStatus, intStatCode, customerAccountKey);
                    default:
                        return null;

                }
            }
        }
        logger.debug("Exit - getAdditionalStat method of LoanAccountSummaryDaoImpl class");
        return null;
    }

    private List<AdditionalStat> getAddnStatCaseInfo(StatType responseStatus, int intStatCode) {
        logger.debug("Enter - getAddnStatCaseInfo method of LoanAccountSummaryDaoImpl class");
        switch (intStatCode) {
            case Constants.ERROR_CODE_0:
                return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(), Constants.HTTP_404);
                // 404
            default:
                return null;

        }
    }

    private List<AdditionalStat> getAddnStatCaseError(StatType responseStatus, int intStatCode,
            CustomerAccountKey customerAccountKey) {
        logger.debug("Enter - getAddnStatCaseError method of LoanAccountSummaryDaoImpl class");
        if (Constants.XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.contains(String.valueOf(intStatCode))) {

            return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(),
                    Constants.INTERNAL_SERVER_ERROR_CODE);

        } else {
            List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
            AdditionalStat additionalStat = new AdditionalStat();
            additionalStat.setNativeErrorCd(String.valueOf(responseStatus.getStatCd()));
            additionalStat.setStatDesc(responseStatus.getStatDesc().concat(
                    CustomerAccountsUtil.constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(),
                            customerAccountKey.getSorId())));
            additionalStatList.add(additionalStat);
            return additionalStatList;
        }

    }

}
