/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.dao.impl;

import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.ProfileAccountRelationshipsDao;
import com.capitalone.api.customersaccounts.service.convert.response.ProfileAccountRelationshipsISResponseConverter;
import com.capitalone.api.customersaccounts.service.pojo.CustomerInfoBean;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.profileaccountrelationshipsis.v1.AccountRelationshipRq;
import com.capitalone.profileaccountrelationshipsis.v1.AccountRelationshipRs;
import com.capitalone.profileaccountrelationshipsis.v1.ProfileAccountRelationshipsISSOAP;

/**
 * DAO for retrieving Profile Account Relationship data from ProfileAccountRelationshipsIS
 * 
 */
@Profile
@Trace
@Named
public class ProfileAccountRelationshipsDaoImpl extends AbstractBaseService implements ProfileAccountRelationshipsDao {

    @Inject
    private ProfileAccountRelationshipsISSOAP profileAccountRelationshipsISSOAP;

    @Inject
    private ProfileAccountRelationshipsISResponseConverter profileAccountRelationshipsISResponseConverter;

    @Inject
    private ConversionService conversionService;

    /**
     * Retrieving Profile Account Relationship data from ProfileAccountRelationshipsIS
     * 
     * @param context holds the request context
     * @param custId user sorcustID
     * @param accountNumber account information
     * @param apiKey client key
     * @return list of customers role
     * 
     */


    @Async
    @Override
    public Future<ProfileRelationshipLookup> retrieve(EPFContext context, final String custId,
            final String accountNumber, String apiKey) {

        logger.debug("Enter - retrieve method of ProfileAccountRelationshipsDaoImpl class");
        ProfileRelationshipLookup response = new ProfileRelationshipLookup();
        AccountRelationshipRs acctListInqISRs = null;

        AccountRelationshipRq nativeRequest = null;
        CustomerInfoBean custInfo = new CustomerInfoBean();
        custInfo.setAccountNumber(accountNumber);
        custInfo.setCustomerId(custId);
        nativeRequest = conversionService.convert(custInfo, AccountRelationshipRq.class);
        try {
            acctListInqISRs = (AccountRelationshipRs) profileAccountRelationshipsISSOAP
                    .profileAccountRelationshipsInq(nativeRequest);
        } catch (Exception ex) {
            logger.error("Exception while making call to ProfileAccountRelationshipsIS {}", logger.getClass(), ex);
            response.setAccountNumber(accountNumber);
            response.setErrorCd(Constants.PROFILE_ACCOUNT_EXCEPTION);
        }

        if (null != acctListInqISRs && null != acctListInqISRs.getCmd()) {
            response = profileAccountRelationshipsISResponseConverter.convert(acctListInqISRs, custId,
                    custInfo.getAccountNumber());
        }
        logger.debug("Exit - retrieve method of ProfileAccountRelationshipsDaoImpl class");
        return new AsyncResult<ProfileRelationshipLookup>(response);
    }
}