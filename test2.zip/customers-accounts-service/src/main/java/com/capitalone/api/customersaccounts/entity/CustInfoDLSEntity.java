package com.capitalone.api.customersaccounts.entity;

import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRq;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs;

public interface CustInfoDLSEntity {
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    CustInfoDLSInqRs retiveAccountDetails(CustInfoDLSInqRq custInfoDLSInqRq,String userId) throws Exception;
}
