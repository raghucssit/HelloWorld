package com.capitalone.api.customersaccounts.dao.impl;

import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.referencedata.cache.impl.AbstractLocalReferenceDataCategoryCacheManagerImpl;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;

@Named
@Profile
@Trace
public class OLBRLocalReferenceDataCategoryCacheManagerImpl extends
AbstractLocalReferenceDataCategoryCacheManagerImpl<OLBAttributes>{

}
