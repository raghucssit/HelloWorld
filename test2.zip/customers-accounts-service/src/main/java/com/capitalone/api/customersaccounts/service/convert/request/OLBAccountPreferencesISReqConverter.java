package com.capitalone.api.customersaccounts.service.convert.request;

import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInput;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRq;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRq.Cmd;

@Profile
@Trace
@Named
public class OLBAccountPreferencesISReqConverter extends
        ConversionServiceAwareConverter<CustomerAccountsRequest, AccountPreferencesInqRq> {
	/**
     * Converts the CustomerAccountsRequest to AccountPreferencesInqRq(OLB req) type
     * 
     * @param request customers accounts information
     * @return input Request for OLB
     */
    @Override
    public AccountPreferencesInqRq convert(CustomerAccountsRequest request) {
        AccountPreferencesInqRq accountPreferencesInqRq = null;

        if (request != null && request.getProfileReferenceId() != null) {
            accountPreferencesInqRq = new AccountPreferencesInqRq();
            Cmd cmd = new Cmd();
            AccountPreferencesInput accountPreferencesInput = new AccountPreferencesInput();
            accountPreferencesInput.setPermLginTxt(request.getProfileReferenceId().getSSOID());
            cmd.setAccountPreferencesInput(accountPreferencesInput);
            accountPreferencesInqRq.setCmd(cmd);
        }

        return accountPreferencesInqRq;
    }
}
