package com.capitalone.api.customersaccounts.service.convert.response;

import java.math.BigDecimal;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.model.product.Product;

@Profile
@Trace
@Named
public class ProfileAccountDetailResponseConverter extends
        ConversionServiceAwareConverter<ProfileAccountDetail, CustomerAccountsResponse> {

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    /**
     * Converts profileAccountDetail to CustomerAccountKey type
     * 
     * @param profileAccountDetail 360 account details
     * @return customer accounts response
     */
    @Override
    public CustomerAccountsResponse convert(ProfileAccountDetail profileAccountDetail) {

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        logger.debug("Enter - convert method of ProfileAccountDetailResponseConverter class");
        if (profileAccountDetail != null) {

            Product product = profileAccountDetail.getProduct();

            if (product != null) {
                response.setProductId(product.getProductId());
                response.setProductName(product.getProductName());
                response.setProductTypeCode(product.getProductTypeCode());
                response.setProductTypeDescription(product.getProductTypeDescription());

                // set product name if retirement indicator is on.
                setProductNameDetail(profileAccountDetail, response);

            }
            setProfileAcctDetail(profileAccountDetail, response);

        }
        logger.debug("Exit - convert method of ProfileAccountDetailResponseConverter class");
        return response;
    }

    private void setProductNameDetail(ProfileAccountDetail profileAccountDetail, CustomerAccountsResponse response) {
        logger.debug("Enter - setProductNameDetail method of ProfileAccountDetailResponseConverter class");
        if (profileAccountDetail.getProduct() != null && profileAccountDetail.getProduct().getProductId() != null
                && profileAccountDetail.getRetirementAccountIndicator() != null) {
            if (profileAccountDetail.getProduct().getProductId().equalsIgnoreCase(Constants.KEY_PROD_TYPE_3000)
                    && profileAccountDetail.getRetirementAccountIndicator()) {
                response.setProductName(Constants.PROD_DESC_IRA_SAVINGS);
            }
            if (profileAccountDetail.getProduct().getProductId().equalsIgnoreCase(Constants.KEY_PROD_TYPE_3500)
                    && profileAccountDetail.getRetirementAccountIndicator()) {
                response.setProductName(Constants.PROD_DESC_IRA_CD);
            }
        }
        logger.debug("Exit - setProductNameDetail method of ProfileAccountDetailResponseConverter class");
    }

    private void setProfileAcctDetail(ProfileAccountDetail profileAccountDetail, CustomerAccountsResponse response) {
        logger.debug("Enter - setProfileAcctDetail method of ProfileAccountDetailResponseConverter class");
        setAccountDetail(profileAccountDetail, response);

        if (response.getProductTypeCode() != null) {
            response.setBusinessLine(customerAccountsRefDataBean.getBusinessLine(response.getProductTypeCode(),
                    String.valueOf(Constants.PROFILE_SOR_ID_INT)));
        }

        if (profileAccountDetail.getAvailableBalance() != null) {
            response.setAvailableBalance(profileAccountDetail.getAvailableBalance());
        }
        /**
         * If profile Api doesn't send available balance set it to zero
         */
        else {
            response.setAvailableBalance(BigDecimal.ZERO);
        }

        populateCurrentBalance(profileAccountDetail, response);

        response.setBankNumber(Constants.BANK_NUM_360);
        response.setBankNumberDescription(Constants.BANK_NUM_360);

        if (profileAccountDetail.getOpenDate() != null) {
            response.setOpenDate(customerAccountsUtil.convertLocalDateToInstant(profileAccountDetail.getOpenDate()));
        }

        if (profileAccountDetail.getClosedDate() != null) {
            response.setClosedDate(customerAccountsUtil.convertLocalDateToInstant(profileAccountDetail.getClosedDate()));

        }

        response.setCurrencyCode(Constants.CURRENCY_CODE_USA);

        if (profileAccountDetail.getLoanAmountDue() != null) {
            response.setPaymentDueAmount(profileAccountDetail.getLoanAmountDue());
        }

        if (profileAccountDetail.getPaymentDueDate() != null) {
            response.setPaymentDueDate(customerAccountsUtil.convertLocalDateToInstant(profileAccountDetail
                    .getPaymentDueDate()));
        }
        logger.debug("Exit - setProfileAcctDetail method of ProfileAccountDetailResponseConverter class");
    }

    private void populateCurrentBalance(ProfileAccountDetail profileAccountDetail, CustomerAccountsResponse response) {
        /**
         * PrincipalBalance will be applicable to Loans
         */
        logger.debug("Enter - populateCurrentBalance method of ProfileAccountDetailResponseConverter class");
        if (Constants.PROFILE_LOANS_BUSINESS_LINE.equals(response.getBusinessLine())
                && profileAccountDetail.getPrincipalBalance() != null) {
            response.setCurrentBalance(profileAccountDetail.getPrincipalBalance());
        }
        /**
         * LedgerBalance will be applicable to Deposits
         */
        else if (Constants.PROFILE_DEPOSITS_BUSINESS_LINE.equals(response.getBusinessLine())
                && profileAccountDetail.getLedgerBalance() != null) {
            response.setCurrentBalance(profileAccountDetail.getLedgerBalance());
        }

        /**
         * Set Current Balance as zero if the above conditions do not satisfy
         */
        else {
            response.setCurrentBalance(BigDecimal.ZERO);
        }
        logger.debug("Exit - populateCurrentBalance method of ProfileAccountDetailResponseConverter class");
    }

    private void setAccountDetail(ProfileAccountDetail profileAccountDetail, CustomerAccountsResponse response) {
        logger.debug("Enter - setAccountDetail method of ProfileAccountDetailResponseConverter class");
        if (profileAccountDetail.getRetirementAccountIndicator() != null) {
            response.setRetirementIndicator(profileAccountDetail.getRetirementAccountIndicator());
        }

        if (profileAccountDetail.getAccountNumber() != null) {
            response.setAccountNumber(profileAccountDetail.getAccountNumber());
            response.setAccountId(profileAccountDetail.getAccountNumber());
            response.setDisplayAccountNumber(profileAccountDetail.getAccountNumber());
        }

        if (profileAccountDetail.getAccountNickname() != null) {
            response.setAccountNickname(profileAccountDetail.getAccountNickname());
        }

        if (profileAccountDetail.getAccountStatus() != null) {
            logger.debug("Account Status of 360 {}", profileAccountDetail.getAccountStatus());
            if (profileAccountDetail.getAccountStatus().equalsIgnoreCase(Constants.ACTIVE)) {
                response.setAccountStatusDescription(Constants.ACCOUNT_STATUS_OPEN);
            } else {
                response.setAccountStatusDescription(profileAccountDetail.getAccountStatus());
            }

        }
        logger.debug("Exit - setAccountDetail method of ProfileAccountDetailResponseConverter class");
    }
}
