package com.capitalone.api.customersaccounts.dao.impl;

import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.dao.OLBAccountPreferencesISDAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRq;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRs;
import com.capitalone.olbaccountpreferencesis.v1.OLBAccountPreferencesISSoap;

@Profile
@Trace
@Named
public class OLBAccountPreferencesISDAOImpl extends AbstractBaseService implements OLBAccountPreferencesISDAO {

    @Inject
    private OLBAccountPreferencesISSoap olbAccountPreferencesISSoap;

    @Inject
    private ConversionService conversionService;

    /**
     * Getting Retail Accounts Nickname
     * 
     * @param context holds the request context
     * @param customerAccountsRequest holds the list of card accounts
     * @return list of nickname
     * 
     */
    @SuppressWarnings("unchecked")
    @Override
    @Async
    public Future<List<OLBResponse>> getAccountNickname(EPFContext context,
            CustomerAccountsRequest customerAccountsRequest) {
        AccountPreferencesInqRq accountPreferencesInqRq = conversionService.convert(customerAccountsRequest,
                AccountPreferencesInqRq.class);
        AccountPreferencesInqRs accountPreferencesInqRs = null;
        List<OLBResponse> olbResponses = null;
        if (accountPreferencesInqRq != null) {
            try {
                accountPreferencesInqRs = olbAccountPreferencesISSoap.accountPreferencesInq(accountPreferencesInqRq);
            } catch (Exception ex) {
                logger.debug("Exception while making a call to OLBAccountPreferencesIS");
            }
        }
        if (accountPreferencesInqRs != null && accountPreferencesInqRs.getCmd() != null) {
            olbResponses = conversionService.convert(accountPreferencesInqRs, List.class);
        }
        return new AsyncResult<List<OLBResponse>>(olbResponses);
    }
}
