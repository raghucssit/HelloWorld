package com.capitalone.api.customersaccounts.service.convert.response;

import org.apache.commons.lang3.tuple.Pair;

import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.service.pojo.CSTBusinessCustomerResponse;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerSignersRs;
import com.capitalone.cstbusinesscustomeris.v1.BusinessDetailsRs;

/**
 * This class is the response Converter for CSTBusinessCustomerIS
 * 
 */

public class CSTBusinessCustomerRsConverter
        extends
        ConversionServiceAwareConverter<Pair<BusinessCustomerSignersRs, BusinessDetailsRs>, CSTBusinessCustomerResponse> {

   /**
     * Response Converter of CSTBusinessCustomerIS
     * 
     * @param inputPair combination customerSigner and Business Details
     * @return customers role
     */


    @Override
    public CSTBusinessCustomerResponse convert(Pair<BusinessCustomerSignersRs, BusinessDetailsRs> inputPair) {

        logger.debug("CSTBusinessCustomerRsConverter  : convert -> Start");
        CSTBusinessCustomerResponse response = new CSTBusinessCustomerResponse();

        BusinessCustomerSignersRs businessCustomerRs = inputPair.getLeft();
        BusinessDetailsRs businessDetailsRs = inputPair.getRight();
        response.setRole(businessCustomerRs.getCmd().getBusinessCustomerRoleTypes());
        response.setRelationshipCode(businessDetailsRs.getCmd().getCustomerAccountRelationshipCode());
        logger.debug("CSTBusinessCustomerRsConverter  : convert -> End");
        return response;
    }

}
