package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.CreditCardAccountSummaryDao;
import com.capitalone.api.customersaccounts.dao.CreditCardAccountSummaryV2Dao;
import com.capitalone.api.customersaccounts.dao.CreditCardAccountSummaryV3Dao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;

@Profile
@Trace
@Named
public class CreditCardAccountSummaryOrchService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    private static final int ACCOUNT_LIMIT = 50;

    @Inject
    private CreditCardAccountSummaryDao creditCardAccountSummaryDao;

    @Inject
    private CreditCardAccountSummaryV2Dao creditCardAccountSummaryV2Dao;

    @Inject
    private CreditCardAccountSummaryV3Dao creditCardAccountSummaryV3Dao;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    /**
     * Method for retrieving Card Account
     * 
     * @param customerAccountsRequest input request
     * @param context holds the user Context
     * @return Customers account response
     * 
     */
    @Async
    public Future<REASResponse> execute(CustomerAccountsRequest customerAccountsRequest, EPFContext context) {

        logger.debug("Enter - execute method of CreditCardAccountSummaryOrchService class:");

        List<Future<REASResponse>> creditCardResponeFutures = new ArrayList<Future<REASResponse>>();

        REASResponse finalReas = new REASResponse();
        

        List<REASResponse> creditCardResponeFuturesRes = new ArrayList<REASResponse>();

        List<List<CustomerAccountKey>> splitAccountKeyList = new ArrayList<List<CustomerAccountKey>>();

        List<CustomerAccountKey> accountKeyList = new ArrayList<CustomerAccountKey>();

        if (customerAccountsRequest != null && customerAccountsRequest.getReasSupportedSORID() != null
                && !(customerAccountsRequest.getReasSupportedSORID().contains(Constants.CREDIT_CARD_SORID.toString()))) {
            
            for (CustomerAccountKey listCreditCardAccounts : customerAccountsRequest.getCustomerAccountKeyList()) {
                if (listCreditCardAccounts.getSorId().equals(Constants.CREDIT_CARD_SORID)) {
                    accountKeyList.add(listCreditCardAccounts);

                }

            }
            if (accountKeyList.size() > ACCOUNT_LIMIT) {
                splitAccountKeyList = customerAccountsUtil.split(customerAccountsRequest.getCustomerAccountKeyList(),
                        ACCOUNT_LIMIT);

            } else {
                splitAccountKeyList.add(accountKeyList);

            }
            logger.debug("CreditCardAccountSummaryOrchService  : List of accounts{}",splitAccountKeyList);
            for (List<CustomerAccountKey> keyList : splitAccountKeyList) {
            	
                getCreditCardAcctSummary(customerAccountsRequest, context, creditCardResponeFutures, keyList);
            }

            populateCreditCardResponeFutures(creditCardResponeFutures, creditCardResponeFuturesRes);

            for (REASResponse repo : creditCardResponeFuturesRes) {
                finalReas = customerAccountsUtil.merge(finalReas, repo);
            }
        }

        logger.debug("Exit - execute method of CreditCardAccountSummaryOrchService class");

        return new AsyncResult<REASResponse>(finalReas);

    }

    private void getCreditCardAcctSummary(CustomerAccountsRequest customerAccountsRequest, EPFContext context,
            List<Future<REASResponse>> creditCardResponeFutures, List<CustomerAccountKey> keyList) {
        if (customerAccountsUtil.findSORID(customerAccountsRequest, Constants.CREDIT_CARD_SORID)) {
            logger.debug("Enter - call DAOImp for cards");
            logger.debug("DLSVersions: {}", customerAccountsRequest.getCcOnlineCachedConfig());

            if (customerAccountsRequest.getAppVersion().equalsIgnoreCase(Constants.APP_VERSION5)) {

                if (customerAccountsRequest.getCcOnlineCachedConfig().contains(
                        customerAccountsRequest.getAppVersion())) {
                    logger.debug("Call DAOImpl cconline v3 for cards");
                    creditCardResponeFutures.add(creditCardAccountSummaryV3Dao.retrieveCreditCardAccountSummary(
                            context, keyList, customerAccountsRequest.getAppVersion(),
                            customerAccountsRequest.getEnableappVersionV4()));

                } else {
                    logger.debug("Call DAOImpl cconline v2 for cards");
                    creditCardResponeFutures.add(creditCardAccountSummaryV2Dao.retrieveCreditCardAccountSummary(
                            context, keyList, customerAccountsRequest.getAppVersion(),
                            customerAccountsRequest.getEnableappVersionV4()));
                }

            } else {
                if (customerAccountsRequest.getCcOnlineCachedConfig().contains(
                        customerAccountsRequest.getAppVersion())) {
                    logger.debug("Call DAOImpl cconline v3 for cards");
                    creditCardResponeFutures.add(creditCardAccountSummaryV3Dao.retrieveCreditCardAccountSummary(
                            context, keyList, customerAccountsRequest.getAppVersion(),
                            customerAccountsRequest.getEnableappVersionV4()));

                } else {

                    creditCardResponeFutures.add(creditCardAccountSummaryDao.retrieveCreditCardAccountSummary(context,
                            keyList, customerAccountsRequest.getAppVersion(),
                            customerAccountsRequest.getEnableappVersionV4()));
                }
            }
        }
    }

    private void populateCreditCardResponeFutures(List<Future<REASResponse>> creditCardResponeFutures,
            List<REASResponse> creditCardResponeFuturesRes) {
        for (Future<REASResponse> res : creditCardResponeFutures) {
            try {
            	REASResponse response = res.get(Constants.WAIT_TIME, Constants.WAIT_UNIT);
                creditCardResponeFuturesRes.add(response);

            } catch (ExecutionException ex) {
                logger.error(" Execution Exception", ex);
                res.cancel(true);

            } catch (InterruptedException ex) {
                logger.error(" Interupted Exception", ex);
                res.cancel(true);
            } catch (TimeoutException ex) {
                logger.error(" TimeoutException Exception", ex);
                res.cancel(true);
            }
        }
    }
}
