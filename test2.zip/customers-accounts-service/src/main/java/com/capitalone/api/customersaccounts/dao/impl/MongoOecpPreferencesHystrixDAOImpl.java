package com.capitalone.api.customersaccounts.dao.impl;

import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractRestBaseService;
import com.capitalone.api.customer.pref.model.v3.DigitalProfile;
import com.capitalone.api.customer.pref.model.v3.DigitalProfiles;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.MongoOecpPreferencesHystrixDAO;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.EndpointManager;
import com.capitalone.epf.servicelocator.model.EndpointProperties;
import com.google.common.net.HttpHeaders;

@Profile
@Trace
@Named
public class MongoOecpPreferencesHystrixDAOImpl extends AbstractRestBaseService<Client, DigitalProfile> implements
        MongoOecpPreferencesHystrixDAO {
    private static final String TILDE = "~";

    private static final String PREFERENCES = "preferences";

    private static final String PROFILES = "profiles";

    @Inject
    private Client eapiRestClient;

    @Inject
    private EndpointManager endpointManager;

    private static final String INT_MONGO_OECP_PREFERENCES_RESOURCE_URL = "int-mongo-oecp-preferences-Service";

    private static final String APPLICATION_JSON_V_3 = "application/json";

    /**
     * Getting user account sort order
     * 
     * @param request holds the input information
     * @param context holds the request context
     * @return list of accounts in order
     * @throws Exception
     * 
     */
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    @Override
    @Async
    public Future<List<String>> getCustomSortOrderDetails(CustomerAccountsRequest request, EPFContext context)
            throws Exception {
        logger.debug("Enter - retrieveCustomSortOrderDetails method of MongoOecpPreferencesDAOImpl class");
        List<String> customSortOrderAccountList = null;
        if (request.getProfileReferenceId() == null || StringUtils.isBlank(request.getProfileReferenceId().getSSOID())) {
            return null;
        }

        EndpointProperties endpointProperties = getRestEndpointProperties(INT_MONGO_OECP_PREFERENCES_RESOURCE_URL);

        String url = endpointProperties.getUrl();
        logger.debug("oecp url {}", url);

        try {
            Builder buildrequest = constructRestBuilder(request, url);
            DigitalProfiles digitalProfiles = buildrequest.get(DigitalProfiles.class);

            // DigitalProfiles digitalProfiles = DummyResponseUtil.getdiDitalProfiles();

            // The Response is returning list of profiles
            // when we pass profileReferenceID it provides only one profile
            // But when we pass ESCID and when there are multiple ESCID the list will have more
            // So for this i hard coded it to get the first item in the list .get(0)
            customSortOrderAccountList = invokeIntMongoOecp(digitalProfiles);
        } catch (Exception e) {
            logger.debug("Exception Occurred {}", e);
            int httpstatusCode = Constants.ERROR_CODE_400;
            if (e.getCause() instanceof CustomerAPIRESTException) {
                CustomerAPIRESTException errorResponse = (CustomerAPIRESTException) e.getCause();
                if (errorResponse.getHttpStatus() != null) {
                    httpstatusCode = errorResponse.getHttpStatus();
                }
                // We are throwing an exception only if it is 500 or more i.e System error
                if (httpstatusCode >= Constants.INTERNAL_SERVER_ERROR_CODE) {
                    throw e;
                } 
            }else{
            	// Throwing an exception if Exception caused is not type of CustomerAPIRESTException
                throw e;
            }

        }
        logger.debug("Exit - retrieveCustomSortOrderDetails method of MongoOecpPreferencesDAOImpl class");
        logger.debug("customSortOrderAccountList {}", customSortOrderAccountList);
        return new AsyncResult<List<String>>(customSortOrderAccountList);
    }

	private List<String> invokeIntMongoOecp(DigitalProfiles digitalProfiles) {
		List<String> customSortOrderAccountList = null;
		if (digitalProfiles != null && CollectionUtils.isNotEmpty(digitalProfiles.getProfiles())) {
		    DigitalProfile digitalProfile = digitalProfiles.getProfiles().get(0);
		    String[] accountOrder = digitalProfile.getAccountDisplayOrder();
		    if (null != accountOrder && accountOrder.length > 0) {
		        customSortOrderAccountList = Arrays.asList(accountOrder);
		    }
		}
		return customSortOrderAccountList;
	}

    @SuppressWarnings("deprecation")
    private Builder constructRestBuilder(CustomerAccountsRequest request, String url) {
        logger.debug("Enter - constructBuilder method of MongoOecpPreferencesDAOImpl class");
        ProfileReferenceId profileReferenceId = request.getProfileReferenceId();

        WebTarget requestPath = null;
        UriBuilder uri = UriBuilder.fromUri(url).path(TILDE).path(PROFILES)
                .path(URLEncoder.encode(profileReferenceId.getSSOID())).path(PREFERENCES);

        requestPath = eapiRestClient.target(uri);

        Builder buildrequest = requestPath.request().accept(APPLICATION_JSON_V_3)
                .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V_3);
        logger.debug("Exit - constructBuilder method of MongoOecpPreferencesDAOImpl class");
        return buildrequest;
    }

    private EndpointProperties getRestEndpointProperties(String restApiUrl) {
        logger.debug("Enter - getEndpointProperties method of MongoOecpPreferencesDAOImpl class");
        EndpointProperties endpointProperties = endpointManager.getWSProperties(StringUtils.EMPTY, restApiUrl, null);
        logger.debug("Exit - getEndpointProperties method of MongoOecpPreferencesDAOImpl class");
        return endpointProperties;

    }

}
