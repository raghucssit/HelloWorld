package com.capitalone.api.customersaccounts.dao;

import java.util.List;
import java.util.concurrent.Future;

import com.capitalone.api.commons.services.api.HealthCheckableService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.epf.context.model.EPFContext;

public interface CreditCardAccountSummaryDao extends HealthCheckableService {

    Future<REASResponse> retrieveCreditCardAccountSummary(EPFContext context, List<CustomerAccountKey> customerAccountsRequest,String appVersion, String appversionSwitch);

}
