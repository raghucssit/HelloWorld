package com.capitalone.api.customersaccounts.dao;

import java.util.List;
import java.util.concurrent.Future;

import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.epf.context.model.EPFContext;

public interface OecpPreferencesDefaultDao {
	Future<List<OecpPreferResponse>> retrieveAccountNickname(
			EPFContext context, String consumerId);

}
