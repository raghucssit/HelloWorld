/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;

public final class CustomerAccountsFilterUtil {

    private CustomerAccountsFilterUtil() {

    }

    /**
     * This method returns list of CustomerAccountKey filter by SoRID
     * 
     * @param customerAccountKeyList customers account input key
     * @param soRIDSet list of sor ID
     * @return list of accounts based of sor ID
     */


    public static List<CustomerAccountKey> filterbySoRID(List<CustomerAccountKey> customerAccountKeyList,
            Set<String> soRIDSet) {
        if (soRIDSet == null || soRIDSet.isEmpty() || customerAccountKeyList == null) {
            return customerAccountKeyList;
        }

        List<CustomerAccountKey> filteredCustomerAccountKeyList = null;
        filteredCustomerAccountKeyList = new ArrayList<CustomerAccountKey>();
        for (CustomerAccountKey customerAccountKey : customerAccountKeyList) {
            if ((customerAccountKey.getSorId() != null)
                    && (soRIDSet.contains(customerAccountKey.getSorId().toString()))) {
                filteredCustomerAccountKeyList.add(customerAccountKey);

            }
        }
        return filteredCustomerAccountKeyList;
    }

    /**
     * This method returns CustomerAccountsResponse filter by ProductType
     * 
     * @param custAccountList list of customer accounts response
     * @param filterList list of product type
     * @return List of accounts based on product type
     */


    public static List<CustomerAccountsResponse> filterByProductType(List<CustomerAccountsResponse> custAccountList,
            Set<String> filterList) {

        String reasProductType = null;
        if (filterList == null || filterList.isEmpty() || custAccountList == null) {
            return custAccountList;
        }
        List<CustomerAccountsResponse> custAccountFinalList = new ArrayList<CustomerAccountsResponse>();
        for (CustomerAccountsResponse response : custAccountList) {
            reasProductType = response.getProductTypeCode();
            if ((StringUtils.isNotBlank(reasProductType)) && (filterList.contains(reasProductType))) {

                custAccountFinalList.add(response);

            }
        }
        return custAccountFinalList;
    }

    /**
     * This method returns list of CustomerAccountKey filter by BusinessLine
     * 
     * @param custAccountList list of customer accounts response
     * @param filterList list of business
     * @return List of accounts based on business line
     */


    public static List<CustomerAccountsResponse> filterByBusinessLine(List<CustomerAccountsResponse> custAccountList,
            Set<String> filterList) {

        if (filterList == null || filterList.isEmpty() || custAccountList == null) {
            return custAccountList;
        }
        String reasBusinessLine = null;
        List<CustomerAccountsResponse> custAccountFinalList = new ArrayList<CustomerAccountsResponse>();
        for (CustomerAccountsResponse response : custAccountList) {
            reasBusinessLine = response.getBusinessLine();
            if (StringUtils.isNotBlank(reasBusinessLine)) {
                reasBusinessLine = reasBusinessLine.toUpperCase();
                if (filterList.contains(reasBusinessLine)) {
                    custAccountFinalList.add(response);
                }
            }
        }
        return custAccountFinalList;
    }
}