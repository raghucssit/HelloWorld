/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.pojo;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class CustomerAccountKey {
    private String consumerId = null;

    private String accountNumber = null;

    private Short sorId = null;

    private String accountUseType = null;

    public String getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(String consumerId) {
        this.consumerId = consumerId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Short getSorId() {
        return sorId;
    }

    public void setSorId(Short sorId) {
        this.sorId = sorId;
    }

    public String getAccountUseType() {
        return accountUseType;
    }

    public void setAccountUseType(String accountUseType) {
        this.accountUseType = accountUseType;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    @Override
    public int hashCode() {
        HashCodeBuilder builder = new HashCodeBuilder();
        builder.append(getConsumerId());
        builder.append(getAccountNumber());
        builder.append(getSorId());
        return builder.build();
    }

    @Override
    public boolean equals(Object rhs) {
        // ensure we don't have a null nor a non-castable class
        if (!(rhs instanceof CustomerAccountKey)) {
            return false;
        }

        CustomerAccountKey that = (CustomerAccountKey) rhs;

        EqualsBuilder builder = new EqualsBuilder();
        builder.append(getConsumerId(), that.getConsumerId());
        builder.append(getAccountNumber(), that.getAccountNumber());
        builder.append(getSorId(), that.getSorId());
        return builder.build();
    }
}