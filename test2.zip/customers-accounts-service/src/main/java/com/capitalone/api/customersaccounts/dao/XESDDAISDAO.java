package com.capitalone.api.customersaccounts.dao;

import java.util.Map;
import java.util.concurrent.Future;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.epf.context.model.EPFContext;

public interface XESDDAISDAO {
    Future<REASResponse> getIMAccountDetails(EPFContext context, CustomerAccountKey customerAccountKey,
            Map<String, Map<String, OLBAttributes>> mapProdDesc);
}
