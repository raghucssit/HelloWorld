/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.constant;
 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 
 * This class declare all the constant used by the customer account service.
 * 
 * 
 **/

public final class Constants {
 
    public static final String LBL_USER_ID = "User-Id";

    public static final int MISSING_INPUT_PARAMETER = 100400;

    public static final int NO_RECORDS_MATCH_SELECTION_CRITERIA_1 = 1120;

    public static final int NO_RECORDS_MATCH_SELECTION_CRITERIA_2 = 1420;

    public static final int NO_RECORDS_MATCH_SELECTION_CRITERIA_3 = 100109;

    public static final int MULTIPLE_CUSTOMER_KEYS_FOUND = 120547;

    public static final int PARTIAL_SUCCESS = 120109;

    public static final String API_PARTIAL_SUCCESS = "200872";

    public static final int LOOKASIDE_DATA = 120148;

    public static final int ODS_GENERAL_ERROR = 120134;

    public static final int TS2_GENERAL_ERROR = 120135;

    public static final int DATA_LAYER_SERVICE_ERROR = 120335;

    public static final int RECORDS_EXCEED_LIMIT = 120048;

    public static final int ERR_INVALID_INPUT_CARD = 100031;

    public static final int TRANSACTION_TIMED_OUT_CARD = 100000;

    public static final int SOURCE_ACCOUNT_INVALID = 2300;

    public static final int IO_ERROR_CODE = 2400;

    public static final int ERR_INVALID_INPUT = 120375;

    public static final int ERR_SYSTEM_NOT_AVAILABLE = 300;

    public static final String ERR_SYSTEM_NOT_AVAILABLE_STRING = "300";

    public static final int ERR_MULTIPLE_ESCID_BLOCKS_FOUND = 120765;

    public static final String ERROR_MULTIPLE_ESCID_BLOCKS_FOUND = "200900";
    
    public static final String ERROR_NO_ACCOUNTS_FOUND = "201934";

    public static final int ProfileReferenceID_CustomerReferenceID_DIFFER = 120768;

    public static final String REF_STAT_CODE_COLUMN = "StatCd";

    public static final String REF_ERROR_DESC_COLUMN = "ErrorDesc";

    public static final String REF_STAT_DESC_COLUMN = "StatDesc";

    public static final String REF_ADDN_STAT_DESC_COLUMN = "AddnStatDesc";

    public static final String OPERATION_RETREVE_CUSTOMER_ACCOUNT = "RetrieveCustomerAccounts";

    public static final String OPERATION_PING = "Ping";

    public static final String OPERATION_VERSION_1 = "1.0";

    public static final long SUCCESS_STAT_CD = 0;

    public static final String PARTIAL_SUCCESS_XES = "200042";

    public static final long REQUEST_VALIDATION_FAILED_CODE = 200000;

    public static final int TRANSACTION_TIMED_OUT = 200004;

    public static final int SYSTEM_NOT_AVAILABLE = 200003;

    public static final String GENERAL_ERROR_CODE = "200001";

    public static final String API_360_ERROR_CODE = "201824";

    public static final String API_COI_ERROR_CODE = "202277";

    public static final String API_HL_ERROR_CODE = "201835";

    public static final String API_COAF_ERROR_CODE = "201823";

    public static final String REQUEST_VALIDATION_FAILED_MSG = "Request validation failed";

    public static final String REQUEST_VALIDATION_INVALID_INPUT_MSG_300104 = "Only one identifier may be present in request [customerReferenceID or profileReferenceID]. Please correct your request URL";

    public static final String REQUEST_VALIDATION_INVALID_INPUT_MSG_300105 = "Atleast one identifier must be present in request [customerReferenceID or profileReferenceID]. Please correct your request URL";

    public static final String REQUEST_VALIDATION_INVALID_INPUT_MSG_120765 = "Multiple ESCIDs found this ProfileReferenceId. Please contact Customer Support to fix this.";

    public static final String MULTIPLE_ESCID_BLOCKS_FOUND_MSG_200900 = "Multiple ESCIDs found for the given SSOID";
	
	public static final String NO_ACCOUNT_FOUND_IN_ECR_201934 = "No Accounts found in ECR";

    public static final String REQUEST_VALIDATION_INVALID_INPUT_MSG_120768 = "profileReferenceID is not for same customerReferenceID. Please correct your request URL";

    public static final String REQUEST_VALIDATION_INVALID_INPUT_MSG_300103 = "Customer Reference ID is missing. Please correct your request URL";

    public static final String REQUEST_VALIDATION_INVALID_INPUT_MSG_300101 = "Business line is invalid. Please use the Business line configured in AccountCategories Reference Data";

    public static final String REQUEST_VALIDATION_INVALID_INPUT_MSG_300102 = "Product Type Code is invalid. Please use the Product Type Code configured in AccountCategories Reference Data";

    public static final String XES_ROLE_MAPPING_NOT_FOUND = "ROLE NOT FOUND FOR ACCOUNT : ";

    public static final Integer MAX_DEFAULT_RETURN_SIZE = 10;

    public static final List<String> restResponseFieldList = new ArrayList<String>();

    public static final String CURRENCY_CODE_USA = "USD";

    public static final String ACCOUNT_REFERENCE_ID_PLACEHOLDER = "accountReferenceId";

    public static final String MSG_MISSING_APIKEY = "API Key is missing";

    public static final String MSG_INVALID_BUS_LIN = "Business line is invalid";

    public static final String MSG_INVALID_PRO_TYP = "Product Type is invalid";

    public static final String MSG_INVALID_SORT = "Sort parameter is invalid";

    public static final String MSG_MISSING_CUST_REF_ID = "customerReferenceID is missing";

    public static final String MSG_OFFSET_GREATER_THAN_TOTAL_RESULT = "Offset value {0} is greater than total result {1}";

    public static final String APP_VERSION3 = "V3";

    public static final String APP_VERSION4 = "V4";

    public static final String APP_VERSION5 = "V5";

    public static final String APP_VERSION = "APPVERSION_SWITCH";
    
    public static final String XESDDAIS_CACHE = "XESDDAIS_CACHED_CALL_CONFIG";

    public static final String BANK_NUM_360 = "360";

    public static final Short PROFILE_SOR_ID_INT = 185;

    public static final String PRODUCT_TYPE_CODE_360 = "360_Product_Code";

    public static final String PRODUCT_DESCRIPTION_360 = "360_Product_Description";

    public static final String PROD_DESC_SAVING = "360 Savings";

    public static final String PROD_DESC_IRA_SAVINGS = "360 IRA Savings";
    
    public static final String KEY_PROD_TYPE_3000 = "3000";

    public static final String KEY_PROD_TYPE_3500 = "3500";
    
    public static final String PROD_DESC_CD = "CD";

    public static final String PROD_DESC_IRA_CD = "IRA CD";

    public static final String PROD_DESC_CHECKING = "360 Checking";

    public static final String BANK_ACCT_TYPE_CODE_DDA = "DDA";

    public static final String BANK_ACCT_TYPE_CODE_TDA = "TDA";

    public static final List<Short> SORIDLIST_360 = new ArrayList<Short>();

    public static final List<Short> SORIDLIST_RETAIL = new ArrayList<Short>();

    public static final List<String> SORIDLIST_RETAIL_STRING = new ArrayList<String>();

    public static final List<Short> SORIDLIST_ST = new ArrayList<Short>();

    public static final List<Short> SORIDLIST_IM = new ArrayList<Short>();

    public static final Map<Short, String> SORID_TO_BANKNUM = new HashMap<Short, String>();

    public static final List<String> PRODUCT_TYPE_CODE = new ArrayList<String>();

    public static final String TRUST_CODE_X = "X";

    public static final String BANK_NUM_38 = "30";

    public static final String BANK_NUM_39 = "81";

    public static final List<String> XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500 = new ArrayList<String>();

    public static final int WAIT_TIME = 30;

    public static final TimeUnit WAIT_UNIT = TimeUnit.SECONDS;

    public static final List<String> SORID_ST = new ArrayList<String>();

    public static final List<String> SORID_IM = new ArrayList<String>();

    public static final List<Short> SOR_ID_SDB = new ArrayList<Short>();

    public static final String BUSSINESSLINE_SDB = "DEPOSITS";

    public static final String PRODUCT_ID_SDB = "SD";

    public static final int SAFE_DEPOST_BOX_ACCOUNT_LENGTH = 8;

    public static final String PREFERENCE_TYPE_CODE = "ANKNM";

    public static final int HTTP_404 = 404;

    public static final String PROFILE_DEPOSITS_BUSINESS_LINE = "DEPOSITS";

    public static final String PROFILE_LOANS_BUSINESS_LINE = "LOANS";

    public static final String ACCOUNT_NUMBER_PADDING = "0";

    public static final String ENABLE_OECP_CALL = "ENABLE_OECP_CALL";

    public static final String OECP_SORT_ORDER = "OECP_SORT_ORDER";

    public static final String COI_CALL = "COI_CALL";

    public static final String SORT_BY_OPEN_DATE = "SORT_BY_OPEN_DATE";

    public static final int NO_RECORDS_MATCH_SELECTION_CRITERIA_SDB = 1120;

    public static final String INVALID_CUSTOMER_ID_SDB = "201839";

    public static final String SDB_ERROR_CODE = "201840";

    public static final String SDB_SERVICE_DOWN = "Could not connect to Xpress to retrieve Safe Deposit Account details";

    public static final int CUSTOMER_IDENTIFIER_INVALID = 120052;

    public static final int ERR_CUSTOMER_NOT_FOUND = 100106;

    public static final String SDB_NO_RECORDS_STAT_DESC = "No Safe Deposit Box accounts or Customer found or Customer Id is invalid";

    public static final String CCONLINE_ERROR_CODE = "201836";

    public static final String CCONLINE_SERVICE_DOWN_STAT_DESC = "Could not connect to Credit Card DLS Service ";

    public static final String XPRESS_CONNECT_ERROR = "201837";

    public static final String XES_LOANACNT_CONNECT_ERROR = "201838";

    public static final String ODS_BROKERAGEIS_CONNECT_ERROR = "202027";

    public static final String ODS_BROKERAGEIS_PARTIAL_SUCCESS = "202028";

    public static final String ODS_BROKERAGEIS_PARTIAL_SUCCESS_MSG = "No Brokerage account found for Account :";

    public static final String ODS_BROKERAGEIS_SERVICE_DOWN_STAT_DESC = "Could not connect to ODS service to retrieve Retail Brokerage account details";

    public static final String ERROR_HAS_OCCURRED = "200002";

    public static final String NO_SUPPORTED_ACCNT_ERROR_CODE = "201933";

    public static final String NOT_SUPPORTED_ACCOUNT_ERROR_CODE = "202174";

    public static final String PROFILE_API_SYSTEM_DOWN = "200003";

    public static final String ODS_GEN_ERROR_API_CODE = "200036";

    public static final String ODS_DATA_NOT_FOUND = "202030";

    public static final String NO_SUPPORTED_ACCNT_ERROR_CODE_MSG = "Following product types are not supported by the API currently:";

    public static final List<String> SORID_ERROR_HANDLING = new ArrayList<String>();

    public static final String SOR_ID_KEY = "Sor_Id";

    public static final String SOR_ID_KEY_2 = "SoRID";

    public static final String BANK_NUM_KEY = "BankNumber";

    public static final String BANK_GRP_NUM_KEY = "Bank_Grp_Num";

    public static final int SRC_ACCNT_INVALID_SERVER_STAT_CODE = 400;

    public static final int ERROR_CODE_100 = 100;

    public static final int ERROR_CODE_200 = 200;

    public static final int ERROR_CODE_300 = 300;

    public static final int ERROR_CODE_400 = 400;

    public static final int ERROR_CODE_1740 = 1740;

    public static final int ERROR_CODE_1760 = 1760;

    public static final int ERROR_CODE_1020 = 1020;

    public static final int ERROR_CODE_1700 = 1700;

    public static final int ERROR_CODE_1360 = 1360;

    public static final int ERROR_CODE_0 = 0;

    public static final int ERROR_CODE_2350 = 2350;

    public static final int ERROR_CODE_2380 = 2380;

    public static final int ERROR_CODE_2460 = 2460;

    public static final int ERROR_CODE_2490 = 2490;

    public static final String SERVER_STAT_CODE_TP2006 = "TP2006";

    public static final String XPRESS_SERVICE_DOWN_STAT_DESC = "Could not connect to Retail Deposit service for Account Number : ";

    public static final String XPRESS_LENDING_SERVICE_DOWN_STAT_DESC = "Could not connect to Retail Lending service for Account Number : ";

    public static final String ERROR_CODE_INVALID_RESPONSE_CONTENT = "201996";

    public static final String SORID_STRING = "SORID: ";

    public static final String ACCOUNT_NUMBER_STRING = "Account number: ";

    public static final List<String> SELECT_LIST_CONTENT = new ArrayList<String>();

    public static final String BUSSINESSLINE_BROKERAGE = "Brokerage";

    public static final String ODS_GEN_ERROR_STAT = "ODS General Error";

    public static final String ODS_DATA_NOT_FOUND_MSG = "No Brokerage account found in ODS";

    // Sorting Constants
    public static final String SORTING_FACTORY = "sortingFactory";

    public static final String FIELD_BUSINESS_LINE = "businessLine";

    public static final String FIELD_PRODUCT_TYPE = "productType";

    public static final String FIELD_PRODUCT_NAME = "productName";

    public static final String FIELD_ACCOUNT_NUMBER = "accountNumber";

    public static final String FIELD_DISPLAY_ACCOUNT_NUMBER = "displayAccountNumber";

    public static final String FIELD_BANK_NUMBER = "bankNumber";

    public static final String FIELD_BANK_NUMBER_DESCRIPTION = "bankNumberDescription";

    public static final String FIELD_ACCOUNT_STATUS = "accountStatus";

    public static final String FIELD_ACCOUNT_NICK_NAME = "accountNickName";

    public static final String FIELD_OPEN_DATE = "openDate";

    public static final String FIELD_CLOSED_DATE = "closedDate";

    public static final String FIELD_CURRENCY_CODE = "currencyCode";

    public static final String FIELD_CUSTOMER_ROLE = "customerRole";

    public static final String FIELD_ACCOUNT_DETAILS_URL = "accountDetailsURL";

    public static final String FIELD_CURRENT_BALANCE = "currentBalance";

    public static final String FIELD_AVAILABLE_BALANCE = "availableBalance";

    public static final String FIELD_PRINCIPAL_BALANCE = "currentPrincipal";

    public static final String FIELD_PRESENT_BALANCE = "presentBalance";

    public static final String ASCENDING_SORT = "A";

    public static final String DESCENDING_SORT = "D";

    // RelationShipCode Constants
    public static final String CUST_REL_TO_CODE = "CustAcctToRelationshipCd";

    public static final String CUST_REL_FROM_CODE = "CustAcctFromRelationshipCd";

    public static final String CUST_REL_DESC = "CustAcctRelationshipDesc";

    public static final String DISP_IND = "DisplayAcctInd";

    public static final String APPL_SYS_CD = "ApplicationSystemCd";

    public static final String APPL_SYS_DESC = "ApplicationSystemDesc";

    public static final String BANK_MKT_CD = "BankMarketCd";

    public static final String APPL_CD_ST = "ST";

    public static final String APPL_CD_IM = "IM";

    public static final String CUST_REL_CODE = "RelationshipCd";

    public static final String CUST_REL_ROLE_CODE = "Role";

    public static final String CUST_REL_TRUST_CODE = "TrustCode";

    public static final String CUST_REL_ROLE_DESC = "RoleDescription";

    public static final String KEY_PROD_TYPE_CD = "ProductTypeCode";

    public static final String KEY_RTMT_ACCT_INDICATOR = "RetirementAccountIndicator";

    public static final String KEY_FEATURE_TYPE_CD = "ProductFeatureCode";

    public static final String KEY_PROD_TYPE_DESC = "ProductTypeDescription";

    public static final String NOT_APPLICABLE_CD = "N/A";

    public static final String NOT_AVAILABLE_CD = "NOT AVAILABLE";

    public static final String KEY_SOR_ID = "SORid";

    public static final String KEY_BUSINESS_LINE = "BusinessLine";

    public static final String KEY_ACCOUNT_DETAILS_URL = "AccountDetailsURL";

    public static final String KEY_BANK_NUM = "BankNum";

    public static final String KEY_BANK_NUM_DESC = "BankDesc";

    public static final String CARD_STATUS_OPEN = "Open";

    public static final String CARD_STATUS_CLOSED = "Closed";

    public static final String CARD_STATUS_CHRG_OFF = "Charged off";

    public static final String ACCOUNT_STATUS_CLOSED = "Closed";

    public static final String ACCOUNT_STATUS_OPEN = "Open";

    public static final String ACCOUNT_STATUS_BANKRUPTCY = "Bankruptcy";

    public static final String KEY_PROFILE_PROD_TYPE_CD = "ProfileProdTypeCd";

    public static final String KEY_COF_PROD_TYPE_CD = "COFProdTypeCd";

    public static final String HTTP_METHOD_GET = "GET";

    public static final String SUPPORTED_CONTENT_TYPES = "application/json,application/xml";

    public static final String TILDE = "~";

    public static final String DEFAULT_NAME_IDENTIFIER = "APIPLT";

    public final static String PROFILE_TYPE = "LGIN";

    public final static Short PROFILE_SORID = 49;

    public final static Short CREDIT_CARD_SORID = 7;

    public final static Short BROKERAGE_SORID = 102;

    public final static String HOME_LOAN_SORID = "56";

    public final static String SORID_360 = "185";

    public final static Short HOME_LOAN_SORID_INT = 56;

    public final static Short MRN_REQUEST_LIMT = 50;

    public static final String ECR_REGISTRY_TYPE_CD = "ESP";

    public static final String ECR_REGISTRY_SORID = "227";

    public static final String ECR_REGISTRY_CAT_CD = "ECR";

    public static final String AUTO_LOAN_PRODUCT_CD = "AL";

    public static final int REQUEST_VALIDATION_ERROR_KEY_300101 = 300101;

    public static final int REQUEST_VALIDATION_ERROR_KEY_300102 = 300102;

    public static final int REQUEST_VALIDATION_ERROR_KEY_300103 = 300103;

    public static final int REQUEST_VALIDATION_ERROR_KEY_300105 = 300105;

    public static final String CREDIT_CARD_PRODUCT_TYPE_CODE = "CC";

    public static final String NILL = "NILL";

    public static final String FALSE = "FALSE";

    public static final String ACCOUNT_MASK_10 = "XXXXXX";

    public static final String PER_ACCOUNTUSECODE = "PER";

    public static final String BUS_ACCOUNTUSECODE = "BUS";

    public static final String EXP_ACCOUNTUSECODE = "EXP";

    public static final String ACCOUNTUSECODE_PERSONAL = "Personal";

    public static final String ACCOUNTUSECODE_BUSINESS = "Business";

    public static final String ACCOUNTUSECODE_EXPENSE = "Expense";

    public static final String ACCOUNTUSECODE_UNKNOWN = "Unknown";

    public static final String SORID_HomeEquity = "56";

    public static final String ProductId_HomeEquity = "7100";

    public static final String ProductName_HIL = "Home Equity Installment Loan";

    public static final String ProductTypeCode_HIL = "HIL";

    public static final String ProductName_HLC = "Home Equity Line Of Credit";

    public static final String ProductTypeCode_HLC = "HLC";

    public static final String PRODUCTNAME_HOME_EQUITY = "Home Equity";

    public static final String ProductTypeCode_LOC = "LOC";

    public static final String AUTO_LOAN_SORID = "2";

    public static final Short AUTO_LOAN_SORID_INT = 2;

    public static final String XES_EXCEPTION = "201441";

    public static final String XES_ROLE_NOT_FOUND = "System could not connect to Xpress for Role Information of one or more accounts. ";

    public static final String PROFILE_ACCOUNT_EXCEPTION = "201442";

    public static final String PROFILE_ROLE_NOT_FOUND = "System could not connect to Profile for Role Information of one or more accounts. ";

    public static final String CST_ACCOUNT_EXCEPTION = "201444";

    public static final String CST_ROLE_NOT_FOUND = "System could not connect to CST for Role Information of one or more accounts. ";

    public static final String LOANACCOUNTS_API_DOWN = "Could not connect to COAF API for Account : ";

    public static final String CCONLINE_SERVICE_DOWN = "System could not connect to CCOnLineServicingDLS Service for Credit Card accounts Information ";

    public static final String XES_SERVICE_DOWN = "System could not connect to XESRelatedAcctIS Service for Retail accounts Information ";

    public static final String BANK360_API_DOWN = "Could not connect to 360 API for Account : ";

    public static final String COI_API_DOWN = "Could not connect to COI service to retrieve Investing account details : ";

    public static final String HL_API_DOWN = "Could not connect to HL API for Account : ";

    public static final String AUTO_LOAN_SORID_38 = "38";

    public static final String AUTO_LOAN_SORID_39 = "39";

    public static final String COBORROWER_CODE = "1";

    public static final String ERROR_CD_TP1065 = "TP1065";

    public static final String ERROR_CD_TP1067 = "TP1067";

    public static final String ERROR_CD_TP2006 = "TP2006";

    public static final String BY_PASS_REAS = "BY_PASS_REAS";

    public static final String SAFE_DEPOSIT_BOX = "SAFE_DEPOSIT_BOX";

    public static final String ENABLE_ERROR_HANDLING = "ENABLE_ERROR_HANDLING";

    public static final String REAS_SUPPORTED_SORID = "REAS_SUPPORTED_SORID";

    public static final int SUCCESS_STATUS_CODE = 200;

    public static final int INTERNAL_SERVER_ERROR_CODE = 500;

    public static final int PARTIAL_SUCCESS_HTTP_CODE = 203;

    public static final int HTTP_STATUS_CODE_403 = 403;

    public static final String KEY_SORID = "SORID";

    public static final String KEY_BANK_ACCT_TYPE_CD = "BankAcctTypeCd";

    public static final String COAF_API_VERSION = "COAF_API_VERSION";

    public static final String COAF_API_ENTITLEMENT = "COAF_API_ENTITLEMENT";

    public static final List<String> INVALID_ERROR_CD = new ArrayList<String>();

    public static final List<String> INVALID_CARD_ERROR_CD = new ArrayList<String>();

    public static final String SOR_PRODUCT_TYPE_KEY = "SORProductType";

    public static final String SORT_KEY_FIELD_VALUE = "SortKeyFieldValue";

    public static final String SORT_KEY = "SortKey";

    public static final String SORT_KEY_FIELD = "SortKeyField";

    public static final String SORT_ORDER = "SortOrder";

    public static final String SUCCESS_RESPONSE = "SUCCESS";

    public static final String OLBR_ACCT_NICKNAME = "OLBR_ACCT_NICKNAME";

    public static final String API_KEY = "ApiKey";

    public static final String IS360_ACCOUNTS_SOURCED_FROM_DGW = "is360AccountsSourcedFromDGW";

    public static final String COI = "COI";

    public static final String ACTIVE = "Active";

    public static final String SOR_ID_COI = "199";

    public static final String COI_PRODUCT_NAME = "Capital One Investing";

    public static final String CARD_PARTIAL_SUCCESS_MSG_START = "Credit Card Account: ";

    public static final String CARD_PARTIAL_SUCCESS_MSG_END = " was not returned from the backend.";
        
    public static final String API360_ALLOWED_CLIENT = "api360AllowedClient";
    
    public static final String ECR_CACHED_CONFIG="ECR_CACHED_CONFIG";

    // OLBRBankProdCodeIS
    public final static String OLBRBankProdCodeIS_GENERAL_ERROR_DESC = "OLBRBankProdCodeIS_GENERAL_ERROR";

    public final static String VALIDATION_ERROR_DESC_OLBRBankProdCodeIS = "VALIDATION_ERROR_AT_OLBRBankProdCodeIS";

    public final static String OLBRBankProdCodeIS_ERR_SYSTEM_NOT_AVAILABLE_DESC = "OLBRBankProdCodeIS_NOT_AVAILABLE";

    public final static String OLBRBankProdCodeIS_TIMEOUT_STAT_DESC = "OLBRBankProdCodeIS_TIMED_OUT";

    public final static String CustomCacheBankProductCode_SPECS = "CustomCacheBankProductCodeLoader";

    public final static String OLBRBankProdCodeIS_REQUEST_CMD_NAME = "referenceDataInq";

    public final static String OLBRBankProdCodeIS_REQUEST_DESTLGClID = "DestLgclId_11";

    public final static String OLBRBankProdCodeIS_REQUEST_SRCLGClID = "olb";

    public final static String OLBRBankProdCodeIS_REQUEST_MSGID = "204.63.57.9-17ce502:1211043c5d8:-7e49";

    public final static String OLBRBankProdCodeIS_REQUEST_SESNID = "SesnId_11";

    /**
     * Product Type Code Reference Data - START
     */
    public final static String BILL_PAY_ALLOWED_INDICATOR = "BILL_PAY_FROM_ELIG_IND";

    public final static String CASH_EDGE_SEGMENTATION_CODE = "EXTRNL_TRFR_SEGN_TYPE_CD";

    public final static String CHECK_COPY_REQUEST_ALLOWED_INDICATOR = "CHK_COPY_ORD_ELIG_IND";

    public final static String CHECK_IMAGE_ALLOWED_INDICATOR = "CHK_IMG_ELIG_IND";

    public final static String CHECK_REORDER_ALLOWED_INDICATOR = "CHK_REORD_ELIG_IND";

    public final static String FUNDS_TRANSFER_DEST_ACCT_INDICATOR = "TRFR_TO_ELIG_IND";

    public final static String FUNDS_TRANSFER_SRC_ACCT_INDICATOR = "TRFR_FROM_ELIG_IND";

    public final static String OFX_ACCT_CATEGORY_DESC = "BDGT_TYPE_DESC";

    public final static String OVERDRAFT_OPTIN_ELIGIBLE_ACCT_INDICATOR = "OVDRFT_CVRGE_ELIG_IND";

    public final static String REWARDS_ELIGIBLE_ACCT_INDICATOR = "RWRDS_ELIG_IND";

    public final static String PRODUCT_NAME = "OLB_PROD_NM";

    // public final static String STATEMENT_IMAGE_ALLOWED_INDICATOR =
    // "STATEMENTIMAGES";
    public final static String STATEMENT_COPY_REQUEST_ALLOWED_INDICATOR = "STMT_COPY_ORD_ELIG_IND";

    public final static String STOP_PAYMENT_REQUEST_ALLOWED_INDICATOR = "STOP_PMT_ELIG_IND";

    public final static String PAPERLESS_STATEMENT_ELIGIBLE_ACCT_INDICATOR = "STMT_IMG_ELIG_IND";

    public final static String RDC_ELIGIBILITY_INDICATOR = "RDC_ELIGY_IND";

    public final static String BANK_ACCT_STAT_DESC_DORMANT = "Dormant";

    public final static String BANK_ACCT_STAT_DESC_DEPOSITSONLY = "Deposits Only";
    
    public final static String KEY = "Key";

    /**
     * Product Type Code Reference Data - END
     */

    public static final String IS360_API_KEY_PRESENT = "is360ApiKeyPresent";
    
    public static final String ENTITLEMENT_ALLOW_MSG_ERRORCODE = "ENTITLEMENT_ALLOW_MSG_ERRORCODE";

    public static final String CUST_INFO_DLS_CALL = "CUST_INFO_DLS_CALL";
    
    public static final String CCONLINESERVICINGDLS_VERSION_SWITCH = "CCONLINE_CACHED_CALL_CONFIG";   
    
    public static final int SIZE_TO_PAD = 11;
	
	public static final String INT_PROFILE_VERSION = "INT_PROFILE_VERSION";
    
	public static final String SORT_ORDER_HYSTRIX_ENABLED = "SORT_ORDER_HYSTRIX_ENABLED";
	
	public static final String ACCOUNT_NICKNAME_HYSTRIX_ENABLED = "ACCOUNT_NICKNAME_HYSTRIX_ENABLED";
	
	public static final String NO_ACCOUNT_FOUND_IN_COI_202277 = "No Accounts found from COI";
	
    private Constants() {
    }

    static {
        SORIDLIST_360.add((short) 185);

        restResponseFieldList.add(Constants.FIELD_BUSINESS_LINE.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_PRODUCT_TYPE.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_PRODUCT_NAME.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_ACCOUNT_NUMBER.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_DISPLAY_ACCOUNT_NUMBER.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_BANK_NUMBER.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_BANK_NUMBER_DESCRIPTION.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_ACCOUNT_STATUS.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_ACCOUNT_NICK_NAME.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_OPEN_DATE.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_CURRENCY_CODE.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_CUSTOMER_ROLE.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_ACCOUNT_DETAILS_URL.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_CURRENT_BALANCE.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_AVAILABLE_BALANCE.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_PRINCIPAL_BALANCE.toUpperCase());
        restResponseFieldList.add(Constants.FIELD_PRESENT_BALANCE.toUpperCase());

    }
    static {
        SORIDLIST_ST.add((short) 12);
        SORIDLIST_ST.add((short) 13);
        SORIDLIST_ST.add((short) 14);
        SORIDLIST_ST.add((short) 15);
    }

    static {
        SORIDLIST_IM.add((short) 16);
        SORIDLIST_IM.add((short) 17);
        SORIDLIST_IM.add((short) 18);
        SORIDLIST_IM.add((short) 19);
    }

    static {
        SORIDLIST_RETAIL.add((short) 12);
        SORIDLIST_RETAIL.add((short) 13);
        SORIDLIST_RETAIL.add((short) 14);
        SORIDLIST_RETAIL.add((short) 15);
        SORIDLIST_RETAIL.add((short) 16);
        SORIDLIST_RETAIL.add((short) 17);
        SORIDLIST_RETAIL.add((short) 18);
        SORIDLIST_RETAIL.add((short) 19);
        SORIDLIST_RETAIL.add((short) 38);
        SORIDLIST_RETAIL.add((short) 39);

        SORIDLIST_RETAIL_STRING.add("12");
        SORIDLIST_RETAIL_STRING.add("13");
        SORIDLIST_RETAIL_STRING.add("14");
        SORIDLIST_RETAIL_STRING.add("15");
        SORIDLIST_RETAIL_STRING.add("16");
        SORIDLIST_RETAIL_STRING.add("17");
        SORIDLIST_RETAIL_STRING.add("18");
        SORIDLIST_RETAIL_STRING.add("19");
        SORIDLIST_RETAIL_STRING.add("38");
        SORIDLIST_RETAIL_STRING.add("39");

        SORID_TO_BANKNUM.put((short) 12, "30");
        SORID_TO_BANKNUM.put((short) 13, "81");
        SORID_TO_BANKNUM.put((short) 14, "83");
        SORID_TO_BANKNUM.put((short) 15, "87");
        SORID_TO_BANKNUM.put((short) 16, "30");
        SORID_TO_BANKNUM.put((short) 17, "81");
        SORID_TO_BANKNUM.put((short) 18, "83");
        SORID_TO_BANKNUM.put((short) 19, "87");

        PRODUCT_TYPE_CODE.add("3000");
        PRODUCT_TYPE_CODE.add("3500");
        PRODUCT_TYPE_CODE.add("4000");

    }

    static {
        INVALID_ERROR_CD.add(ERROR_CD_TP1065);
        INVALID_ERROR_CD.add(ERROR_CD_TP1067);
        INVALID_CARD_ERROR_CD.add("200091");
        INVALID_CARD_ERROR_CD.add("200092");
        INVALID_CARD_ERROR_CD.add("200105");
        INVALID_CARD_ERROR_CD.add("200106");
        INVALID_CARD_ERROR_CD.add("200056");
    }

    static {
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("100");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("200");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("300");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("400");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("1740");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("1760");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("1020");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("1700");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("1360");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("2350");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("2380");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("2460");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("2490");
        XES_LOAN_ACCOUNT_ERROR_CD_TO_API_500.add("2300");

    }

    static {
        SORID_ST.add("12");
        SORID_ST.add("13");
        SORID_ST.add("14");
        SORID_ST.add("15");
    }

    static {
        SORID_IM.add("16");
        SORID_IM.add("17");
        SORID_IM.add("18");
        SORID_IM.add("19");
    }

    static {
        SOR_ID_SDB.add((short) 69);
        SOR_ID_SDB.add((short) 70);
    }

    static {
        SORID_ERROR_HANDLING.add(API_COAF_ERROR_CODE);
        SORID_ERROR_HANDLING.add(API_360_ERROR_CODE);
        SORID_ERROR_HANDLING.add(API_HL_ERROR_CODE);
        SORID_ERROR_HANDLING.add(INVALID_CUSTOMER_ID_SDB);
        SORID_ERROR_HANDLING.add(SDB_ERROR_CODE);
        SORID_ERROR_HANDLING.add(CCONLINE_ERROR_CODE);
        SORID_ERROR_HANDLING.add(XPRESS_CONNECT_ERROR);
        SORID_ERROR_HANDLING.add(XES_LOANACNT_CONNECT_ERROR);
        SORID_ERROR_HANDLING.add(NO_SUPPORTED_ACCNT_ERROR_CODE);
        SORID_ERROR_HANDLING.add(ODS_BROKERAGEIS_CONNECT_ERROR);
        SORID_ERROR_HANDLING.add(ODS_BROKERAGEIS_PARTIAL_SUCCESS);
        SORID_ERROR_HANDLING.add(ODS_GEN_ERROR_API_CODE);
        SORID_ERROR_HANDLING.add(ODS_DATA_NOT_FOUND);
        SORID_ERROR_HANDLING.add(NOT_SUPPORTED_ACCOUNT_ERROR_CODE);
        SORID_ERROR_HANDLING.add(API_COI_ERROR_CODE);
        SORID_ERROR_HANDLING.add(PROFILE_API_SYSTEM_DOWN);
    }

    static {
        SELECT_LIST_CONTENT.add(FIELD_BUSINESS_LINE);
        SELECT_LIST_CONTENT.add(FIELD_ACCOUNT_NUMBER);
        SELECT_LIST_CONTENT.add(ACCOUNT_REFERENCE_ID_PLACEHOLDER);
        SELECT_LIST_CONTENT.add(FIELD_BANK_NUMBER);
    }

}
