package com.capitalone.api.customersaccounts.dao;

import com.capitalone.api.model.id.ReferenceId;

/**
 * Provides all functionality needed to marshal and encode a reference ID. This is needed on the client side of a REST
 * operation when the ID in question will be part of a URL (either as a path or a query parameter). Note that this
 * should NOT be used when the ID is part of a message body.
 * 
 * Note that as per ReferenceId standards, the ID will be encrypted prior to encoding but following marshalling
 * 
 */
public interface ReferenceIdEncoder {
    /**
     * Converts the given ID to a string, encrypts it, and URL-encodes the result.
     * 
     * @param id The reference id in question
     * 
     * @return The encoded ID
     */
    String encode(ReferenceId id);
}

/*
 * Copyright 2014 Capital One Financial Corporation. All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
