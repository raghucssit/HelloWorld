/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.pojo;

import java.util.List;

import com.capitalone.api.customersaccounts.model.v1.CustomerApiErrorCode;

public class REASResponse {

    private List<CustomerAccountsResponse> customerAccountsResponseList = null;

    private List<AdditionalStat> addStatList = null;

    private CustomerApiErrorCode partialError = null;

    public List<CustomerAccountsResponse> getCustomerAccountsResponseList() {
        return customerAccountsResponseList;
    }

    public void setCustomerAccountsResponseList(List<CustomerAccountsResponse> customerAccountsResponseList) {
        this.customerAccountsResponseList = customerAccountsResponseList;
    }

    public List<AdditionalStat> getAddStatList() {
        return addStatList;
    }

    public void setAddStatList(List<AdditionalStat> addStatList) {
        this.addStatList = addStatList;
    }

    public CustomerApiErrorCode getPartialError() {
        return partialError;
    }

    public void setPartialError(CustomerApiErrorCode partialError) {
        this.partialError = partialError;
    }
}