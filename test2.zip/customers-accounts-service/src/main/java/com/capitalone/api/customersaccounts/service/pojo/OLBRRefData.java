package com.capitalone.api.customersaccounts.service.pojo;

import java.io.Serializable;
import java.util.Map;

public class OLBRRefData implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String key;

    private Map<String, OLBAttributes> attributes;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Map<String, OLBAttributes> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, OLBAttributes> attributes) {
        this.attributes = attributes;
    }

}
