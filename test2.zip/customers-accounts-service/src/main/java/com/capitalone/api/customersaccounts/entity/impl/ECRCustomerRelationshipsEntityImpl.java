package com.capitalone.api.customersaccounts.entity.impl;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.entity.ECRCustomerRelationshipsEntity;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRq;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs;
import com.capitalone.ecrcustomerrelationshipsis.v1.ECRCustomerRelationshipsISSoap;

@Profile
@Trace
@Named
public class ECRCustomerRelationshipsEntityImpl implements ECRCustomerRelationshipsEntity {
 
    @Inject
    private ECRCustomerRelationshipsISSoap ecrCustomerRelationshipsService;

    private Logger logger = LoggerFactory.getLogger(getClass());
	
    /**
     * Getting Account details linked to the SSOID
     * 
     * @param custIdentityMatchedAccountsInqRq holds the request
     * @param userId holds the user Id
     * @return list of accounts related to the SSOID
     * 
     */

    @Override
   // @Cacheable(value = "eapi-shortterm-ecrcustomerrelationshipsentity-custidentitymatchedaccountsinq", key = "#userId")
    public CustIdentityMatchedAccountsInqRs custIdentityMatchedAccountsInq(
            CustIdentityMatchedAccountsInqRq custIdentityMatchedAccountsInqRq, String userId) {

        logger.debug("Cached data not available for ssoid {}. Retrieving related accounts from ECR for  {}", userId,
                custIdentityMatchedAccountsInqRq.getCmd().getECRLookUpKey());
        return ecrCustomerRelationshipsService.custIdentityMatchedAccountsInq(custIdentityMatchedAccountsInqRq);
    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */