package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.XESDDAISV2DAO;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.xesddaisv2.v2.AcctInqISRq;
import com.capitalone.xesddaisv2.v2.AcctInqISRs;
import com.capitalone.xesddaisv2.v2.XESDDAISV2Soap;
//import com.capitalone.xesddais.v1.XESDDAISSoap;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Profile
@Trace
@Named
@SuppressWarnings("CPD-START")
public class XESDDAISDAOV2Impl extends AbstractBaseService implements XESDDAISV2DAO {

    @Inject
    private XESDDAISV2Soap xesddaisSoap;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Inject
    private ConversionService conversionService;

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    /**
     * Getting Retail IM Accounts
     * 
     * @param context holds the request context
     * @param customerAccountKey holds the list of accounts
     * @return list of accounts details
     * 
     */
    @Override
    @Async
    public Future<REASResponse> getIMAccountDetails(EPFContext context, CustomerAccountKey customerAccountKey,
            Map<String, Map<String, OLBAttributes>> mapProdDesc) {
        logger.debug("Enter - getIMAccountDetails method of XESDDAISDAO");
        StatType stat = null;
        REASResponse response = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = null;
        AcctInqISRs acctInqISRs = null;
        List<CustomerAccountsResponse> listCustomerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();

        logger.debug("GET - AdditionalStat method of XESDDAISDAO {}", response);

        AcctInqISRq acctInqISRq = conversionService.convert(customerAccountKey, AcctInqISRq.class);
        try {
            acctInqISRs = xesddaisSoap.acctInq(acctInqISRq);

            logger.debug("RESPONSE of method of XESDDAISDAO {}", acctInqISRs.getCmd().getStat());
        } catch (Exception ex) {
            logger.error("Exception while making call to xesddaisSoap {}", ex);
            addnStatFail.setNativeErrorCd(Constants.XPRESS_CONNECT_ERROR);
            addnStatFail.setStatDesc(Constants.XPRESS_SERVICE_DOWN_STAT_DESC.concat(CustomerAccountsUtil
                    .constructAcctSorIDnotfound(customerAccountKey.getAccountNumber(), customerAccountKey.getSorId())));
            addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
            addnStatFail.setAccountId(customerAccountKey.getAccountNumber());
            addnStatFailList.add(addnStatFail);
            response.setAddStatList(addnStatFailList);
            response.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));
            logger.debug("CATCH - AdditionalStat method of XESDDAISDAO {}", response);
        }

        if (acctInqISRs != null && acctInqISRs.getCmd() != null) {
            customerAccountsResponse = conversionService.convert(acctInqISRs, CustomerAccountsResponse.class);
            stat = acctInqISRs.getCmd().getStat();

            if (customerAccountsResponse != null) {
                customerAccountsResponse.setSorId(customerAccountKey.getSorId().toString());
                // Sorid is not given by the XESDDAIS
                // Now retrive the productype code from the SORID & BankAcctTypeCd from the new reference data.
                // customerAccountsRefDataBean.getProductTypeCode - with method we get the prodcutype code & with
                // derive
                // the prodcutdescription, bussiness line etc.

                customerAccountsResponse.setProductTypeCode(customerAccountsRefDataBean.getProductTypeCode(
                        Short.valueOf(customerAccountsResponse.getSorId()), acctInqISRs.getCmd()
                                .getDemandDepositAcctInfo().getBankAcctTypeCd()));
                customerAccountsResponse.setProductTypeDescription(customerAccountsRefDataBean
                        .getProductTypeDescription(customerAccountsResponse.getProductTypeCode()));

                customerAccountsResponse.setBusinessLine(customerAccountsRefDataBean.getBusinessLine(
                        customerAccountsResponse.getProductTypeCode(), String.valueOf(customerAccountKey.getSorId())));
                // Setting Product name from OLBR
                retreiveOLBRProductName(mapProdDesc, acctInqISRs, customerAccountsResponse);

                listCustomerAccountsResponses.add(customerAccountsResponse);
            }

            response.setCustomerAccountsResponseList(listCustomerAccountsResponses);
            response.setAddStatList(customerAccountsUtil.getAdditionalStat(stat, customerAccountKey));
        }
        logger.debug("Exit - getIMAccountDetails method of XESDDAISDAO");
        return new AsyncResult<REASResponse>(response);
    }

    private void retreiveOLBRProductName(Map<String, Map<String, OLBAttributes>> mapProdDesc, AcctInqISRs acctInqISRs,
            CustomerAccountsResponse customerAccountsResponse) {
        OLBAttributes olbAttributes = null;
        Map<String, OLBAttributes> map = null;
        AcctInqISRs.Cmd.DemandDepositAcctInfo demandDepositAcctInfo = null;
        demandDepositAcctInfo = acctInqISRs.getCmd().getDemandDepositAcctInfo();
        if (!mapProdDesc.isEmpty()) {
            String key = StringUtils.join(
                    new String[] {demandDepositAcctInfo.getProdID(), demandDepositAcctInfo.getIntrnlRtgNum()}, "|");
            map = mapProdDesc.get(key);
            if (map != null && !map.isEmpty()) {
                olbAttributes = mapProdDesc.get(key).get(key);
            }
            if (olbAttributes == null) {
                String prodCd = demandDepositAcctInfo.getProdID().substring(0, 2)
                        + demandDepositAcctInfo.getBankAcctTypeCd();
                key = StringUtils.join(new String[] {prodCd, "DEFAULT"}, "|");
            }
            map = mapProdDesc.get(key);
            if (map != null && !map.isEmpty()) {
                olbAttributes = mapProdDesc.get(key).get(key);
            }

        }
        if (olbAttributes != null) {
            customerAccountsResponse.setProductName(olbAttributes.getProdNm());
        }
    }

}
