package com.capitalone.api.customersaccounts.service.convert.response;

import javax.annotation.Resource;
import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xestdais.v1.AcctInqISRs;

@Profile
@Trace
@Named
public class XESTDAISRsConverter extends ConversionServiceAwareConverter<AcctInqISRs, CustomerAccountsResponse> {

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;
    /**
     * Converts native response of XESTDAIS to customer account Response type
     * 
     * @param nativeResponse response of XESTDAIS
     * @return retails accounts response
     */
    @Override
    public CustomerAccountsResponse convert(AcctInqISRs nativeResponse) {
        logger.debug("Enter - convert method of XESTDAISRsConverter class");
        CustomerAccountsResponse response = null;

        if (nativeResponse != null && nativeResponse.getCmd() != null
                && nativeResponse.getCmd().getTimeDepositAcctInq() != null) {

            response = new CustomerAccountsResponse();

            if (nativeResponse.getCmd().getTimeDepositAcctInq().getProdID() != null) {
                response.setProductId(nativeResponse.getCmd().getTimeDepositAcctInq().getProdID());
            }
            if (nativeResponse.getCmd().getTimeDepositAcctInq().getProdDesc() != null) {

                response.setProductName(nativeResponse.getCmd().getTimeDepositAcctInq().getProdDesc());
            }

            setTimeDepositAcctInfo(nativeResponse, response);

        }
        logger.debug("Exit - convert method of XESTDAISRsConverter class");
        return response;
    }

    private void setTimeDepositAcctInfo(AcctInqISRs nativeResponse, CustomerAccountsResponse response) {
        logger.debug("Enter - setTimeDepositAcctInfo method of XESTDAISRsConverter class");
        if (nativeResponse.getCmd().getTimeDepositAcctInq().getTimeDepositBalancesInfo().getCapOneCurrentBal() != null) {
            response.setCurrentBalance(nativeResponse.getCmd().getTimeDepositAcctInq().getTimeDepositBalancesInfo()
                    .getCapOneCurrentBal());
        }
        if (nativeResponse.getCmd().getTimeDepositAcctInq().getTimeDepositBalancesInfo().getAvailableBal() != null) {
            response.setAvailableBalance(nativeResponse.getCmd().getTimeDepositAcctInq().getTimeDepositBalancesInfo()
                    .getAvailableBal());
        }
        if (nativeResponse.getCmd().getTimeDepositAcctInq().getBankNum() != null) {
            response.setBankNumber(nativeResponse.getCmd().getTimeDepositAcctInq().getBankNum());
            response.setBankNumberDescription(customerAccountsRefDataBean.getBankNumberDescription(nativeResponse
                    .getCmd().getTimeDepositAcctInq().getBankNum()));
        }

        if (nativeResponse.getCmd().getTimeDepositAcctInq().getAcctID() != null) {
            response.setAccountId(nativeResponse.getCmd().getTimeDepositAcctInq().getAcctID());
            response.setDisplayAccountNumber(nativeResponse.getCmd().getTimeDepositAcctInq().getAcctID());
            response.setAccountNumber(nativeResponse.getCmd().getTimeDepositAcctInq().getAcctID());
        }
        if (nativeResponse.getCmd().getTimeDepositAcctInq().getBankAcctStatusDesc() != null) {
            response.setAccountStatusDescription(nativeResponse.getCmd().getTimeDepositAcctInq()
                    .getBankAcctStatusDesc());
        }
        if (nativeResponse.getCmd().getTimeDepositAcctInq().getOpenDt() != null) {
            response.setOpenDate(nativeResponse.getCmd().getTimeDepositAcctInq().getOpenDt());
        }
        response.setCurrencyCode(Constants.CURRENCY_CODE_USA);
        if (nativeResponse.getCmd().getTimeDepositAcctInq().isRtirmntAcctInd() != null) {
            response.setRetirementIndicator(nativeResponse.getCmd().getTimeDepositAcctInq().isRtirmntAcctInd());
        }
        if (nativeResponse.getCmd().getTimeDepositAcctInq().getClosedDate() != null) {
            response.setClosedDate(nativeResponse.getCmd().getTimeDepositAcctInq().getClosedDate());

        }
        logger.debug("Exit - setTimeDepositAcctInfo method of XESTDAISRsConverter class");
    }

}
