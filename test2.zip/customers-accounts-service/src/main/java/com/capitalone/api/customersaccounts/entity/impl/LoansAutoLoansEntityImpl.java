package com.capitalone.api.customersaccounts.entity.impl;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.configuration.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractRestBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.entity.LoansAutoLoansEntity;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.model.EndpointProperties;

@Profile
@Trace
@Named
public class LoansAutoLoansEntityImpl extends AbstractRestBaseService<Client, AutoLoanAccount> implements
        LoansAutoLoansEntity {

    @Inject
    @Named("upf-app-config")
    private Configuration config;

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    private Client eapiRestClient;    

    @Inject
    private ReferenceIdEncoder encoder;
    
    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    private static final String LOAN_AUTOLOAN_ACCOUNTS_API_ROOT_RESOURCE_URL = "loan-autoloan-account-Service";

    private static final String APPLICATION_JSON_V = "application/json; v=";

    private static final String SSOID = "SSOID";

    private static final String ENTITLED = "entitled";
    
    /**
     * Calling COAF API and caching the result.
     * 
     * @param customerAccountKey hold input information
     * @param epfContext holds the request context
     * @param accountNumber account information
     * @param sorId sor id f account
     * @param ssoid single sin on
     * @return list of auto loan accounts
     */

    
    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    //@Cacheable(value = "eapi-shortterm-loansautoLoansentity-getAccount", key = "#accountNumber.concat(#sorId)")
    public AutoLoanAccount retiveAccountDetails(CustomerAccountKey customerAccountKey, EPFContext epfContext,
            String accountNumber, String sorId, String ssoid) throws Exception{
        logger.debug("Enter - retiveAccountDetails method of LoansAutoLoansEntityImpl class");
        EndpointProperties endpointProperties = customerAccountsUtil.getEndpointProperties(LOAN_AUTOLOAN_ACCOUNTS_API_ROOT_RESOURCE_URL);

        String url = endpointProperties.getUrl();
        String coafAPIVersion = "4";
        Boolean coafEntitlement = false;

        if (config != null) {
            coafAPIVersion = config.getString(Constants.COAF_API_VERSION);
            coafEntitlement = config.getBoolean(Constants.COAF_API_ENTITLEMENT);
        }

        Builder buildrequest = constructBuilder(customerAccountKey, ssoid, url, coafAPIVersion, coafEntitlement);
        logger.debug("Build Request {} ", buildrequest.toString());

        AutoLoanAccount autoLoanAccount = buildrequest.get(AutoLoanAccount.class);
        logger.debug("The hashcode for auto loan account is {}", autoLoanAccount);
        return autoLoanAccount;

    }
    /**
     * Creating builder to point COAF API url
     * 
     * @param customerAccountKey
     * @param ssoid
     * @param url
     * @param coafAPIVersion
     * @param coafEntitlement
     * @return buildrequest
     * 
     */
    private Builder constructBuilder(CustomerAccountKey customerAccountKey, String ssoid, String url,
            String coafAPIVersion, Boolean coafEntitlement) {
        logger.debug("Enter - constructBuilder method of LoansAutoLoansEntityImpl class");
        AccountReferenceId accountRefID = new AccountReferenceId(customerAccountKey.getAccountNumber(),
                customerAccountKey.getSorId().toString());
        String acountReferenceId = encoder.encode(accountRefID.getReferenceId());
        UriBuilder uri = UriBuilder.fromUri(url).path(acountReferenceId);
        WebTarget requestPath = eapiRestClient.target(uri);
        Builder buildrequest = null;
        if (coafEntitlement) {
            buildrequest = requestPath.request().accept(APPLICATION_JSON_V + coafAPIVersion)
                    .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V + coafAPIVersion);

        } else {
            buildrequest = requestPath.request().accept(APPLICATION_JSON_V + coafAPIVersion)
                    .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V + coafAPIVersion).header("entitled", ENTITLED);
        }
        if (ssoid != null && !(ssoid.equalsIgnoreCase(""))) {
            buildrequest.header(SSOID, ssoid);
        }
        logger.debug("Exit - constructBuilder method of LoansAutoLoansEntityImpl class");
        return buildrequest;
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */