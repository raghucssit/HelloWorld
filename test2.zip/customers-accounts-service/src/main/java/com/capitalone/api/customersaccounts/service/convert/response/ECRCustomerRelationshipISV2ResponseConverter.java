/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.convert.response;

import javax.inject.Named;

import org.apache.commons.lang.StringUtils;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails;

/**
 * This class is the response Converter for ECRCustomerRelationshipISV2
 * 
 */

@Profile
@Trace
@Named
public class ECRCustomerRelationshipISV2ResponseConverter extends
        ConversionServiceAwareConverter<AcctDetails, CustomerAccountKey> {

    /**
     * Converts ECR acctDetails to CustomerAccountKey type for V2
     * 
     * @param acctDetails list of accounts
     * @return customers accounts list
     */


    @Override
    public CustomerAccountKey convert(AcctDetails acctDetails) {

    	logger.debug("ECRCustomerRelationshipISV2ResponseConverter : convert -> Start ");
        CustomerAccountKey customerAccountKeyForV2 = null;
        if (acctDetails != null) {
            customerAccountKeyForV2 = new CustomerAccountKey();
            customerAccountKeyForV2.setConsumerId(acctDetails.getSORCnsmrID());            
            customerAccountKeyForV2.setSorId(acctDetails.getSoRID());
            if(Constants.CREDIT_CARD_SORID.equals(acctDetails.getSoRID())){
            	customerAccountKeyForV2.setAccountNumber(StringUtils.leftPad(acctDetails.getApplctnAcctID(), 11, "0"));
            }else{
            	customerAccountKeyForV2.setAccountNumber(acctDetails.getApplctnAcctID());
            }
            customerAccountKeyForV2.setAccountUseType(acctDetails.getAcctUseCd());
        }
        logger.debug("ECRCustomerRelationshipISV2ResponseConverter  : convert -> End ");
        return customerAccountKeyForV2;
    }
}