package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.CreditCardAccountSummaryDao;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.cconlineservicingdls.v1.AcctSumryDLSInqRq;
import com.capitalone.cconlineservicingdls.v1.AcctSumryDLSInqRs;
import com.capitalone.cconlineservicingdls.v1.AcctSumryDLSInqRs.Cmd;
import com.capitalone.cconlineservicingdls.v1.CCOnLineServicingDLSSoap;
import com.capitalone.epf.context.model.EPFContext;

@Profile
@Trace
@Named
public class CreditCardAccountSummaryDaoImpl extends AbstractBaseService implements CreditCardAccountSummaryDao {

    @Inject
    private ConversionService conversionService;

    @Inject
    private CCOnLineServicingDLSSoap ccOnLineServicingDLSSoap;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    /**
     * Getting Credit card Accounts
     * 
     * @param context holds the request context
     * @param customerAccountsRequest holds the list of card accounts
     * @return list of accounts details
     * 
     */
    @Override
    @Async
    public Future<REASResponse> retrieveCreditCardAccountSummary(EPFContext context,
            List<CustomerAccountKey> customerAccountsRequest, String appVersion, String appversionSwitch) {

        logger.debug("Entry - retrieve method of CreditCardAccountSummaryDaoImpl class");

        AcctSumryDLSInqRq nativeRequest = conversionService.convert(customerAccountsRequest, AcctSumryDLSInqRq.class);

        AcctSumryDLSInqRs acctSumryDLSInqRs = new AcctSumryDLSInqRs();
        REASResponse response = new REASResponse();
        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();

        if (checkEmptyRq(nativeRequest)) {
            return null;
        }

        try {
            acctSumryDLSInqRs = (AcctSumryDLSInqRs) ccOnLineServicingDLSSoap.accountSummaryInq(nativeRequest);
        } catch (Exception ex) {
            logger.error("Exception while making call to ccOnLineServicingDLSSoap {}", logger.getClass(), ex);
            addnStatFail.setNativeErrorCd(Constants.CCONLINE_ERROR_CODE);
            addnStatFail.setStatDesc(Constants.CCONLINE_SERVICE_DOWN_STAT_DESC);
            addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
            addnStatFailList.add(addnStatFail);
            response.setAddStatList(addnStatFailList);
            response.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));

        }

        if (null != acctSumryDLSInqRs && null != acctSumryDLSInqRs.getCmd()) {
            if (blockCardAcnts(appVersion, appversionSwitch, acctSumryDLSInqRs)) {
                return null;
            }
            response = conversionService.convert(acctSumryDLSInqRs, REASResponse.class);

            // Partial Success Error Handling
            setPartialSuccess(customerAccountsRequest, acctSumryDLSInqRs, response);

            if ((appVersion.equalsIgnoreCase(Constants.APP_VERSION3)) && null != response) {

                blockV3HAMode(response);

            }
        }
        logger.debug("Exit - retrieve method of CreditCardAccountSummaryDaoImpl class");
        return new AsyncResult<REASResponse>(response);

    }

    private void setPartialSuccess(List<CustomerAccountKey> customerAccountsRequest,
            AcctSumryDLSInqRs acctSumryDLSInqRs, REASResponse response) {
        Cmd cmd = acctSumryDLSInqRs.getCmd();
        if (response != null && cmd != null && cmd.getStat() != null
                && Long.valueOf(Constants.PARTIAL_SUCCESS) == cmd.getStat().getStatCd()) {
            customerAccountsUtil.setPartialStatus(response, acctSumryDLSInqRs.getCmd().getStat().getStatCd(),
                    customerAccountsRequest);
        }
    }

    private boolean checkEmptyRq(AcctSumryDLSInqRq nativeRequest) {
        boolean isInvalidRq = false;
        if (nativeRequest != null && nativeRequest.getCmd() != null && nativeRequest.getCmd().getAcctArray() != null
                && nativeRequest.getCmd().getAcctArray().size() == 0) {
            isInvalidRq = true;

        }
        return isInvalidRq;
    }

    private boolean blockCardAcnts(String appVersion, String appversionSwitch, AcctSumryDLSInqRs acctSumryDLSInqRs) {
        boolean isConditionResult = false;
        if (appVersion.equalsIgnoreCase(appversionSwitch)
                && ((null != acctSumryDLSInqRs.getCmd().getStat()) && (Constants.LOOKASIDE_DATA == (long) acctSumryDLSInqRs
                        .getCmd().getStat().getStatCd()))) {
            isConditionResult = true;
        }
        return isConditionResult;
    }

    private void blockV3HAMode(REASResponse response) {
        for (CustomerAccountsResponse customerAccountsResponse : response.getCustomerAccountsResponseList()) {

            if (null != customerAccountsResponse) {

                customerAccountsResponse.setIsHighAvailabilityEnabled(null);
                customerAccountsResponse.setValidAsOfTimestamp(null);

            }

        }
    }

}
