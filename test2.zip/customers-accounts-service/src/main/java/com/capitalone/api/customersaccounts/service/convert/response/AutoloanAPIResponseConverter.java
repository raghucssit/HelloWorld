package com.capitalone.api.customersaccounts.service.convert.response;

import javax.annotation.Resource;
import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.api.model.id.ReferenceId;

@Profile
@Trace
@Named
public class AutoloanAPIResponseConverter extends
        ConversionServiceAwareConverter<AutoLoanAccount, CustomerAccountsResponse> {

    private static final String ACCOUNT_ID = "accountId";
	
	private static final int LOAN_SEQUENCE_LENGTH=4;
    
    private static final int ACCOUNT_ID_LENGTH=13;

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;
    /**
     * Converts autoLoanAccount to CustomerAccountKey type
     * 
     * @param autoLoanAccount autoloan account details
     * @return customer accounts response
     */
    @Override
    public CustomerAccountsResponse convert(AutoLoanAccount autoLoanAccount) {

        logger.debug("Entry - convert method of AutoloanAPIResponseConverter class");

        CustomerAccountsResponse response = new CustomerAccountsResponse();

        if (autoLoanAccount != null) {
            if (autoLoanAccount.getLoanBalance() != null) {
                response.setCurrentPrincipal(autoLoanAccount.getLoanBalance());
            }

            if (autoLoanAccount.getOpenDate() != null) {
                response.setOpenDate(autoLoanAccount.getOpenDate());
            }
            response.setCurrencyCode(Constants.CURRENCY_CODE_USA);
            if (autoLoanAccount.getTotalAmountDue() != null) {
                response.setPaymentDueAmount(autoLoanAccount.getTotalAmountDue());
            }
            if (autoLoanAccount.getDueDate() != null) {
                response.setPaymentDueDate(autoLoanAccount.getDueDate());
            }
            response.setProductTypeCode(Constants.AUTO_LOAN_PRODUCT_CD);
            response.setProductTypeDescription(customerAccountsRefDataBean
                    .getProductTypeDescription(Constants.AUTO_LOAN_PRODUCT_CD));

            if (response.getProductTypeCode() != null) {
                response.setBusinessLine(customerAccountsRefDataBean.getBusinessLine(response.getProductTypeCode(),
                        Constants.AUTO_LOAN_SORID));
            }

            if (autoLoanAccount.getLoanApplicationId() != null) {
                response.setAppnId(autoLoanAccount.getLoanApplicationId().toString());
            }
            if (autoLoanAccount.getPaidOffDate() != null) {
                response.setClosedDate(autoLoanAccount.getPaidOffDate());
            }

            setAutoLoanAccountStatus(autoLoanAccount, response);
            response.setSorId(Constants.AUTO_LOAN_SORID); // Hard coded as not returned by API

            logger.debug("Exit - convert method of AutoloanAPIResponseConverter class");
        }

        return response;
    }

    private void setAutoLoanAccountStatus(AutoLoanAccount autoLoanAccount, CustomerAccountsResponse response) {

        if (autoLoanAccount.getAccountStatus() != null
                && autoLoanAccount.getAccountStatus().getStatusDescription() != null) {
            response.setAccountStatusDescription(autoLoanAccount.getAccountStatus().getStatusDescription());
        }
        if (autoLoanAccount.getIsAccountClosed() != null && autoLoanAccount.getIsAccountClosed().equals(Boolean.TRUE)) {
            response.setAccountStatusDescription(Constants.ACCOUNT_STATUS_CLOSED);
        }
        if (autoLoanAccount.getAccountNickname() != null) {
            response.setAccountNickname(autoLoanAccount.getAccountNickname());
        }

        // the below gives the 17 digit account number
        if (autoLoanAccount.getAutoLoanAccountReferenceId() != null) {
            ReferenceId referenceid = autoLoanAccount.getAutoLoanAccountReferenceId();
            String longaccountnumber = referenceid.getField(ACCOUNT_ID);
            response.setLoanSeqNum(longaccountnumber.substring(longaccountnumber.length() - LOAN_SEQUENCE_LENGTH));
            response.setAccountId(longaccountnumber.substring(0, ACCOUNT_ID_LENGTH)); // This field needs to be 13 digit account number.
        }
        // if COAF API not returning 17 digit account number we need to have the 13 digit account number to be there.
        if (autoLoanAccount.getAutoLoanAccountReferenceId() == null && autoLoanAccount.getAccountReferenceId() != null) {
            ReferenceId referenceid = autoLoanAccount.getAccountReferenceId();
            logger.debug("getAutoLoanAccountReferenceId is Null");
            logger.debug("AccountId : {}", referenceid.getField(ACCOUNT_ID));
            response.setAccountId(referenceid.getField(ACCOUNT_ID));
        }
        // the below gives the 13 digit account number
        if (autoLoanAccount.getAccountReferenceId() != null) {
            ReferenceId referenceid = autoLoanAccount.getAccountReferenceId();
            logger.debug("AccountId from getAccountReferenceId(): {}", referenceid.getField(ACCOUNT_ID));
            response.setAccountNumber(referenceid.getField(ACCOUNT_ID));
            response.setDisplayAccountNumber(referenceid.getField(ACCOUNT_ID));
        }
    }
}
