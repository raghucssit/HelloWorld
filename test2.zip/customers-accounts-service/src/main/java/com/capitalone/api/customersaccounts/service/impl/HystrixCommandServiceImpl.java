package com.capitalone.api.customersaccounts.service.impl;

import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.customersaccounts.dao.MongoOecpPreferencesHystrixDAO;
import com.capitalone.api.customersaccounts.dao.OecpPreferencesHystrixDao;
import com.capitalone.api.customersaccounts.service.api.HystrixCommandService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.upf.resiliency.UPFAsyncResult;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Profile
@Trace
@Named
public class HystrixCommandServiceImpl implements HystrixCommandService {

    @Inject
    private OecpPreferencesHystrixDao oecpPreferencesDao;

    @Inject
    private MongoOecpPreferencesHystrixDAO mongoOecpPreferencesDAO;
    
    public static final int WAIT_TIME = 500;
    

    @Override
    public void health() {
        logger.debug("Invoke of health");
    }

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    @HystrixCommand(groupKey = "OECP_NICKNAME_KEY", commandKey = "CMD_KEY_OECP_NICKNAME", fallbackMethod = "fallbackOecpNickName")
    @Async
    public Future<List<OecpPreferResponse>> retrieveAccountNickname(EPFContext context,
            CustomerAccountsRequest customerAccountsRequest) throws Exception {

        Future<List<OecpPreferResponse>> response = null;
        response = oecpPreferencesDao.retrieveAccountNickname(context, customerAccountsRequest.getCustomerESCID());
        List<OecpPreferResponse> res = response.get(WAIT_TIME, TimeUnit.MILLISECONDS);

        logger.debug("Oecp Res {}", res);
        return getAsyncResultOecpNickName(res);
    }

    private UPFAsyncResult<List<OecpPreferResponse>> getAsyncResultOecpNickName(final List<OecpPreferResponse> resp) {
        return new UPFAsyncResult<List<OecpPreferResponse>>() {

            @Override
            public List<OecpPreferResponse> invoke() {
                logger.debug("Invoke of success");
                return resp;
            }

        };
    }

    public List<OecpPreferResponse> fallbackOecpNickName(EPFContext context,
            CustomerAccountsRequest customerAccountsRequest) {
        List<OecpPreferResponse> res = null;
        logger.error("Entry of fallbackOecpNickName method");
        logger.error("The oecp nickname Service is Down");
        return res;

    }

    @Override
    @SuppressWarnings("PMD.SignatureDeclareThrowsException")
    @HystrixCommand(groupKey = "Group_Key_MongoOecp", commandKey = "COMMAND_KEY_MongoOecp", fallbackMethod = "fallBackSortOrder")
    @Async
    public Future<List<String>> retriveCustomSortOrderDetails(CustomerAccountsRequest request,
            EPFContext contextEPFContext) throws Exception {
        Future<List<String>> sortOrderResponse = mongoOecpPreferencesDAO.getCustomSortOrderDetails(request,
                contextEPFContext);

        List<String> sortOrderList = null;
        sortOrderList = sortOrderResponse.get(WAIT_TIME, TimeUnit.MILLISECONDS);
        logger.debug("Sort Order list{}", sortOrderList);
        return getAsyncResultOecpSortOrder(sortOrderList);
    }

    private UPFAsyncResult<List<String>> getAsyncResultOecpSortOrder(final List<String> sortOrderList) {
        return new UPFAsyncResult<List<String>>() {
            @Override
            public List<String> invoke() {
                logger.debug("Invoke of success");
                return sortOrderList;
            }

        };
    }

    public List<String> fallBackSortOrder(CustomerAccountsRequest request, EPFContext contextEPFContext) {
        List<String> res = null;
        logger.debug("Entry of fallBackSortOrder method");
        logger.debug("MongoOecp sortOrder Service is Down");
        return res;
    }

}
