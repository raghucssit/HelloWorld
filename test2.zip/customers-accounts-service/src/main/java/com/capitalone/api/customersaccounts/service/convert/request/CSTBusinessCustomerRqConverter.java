package com.capitalone.api.customersaccounts.service.convert.request;

import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRq;

/**
 * This class Converts form String To CSTBusinessCustomer Request
 * 
 */
@Profile
@Trace
@Named
public class CSTBusinessCustomerRqConverter extends ConversionServiceAwareConverter<String, BusinessCustomerRq> {
    /**
     * Converts the given ID a string to BusinessCustomerRq
     * 
     * @param bif Business ID 
     * @return inputRq
     */


    @Override
    public BusinessCustomerRq convert(String bif) {
        logger.debug("CSTBusinessCustomerRqConverter  : convert -> Start");
        BusinessCustomerRq businessCustomerRq = new BusinessCustomerRq();
        BusinessCustomerRq.Cmd cmd = new BusinessCustomerRq.Cmd();
        cmd.setPrimaryCustomerID(bif);
        cmd.setName("businessCustomerRqCmd");
        businessCustomerRq.setCmd(cmd);
        logger.debug("CSTBusinessCustomerRqConverter  : convert -> End");
        return businessCustomerRq;

    }

}
