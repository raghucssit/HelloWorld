/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.convert.request;

import javax.inject.Named;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.service.pojo.CustomerInfoBean;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRq;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRq.Cmd.PagingRqInfo;

/**
 * This class is the request Converter for XESRelatedAcctIS
 * 
 */

@Profile
@Trace
@Named
public class XESRelatedAcctISRequestConverter extends ConversionServiceAwareConverter<CustomerInfoBean, AcctListInqRq> {

    private Logger logger = LoggerFactory.getLogger(getClass());

    private static final String OPERATION_NAME = "acctListInq";

    private static final long RECORD_COUNT = 50;

    /**
     * Converts CustomerInfoBean To XESRelatedAcctIS Request
     * 
     * @param xesBean customer information
     * @return inputRq for XES
     */


    @Override
    public AcctListInqRq convert(CustomerInfoBean xesBean) {

        logger.debug("XESRelatedAcctISRequestConverter  : convert -> Start");
        String custId = xesBean.getCustomerId();

        logger.debug("custId {}", custId);

        if (StringUtils.isBlank(custId)) {
            return null;
        }
        AcctListInqRq acctListInqRq = new AcctListInqRq();
        acctListInqRq.setCmd(new AcctListInqRq.Cmd());
        acctListInqRq.getCmd().setName(OPERATION_NAME);
        acctListInqRq.getCmd().setRMCustID(custId);
        acctListInqRq.getCmd().setPagingRqInfo(new PagingRqInfo());
        // Setting MaxRecords Per Request.
        acctListInqRq.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);
        logger.debug("XESRelatedAcctISRequestConverter  : convert -> End");
        return acctListInqRq;
    }

}