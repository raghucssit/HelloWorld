/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.joda.time.Instant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.entitlement.EnableEntitlementPostFiltering;
import com.capitalone.api.commons.annotations.entitlement.EnableEntitlements;
import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.exception.ApiBusinessException;
import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.exception.NotFoundException;
import com.capitalone.api.commons.exception.RequestValidationException;
import com.capitalone.api.commons.model.Direction;
import com.capitalone.api.commons.model.EntityCollectionRequest;
import com.capitalone.api.commons.model.FieldComparator;
import com.capitalone.api.commons.model.Sort;
import com.capitalone.api.commons.services.api.EapiServiceableAccountProvider;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.CustomerAccountsKeyDao;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccount;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccountsEntityCollectionResponse;
import com.capitalone.api.customersaccounts.service.api.CustomerAccountsService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsOrchResponse;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsFilterUtil;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.api.security.CryptoSerializerDeserializer;

/**
 * Implementation for CustomerAccounts Service Class
 * 
 * @author RQA254
 * @since 1.0
 */
@Profile
@Trace
@Named
@SuppressWarnings("unchecked")
public class CustomerAccountsServiceImpl extends AbstractBaseService implements CustomerAccountsService {
    private static final String ACCOUNT_NUMBER = "accountNumber";

    private static final String OPEN_DATE = "openDate";

    private static final String CLOSED_DATE = "closedDate";

    private static final String CLOSED = "Closed";

    private static final String PRIMARY = "Primary";

    private static final String SECONDARY = "secondary";

    private static final String TERTIARY = "tertiary";

    private static final String SPLITTER = ",";

    private static final int OECP_SORT_WAIT_TIME = 500;

    private static final TimeUnit OECP_SORT_WAIT_UNIT = TimeUnit.MILLISECONDS;

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Inject
    @Named("restfulApiServiceableAccountProvider")
    private EapiServiceableAccountProvider serviceableAccountProvider;

    @Inject
    private CustomerAccountsKeyDao customerAccountsDao;

    @Inject
    private CustomerAccountsOrchService customerAccountsOrchService;

    @Inject
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Inject
    private FetchLightWeightECROrchService fetchLightWeightECROrchService;

    @Inject
    private CustomerAccountsAggregationService customerAccountsAggregationService;

    @Inject
    @Named("defaultCryptoSerializerDeserializer")
    private CryptoSerializerDeserializer crypto;

    /**
     * This method is getting all CustomerAccountList by calling all service impl classes
     * 
     * @param request list of Collection
     * @param customerAccountsRequest customers accounts Input
     * @param select query element
     * @return customers entity collection
     */

    private CustomerAccountsEntityCollectionResponse getCustomerAccountList(EntityCollectionRequest request,
            CustomerAccountsRequest customerAccountsRequest, String select) {

        logger.debug("Enter - getCustomerAccountList method of CustomerAccountsServiceImpl class");
        Set<String> businessLineSet = null;
        Set<String> productTypeSet = null;
        Set<String> filteredSoRIDSet = null;
        List<CustomerAccountKey> customerAccountKeyList = null;
        List<CustomerAccount> customerAccountList = null;
        REASResponse customerAccountsAggregatedResponse = null;
        List<CustomerAccountKey> unsupportedAccountKeyList = null;
        List<String> selectOptionList = null;
        boolean defaultSortByOpenDateFlag = false;
        boolean customSortFlag = false;
        if (StringUtils.isNotBlank(select)) {
            selectOptionList = Arrays.asList((select.trim()).split(SPLITTER));
        }

        logger.debug("select option list {}", selectOptionList);
        if (selectOptionList == null || Constants.SELECT_LIST_CONTENT.containsAll(selectOptionList)) {
            validateInput(customerAccountsRequest);

            // Fetch Account 3 part key from ECR based on customerReferenceID or
            // profileReferenceID

            // Make ECR Call to fetch accounts based on ProfileReferenceID or
            // CustomerReferenceID

            logger.debug("Calling retrieveCustomerAccountsKeyBasedOnProfileReferenceId method of CustomerAccountsKeyDao Class ");
            customerAccountKeyList = customerAccountsDao
                    .retrieveCustomerAccountsKeyBasedOnProfileReferenceId(customerAccountsRequest);
            logger.debug("CustomerAccountKeyList: {}", customerAccountKeyList);

            // Filter out the list supported by REAS
            List<CustomerAccountKey> supportedAccountList = customerAccountsRefDataBean
                    .getSupportedAccountsList(customerAccountKeyList);
            // Filter out the list based on requested businessLine and
            // productType
            businessLineSet = customerAccountsRequest.getBusinessLineSet();
            productTypeSet = customerAccountsRequest.getProductTypeSet();
            filteredSoRIDSet = customerAccountsUtil.retrieveSoRIDsBasedOnBusinessLineAndProductType(businessLineSet,
                    productTypeSet);

            // check for COI switch is off if remove all COI accounts.
            if (CollectionUtils.isEmpty(customerAccountsRequest.getCoiSwitch())
                    || !customerAccountsRequest.getCoiSwitch().contains(customerAccountsRequest.getAppVersion())) {
                CollectionUtils.filter(supportedAccountList, filterCOIAccounts());
            }

            if (filteredSoRIDSet != null && !filteredSoRIDSet.isEmpty()) {
                supportedAccountList = customerAccountsUtil.filterbySoRID(supportedAccountList, filteredSoRIDSet);
            }
            // If SSOID does not contain supported accounts throw error with
            // appropriate message
            unsupportedAccountKeyList = (List<CustomerAccountKey>) CollectionUtils.subtract(customerAccountKeyList,
                    supportedAccountList);
            if (supportedAccountList == null || supportedAccountList.isEmpty()) {
                logger.debug("No supported accounts found ");
                ApiErrorCode errorCode = getNotFoundApiErrorCode(unsupportedAccountKeyList);
                throw new ApiBusinessException(errorCode, Constants.HTTP_STATUS_CODE_403);
            }

            customerAccountsRequest.setCustomerAccountKeyList(supportedAccountList);
            customerAccountsRequest.setUnSupportedAccountKeyList(unsupportedAccountKeyList);
            // Fetch account details and relationships form REAS and
            // XESRelatedAccountIS and ProfileAccountRelationshipsIS
            if (selectOptionList == null) {

                CustomerAccountsOrchResponse orchResponse = customerAccountsOrchService
                        .execute(customerAccountsRequest);
                logger.debug("Calling execute method of CustomerAccountsAggregationService Class ");
                customerAccountsAggregatedResponse = customerAccountsAggregationService.execute(orchResponse,
                        customerAccountsRequest.isEnableErrorHandlingSwitch(), false, customerAccountKeyList);

                // to retrieve AccountNickname from OECP for All LOB's
                if (orchResponse != null && orchResponse.getFutureOecpPrefResponse() != null) {
                    customerAccountsAggregatedResponse = customerAccountsAggregationService.retrieveNicknameFromOecp(
                            customerAccountsAggregatedResponse, orchResponse.getFutureOecpPrefResponse());

                }

                // to retrieve AccountNickname from OLBAccountIS

                if (orchResponse.getFutureOLBAccountsResponse() != null) {
                    customerAccountsAggregatedResponse = customerAccountsAggregationService.retrieveNicknameFromOLBR(
                            customerAccountsAggregatedResponse, orchResponse.getFutureOLBAccountsResponse());
                }

                if (customerAccountsAggregatedResponse.getCustomerAccountsResponseList() == null
                        || customerAccountsAggregatedResponse.getCustomerAccountsResponseList().size() == 0) {
                    throw new NotFoundException();
                }
                if (customerAccountsAggregatedResponse.getCustomerAccountsResponseList() != null
                        && customerAccountsAggregatedResponse.getCustomerAccountsResponseList().size() > 0) {

                    // RE Filter out the list based on requested businessLine
                    // and
                    // productType
                    if (businessLineSet != null && !businessLineSet.isEmpty()) {
                        customerAccountsAggregatedResponse.setCustomerAccountsResponseList(CustomerAccountsFilterUtil
                                .filterByBusinessLine(
                                        customerAccountsAggregatedResponse.getCustomerAccountsResponseList(),
                                        businessLineSet));
                    }
                    if (productTypeSet != null && !productTypeSet.isEmpty()) {
                        customerAccountsAggregatedResponse.setCustomerAccountsResponseList(CustomerAccountsFilterUtil
                                .filterByProductType(
                                        customerAccountsAggregatedResponse.getCustomerAccountsResponseList(),
                                        productTypeSet));
                    }
                }

                customerAccountList = customerAccountsUtil.maptoFinalResponse(
                        customerAccountsAggregatedResponse.getCustomerAccountsResponseList(),
                        customerAccountsRequest.getAppVersion(), customerAccountKeyList);
                // Change
                boolean isSortEmpty = request.getSort() == null || request.getSort().isEmpty() || request.getSort().size() == 0;
                if ((isSortEmpty)
                        && customerAccountsRequest.isEnableOecpSortOrder()
                        && orchResponse.getFutureMongoOecpPreferencesResponse() != null) {
                    logger.debug("Calling execute of mongoOecpPreferencesOrchService class ");
                    List<String> customSortOrderAcctList = getAcctSortList(orchResponse
                            .getFutureMongoOecpPreferencesResponse());
                    logger.debug("the custom sort list is {}", customSortOrderAcctList);
                    if (customSortOrderAcctList != null && !customSortOrderAcctList.isEmpty()) {
                        arrangeResponseAccountsByCustomSortOrder(customSortOrderAcctList, customerAccountList);
                        customSortFlag = true;
                    }

                }

            } else {
                customerAccountList = fetchLightWeightECROrchService.fetchLightWeightECRKeyBasedOnResponseListContent(
                        customerAccountsRequest, selectOptionList);
            }

            // prepare to perform default sort if sorting is not defined
            boolean isSortEmpty = (request.getSort() == null || request.getSort().isEmpty() || request.getSort().size() == 0);
            if ((isSortEmpty) && customerAccountsRequest.isSortByOpenDate() && !customSortFlag) {

                Sort defaultSort = new Sort();
                defaultSort.setField(OPEN_DATE);
                defaultSort.setDirection(Direction.ASC);
                List<Sort> defaultSortList = new ArrayList<Sort>();
                defaultSortList.add(defaultSort);
                request.setSort(defaultSortList);
                defaultSortByOpenDateFlag = true;
            }

        } else {

            logger.debug("Invalid value for responseListContent");
            ApiErrorCode error = new ApiErrorCode();
            List<ApiErrorCode> errorDetails = new ArrayList<ApiErrorCode>();
            ApiErrorCode errorDetail = new ApiErrorCode();
            errorDetail.setId(Constants.ERROR_CODE_INVALID_RESPONSE_CONTENT);
            errorDetails.add(errorDetail);
            error.setErrorDetails(errorDetails);

            throw new ApiBusinessException(error, Constants.ERROR_CODE_400);

        }

        CustomerAccountsEntityCollectionResponse response = new CustomerAccountsEntityCollectionResponse(request,
                customerAccountList);
        if (customerAccountsAggregatedResponse != null) {
            response.setErrorResponse(customerAccountsAggregatedResponse.getPartialError());
        }

        if ((request.getSort() == null || request.getSort().isEmpty()) && !customerAccountsRequest.isSortByOpenDate()
                && !customSortFlag) {
            defaultAcctSort(response.getEntries());
        }

        if (defaultSortByOpenDateFlag) {
            arrangeResponseAccounts(response);
        }

        logger.debug("Exit - getCustomerAccountList method of CustomerAccountsServiceImpl class");

        return response;
    }

    private List<String> getAcctSortList(Future<List<String>> futureMongoOecpPreferencesResponse) {
        List<String> acctSortOrderList = null;
        try {
            acctSortOrderList = futureMongoOecpPreferencesResponse.get(OECP_SORT_WAIT_TIME, OECP_SORT_WAIT_UNIT);
        } catch (InterruptedException e) {
            logger.error(" Interupted Exception", e);
            futureMongoOecpPreferencesResponse.cancel(true);
        } catch (ExecutionException e) {
            logger.error(" Execution Exception", e);
            futureMongoOecpPreferencesResponse.cancel(true);
        } catch (TimeoutException e) {
            logger.error(" TimeoutException Exception", e);
            futureMongoOecpPreferencesResponse.cancel(true);
        }
        return acctSortOrderList;

    }

    private void arrangeResponseAccountsByCustomSortOrder(List<String> customSortOrderAcctList,
            List<CustomerAccount> customerAccountList) {

        List<CustomerAccount> listOecpSortedAccnts = new ArrayList<CustomerAccount>();
        logger.debug("Enter - arrangeResponseAccountsByCustomSortOrder method of CustomerAccountsServiceImpl class");
        logger.debug("CustomSortList {}", customSortOrderAcctList);
        if (CollectionUtils.isNotEmpty(customerAccountList)) {
            List<CustomerAccount> listFinalSortedAcnts = new ArrayList<CustomerAccount>();
            Iterator<String> listCustomerAccountSortedIt = customSortOrderAcctList.iterator();
            while (listCustomerAccountSortedIt.hasNext()) {
                try {
                    ReferenceId referenceid = ReferenceId.valueOf(crypto.decrypt(listCustomerAccountSortedIt.next()));
                    List<CustomerAccount> listAllCustomerAccount = new ArrayList<CustomerAccount>();
                    listAllCustomerAccount.addAll(customerAccountList);
                    CollectionUtils.filter(listAllCustomerAccount, getCustomSortPredicate(referenceid));
                    logger.debug("listAllCustomerAccount {}", listAllCustomerAccount);
                    listOecpSortedAccnts.addAll(listAllCustomerAccount);
                    logger.debug("listFinalSortedAcnts {}", listOecpSortedAccnts);
                } catch (Exception e) {
                    logger.debug("Exception Occurred while sorting{}", e);
                }

            }
            List<CustomerAccount> listNonOecpAccnts = (List<CustomerAccount>) CollectionUtils.subtract(
                    customerAccountList, listOecpSortedAccnts);
            if (listNonOecpAccnts != null && listNonOecpAccnts.size() > 1) {
                defaultAcctSort(listNonOecpAccnts);
            }
            if (listNonOecpAccnts != null && !listNonOecpAccnts.isEmpty()) {
                listFinalSortedAcnts.addAll(listNonOecpAccnts);
            }
            listFinalSortedAcnts.addAll(listOecpSortedAccnts);
            customerAccountList.clear();
            customerAccountList.addAll(listFinalSortedAcnts);
            // reasResponse.setCustomerAccountsResponseList(listFinalSortedAcnts);
        }

        logger.debug("Exit - arrangeResponseAccountsByCustomSortOrder method of CustomerAccountsServiceImpl class");
    }

    private Predicate getCustomSortPredicate(final ReferenceId accountRefId) {
        logger.debug("Enter - getCustomSortPredicate method of CustomerAccountsServiceImpl class");

        Predicate predicate = new Predicate() {

            @Override
            public boolean evaluate(Object customerAccount) {
                if ((((CustomerAccount) customerAccount).getAccountReferenceId() == null)
                        && (((CustomerAccount) customerAccount).getAccountReferenceId().getValue() != null)) {
                    return false;
                }
                return (((CustomerAccount) customerAccount).getAccountReferenceId().getValue())
                        .equalsIgnoreCase(accountRefId.getValue());
            }
        };
        logger.debug("Exit - getCustomSortPredicate method of CustomerAccountsServiceImpl class");
        return predicate;
    }

    /**
     * This method is fetching Accounts and their RelationShip
     * 
     * @param request list of Collection
     * @param customerAccountsRequest customers accounts Input
     * @param select query element
     * @return customers entity collection
     */

    @Override
    public CustomerAccountsEntityCollectionResponse fetchAccountsAndRelationShip(EntityCollectionRequest request,
            CustomerAccountsRequest customerAccountsRequest, String select) {
        logger.debug("Enter - fetchAccountsAndRelationShip method of CustomerAccountsServiceImpl class");
        return getCustomerAccountList(request, customerAccountsRequest, select);
    }

    /**
     * This method is fetching Account with Entitelments
     * 
     * @param request list of Collection
     * @param customerAccountsRequest customers accounts Input
     * @param select query element
     * @return customers entity collection
     */

    @Override
    @EnableEntitlements
    @EnableEntitlementPostFiltering
    public CustomerAccountsEntityCollectionResponse fetchAccountwithEntitelments(EntityCollectionRequest request,
            CustomerAccountsRequest customerAccountsRequest, String select) {
        logger.debug("Enter - fetchAccountwithEntitelments method of CustomerAccountsServiceImpl class");
        List<CustomerAccountKey> servicableList = new ArrayList<CustomerAccountKey>();
        if (serviceableAccountProvider != null && serviceableAccountProvider.canProvideServiceableAccounts()) {
            List<ReferenceId> serviceableAccounts = serviceableAccountProvider.getServiceableAccounts();
            for (ReferenceId referenceId : serviceableAccounts) {
                CustomerAccountKey customerAccountKey = new CustomerAccountKey();
                Pair<String, Short> accountdetails = convertAccountReferenceIdToAccountKey(referenceId);
                customerAccountKey.setAccountNumber(accountdetails.getLeft());
                customerAccountKey.setSorId(accountdetails.getRight());
                servicableList.add(customerAccountKey);
            }
        }
        customerAccountsRequest.setServicableAccountKeyList(servicableList);
        logger.debug("Exit - fetchAccountwithEntitelments method of CustomerAccountsServiceImpl class");
        return getCustomerAccountList(request, customerAccountsRequest, select);
    }

    private Pair<String, Short> convertAccountReferenceIdToAccountKey(ReferenceId referenceId) {
        AccountReferenceId accountReferenceId = new AccountReferenceId(referenceId);
        return Pair.of(accountReferenceId.getAccountId(), Short.valueOf(accountReferenceId.getSystemOfRecordId()));
    }

    /**
     * This method is fetching Account 3 part key from ECR based on customerReferenceID or profileReferenceID
     * 
     * @param request list of Collection
     * @param customerAccountsRequest customers accounts Input
     * @return customers entity collection
     */

    @Override
    public CustomerAccountsEntityCollectionResponse fetchCustomerRefID(EntityCollectionRequest request,
            CustomerAccountsRequest customerAccountsRequest) {
        logger.debug("Enter - fetchCustomerRefID method of CustomerAccountsServiceImpl class");
        validateInput(customerAccountsRequest);

        // Fetch Account 3 part key from ECR based on customerReferenceID or
        // profileReferenceID

        if (null != customerAccountsRequest.getProfileReferenceId()
                && (StringUtils.isNotBlank(customerAccountsRequest.getProfileReferenceId().getSSOID()))) {
            customerAccountsDao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(customerAccountsRequest);
        } else {
            customerAccountsDao.createCustomerReferenceURL(customerAccountsRequest.getCustomerReferenceId());
        }

        CustomerAccountsEntityCollectionResponse response = null;
        logger.debug("Exit - fetchCustomerRefID method of CustomerAccountsServiceImpl class");
        return response;
    }

    /**
     * This method is Validating the request
     * 
     * @param request input information
     * @return
     */

    private void validateInput(CustomerAccountsRequest request) {

        logger.debug("Enter - validateInput method of CustomerAccountsServiceImpl class");

        Set<String> allBusinessLines = null;
        Set<String> requestBusinessLineSet = null;
        requestBusinessLineSet = request.getBusinessLineSet();
        allBusinessLines = customerAccountsRefDataBean.getAllBusinessLines();

        Set<String> allProductTypes = null;
        Set<String> requestProductTypeSet = null;
        requestProductTypeSet = request.getProductTypeSet();
        allProductTypes = customerAccountsRefDataBean.getAllProductTypes();

        String detailId = null;
        detailId = ApiErrorCode.REQUEST_VALIDATION_FAILURE;
        ApiErrorCode error = new ApiErrorCode();
        error.setId(detailId);

        if (allBusinessLines != null && !allBusinessLines.isEmpty()) {
            constructError(allBusinessLines, requestBusinessLineSet, allProductTypes, requestProductTypeSet, error);
        }

        List<ApiErrorCode> errorDetails = error.getErrorDetails();
        if (errorDetails != null && !errorDetails.isEmpty()) {
            RequestValidationException ex = new RequestValidationException(error);
            throw ex;
        }
        logger.debug("Exit - validateInput method of CustomerAccountsServiceImpl class");
    }

    private void constructError(Set<String> allBusinessLines, Set<String> requestBusinessLineSet,
            Set<String> allProductTypes, Set<String> requestProductTypeSet, ApiErrorCode error) {
        logger.debug("Enter - constructError method of CustomerAccountsServiceImpl class");
        if ((requestBusinessLineSet != null && !requestBusinessLineSet.isEmpty())
                && !allBusinessLines.containsAll(requestBusinessLineSet)) {
            List<String> messageParms = new ArrayList<String>();
            messageParms.add(allBusinessLines.toString());
            error.getErrorDetails().add(
                    customerAccountsUtil.constructApiErrorCode(Constants.REQUEST_VALIDATION_ERROR_KEY_300101,
                            messageParms, Constants.REQUEST_VALIDATION_INVALID_INPUT_MSG_300101));
        }
        if ((requestProductTypeSet != null && !requestProductTypeSet.isEmpty())
                && !allProductTypes.containsAll(requestProductTypeSet)) {
            List<String> messageParms = new ArrayList<String>();
            messageParms.add(allProductTypes.toString());
            error.getErrorDetails().add(
                    customerAccountsUtil.constructApiErrorCode(Constants.REQUEST_VALIDATION_ERROR_KEY_300102,
                            messageParms, Constants.REQUEST_VALIDATION_INVALID_INPUT_MSG_300102));
        }
        logger.debug("Enter - constructError method of CustomerAccountsServiceImpl class");
    }

    /**
     * This method is Sorting the response according to the account status referring the reference data
     * 
     * @param response customers accounts response
     * @return
     */

    private void defaultAcctSort(List<CustomerAccount> listCustomerAccount) {
        logger.debug("Enter - defaultAcctSort method of CustomerAccountsServiceImpl class");
        List<CustomerAccount> listSortedAccounts = new ArrayList<CustomerAccount>();
        List<CustomerAccount> listClosedSortedAccounts = new ArrayList<CustomerAccount>();
        if (listCustomerAccount != null && CollectionUtils.isNotEmpty(listCustomerAccount)) {
            // List<CustomerAccount> listCustomerAccount = response.getEntries();
            List<String> primarySortKeyList = customerAccountsRefDataBean.getSortKey(PRIMARY);
            logger.debug("Primary sort items {}", primarySortKeyList);
            Iterator<String> listCustomerAccountIt = primarySortKeyList.iterator();
            while (listCustomerAccountIt.hasNext()) {
                String status = listCustomerAccountIt.next();
                List<CustomerAccount> listAllCustomerAccount = new ArrayList<CustomerAccount>();
                listAllCustomerAccount.addAll(listCustomerAccount);
                CollectionUtils.filter(listAllCustomerAccount, getPrimaryPredicate(status));
                listClosedSortedAccounts.addAll(performSecondarySort(listAllCustomerAccount, status));
            }
            List<CustomerAccount> listOtherSortedAccounts = (List<CustomerAccount>) CollectionUtils.subtract(
                    listCustomerAccount, listClosedSortedAccounts);
            CollectionUtils.filter(listOtherSortedAccounts, getFilterEmptyStatusPredicate());
            listSortedAccounts.addAll(performSecondarySort(listOtherSortedAccounts, OPEN_DATE));
            logger.debug("only open accounts {}", listSortedAccounts);
            listSortedAccounts.addAll(listClosedSortedAccounts);
            List<CustomerAccount> listEmptyAcntStatAccounts = (List<CustomerAccount>) CollectionUtils.subtract(
                    listCustomerAccount, listSortedAccounts);
            listSortedAccounts.addAll(listEmptyAcntStatAccounts);
            logger.debug("closed accounts {}", listClosedSortedAccounts);
            logger.debug("open and closed accounts {}", listSortedAccounts);

            listCustomerAccount.clear();
            listCustomerAccount.addAll(listSortedAccounts);
            // response.setEntries(listSortedAccounts);

        }
        logger.debug("Exit - defaultAcctSort method of CustomerAccountsServiceImpl class");
    }

    /**
     * This method is Sorting the response according to the ProductTypeDesc referring the reference data
     * 
     * @param listCustomerAccountSorted list of customers account sorted
     * @param status sort status
     * @return list of customerAccount
     */

    private List<CustomerAccount> performSecondarySort(List<CustomerAccount> listCustomerAccountSorted, String status) {
        logger.debug("Enter - performSecondarySort method of CustomerAccountsServiceImpl class");
        List<CustomerAccount> sortedList = new ArrayList<CustomerAccount>();
        if (CollectionUtils.isNotEmpty(listCustomerAccountSorted)) {
            List<String> secondarySortKeyList = customerAccountsRefDataBean.getSortKey(SECONDARY);
            logger.debug("Secondary sort items {}", secondarySortKeyList);
            Iterator<String> secondarySortKeyListIt = secondarySortKeyList.iterator();
            List<CustomerAccount> listAllCustomerAccount;
            String tertiaryOperator = "";
            if (StringUtils.isNotEmpty(status) && (status.equalsIgnoreCase(CLOSED))) {
                tertiaryOperator = Constants.FIELD_CLOSED_DATE;
            } else {
                tertiaryOperator = Constants.FIELD_OPEN_DATE;
            }

            while (secondarySortKeyListIt.hasNext()) {
                listAllCustomerAccount = new ArrayList<CustomerAccount>();
                listAllCustomerAccount.addAll(listCustomerAccountSorted);
                CollectionUtils.filter(listAllCustomerAccount, getSecondaryPredicate(secondarySortKeyListIt.next()));
                performTertiarySort(listAllCustomerAccount, tertiaryOperator, customerAccountsRefDataBean
                        .getTertiarySortKey(TERTIARY).get(tertiaryOperator));
                sortedList.addAll(listAllCustomerAccount);

            }
            List<CustomerAccount> noProductTypeDesc = (List<CustomerAccount>) CollectionUtils.subtract(
                    listCustomerAccountSorted, sortedList);
            performTertiarySort(noProductTypeDesc, tertiaryOperator,
                    customerAccountsRefDataBean.getTertiarySortKey(TERTIARY).get(tertiaryOperator));
            sortedList.addAll(noProductTypeDesc);
            logger.debug("The sortDir {} {}", tertiaryOperator,
                    customerAccountsRefDataBean.getTertiarySortKey(TERTIARY));

        }
        logger.debug("Exit - performSecondarySort method of CustomerAccountsServiceImpl class");
        return sortedList;
    }

    private void performTertiarySort(List<CustomerAccount> listCustomerAccountSorted, String sortField,
            String sortDirection) {
        logger.debug("Enter - performTertiarySort method of CustomerAccountsServiceImpl class");
        List<Instant> openDateList = new ArrayList<Instant>();
        List<Instant> closedDateList = new ArrayList<Instant>();
        List<CustomerAccount> listAllCustomers = new ArrayList<CustomerAccount>();
        List<CustomerAccount> listFinalSorted = new ArrayList<CustomerAccount>();
        logger.debug("Sort field and order {}{}", sortField, sortDirection);
        if (sortField != null && sortDirection != null) {

            Sort sort = new Sort();
            sort.setField(sortField);
            if (sortDirection.equalsIgnoreCase(String.valueOf(Direction.ASC))) {
                sort.setDirection(Direction.ASC);
            } else if (sortDirection.equalsIgnoreCase(String.valueOf(Direction.DESC))) {
                sort.setDirection(Direction.DESC);
            }
            List<Sort> sortList = new ArrayList<Sort>();
            sortList.add(sort);
            FieldComparator comparator = new FieldComparator(sortList);
            Collections.sort(listCustomerAccountSorted, comparator);
            List<CustomerAccount> listNonSortFieldAcnts = new ArrayList<CustomerAccount>();
            Iterator<CustomerAccount> listCustomerAccountIt = listCustomerAccountSorted.iterator();
            while (listCustomerAccountIt.hasNext()) {
                Boolean flag = false;
                CustomerAccount account = listCustomerAccountIt.next();
                setDateList(sortField, openDateList, closedDateList, account);
                flag = setFlagForTertiarySort(sortField, account);

                if (flag) {

                    listNonSortFieldAcnts.add(account);
                    listCustomerAccountIt.remove();
                }
            }
            listCustomerAccountSorted.addAll(listNonSortFieldAcnts);
            logger.debug("openDateList {}", openDateList);
            sortByAccountNumber(listCustomerAccountSorted, sortField, openDateList, closedDateList, listAllCustomers,
                    listFinalSorted);

        }
        logger.debug("openDateSorted {}", listCustomerAccountSorted);
        logger.debug("Exit - performTertiarySort method of CustomerAccountsServiceImpl class");
    }

    private void setDateList(String sortField, List<Instant> openDateList, List<Instant> closedDateList,
            CustomerAccount account) {
        if (sortField.equalsIgnoreCase(OPEN_DATE) && account.getOpenDate() != null
                && !openDateList.contains(account.getOpenDate())) {
            openDateList.add(account.getOpenDate());
        } else if (sortField.equalsIgnoreCase(CLOSED_DATE) && account.getClosedDate() != null
                && !closedDateList.contains(account.getClosedDate())) {
            closedDateList.add(account.getClosedDate());
        }
    }

    private void sortByAccountNumber(List<CustomerAccount> listCustomerAccountSorted, String sortField,
            List<Instant> openDateList, List<Instant> closedDateList, List<CustomerAccount> listAllCustomers,
            List<CustomerAccount> listFinalSorted) {
        if (sortField.equalsIgnoreCase(OPEN_DATE)) {

            Iterator<Instant> openDateIt = openDateList.iterator();
            while (openDateIt.hasNext()) {
                Instant openDate = openDateIt.next();
                listAllCustomers.addAll(listCustomerAccountSorted);
                CollectionUtils.filter(listAllCustomers, getAccountSortPredicate(openDate));
                sortByAccountNumber(listAllCustomers);
                listFinalSorted.addAll(listAllCustomers);
            }
            List<CustomerAccount> nonOpenDateAccounts = (List<CustomerAccount>) CollectionUtils.subtract(
                    listCustomerAccountSorted, listFinalSorted);
            if (CollectionUtils.isNotEmpty(nonOpenDateAccounts)) {
                sortByAccountNumber(nonOpenDateAccounts);
                listFinalSorted.addAll(nonOpenDateAccounts);
            }
            listCustomerAccountSorted.clear();
            listCustomerAccountSorted.addAll(listFinalSorted);
        } else if (sortField.equalsIgnoreCase(CLOSED_DATE)) {

            Iterator<Instant> closedDateIt = closedDateList.iterator();
            while (closedDateIt.hasNext()) {
                Instant closedDate = closedDateIt.next();
                listAllCustomers.addAll(listCustomerAccountSorted);
                CollectionUtils.filter(listAllCustomers, getAccountSortPredicateClosed(closedDate));
                sortByAccountNumber(listAllCustomers);
                listFinalSorted.addAll(listAllCustomers);
            }
            List<CustomerAccount> nonClosedDateAccounts = (List<CustomerAccount>) CollectionUtils.subtract(
                    listCustomerAccountSorted, listFinalSorted);
            if (CollectionUtils.isNotEmpty(nonClosedDateAccounts)) {
                sortByAccountNumber(nonClosedDateAccounts);
                listFinalSorted.addAll(nonClosedDateAccounts);
            }
            listCustomerAccountSorted.clear();
            listCustomerAccountSorted.addAll(listFinalSorted);
        }
    }

    private void sortByAccountNumber(List<CustomerAccount> listCustomerAccount) {
        Sort sort = new Sort();
        sort.setField(ACCOUNT_NUMBER);
        sort.setDirection(Direction.ASC);
        List<Sort> sortList = new ArrayList<Sort>();
        sortList.add(sort);
        FieldComparator comparator = new FieldComparator(sortList);
        Collections.sort(listCustomerAccount, comparator);
    }

    private Boolean setFlagForTertiarySort(String sortField, CustomerAccount account) {
        Boolean flag = false;
        logger.debug("Enter - setFlagForTertiarySort method of CustomerAccountsServiceImpl class");
        if (sortField.equalsIgnoreCase(Constants.FIELD_OPEN_DATE)) {
            if (account.getOpenDate() == null) {
                flag = true;
            }
        } else if ((sortField.equalsIgnoreCase(Constants.FIELD_CLOSED_DATE)) && (account.getClosedDate() == null)) {

            flag = true;

        }
        logger.debug("Exit - setFlagForTertiarySort method of CustomerAccountsServiceImpl class");
        return flag;
    }

    private Predicate getPrimaryPredicate(final String fieldValue) {
        logger.debug("Enter - getPrimaryPredicate method of CustomerAccountsServiceImpl class");
        Predicate predicate = new Predicate() {

            @Override
            public boolean evaluate(Object customerAccount) {
                if (((CustomerAccount) customerAccount).getAccountStatus() == null) {
                    return false;
                }
                logger.debug("the primary predicate {} {} {}", fieldValue,
                        ((CustomerAccount) customerAccount).getAccountStatus(),
                        fieldValue.equalsIgnoreCase(((CustomerAccount) customerAccount).getAccountStatus()));
                return (fieldValue.equalsIgnoreCase(((CustomerAccount) customerAccount).getAccountStatus()));
            }
        };
        logger.debug("Exit - getPrimaryPredicate method of CustomerAccountsServiceImpl class");
        return predicate;
    }

    private Predicate getFilterEmptyStatusPredicate() {
        logger.debug("Enter - getFilterEmptyStatusPredicate method of CustomerAccountsServiceImpl class");
        Predicate predicate = new Predicate() {

            @Override
            public boolean evaluate(Object customerAccount) {
                String accountStatus = ((CustomerAccount) customerAccount).getAccountStatus();
                if (accountStatus == null || accountStatus.isEmpty()) {
                    return false;
                }
                return true;
            }
        };
        logger.debug("Exit - getFilterEmptyStatusPredicate method of CustomerAccountsServiceImpl class");
        return predicate;
    }

    private Predicate getSecondaryPredicate(final String fieldValue) {
        logger.debug("Enter - getSecondaryPredicate method of CustomerAccountsServiceImpl class");
        Predicate predicate = new Predicate() {

            @Override
            public boolean evaluate(Object customerAccount) {
                if (((CustomerAccount) customerAccount).getProduct() == null
                        || ((CustomerAccount) customerAccount).getProduct().getProductTypeDescription() == null) {
                    return false;
                }
                return (fieldValue.toUpperCase()).equalsIgnoreCase(((CustomerAccount) customerAccount).getProduct()
                        .getProductTypeDescription().toUpperCase());
            }
        };
        logger.debug("Enter - getSecondaryPredicate method of CustomerAccountsServiceImpl class");
        return predicate;
    }

    private Predicate getAccountSortPredicate(final Instant openDate) {
        logger.debug("Enter - getAccountSortPredicate method of CustomerAccountsServiceImpl class");
        Predicate predicate = new Predicate() {

            @Override
            public boolean evaluate(Object customerAccount) {
                if (((CustomerAccount) customerAccount).getOpenDate() == null) {
                    return false;
                }
                return (openDate.equals(((CustomerAccount) customerAccount).getOpenDate()));
            }
        };
        logger.debug("Exit - getAccountSortPredicate method of CustomerAccountsServiceImpl class");
        return predicate;
    }

    private Predicate getAccountSortPredicateClosed(final Instant closedDate) {
        logger.debug("Enter - getAccountSortPredicateClosed method of CustomerAccountsServiceImpl class");
        Predicate predicate = new Predicate() {

            @Override
            public boolean evaluate(Object customerAccount) {
                if (((CustomerAccount) customerAccount).getClosedDate() == null) {
                    return false;
                }
                return (closedDate.equals(((CustomerAccount) customerAccount).getClosedDate()));
            }
        };
        logger.debug("Exit - getAccountSortPredicateClosed method of CustomerAccountsServiceImpl class");
        return predicate;
    }


     /*predicate to filters out all coi accounts.
     */
         private Predicate filterCOIAccounts() {
        logger.debug("Enter - filterCOIAccounts method of CustomerAccountsServiceImpl class");
        Predicate predicate = new Predicate() {

            @Override
            public boolean evaluate(Object customerAccountKey) {
                if (((CustomerAccountKey) customerAccountKey).getSorId() == null) {
                    return false;
                }
                return !((Constants.SOR_ID_COI).equals(String.valueOf(((CustomerAccountKey) customerAccountKey).getSorId())));
            }
        };
        logger.debug("Exit - filterCOIAccounts method of CustomerAccountsServiceImpl class");
        return predicate;
    }

    private void arrangeResponseAccounts(CustomerAccountsEntityCollectionResponse response) {
        if (response != null && CollectionUtils.isNotEmpty(response.getEntries())) {
            List<CustomerAccount> listCustomerAccount = response.getEntries();
            List<CustomerAccount> listNonOpenDateAcnts = new ArrayList<CustomerAccount>();
            Iterator<CustomerAccount> listCustomerAccountIt = listCustomerAccount.iterator();
            while (listCustomerAccountIt.hasNext()) {
                CustomerAccount account = listCustomerAccountIt.next();
                if (account != null && account.getOpenDate() == null) {
                    listNonOpenDateAcnts.add(account);
                    listCustomerAccountIt.remove();
                }
            }
            listCustomerAccount.addAll(listNonOpenDateAcnts);
        }
    }

    private ApiErrorCode getNotFoundApiErrorCode(List<CustomerAccountKey> unsupportedAccountKeyList) {
        ApiErrorCode error = new ApiErrorCode();
        error.setId(Constants.NO_SUPPORTED_ACCNT_ERROR_CODE);
        List<ApiErrorCode> errorDetails = new ArrayList<ApiErrorCode>();
        ApiErrorCode errorDetail = new ApiErrorCode();
        errorDetail.setId(Constants.NOT_SUPPORTED_ACCOUNT_ERROR_CODE);
        List<String> messageParam = new ArrayList<String>();
        messageParam.add(customerAccountsRefDataBean.getSorProductTypeFromSorId(unsupportedAccountKeyList));
        errorDetail.setMessageParms(messageParam);
        errorDetails.add(errorDetail);
        error.setErrorDetails(errorDetails);
        return error;
    }

}
