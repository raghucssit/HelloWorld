package com.capitalone.api.customersaccounts.service.convert.response;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.commons.lang.StringUtils;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo;

/**
 * This class is the response Converter for CustInfoDLSRsConverter
 * 
 */
@Profile
@Trace
@Named
public class CustInfoDLSRsConverter extends ConversionServiceAwareConverter<List<CustInfo>, Map<String, String>> {

    /**
     * Response Converter of CustomerInformationDLS
     * 
     * @param listCustInfo 
     * @return response
     */

    @Override
    public Map<String, String> convert(List<CustInfo> listCustInfo) {

        logger.debug("CustInfoDLSRsConverter  : convert -> Start");
        Map<String, String> response = new HashMap<String, String>();
        for (CustInfo custInfo : listCustInfo) {
            if (custInfo.getAcct() != null && custInfo.getCustAcctRoleType() != null
                    && custInfo.getCust().getCustID() != null) {
                String key = StringUtils.join(
                        new String[] {StringUtils.stripStart(custInfo.getCust().getCustID(), "0"),
                                StringUtils.stripStart(custInfo.getAcct().getAcctID(), "0")}, "|");
                response.put(key, custInfo.getCustAcctRoleType().getCustAcctRoleTypeDesc());

            }
        }
        return response;
    }

}
