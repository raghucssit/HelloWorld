package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractRestBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.CapitalOneInvestingAccountDAO;
import com.capitalone.api.customersaccounts.model.v1.AccountApplicantKey;
import com.capitalone.api.customersaccounts.model.v1.AccountApplicants;
import com.capitalone.api.customersaccounts.model.v1.InvestingAccounts;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.model.EndpointProperties;
import com.google.common.net.HttpHeaders;

/**
 * DAO for retrieving Investing Accounts
 */

@Profile
@Trace
@Named
public class CapitalOneInvestingAccountDAOImpl extends AbstractRestBaseService<Client, InvestingAccounts> implements
        CapitalOneInvestingAccountDAO {

    private static final String INFO = "INFO";

    private static final String ERR_GENERAL_ERROR_IN_PERF_LOG = "ERR_GENERAL_ERROR in Perf Log";

    private static final String ERROR = "SOAP-FAULT";

    @Inject
    private Client eapiRestClient;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    private static final String SHAREBUILDER_INVESTING_RESOURCE_URL = "sharebuilder-investing-account-Service";

    private static final String APPLICATION_JSON_V_3 = "application/json";

    @Override
    @Async
    public Future<REASResponse> getInvestingAccount(EPFContext context, CustomerAccountsRequest request) {
        logger.debug("Enter -- getInvestingAccount of CapitalOneInvestingAccountDAOImpl");
        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();
        List<AdditionalStat> stat = new ArrayList<AdditionalStat>();
        AdditionalStat addnStat = null;
        REASResponse resp = new REASResponse();
        InvestingAccounts investingAccounts = null;

        EndpointProperties endpointProperties = customerAccountsUtil
                .getEndpointProperties(SHAREBUILDER_INVESTING_RESOURCE_URL);

        String url = endpointProperties.getUrl();

        UriBuilder uri = UriBuilder.fromUri(url);
        WebTarget requestPath = eapiRestClient.target(uri);

        long startTime = 0;
        long responseTime = 0;

        try {

            List<AccountApplicantKey> acctApplKeyList = new ArrayList<AccountApplicantKey>();

            for (CustomerAccountKey listInvestingAccounts : request.getCustomerAccountKeyList()) {
                if (listInvestingAccounts.getSorId().equals(Short.valueOf(Constants.SOR_ID_COI))) {

                    AccountApplicantKey acctApplKey = new AccountApplicantKey();
                    acctApplKey.setInvestorId(Long.valueOf(listInvestingAccounts.getConsumerId()));
                    acctApplKey
                            .setAccountNumber(StringUtils.leftPad(listInvestingAccounts.getAccountNumber(), 10, "0"));

                    acctApplKeyList.add(acctApplKey);
                }
            }

            if (CollectionUtils.isNotEmpty(acctApplKeyList)) {
                AccountApplicants accountApplicants = new AccountApplicants();
                accountApplicants.setAccountApplicantKey(acctApplKeyList);
                startTime = System.currentTimeMillis();
                investingAccounts = requestPath.request().accept(APPLICATION_JSON_V_3)
                        .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V_3)
                        .post(Entity.json(accountApplicants), InvestingAccounts.class);
                responseTime = System.currentTimeMillis() - startTime;
                customerAccountsUtil.generateCustomPerfLog(context, responseTime,
                        String.valueOf(Constants.SUCCESS_STAT_CD), INFO, Constants.SUCCESS_RESPONSE,
                        SHAREBUILDER_INVESTING_RESOURCE_URL, Constants.ERROR_CODE_200);
                logger.debug("Ivesting account Response {}", investingAccounts);

            }
            if (investingAccounts != null) {
                resp = conversionService.convert(investingAccounts, REASResponse.class);
            } else {
                logger.debug("Inside else of Investing Account");
                addnStat = new AdditionalStat();
                addnStat.setNativeErrorCd(Constants.API_COI_ERROR_CODE);
                addnStat.setStatDesc(Constants.COI_API_DOWN);
                stat.add(addnStat);
            }

            if (CollectionUtils.isNotEmpty(stat)) {
                resp.setAddStatList(stat);
            }
            
        } catch (WebApplicationException e){
        	responseTime = System.currentTimeMillis() - startTime;
            String errocode = String.valueOf(Constants.ERROR_CODE_100);
            String statusDescription = ERR_GENERAL_ERROR_IN_PERF_LOG;
            int httpstatusCode = Constants.ERROR_CODE_400;
            String sevirity = ERROR;
        	
        	int status = ((WebApplicationException) e).getResponse().getStatus();
            if (status == Response.Status.NOT_FOUND.getStatusCode()) {
                addnStat = new AdditionalStat();
                addnStat.setNativeErrorCd(Constants.API_COI_ERROR_CODE);
                errocode = Constants.API_COI_ERROR_CODE;
                sevirity = INFO;
                httpstatusCode = Response.Status.NOT_FOUND.getStatusCode();
                 statusDescription = Constants.NO_ACCOUNT_FOUND_IN_COI_202277;
                 addnStat.setStatDesc(Constants.NO_ACCOUNT_FOUND_IN_COI_202277);
                stat.add(addnStat);
                resp.setAddStatList(stat);
            }
            
            customerAccountsUtil.generateCustomPerfLog(context, responseTime, errocode, sevirity, statusDescription,
                    SHAREBUILDER_INVESTING_RESOURCE_URL, httpstatusCode);
        }
        catch (Exception e) {
            logger.debug("Exception Occurred {}", e.getCause());
            logger.debug("Exception Occurred of e {}", e);

            responseTime = System.currentTimeMillis() - startTime;
            String errocode = String.valueOf(Constants.ERROR_CODE_100);
            String statusDescription = ERR_GENERAL_ERROR_IN_PERF_LOG;
            int httpstatusCode = Constants.ERROR_CODE_400;
            String sevirity = ERROR;

            errocode = Constants.API_COI_ERROR_CODE;
            sevirity = INFO;
            httpstatusCode = Constants.INTERNAL_SERVER_ERROR_CODE;
            statusDescription = Constants.COI_API_DOWN;
            errorWhileRetrieveInvtAccount(resp, addnStatFail, addnStatFailList);
            
            // errorWhileRetrieveInvtAccount( resp, addnStatFail, addnStatFailList, e);
            customerAccountsUtil.generateCustomPerfLog(context, responseTime, errocode, sevirity, statusDescription,
                    SHAREBUILDER_INVESTING_RESOURCE_URL, httpstatusCode);
        }
        logger.debug("Exit -- getInvestingAccount of CapitalOneInvestingAccountDAOImpl");
        return new AsyncResult<REASResponse>(resp);

    }

    private void errorWhileRetrieveInvtAccount(REASResponse resp, AdditionalStat addnStatFail,
            List<AdditionalStat> addnStatFailList) {
        logger.debug("Enter -- errorWhileRetrieveInvtAccount of CapitalOneInvestingAccountDAOImpl");

        addnStatFail.setNativeErrorCd(Constants.API_COI_ERROR_CODE);
        addnStatFail.setStatDesc(Constants.COI_API_DOWN);
        addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
        addnStatFailList.add(addnStatFail);
        resp.setAddStatList(addnStatFailList);
        resp.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));
        logger.debug("Exit -- errorWhileRetrieveInvtAccount of CapitalOneInvestingAccountDAOImpl");
    }

}
