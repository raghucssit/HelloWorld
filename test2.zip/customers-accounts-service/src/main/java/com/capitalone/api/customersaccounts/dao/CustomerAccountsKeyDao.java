/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.dao;

import java.util.List;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.commons.services.api.HealthCheckableService;
import com.capitalone.api.model.id.CustomerReferenceId;

public interface CustomerAccountsKeyDao extends HealthCheckableService {

    List<CustomerAccountKey> retrieveCustomerAccountsKeyBasedOnProfileReferenceId(
            CustomerAccountsRequest customerAccountsRequest);

    void createCustomerReferenceURL(CustomerReferenceId customerRefID);

    // void ping();
}