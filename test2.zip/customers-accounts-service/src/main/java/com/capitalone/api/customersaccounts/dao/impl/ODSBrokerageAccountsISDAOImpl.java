package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.ODSBrokerageAccountsISDAO;
import com.capitalone.api.customersaccounts.model.v1.CustomerApiErrorCode;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRq;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRs;
import com.capitalone.odsbrokerageaccountsis.v1.ODSBrokerageAccountsISSoap;

@Profile
@Trace
@Named
public class ODSBrokerageAccountsISDAOImpl extends AbstractBaseService implements ODSBrokerageAccountsISDAO {

    @Inject
    private ODSBrokerageAccountsISSoap odsBrokerageAccountsISSoap;

    @Inject
    private ConversionService conversionService;

    /**
     * Getting Brokerage Accounts
     * 
     * @param context holds the request context
     * @param customerAccountsRequest holds the list of card accounts
     * @return list of accounts details
     * 
     */
    @Override
    @Async
    public Future<REASResponse> getBrokerageAccounts(EPFContext context,
            List<CustomerAccountKey> customerAccountsRequest) {
        logger.debug("Enter - getBrokerageAccounts method of ODSBrokerageAccountsISDAOImpl class");

        BalancesInqRq balancesInqRq = conversionService.convert(customerAccountsRequest, BalancesInqRq.class);
        BalancesInqRs balancesInqRs = null;
        REASResponse response = new REASResponse();

        AdditionalStat addnStatFail = new AdditionalStat();
        List<AdditionalStat> addnStatFailList = new ArrayList<AdditionalStat>();

        if (balancesInqRq != null && balancesInqRq.getCmd() != null
                && CollectionUtils.isEmpty(balancesInqRq.getCmd().getAccountsArray())) {
            return null;
        }

        try {
            balancesInqRs = odsBrokerageAccountsISSoap.balancesInq(balancesInqRq);
        } catch (Exception ex) {
            logger.error("Exception while making call to ODSBrokerageAccountsISSoap {}", logger.getClass(), ex);
            addnStatFail.setNativeErrorCd(Constants.ODS_BROKERAGEIS_CONNECT_ERROR);
            addnStatFail.setStatDesc(Constants.ODS_BROKERAGEIS_SERVICE_DOWN_STAT_DESC);
            addnStatFail.setHttpStatus(Constants.INTERNAL_SERVER_ERROR_CODE);
            addnStatFailList.add(addnStatFail);
            response.setAddStatList(addnStatFailList);
            response.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(addnStatFailList));

        }

        if (null != balancesInqRs && null != balancesInqRs.getCmd()) {
            response = conversionService.convert(balancesInqRs, REASResponse.class);
        }
        if (response != null && CollectionUtils.isNotEmpty(response.getCustomerAccountsResponseList())) {

            mapUnreturnedAccounts(response, customerAccountsRequest);
        }

        logger.debug("Exit - getBrokerageAccounts method of ODSBrokerageAccountsISDAOImpl class");
        return new AsyncResult<REASResponse>(response);

    }

    private void mapUnreturnedAccounts(REASResponse response, List<CustomerAccountKey> customerAccountsRequest) {
        logger.debug("Enter - mapUnreturnedAccounts method of ODSBrokerageAccountsISDAOImpl class");
        List<AdditionalStat> stat = new ArrayList<AdditionalStat>();
        AdditionalStat addnStat;
        for (CustomerAccountKey accountKey : customerAccountsRequest) {
            String accountNumber = null;
            for (CustomerAccountsResponse customerAccountsResponse : response.getCustomerAccountsResponseList()) {
                if (customerAccountsResponse.getAccountId().equalsIgnoreCase(
                        StringUtils.stripStart(accountKey.getAccountNumber(), "0"))) {
                    customerAccountsResponse.setAccountId(accountKey.getAccountNumber());
                    customerAccountsResponse.setAccountNumber(accountKey.getAccountNumber());
                    customerAccountsResponse.setDisplayAccountNumber(accountKey.getAccountNumber());
                }
                if (StringUtils
                        .equalsIgnoreCase(accountKey.getAccountNumber(), customerAccountsResponse.getAccountId())) {

                    accountNumber = accountKey.getAccountNumber();
                    break;
                }

            }

            if (accountNumber == null) {
                addnStat = new AdditionalStat();
                addnStat.setNativeErrorCd(Constants.ODS_BROKERAGEIS_PARTIAL_SUCCESS);
                addnStat.setStatDesc(Constants.ODS_BROKERAGEIS_PARTIAL_SUCCESS_MSG.concat(CustomerAccountsUtil
                        .constructAcctSorIDnotfound(accountKey.getAccountNumber(), accountKey.getSorId())));
                addnStat.setHttpStatus(Constants.PARTIAL_SUCCESS_HTTP_CODE);
                addnStat.setAccountId(accountKey.getAccountNumber());
                addnStat.setSorId(String.valueOf(accountKey.getSorId()));

                stat.add(addnStat);
                if (response.getAddStatList() == null) {
                    response.setAddStatList(new ArrayList<AdditionalStat>());
                }
                if (response.getPartialError() == null) {
                    response.setPartialError(new CustomerApiErrorCode());
                }
                response.getAddStatList().add(addnStat);
                response.setPartialError(CustomerAccountsUtil.parseAdditionalStatusToApiException(response
                        .getAddStatList()));
            }
        }
        logger.debug("Exit - mapUnreturnedAccounts method of ODSBrokerageAccountsISDAOImpl class");
    }
}
