package com.capitalone.api.customersaccounts.service.convert.response;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.Instant;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.AcctArray;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Profile
@Trace
@Named
@SuppressWarnings("CPD-START")
public class CCOnLineServicingDLSV3ResponseConverter extends
        ConversionServiceAwareConverter<AcctSumryDLSInqRs, REASResponse> {

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    private Boolean isHighAvailabilityEnabled;

    private Instant validAsOfTimestamp;

    /**
     * Converts nativeResponse to CustomerAccountKey type
     * 
     * @param nativeResponse card account details
     * @return card customer accounts response
     */
    @Override
    public REASResponse convert(AcctSumryDLSInqRs nativeResponse) {

        logger.debug("CCOnLineServicingDLSV3ResponseConverter  : convert -> Start");
        isHighAvailabilityEnabled = null;
        validAsOfTimestamp = null;
        StatType stat = null;
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        if (null != nativeResponse && null != nativeResponse.getCmd()
                && null != nativeResponse.getCmd().getAcctSummary()
                && null != nativeResponse.getCmd().getAcctSummary().getAcctArray()) {
            List<AcctArray> creditCardAcctInfoList = nativeResponse.getCmd().getAcctSummary().getAcctArray();
            setHAModeFields(nativeResponse);
            setCreditCardAcctSummary(customerAccountsResponseList, creditCardAcctInfoList);
        }

        if (null != nativeResponse && null != nativeResponse.getCmd() && null != nativeResponse.getCmd().getStat()) {
            stat = nativeResponse.getCmd().getStat();
        }

        REASResponse reasResponse = new REASResponse();
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);
        reasResponse.setAddStatList(getAdditionalStat(stat));

        logger.debug("CCOnLineServicingDLSV3ResponseConverter  : convert -> End");

        return reasResponse;
    }

    private void setHAModeFields(AcctSumryDLSInqRs nativeResponse) {

        Cmd cmd = nativeResponse.getCmd();
        if ((null != cmd.getStat()) && (Constants.LOOKASIDE_DATA == (int) cmd.getStat().getStatCd())) {
            isHighAvailabilityEnabled = Boolean.TRUE;
            if (null != cmd.getAcctSummary().getParm() && null != cmd.getAcctSummary().getParm().getODSLoadTS()) {
                validAsOfTimestamp = cmd.getAcctSummary().getParm().getODSLoadTS();
            }
        }

    }

    private void setCreditCardAcctSummary(List<CustomerAccountsResponse> customerAccountsResponseList,
            List<AcctArray> creditCardAcctInfoList) {
        logger.debug("Enter - setCreditCardAcctSummary method of CCOnLineServicingDLSV3ResponseConverter class");
        CustomerAccountsResponse responseBean;
        if (null != creditCardAcctInfoList && !creditCardAcctInfoList.isEmpty()) {
            for (AcctArray creditCardAcctInfo : creditCardAcctInfoList) {
                responseBean = new CustomerAccountsResponse();
                responseBean.setIsHighAvailabilityEnabled(isHighAvailabilityEnabled);
                responseBean.setValidAsOfTimestamp(validAsOfTimestamp);
                populateCreditCardAcctSummary(responseBean, customerAccountsResponseList, creditCardAcctInfo);
            }

        }
        logger.debug("Exit - setCreditCardAcctSummary method of CCOnLineServicingDLSV3ResponseConverter class");
    }

    private void populateCreditCardAcctSummary(CustomerAccountsResponse responseBean,
            List<CustomerAccountsResponse> customerAccountsResponseList, AcctArray creditCardAcctInfo) {
        logger.debug("Enter - populateCreditCardAcctSummary method of CCOnLineServicingDLSV3ResponseConverter class");
        if (null != creditCardAcctInfo) {
            if (null != creditCardAcctInfo.getProd() && null != creditCardAcctInfo.getProd().getProdDesc()) {
                responseBean.setProductName(StringEscapeUtils.unescapeJava(creditCardAcctInfo.getProd().getProdDesc()));

            }
            if (creditCardAcctInfo.getCardImage() != null
                    && creditCardAcctInfo.getCardImage().getCardImageCode() != null) {
                responseBean.setProductImageId(creditCardAcctInfo.getCardImage().getCardImageCode());
            }
            responseBean.setProductTypeCode(Constants.CREDIT_CARD_PRODUCT_TYPE_CODE);
            responseBean.setProductTypeDescription(getProductTypeDescription(Constants.CREDIT_CARD_PRODUCT_TYPE_CODE));
            responseBean.setBusinessLine(getBusinessLine(responseBean.getProductTypeCode()));

            String acctPlasticId = creditCardAcctInfo.getCardNum().getAcctPlstcID();

            setAccountNumberDetails(responseBean, acctPlasticId);

            populateCreditCardAcctInfo(responseBean, creditCardAcctInfo);

            populateCreditCardAcctInfoAmtDetails(responseBean, creditCardAcctInfo);

            customerAccountsResponseList.add(responseBean);
        }
        logger.debug("Exit - populateCreditCardAcctSummary method of CCOnLineServicingDLSV3ResponseConverter class");
    }

    private void setAccountNumberDetails(CustomerAccountsResponse responseBean, String acctPlasticId) {
        logger.debug("Enter - setAccountNumberDetails method of CCOnLineServicingDLSV3ResponseConverter class");
        if (StringUtils.isNotBlank(acctPlasticId)) {
            String cardNumberPrefix = "XXXX-XXXX-XXXX-";
            String cardLastfour = acctPlasticId == null || acctPlasticId.length() < 4 ? acctPlasticId : acctPlasticId
                    .substring(acctPlasticId.length() - 4);
            String accountNumber = cardNumberPrefix + cardLastfour;
            responseBean.setAccountNumber(accountNumber);
            responseBean.setDisplayAccountNumber(accountNumber);
            responseBean.setCardFirstSix(acctPlasticId.substring(0, 6));
        }
        logger.debug("Exit - setAccountNumberDetails method of CCOnLineServicingDLSV3ResponseConverter class");
    }

    private void populateCreditCardAcctInfoAmtDetails(CustomerAccountsResponse responseBean,
            AcctArray creditCardAcctInfo) {
        logger.debug("Enter - populateCreditCardAcctInfoAmtDetails method of CCOnLineServicingDLSV3ResponseConverter class");
        if (creditCardAcctInfo.getCrCdAcct() != null) {
            if (creditCardAcctInfo.getCrCdAcct().getCurrOustdMinmPmtDueAmt() != null) {
                responseBean.setPaymentDueAmount(creditCardAcctInfo.getCrCdAcct().getCurrOustdMinmPmtDueAmt());
            }

            if (creditCardAcctInfo.getCrCdAcct().getMinmPmtDueDt() != null) {
                responseBean.setPaymentDueDate(creditCardAcctInfo.getCrCdAcct().getMinmPmtDueDt());
            }
            if (creditCardAcctInfo.getCrCdAcct().getOTBAmt() != null) {
                responseBean.setAvailableBalance(creditCardAcctInfo.getCrCdAcct().getOTBAmt());
            }
        }
        logger.debug("Exit - populateCreditCardAcctInfoAmtDetails method of CCOnLineServicingDLSV3ResponseConverter class");
    }

    private void populateCreditCardAcctInfo(CustomerAccountsResponse responseBean, AcctArray creditCardAcctInfo) {
        logger.debug("Enter - populateCreditCardAcctInfo method of CCOnLineServicingDLSV3ResponseConverter class");
        if (creditCardAcctInfo.getAcct() != null && StringUtils.isNotBlank(creditCardAcctInfo.getAcct().getAcctID())) {
            responseBean.setAccountId(creditCardAcctInfo.getAcct().getAcctID());
        }
        if (creditCardAcctInfo.getSoR() != null
                && StringUtils.isNotBlank(String.valueOf(creditCardAcctInfo.getSoR().getSoRID()))) {
            responseBean.setSorId(creditCardAcctInfo.getSoR().getSoRID().toString());
        }

        setAccountStatus(responseBean, creditCardAcctInfo);

        if (creditCardAcctInfo.getAcct().getOpenDt() != null) {
            responseBean.setOpenDate(creditCardAcctInfo.getAcct().getOpenDt());
        }
        if (creditCardAcctInfo.getAcct().getPresBal() != null) {
            responseBean.setPresentBalance(creditCardAcctInfo.getAcct().getPresBal());
        }
        logger.debug("Exit - populateCreditCardAcctInfo method of CCOnLineServicingDLSV3ResponseConverter class");
    }

    private void setAccountStatus(CustomerAccountsResponse responseBean, AcctArray creditCardAcctInfo) {
        logger.debug("Enter - setAccountStatus method of CCOnLineServicingDLSV3ResponseConverter class");
        if (null != creditCardAcctInfo.getAcct() && creditCardAcctInfo.getAcct().isClsdInd()) {
            responseBean.setAccountStatusDescription(Constants.CARD_STATUS_CLOSED);
        } else if (null != creditCardAcctInfo.getLoanAcct() && creditCardAcctInfo.getLoanAcct().isChrgdOffInd()) {
            responseBean.setAccountStatusDescription(Constants.CARD_STATUS_CHRG_OFF);
        } else {
            responseBean.setAccountStatusDescription(Constants.CARD_STATUS_OPEN);
        }
        logger.debug("Exit - setAccountStatus method of CCOnLineServicingDLSResponseConverter class");
    }

    protected List<AdditionalStat> getAdditionalStat(StatType responseStatus) {

        logger.debug("Enter - getAdditionalStat method of CCOnLineServicingDLSV3ResponseConverter class");
        if (responseStatus == null) {
            return null;
        }

        if (Long.valueOf(responseStatus.getStatCd()) != null) {
            int intStatCode = (int) responseStatus.getStatCd();
            if (responseStatus.getSevrty() != null) {
                switch (responseStatus.getSevrty()) {
                    case ERROR:
                        return getAddnStatCaseError(responseStatus, intStatCode);
                    default:
                        return null;

                }
            }
        }
        logger.debug("Exit - getAdditionalStat method of CCOnLineServicingDLSV3ResponseConverter class");
        return null;
    }

    private List<AdditionalStat> getAddnStatCaseError(StatType responseStatus, int intStatCode) {
        switch (intStatCode) {
            case Constants.NO_RECORDS_MATCH_SELECTION_CRITERIA_2:
                List<AdditionalStat> additionalStatList = customerAccountsUtil.addnStatConverter(
                        responseStatus.getAddnStat(), Constants.SUCCESS_STATUS_CODE);
                if (CollectionUtils.isEmpty(additionalStatList)) {
                    AdditionalStat additionalStat = new AdditionalStat();
                    additionalStat.setNativeErrorCd(String.valueOf(responseStatus.getStatCd()));
                    additionalStat.setStatDesc(responseStatus.getStatDesc());
                    additionalStatList.add(additionalStat);
                }
                return additionalStatList;
                // 200
            case Constants.DATA_LAYER_SERVICE_ERROR:
                return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(),
                        Constants.INTERNAL_SERVER_ERROR_CODE);
                // 500
            case Constants.TS2_GENERAL_ERROR:
                return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(),
                        Constants.INTERNAL_SERVER_ERROR_CODE);
                // 500
            case Constants.ODS_GENERAL_ERROR:
                return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(),
                        Constants.INTERNAL_SERVER_ERROR_CODE);
                // 500
            case Constants.ERR_INVALID_INPUT_CARD:
                return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(),
                        Constants.INTERNAL_SERVER_ERROR_CODE);
                // 500
            case Constants.TRANSACTION_TIMED_OUT_CARD:
                return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(),
                        Constants.INTERNAL_SERVER_ERROR_CODE);
                // 500
            case Constants.SOURCE_ACCOUNT_INVALID:
                return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(),
                        Constants.SUCCESS_STATUS_CODE);
                // 200
            default:
                return null;

        }
    }

    /**
     * @param productTypeCode product Type code
     * @return product Description
     */

    protected String getProductTypeDescription(String productTypeCode) {
        return customerAccountsRefDataBean.getProductTypeDescription(productTypeCode);
    }

    /**
     * @param productTypeDescription product Type code
     * @return product Description
     */

    protected String getBusinessLine(String productTypeCode) {
        return customerAccountsRefDataBean
                .getBusinessLine(productTypeCode, String.valueOf(Constants.CREDIT_CARD_SORID));
    }
}
