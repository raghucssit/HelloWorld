package com.capitalone.api.customersaccounts.dao;

import java.util.concurrent.Future;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.epf.context.model.EPFContext;

public interface ProfileAccountDao {
	Future<REASResponse> retrieve360AccountSummary(
			EPFContext context, CustomerAccountKey customerAccountKey,boolean is360ApiKeyPresent);
}
