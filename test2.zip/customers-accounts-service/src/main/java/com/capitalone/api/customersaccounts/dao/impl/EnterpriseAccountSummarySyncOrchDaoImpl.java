/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.dao.CustomerAccountSummaryDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRq;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRs;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.EnterpriseAccountSummarySyncOrchSSoap;
import com.capitalone.epf.context.model.EPFContext;

/**
 * DAO for retrieving AccountSummary from EnterpriseAccountSummarySyncOrchSSoap
 * 
 */
@Profile
@Trace
@Named
public class EnterpriseAccountSummarySyncOrchDaoImpl extends AbstractBaseService implements CustomerAccountSummaryDao {

    private static final int ACCOUNT_LIMIT = 50;

    @Inject
    private EnterpriseAccountSummarySyncOrchSSoap enterpriseAccountSummarySyncOrchSSoap;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Inject
    private ConversionService conversionService;

    /**
     * Retrieving AccountSummary from EnterpriseAccountSummarySyncOrchSSoap
     * 
     * @param context holds the request context
     * @param customerAccountsRequest holds the input information for REAS
     * @return list of accounts details
     * 
     */

    @Override
    @Async
    public Future<REASResponse> retrieveAccountSummary(EPFContext context,
            CustomerAccountsRequest customerAccountsRequest) {

        logger.debug("Enter - retrieveAccountSummary method of EnterpriseAccountSummarySyncOrchDaoImpl class");

        REASResponse reasResponse = new REASResponse();

        List<List<CustomerAccountKey>> splitAccountKeyList = new ArrayList<List<CustomerAccountKey>>();

        if (customerAccountsRequest.getCustomerAccountKeyList().size() > ACCOUNT_LIMIT) {

            splitAccountKeyList = customerAccountsUtil.split(customerAccountsRequest.getCustomerAccountKeyList(),
                    ACCOUNT_LIMIT);

        } else {
            splitAccountKeyList.add(customerAccountsRequest.getCustomerAccountKeyList());
        }

        for (List<CustomerAccountKey> customerAccounts : splitAccountKeyList) {
            /**
             * Creating a temp request collect due to Split.
             */
            CustomerAccountsRequest spiltRequest = new CustomerAccountsRequest();
            spiltRequest.setCustomerAccountKeyList(customerAccounts);
            spiltRequest.setReasSupportedSORID(customerAccountsRequest.getReasSupportedSORID());
            spiltRequest.setEnableModifiedOrchestrationSwitch(customerAccountsRequest
                    .isEnableModifiedOrchestrationSwitch());
            spiltRequest.setApi360AllowedClient(customerAccountsRequest.isApi360AllowedClient());
            if (customerAccountsRequest.getProfileReferenceId() != null) {
                spiltRequest.setProfileReferenceId(customerAccountsRequest.getProfileReferenceId());
            }

            AcctSummaryInqRq nativeRequest = conversionService.convert(spiltRequest, AcctSummaryInqRq.class);
            if (null != nativeRequest) {
                if (null != nativeRequest.getCmd() && null != nativeRequest.getCmd().getAcctSummaryInputKey()
                        && nativeRequest.getCmd().getAcctSummaryInputKey().getAccountApplicantKey().isEmpty()) {
                    return null;
                }
                if (null != nativeRequest.getHdr()) {
                    nativeRequest.getHdr().setSesnId(null);
                }
            }
            logger.debug("reas calling {}", nativeRequest);
            AcctSummaryInqRs nativeResponse = enterpriseAccountSummarySyncOrchSSoap.acctSummaryInq(nativeRequest);

            constructResponse(reasResponse, nativeResponse);
        }

        logger.debug("Exit - retrieveAccountSummary method of EnterpriseAccountSummarySyncOrchDaoImpl class");
        return new AsyncResult<REASResponse>(reasResponse);
    }

    private void constructResponse(REASResponse reasResponse, AcctSummaryInqRs nativeResponse) {
        REASResponse reasResponseFromBackend;
        /**
         * below code is commented due as this is taken care in the below.
         */
        logger.debug("Enter - constructResponse method of EnterpriseAccountSummarySyncOrchDaoImpl class");
        reasResponseFromBackend = conversionService.convert(nativeResponse, REASResponse.class);

        if (null != reasResponseFromBackend) {
            if (reasResponse.getCustomerAccountsResponseList() == null
                    && reasResponseFromBackend.getCustomerAccountsResponseList() != null) {
                reasResponse.setCustomerAccountsResponseList(reasResponseFromBackend.getCustomerAccountsResponseList());
            } else if (reasResponse.getCustomerAccountsResponseList() != null
                    && reasResponseFromBackend.getCustomerAccountsResponseList() != null) {
                reasResponse.getCustomerAccountsResponseList().addAll(
                        reasResponseFromBackend.getCustomerAccountsResponseList());
            }
            if (reasResponse.getAddStatList() == null && reasResponseFromBackend.getAddStatList() != null) {
                reasResponse.setAddStatList(reasResponseFromBackend.getAddStatList());
            } else if (reasResponse.getAddStatList() != null && reasResponseFromBackend.getAddStatList() != null) {
                reasResponse.getAddStatList().addAll(reasResponseFromBackend.getAddStatList());
            }
        }
        logger.debug("Exit - constructResponse method of EnterpriseAccountSummarySyncOrchDaoImpl class");
    }

}