/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.convert.request;

import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.service.pojo.CustomerInfoBean;
import com.capitalone.profileaccountrelationshipsis.v1.AccountRelationshipRq;

/**
 * This class is the request Converter for ProfileAccountRelationships
 * 
 */

@Profile
@Trace
@Named
public class ProfileAccountRelationshipsISRequestConverter extends
        ConversionServiceAwareConverter<CustomerInfoBean, AccountRelationshipRq> {

    private final static String operationName = "acctRelRqCmd";

    /**
     * Converts custInfoBean to ProfileAccountRelationshipsIS Request
     * 
     * @param custInfoBean customer information
     * @return inputRq for profileIS
     */


    public AccountRelationshipRq convert(CustomerInfoBean custInfoBean) {

        logger.debug("ProfileAccountRelationshipsISRequestConverter  : convert -> Start");
        AccountRelationshipRq acctListInqRq = new AccountRelationshipRq();
        acctListInqRq.setCmd(new AccountRelationshipRq.Cmd());
        acctListInqRq.getCmd().setName(operationName);
        acctListInqRq.getCmd().setAccountNumber(custInfoBean.getAccountNumber());
        logger.debug("ProfileAccountRelationshipsISRequestConverter  : convert -> End");
        return acctListInqRq;
    }

}