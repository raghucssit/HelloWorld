package com.capitalone.api.customersaccounts.dao.impl;

import java.net.URLEncoder;

import javax.inject.Inject;
import javax.inject.Named;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.exception.ApiSystemException;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.model.id.ReferenceId;

/**
 * Provides all functionality needed to marshal and encode a reference ID. This is needed on the client side of a REST
 * operation when the ID in question will be part of a URL (either as a path or a query parameter). Note that this
 * should NOT be used when the ID is part of a message body.
 * 
 * Note that as per ReferenceId standards, the ID will be encrypted prior to encoding but following marshaling
 * 
 */
@Profile
@Trace
@Named
public class ReferenceIdEncoderImpl implements ReferenceIdEncoder {

    @Inject
    private ReferenceId.NpiXmlAdapter adapter;

    /**
     * Converts the given ID to a string, encrypts it, and URL-encodes the result.
     * 
     * @param id The reference id in question
     * @return The encoded ID
     */
    
    
    @Override
    public String encode(ReferenceId id) {
        String encodedValue = null;
        try {
            String encryptedId = adapter.marshal(id);
            encodedValue = URLEncoder.encode(encryptedId, "UTF-8");
        } catch (Exception e) {
            throw new ApiSystemException("Unable to encryot given Id.{} ", e);
        }
        return encodedValue;
    }
}

/*
 * Copyright 2014 Capital One Financial Corporation. All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */