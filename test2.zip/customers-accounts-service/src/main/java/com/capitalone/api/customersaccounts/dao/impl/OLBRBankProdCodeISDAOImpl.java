package com.capitalone.api.customersaccounts.dao.impl;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.ws.soap.SOAPFaultException;

import org.apache.commons.lang.StringUtils;
import org.joda.time.Instant;
import org.springframework.remoting.RemoteAccessException;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.OLBRBankProdCodeISDAO;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;
import com.capitalone.api.customersaccounts.service.pojo.OLBRRefData;
import com.capitalone.olbrbankprodcodeis.v1.OLBRBankProdCodeISSoap;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRq;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRs;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRs.Cmd.RefData;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRs.Cmd.RefData.RefDataValue.Attributes;
import com.capitalone.xmlmsgset._2004._07.eil.HdrType;
import com.capitalone.xmlmsgset._2004._07.eil.SevrtyType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Profile
@Trace
@Named
public class OLBRBankProdCodeISDAOImpl extends AbstractBaseService implements OLBRBankProdCodeISDAO {

    @Inject
    private OLBRBankProdCodeISSoap bankProdCodeISSoap;

    /**
     * Getting Retail Accounts Nickname
     * 
     * @param context holds the request context
     * @param customerAccountsRequest holds the list of card accounts
     * @return list of nickname
     * 
     */

    @Override
    public List<OLBRRefData> getProductInfo() {
        ReferenceDataListInqRq referenceDataListRq = new ReferenceDataListInqRq();
        OLBRRefData olbrRefData = null;
        buildRequest(referenceDataListRq);
        ReferenceDataListInqRs referenceDataListInqRs = null;
        List<OLBRRefData> objList = new ArrayList<OLBRRefData>();
        Map<String, OLBAttributes> map = null;

        try {
            referenceDataListInqRs = bankProdCodeISSoap.referenceDataInq(referenceDataListRq);
            logger.debug("referenceData olbr res {}", referenceDataListInqRs.getCmd().getRefData());
            List<ReferenceDataListInqRs.Cmd.RefData> listRefData = referenceDataListInqRs.getCmd().getRefData();

            if (Constants.SUCCESS_STAT_CD == referenceDataListInqRs.getCmd().getStat().getStatCd()) {

                for (RefData refData : listRefData) {
                    map = new HashMap<String, OLBAttributes>();
                    olbrRefData = new OLBRRefData();
                    olbrRefData.setKey(refData.getRefDataKey());
                    logger.debug("ref data key {}", refData.getRefDataKey());

                    map.put(refData.getRefDataKey(),
                            setProductReferenceData(getData(refData.getRefDataKey(), refData.getRefDataValue()
                                    .getAttributes())));
                    olbrRefData.setAttributes(map);

                    objList.add(olbrRefData);

                }
                // logger.debug("final try obj map {}", objList.get(10).getAttributes());
                // repository.addReferenceDataSource("ProdDesRefData", (ReferenceDataDao<ProdRefData>) data);
            }

        } catch (RemoteAccessException remoteAccessException) {
            errorWhileRetrieveProductInfo(referenceDataListRq, remoteAccessException);
        }

        return objList;
    }

    private void errorWhileRetrieveProductInfo(ReferenceDataListInqRq referenceDataListRq,
            RemoteAccessException remoteAccessException) {
        ReferenceDataListInqRs referenceDataListInqRs;
        referenceDataListInqRs = new ReferenceDataListInqRs();
        referenceDataListInqRs.setHdr(referenceDataListRq.getHdr());
        referenceDataListInqRs.setCmd(new ReferenceDataListInqRs.Cmd());
        referenceDataListInqRs.getCmd().setName(referenceDataListRq.getCmd().getName());
        referenceDataListInqRs.getCmd().setStat(new StatType());
        StatType stat = new StatType();
        if ((remoteAccessException.getCause() != null)
                && (remoteAccessException.getCause() instanceof SOAPFaultException)) {
            soapFaultExpWhileRetrieveProductInfo(remoteAccessException, stat);

        } else if ((remoteAccessException.getCause() != null)
                && (remoteAccessException.getCause().getCause() instanceof java.net.SocketTimeoutException)) {
            stat.setSevrty(SevrtyType.ERROR);
            stat.setStatCd(Constants.TRANSACTION_TIMED_OUT_CARD);
            stat.setStatDesc(Constants.OLBRBankProdCodeIS_TIMEOUT_STAT_DESC);
        } else {
            stat.setSevrty(SevrtyType.ERROR);
            stat.setStatCd(Constants.ERROR_CODE_100);
            stat.setStatDesc(Constants.OLBRBankProdCodeIS_GENERAL_ERROR_DESC);
        }

        referenceDataListInqRs.getCmd().setStat(stat);
    }

    private void soapFaultExpWhileRetrieveProductInfo(RemoteAccessException remoteAccessException, StatType stat) {
        Throwable exceptionCause = remoteAccessException;
        exceptionCause = remoteAccessException.getCause();
        if (((SOAPFaultException) exceptionCause).getFault().getFaultString()
                .contains("DataQuality validation failure")
                || ((SOAPFaultException) exceptionCause).getFault().getFaultString().contains("VALIDATION_FAILURE")) {
            stat.setSevrty(SevrtyType.ERROR);
            stat.setStatCd(Constants.ERROR_CODE_100);
            stat.setStatDesc(Constants.VALIDATION_ERROR_DESC_OLBRBankProdCodeIS);
        } else if (((SOAPFaultException) exceptionCause).getFault().getFaultString().contains("Compilation Errors")
                || remoteAccessException.getCause().getMessage().contains("300:ERR_SYSTEM_NOT_AVAILABLE")) {
            stat.setSevrty(SevrtyType.ERROR);
            stat.setStatCd(Constants.ERR_SYSTEM_NOT_AVAILABLE);
            stat.setStatDesc(Constants.OLBRBankProdCodeIS_ERR_SYSTEM_NOT_AVAILABLE_DESC);
        } else if (((SOAPFaultException) exceptionCause).getFault().getFaultString().contains("SocketTimeoutException")
                || exceptionCause instanceof SocketTimeoutException
                || ((SOAPFaultException) exceptionCause).getFault().getFaultString()
                        .contains("ERR_TRANSACTION_TIMED_OUT")) {
            stat.setSevrty(SevrtyType.ERROR);
            stat.setStatCd(Constants.TRANSACTION_TIMED_OUT_CARD);
            stat.setStatDesc(Constants.OLBRBankProdCodeIS_TIMEOUT_STAT_DESC);
        } else {
            stat.setSevrty(SevrtyType.ERROR);
            stat.setStatCd(Constants.ERROR_CODE_100);
            stat.setStatDesc(Constants.OLBRBankProdCodeIS_GENERAL_ERROR_DESC);
        }
    }

    private void buildRequest(ReferenceDataListInqRq referenceDataListRq) {
        HdrType eilHdr = new HdrType();
        referenceDataListRq.setHdr(eilHdr);
        referenceDataListRq.getHdr().setVers((float) 1.0);
        referenceDataListRq.getHdr().setDestLgclId(Constants.OLBRBankProdCodeIS_REQUEST_DESTLGClID);
        referenceDataListRq.getHdr().setSrcLgclId(Constants.OLBRBankProdCodeIS_REQUEST_SRCLGClID);
        referenceDataListRq.getHdr().setMsgId(Constants.OLBRBankProdCodeIS_REQUEST_MSGID);
        referenceDataListRq.getHdr().setCretTS(Instant.now());
        referenceDataListRq.getHdr().setSesnId(Constants.OLBRBankProdCodeIS_REQUEST_SESNID);
        referenceDataListRq.setCmd(new ReferenceDataListInqRq.Cmd());
        referenceDataListRq.getCmd().setName(Constants.OLBRBankProdCodeIS_REQUEST_CMD_NAME);
    }

    private Map<String, String> getData(String logicalKey, List<Attributes> refDataValueAttributes) {

        // RefDataEntityImpl dataRef = null;
        Map<String, String> refData = new HashMap<String, String>();

        logger.debug("The data ref key{}", logicalKey);
        for (Attributes attribute : refDataValueAttributes) {
            refData.put(attribute.getKey(), attribute.getValue());

            logger.debug("The data ref {} {}", attribute.getKey(), attribute.getValue());
        }

        // dataRef = new RefDataEntityImpl(logicalKey, refData);
        return refData;
    }

    private OLBAttributes setProductReferenceData(Map<String, String> data) {

        OLBAttributes refData = null;
        if (data != null) {
            refData = new OLBAttributes();
            refData.setBillPayAllwdInd(getBooleanValue(data.get(Constants.BILL_PAY_ALLOWED_INDICATOR)));
            if (StringUtils.isNotBlank(data.get(Constants.CASH_EDGE_SEGMENTATION_CODE))) {
                refData.setCeSegmentationCd(data.get(Constants.CASH_EDGE_SEGMENTATION_CODE));
            }
            refData.setCheckCopyRqstAllwdInd(getBooleanValue(data.get(Constants.CHECK_COPY_REQUEST_ALLOWED_INDICATOR)));
            refData.setCheckImgAllwdInd(getBooleanValue(data.get(Constants.CHECK_IMAGE_ALLOWED_INDICATOR)));
            refData.setCheckReorderAllwdInd(getBooleanValue(data.get(Constants.CHECK_REORDER_ALLOWED_INDICATOR)));
            refData.setFundsTrnsfrDstntnAcctInd(getBooleanValue(data.get(Constants.FUNDS_TRANSFER_DEST_ACCT_INDICATOR)));
            refData.setFundsTrnsfrSrcAcctInd(getBooleanValue(data.get(Constants.FUNDS_TRANSFER_SRC_ACCT_INDICATOR)));
            //
            if (StringUtils.isNotBlank(data.get(Constants.OFX_ACCT_CATEGORY_DESC))) {
                refData.setoFXAcctCatgyDesc(data.get(Constants.OFX_ACCT_CATEGORY_DESC));
            }
            refData.setOvrdrftOptInElgblAcctInd(getBooleanValue(data
                    .get(Constants.OVERDRAFT_OPTIN_ELIGIBLE_ACCT_INDICATOR)));
            refData.setPprLssStmtElgblAcctInd(getBooleanValue(data
                    .get(Constants.PAPERLESS_STATEMENT_ELIGIBLE_ACCT_INDICATOR)));
            refData.setRwrdsElgblAcctInd(getBooleanValue(data.get(Constants.REWARDS_ELIGIBLE_ACCT_INDICATOR)));
            if (StringUtils.isNotBlank(data.get(Constants.PRODUCT_NAME))) {
                refData.setProdNm(data.get(Constants.PRODUCT_NAME));
            }
            refData.setStmtCopyRqstAllwdInd(getBooleanValue(data
                    .get(Constants.STATEMENT_COPY_REQUEST_ALLOWED_INDICATOR)));
            refData.setStopPmtRqstAllwdInd(getBooleanValue(data.get(Constants.STOP_PAYMENT_REQUEST_ALLOWED_INDICATOR)));
            refData.setrDCEligibleInd(getBooleanValue(data.get(Constants.RDC_ELIGIBILITY_INDICATOR)));
        }
        return refData;
    }

    private Boolean getBooleanValue(String number) {
        return StringUtils.isNotBlank(number)
                && (StringUtils.equals(number, "1") || StringUtils.equalsIgnoreCase(number, "Y")) ? Boolean.TRUE
                : Boolean.FALSE;
    }

}
