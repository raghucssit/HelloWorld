package com.capitalone.api.customersaccounts.dao;

import java.util.concurrent.Future;
import java.util.Map;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.epf.context.model.EPFContext;

@SuppressWarnings("CPD-START")
public interface XESDDAISV2DAO {
	  Future<REASResponse> getIMAccountDetails(EPFContext context,CustomerAccountKey customerAccountKey,
	          Map<String, Map<String, OLBAttributes>> mapProdDesc);
}
