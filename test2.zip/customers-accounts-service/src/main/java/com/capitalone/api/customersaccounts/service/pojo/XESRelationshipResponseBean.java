package com.capitalone.api.customersaccounts.service.pojo;

public class XESRelationshipResponseBean extends CustomerInfoBean {

    private String custAcctFromRelationshipCd;

    private String fISApplicationSystemCd;

    private String custAcctToRelationshipCd;

    private String errorCd;

    public String getCustAcctFromRelationshipCd() {
        return custAcctFromRelationshipCd;
    }

    public void setCustAcctFromRelationshipCd(String custAcctFromRelationshipCd) {
        this.custAcctFromRelationshipCd = custAcctFromRelationshipCd;
    }

    public String getfISApplicationSystemCd() {
        return fISApplicationSystemCd;
    }

    public void setfISApplicationSystemCd(String fISApplicationSystemCd) {
        this.fISApplicationSystemCd = fISApplicationSystemCd;
    }

    public String getCustAcctToRelationshipCd() {
        return custAcctToRelationshipCd;
    }

    public void setCustAcctToRelationshipCd(String custAcctToRelationshipCd) {
        this.custAcctToRelationshipCd = custAcctToRelationshipCd;
    }

    public String getErrorCd() {
        return errorCd;
    }

    public void setErrorCd(String errorCd) {
        this.errorCd = errorCd;
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
