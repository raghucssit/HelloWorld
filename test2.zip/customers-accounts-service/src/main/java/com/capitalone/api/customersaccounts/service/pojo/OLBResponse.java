package com.capitalone.api.customersaccounts.service.pojo;

public class OLBResponse {

    private String accountId;

    private String sorId;

    private String olbAccountNickname;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

    public String getOlbAccountNickname() {
        return olbAccountNickname;
    }

    public void setOlbAccountNickname(String olbAccountNickname) {
        this.olbAccountNickname = olbAccountNickname;
    }

}
