package com.capitalone.api.customersaccounts.service.pojo;

import java.util.List;

public class OecpPreferResponse {

    private List<AdditionalStat> addStatList = null;

    private String customerId;

    private String accountId;

    private String sorId;

    private String accountNickname;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

    public List<AdditionalStat> getAddStatList() {
        return addStatList;
    }

    public void setAddStatList(List<AdditionalStat> addStatList) {
        this.addStatList = addStatList;
    }

    public String getAccountNickname() {
        return accountNickname;
    }

    public void setAccountNickname(String accountNickname) {
        this.accountNickname = accountNickname;
    }

}
