package com.capitalone.api.customersaccounts.entity;

import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRq;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs;

/**
 * A cacheable entity which extracts the relationship from ECR -
 * ECRCustomerRelationshipsIS:custIdentityMatchedAccountsInq()
 * 
 * @author gut001
 * @since 1.0
 */
public interface ECRCustomerRelationshipsEntity {

    CustIdentityMatchedAccountsInqRs custIdentityMatchedAccountsInq(
            CustIdentityMatchedAccountsInqRq custIdentityMatchedAccountsInqRq, String userId);
}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
