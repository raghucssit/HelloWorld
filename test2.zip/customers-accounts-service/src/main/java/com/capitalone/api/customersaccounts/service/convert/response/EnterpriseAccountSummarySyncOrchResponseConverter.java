/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.convert.response;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.BrokerageAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.CreditCardAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.DepositAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.LoanAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.MortgageAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRs;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

/**
 * This class is the response Converter for REAS
 * 
 */

@Profile
@Trace
@Named
public class EnterpriseAccountSummarySyncOrchResponseConverter extends
        ConversionServiceAwareConverter<AcctSummaryInqRs, REASResponse> {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Resource
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    /**
     * Converts native REAS response to REASResponse type
     * 
     * @param nativeResponse REAS response
     * @return customers accounts response
     */

    @Override
    public REASResponse convert(AcctSummaryInqRs nativeResponse) {

        logger.debug("Enter - convert method of EnterpriseAccountSummarySyncOrchResponseConverter class");

        StatType stat = null;
        AcctSummaryInqRs.Cmd resCmd = null;

        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();

        if (nativeResponse != null) {
            logger.debug("Backend Response : response={}",
                    ToStringBuilder.reflectionToString(nativeResponse, ToStringStyle.MULTI_LINE_STYLE));
            resCmd = nativeResponse.getCmd();

            if (resCmd != null && resCmd.getStat() != null) {
                stat = resCmd.getStat();

                // TODO: checkResponseStatus(stat);

                processNativeResponse(resCmd.getAccountInfo(), customerAccountsResponseList);

            }
        }

        REASResponse reasResponse = new REASResponse();
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);
        reasResponse.setAddStatList(getAdditionalStat(stat));
        logger.debug("Exit - convert method of EnterpriseAccountSummarySyncOrchResponseConverter class");

        return reasResponse;

    }

    /**
     * @param nativeAccountInfo account information
     * @param customerAccountsResponseList list of customers account response
     */

    protected void processNativeResponse(
            com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo nativeAccountInfo,
            List<CustomerAccountsResponse> customerAccountsResponseList) {

        logger.debug("Enter - processNativeResponse method of EnterpriseAccountSummarySyncOrchResponseConverter class");

        if (nativeAccountInfo != null) {
            // Defaulted Currency code to USA in CustomerAccountsResponse
            CustomerAccountsResponse responseBean = null;
            List<DepositAcctInfo> depositAcctInfoList = nativeAccountInfo.getDepositAcctInfo();

            for (DepositAcctInfo depositAcctInfo : depositAcctInfoList) {

                responseBean = new CustomerAccountsResponse();
                processDepositAccount(responseBean, depositAcctInfo);
                customerAccountsResponseList.add(responseBean);
            }

            List<LoanAcctInfo> loanAcctInfoList = nativeAccountInfo.getLoanAcctInfo();
            for (LoanAcctInfo loanAcctInfo : loanAcctInfoList) {
                responseBean = new CustomerAccountsResponse();
                processLoanAccount(responseBean, loanAcctInfo);
                customerAccountsResponseList.add(responseBean);
            }

            List<CreditCardAcctInfo> creditCardAcctInfoList = nativeAccountInfo.getCreditCardAcctInfo();
            for (CreditCardAcctInfo creditCardAcctInfo : creditCardAcctInfoList) {
                responseBean = new CustomerAccountsResponse();
                processCreditCardAccount(responseBean, creditCardAcctInfo);
                customerAccountsResponseList.add(responseBean);
            }

            List<BrokerageAcctInfo> brokerageAcctInfoList = nativeAccountInfo.getBrokerageAcctInfo();
            for (BrokerageAcctInfo brokerageAcctInfo : brokerageAcctInfoList) {
                responseBean = new CustomerAccountsResponse();
                processBrokerageAccount(responseBean, brokerageAcctInfo);
                customerAccountsResponseList.add(responseBean);
            }

            List<MortgageAcctInfo> mortgageAcctInfoList = nativeAccountInfo.getMortgageAcctInfo();
            for (MortgageAcctInfo mortgageAcctInfo : mortgageAcctInfoList) {
                responseBean = new CustomerAccountsResponse();
                processMortgageAccount(responseBean, mortgageAcctInfo);
                customerAccountsResponseList.add(responseBean);
            }
        }
        logger.debug("Exit - processNativeResponse method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    /**
     * @param responseBean reponse bean
     * @param acctInfo account information
     */

    protected void processDepositAccount(CustomerAccountsResponse responseBean, DepositAcctInfo acctInfo) {

        logger.debug("Enter - processDepositAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");

        // String productTypeCode = null;
        // String accountDetailsURL = null;
        String bankNum = null;
        Short soRID = acctInfo.getSoRID();
        String productId = acctInfo.getProdID();
        String productName = acctInfo.getProdDesc();
        String productTypeCode = acctInfo.getProdTypeCd();
        Boolean retirementIndicator = acctInfo.isRtirmntAcctInd();

        populateProductInformation(productId, productName, productTypeCode, retirementIndicator, responseBean,
                String.valueOf(soRID));

        if (StringUtils.isNotBlank(acctInfo.getBankMarketCd())) {
            responseBean.setBankMarketCd(acctInfo.getBankMarketCd());
        }
        bankNum = acctInfo.getBankNum();
        if (StringUtils.isNotBlank(bankNum)) {
            responseBean.setBankNumber(bankNum);
            responseBean.setBankNumberDescription(getBankNumberDescription(bankNum));
        }

        setDepositAccountDetail(responseBean, acctInfo, soRID);
        if (acctInfo.getOpenDt() != null) {
            responseBean.setOpenDate(acctInfo.getOpenDt());
        }
        if (acctInfo.getAvailableBal() != null) {
            responseBean.setAvailableBalance(acctInfo.getAvailableBal());
        }
        if (acctInfo.getCapOneCurrentBal() != null) {
            responseBean.setCurrentBalance(acctInfo.getCapOneCurrentBal());
        }
        logger.debug("Exit - processDepositAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    private void setDepositAccountDetail(CustomerAccountsResponse responseBean, DepositAcctInfo acctInfo, Short soRID) {

        logger.debug("Enter - setDepositAccountDetail method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        if (StringUtils.isNotBlank(acctInfo.getAcctID()) && soRID != null) {
            responseBean.setAccountId(acctInfo.getAcctID());
            responseBean.setSorId(soRID.toString());
        }

        if (StringUtils.isNotBlank(acctInfo.getAcctID())) {
            responseBean.setAccountNumber(acctInfo.getAcctID());
            responseBean.setDisplayAccountNumber(acctInfo.getAcctID());
        }

        if (StringUtils.isNotBlank(acctInfo.getBankAcctStatusDesc())) {
            responseBean.setAccountStatusDescription(acctInfo.getBankAcctStatusDesc());
        }
        if (acctInfo.getAccountPreferenceInfo() != null && acctInfo.getAccountPreferenceInfo().getAcctNknmNm() != null) {
            responseBean.setAccountNickname(acctInfo.getAccountPreferenceInfo().getAcctNknmNm());
        }
        logger.debug("Exit - setDepositAccountDetail method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    /**
     * @param responseBean response bean
     * @param acctInfo account information
     */

    protected void processLoanAccount(CustomerAccountsResponse responseBean, LoanAcctInfo acctInfo) {

        logger.debug("Enter - processLoanAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        String bankNum = null;
        Short soRID = acctInfo.getSoRID();

        String productId = acctInfo.getProdID();
        String productName = acctInfo.getProdDesc();
        String productTypeCode = acctInfo.getProdTypeCd();

        populateProductInformation(productId, productName, productTypeCode, null, responseBean, String.valueOf(soRID));

        bankNum = acctInfo.getBankNum();
        if (StringUtils.isNotBlank(bankNum)) {
            responseBean.setBankNumber(bankNum);
            responseBean.setBankNumberDescription(getBankNumberDescription(bankNum));
        }

        if (StringUtils.isNotBlank(acctInfo.getAcctID())) {
            if (StringUtils.isNotBlank(acctInfo.getLoanSeqNum())) {
                // responseBean.setAccountNumber(acctInfo.getAcctID().concat(acctInfo.getLoanSeqNum()));
                // responseBean.setDisplayAccountNumber(acctInfo.getAcctID().concat(acctInfo.getLoanSeqNum()));
                responseBean.setLoanSeqNum(acctInfo.getLoanSeqNum());
            }
            // else{
            responseBean.setAccountNumber(acctInfo.getAcctID());
            responseBean.setDisplayAccountNumber(acctInfo.getAcctID());
            // }

        }
        updateLoanAccountInfo(responseBean, acctInfo, soRID);

        updateLoanAccountPaymentInfo(responseBean, acctInfo, productTypeCode);
        if (acctInfo.getAppnID() != null) {
            responseBean.setAppnId(acctInfo.getAppnID().toString());
        }
        logger.debug("Exit - processLoanAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    private void updateLoanAccountPaymentInfo(CustomerAccountsResponse responseBean, LoanAcctInfo acctInfo,
            String productTypeCode) {
        logger.debug("Enter - updateLoanAccountPaymentInfo method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        if (Constants.AUTO_LOAN_PRODUCT_CD.equals(productTypeCode) && acctInfo.getCurrAmtDueAmt() != null) {
            responseBean.setPaymentDueAmount(acctInfo.getCurrAmtDueAmt());
        } else if (acctInfo.getNextPaymentAmt() != null) {
            responseBean.setPaymentDueAmount(acctInfo.getNextPaymentAmt());
        }

        if (Constants.AUTO_LOAN_PRODUCT_CD.equals(productTypeCode) && acctInfo.getOldstUnpdPmtDueDt() != null) {
            responseBean.setPaymentDueDate(acctInfo.getOldstUnpdPmtDueDt());
        } else if (acctInfo.getNextPaymentDt() != null) {
            responseBean.setPaymentDueDate(acctInfo.getNextPaymentDt());
        }
        logger.debug("Exit - updateLoanAccountPaymentInfo method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    private void updateLoanAccountInfo(CustomerAccountsResponse responseBean, LoanAcctInfo acctInfo, Short soRID) {
        logger.debug("Enter - updateLoanAccountInfo method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        if (StringUtils.isNotBlank(acctInfo.getAcctID()) && soRID != null) {
            responseBean.setAccountId(acctInfo.getAcctID());
            responseBean.setSorId(soRID.toString());
        }
        if (StringUtils.isNotBlank(acctInfo.getBankAcctStatusDesc())) {
            responseBean.setAccountStatusDescription(acctInfo.getBankAcctStatusDesc());
        }
        if (acctInfo.getAccountPreferenceInfo() != null && acctInfo.getAccountPreferenceInfo().getAcctNknmNm() != null) {
            responseBean.setAccountNickname(acctInfo.getAccountPreferenceInfo().getAcctNknmNm());
        }
        if (acctInfo.getOpenDt() != null) {
            responseBean.setOpenDate(acctInfo.getOpenDt());
        }
        if (acctInfo.getAvailableBal() != null) {
            responseBean.setAvailableBalance(acctInfo.getAvailableBal());
        }
        if (acctInfo.getCurrentBal() != null) {
            responseBean.setCurrentBalance(acctInfo.getCurrentBal());
        }

        if (acctInfo.getPrinBal() != null) {
            responseBean.setCurrentPrincipal(acctInfo.getPrinBal());
        }
        logger.debug("Exit - updateLoanAccountInfo method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    /**
     * @param responseBean response bean
     * @param acctInfo card account information
     */

    protected void processCreditCardAccount(CustomerAccountsResponse responseBean, CreditCardAcctInfo acctInfo) {

        logger.debug("Enter - processCreditCardAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        Short soRID = acctInfo.getSoRID();
        String acctPlasticId = null;

        String productName = acctInfo.getProdDesc();
        String productTypeCode = acctInfo.getProdTypeCd();

        populateProductInformation(null, productName, productTypeCode, null, responseBean, String.valueOf(soRID));

        acctPlasticId = acctInfo.getAcctPlstcID();
        if (StringUtils.isNotBlank(acctPlasticId) && acctPlasticId.length() == 4) {
            String cardNumberPrefix = "XXXX-XXXX-XXXX-";
            String accountNumber = cardNumberPrefix + acctInfo.getAcctPlstcID();
            responseBean.setAccountNumber(accountNumber);
            responseBean.setDisplayAccountNumber(accountNumber);
        }
        if (StringUtils.isNotBlank(acctInfo.getAcctID()) && soRID != null) {
            responseBean.setAccountId(acctInfo.getAcctID());
            responseBean.setSorId(soRID.toString());
        }
        if (acctInfo.getOTBAmt() != null) {
            responseBean.setAvailableBalance(acctInfo.getOTBAmt());
        }
        // Set Account Status
        setCardAccountStatus(responseBean, acctInfo);

        setCardAccountDetails(responseBean, acctInfo);
        logger.debug("Exit - processCreditCardAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    private void setCardAccountDetails(CustomerAccountsResponse responseBean, CreditCardAcctInfo acctInfo) {
        logger.debug("Enter - setCardAccountDetails method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        if (acctInfo.getAccountPreferenceInfo() != null && acctInfo.getAccountPreferenceInfo().getAcctNknmNm() != null) {
            responseBean.setAccountNickname(acctInfo.getAccountPreferenceInfo().getAcctNknmNm());
        }
        if (acctInfo.getOpenDt() != null) {
            responseBean.setOpenDate(acctInfo.getOpenDt());
        }
        if (acctInfo.getPresBal() != null) {
            responseBean.setPresentBalance(acctInfo.getPresBal());
        }

        if (acctInfo.getCurrOutstdMinmPmtDueAmt() != null) {
            responseBean.setPaymentDueAmount(acctInfo.getCurrOutstdMinmPmtDueAmt());
        }

        if (acctInfo.getMinmPmtDueDt() != null) {
            responseBean.setPaymentDueDate(acctInfo.getMinmPmtDueDt());
        }
        if (acctInfo.getCardFirstSix() != null) {
            responseBean.setCardFirstSix(acctInfo.getCardFirstSix());
        }
        if (acctInfo.getCardImageCode() != null && !acctInfo.getCardImageCode().isEmpty()) {
            responseBean.setProductImageId(acctInfo.getCardImageCode());
        }
        logger.debug("Exit - setCardAccountDetails method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    /**
     * @param responseBean response bean
     * @param acctInfo brokerage account information
     */

    protected void processBrokerageAccount(CustomerAccountsResponse responseBean, BrokerageAcctInfo acctInfo) {

        logger.debug("Enter - processBrokerageAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        Short soRID = acctInfo.getSoRID();
        responseBean.setBusinessLine("Brokerage");
        if (StringUtils.isNotBlank(acctInfo.getAcctID())) {
            responseBean.setAccountNumber(acctInfo.getAcctID());
            responseBean.setDisplayAccountNumber(acctInfo.getAcctID());
        }
        if (StringUtils.isNotBlank(acctInfo.getAcctID()) && soRID != null) {
            responseBean.setAccountId(acctInfo.getAcctID());
            responseBean.setSorId(soRID.toString());
        }
        // responseBean.setAccountStatusDesc(acctInfo.getBankAcctStatusDesc());

        if (acctInfo.getAccountPreferenceInfo() != null && acctInfo.getAccountPreferenceInfo().getAcctNknmNm() != null) {
            responseBean.setAccountNickname(acctInfo.getAccountPreferenceInfo().getAcctNknmNm());
        }
        // responseBean.setOpenDate(acctInfo.getOpenDt());
        logger.debug("Exit - processBrokerageAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    /**
     * @param responseBean response bean
     * @param acctInfo Mortgage account information
     */

    protected void processMortgageAccount(CustomerAccountsResponse responseBean, MortgageAcctInfo acctInfo) {

        logger.debug("Enter - processMortgageAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        Short soRID = acctInfo.getSoRID();

        String productId = acctInfo.getProdID();
        String productName = acctInfo.getProdDesc();
        String productTypeCode = acctInfo.getProdTypeCd();
        logger.debug("Inside processMortgageAccount productTypeCode {} ", productTypeCode);

        populateProductInformation(productId, productName, productTypeCode, null, responseBean, soRID);

        // responseBean.setAccountType(acctInfo.getAccountType());
        if (StringUtils.isNotBlank(acctInfo.getAcctID())) {
            responseBean.setAccountNumber(acctInfo.getAcctID());
            responseBean.setDisplayAccountNumber(acctInfo.getAcctID());
        }
        if (StringUtils.isNotBlank(acctInfo.getAcctID())) {
            responseBean.setAccountId(acctInfo.getAcctID());
            responseBean.setSorId(soRID.toString());
        }
        if (StringUtils.isNotBlank(acctInfo.getBankAcctStatusDesc())) {
            responseBean.setAccountStatusDescription(acctInfo.getBankAcctStatusDesc());
        }
        if (StringUtils.isNotBlank(acctInfo.getAcctNknmNm())) {
            responseBean.setAccountNickname(acctInfo.getAcctNknmNm());
        }
        if (acctInfo.getOpenDt() != null) {
            responseBean.setOpenDate(acctInfo.getOpenDt());
        }
        if (acctInfo.getAvailableBal() != null) {
            responseBean.setAvailableBalance(acctInfo.getAvailableBal());
        }
        if (acctInfo.getPrincipalBal() != null) {
            responseBean.setPrincipalBalance(acctInfo.getPrincipalBal());
        }
        logger.debug("Exit - processMortgageAccount method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    /**
     * @param productId Product ID
     * @param productName Product Name
     * @param rProductTypeCode Product Type code
     * @param retirementIndicatorBoolean Retirement indication value
     * @param customerAccountsResponse Response of customers accounts
     * 
     */

    private void populateProductInformation(String productId, String productName, String rProductTypeCode,
            Boolean retirementIndicatorBoolean, CustomerAccountsResponse customerAccountsResponse, String sorID) {

        logger.debug("Enter - populateProductInformation method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        String businessLine = null;
        String productTypeDescription = null;

        String productTypeCode = rProductTypeCode;
        customerAccountsResponse.setProductId(productId);
        customerAccountsResponse.setProductName(productName);

        customerAccountsResponse.setRetirementIndicator(retirementIndicatorBoolean);

        if (StringUtils.isNotBlank(productTypeCode)) {
            productTypeCode = getCOFProductType(productTypeCode);

            customerAccountsResponse.setProductTypeCode(productTypeCode);

            productTypeDescription = getProductTypeDescription(productTypeCode);
            customerAccountsResponse.setProductTypeDescription(productTypeDescription);
            if (productTypeCode != null) {
                businessLine = getBusinessLine(productTypeCode, sorID);
            }
            if (StringUtils.isNotBlank(businessLine)) {
                customerAccountsResponse.setBusinessLine(businessLine);
            }
        }
        logger.debug("Exit - populateProductInformation method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    // Added for HE Product type code
    private void populateProductInformation(String productId, String productName, String rProductTypeCode,
            Boolean retirementIndicatorBoolean, CustomerAccountsResponse customerAccountsResponse, Short soRID) {

        logger.debug("Enter - populateProductInformation method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        String businessLine = null;
        String productTypeDescription = null;
        String productTypeCode = null;

        customerAccountsResponse.setProductId(productId);
        customerAccountsResponse.setProductName(productName);

        customerAccountsResponse.setRetirementIndicator(retirementIndicatorBoolean);

        if (Constants.SORID_HomeEquity.equalsIgnoreCase(soRID.toString())
                && Constants.ProductId_HomeEquity.equalsIgnoreCase(productId)) {

            if (Constants.ProductName_HIL.equalsIgnoreCase(productName)) {
                productTypeCode = Constants.ProductTypeCode_HIL;
            } else if ((Constants.ProductName_HLC.equals(productName))
                    || (Constants.PRODUCTNAME_HOME_EQUITY.equalsIgnoreCase(productName))) {
                productTypeCode = Constants.ProductTypeCode_HLC;
            } else {
                productTypeCode = Constants.ProductTypeCode_LOC;
            }
        } else {
            String otherproductTypeCode = rProductTypeCode;
            productTypeCode = getCOFProductType(otherproductTypeCode);
        }

        logger.debug("Inside populateProductInformation with SOR productTypeCode {} ", productTypeCode);

        customerAccountsResponse.setProductTypeCode(productTypeCode);

        productTypeDescription = getProductTypeDescription(productTypeCode);
        customerAccountsResponse.setProductTypeDescription(productTypeDescription);
        if (productTypeCode != null) {
            businessLine = getBusinessLine(productTypeCode, String.valueOf(soRID));
        }
        if (StringUtils.isNotBlank(businessLine)) {
            customerAccountsResponse.setBusinessLine(businessLine);
        }
        logger.debug("Exit - populateProductInformation method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    // end for HE Product type code

    protected List<AdditionalStat> getAdditionalStat(StatType responseStatus) {

        logger.debug("Enter - getAdditionalStat method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        if (responseStatus == null) {
            return null;
        }
        // I am assuming we will never exceed int range for stat codes
        int intStatCode = (int) responseStatus.getStatCd();
        if (responseStatus.getSevrty() != null) {
            switch (responseStatus.getSevrty()) {
                case WARNING:
                    switch (intStatCode) {
                        case Constants.PARTIAL_SUCCESS:
                            return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(),
                                    Constants.SUCCESS_STATUS_CODE);
                        default:
                            return null;
                    }
                case ERROR:
                    switch (intStatCode) {
                        case Constants.NO_RECORDS_MATCH_SELECTION_CRITERIA_2:
                            return customerAccountsUtil.addnStatConverter(responseStatus.getAddnStat(),
                                    Constants.SUCCESS_STATUS_CODE);
                        default:
                            return null;
                    }
                default:
                    return null;
            }
        }
        logger.debug("Exit - getAdditionalStat method of EnterpriseAccountSummarySyncOrchResponseConverter class");
        return null;
    }

    /**
     * @param productTypeCode Product Type Code
     * @return Product description
     */

    protected String getProductTypeDescription(String productTypeCode) {
        return customerAccountsRefDataBean.getProductTypeDescription(productTypeCode);
    }

    /**
     * @param productType Product Type Code
     * @return Business Line
     */

    protected String getBusinessLine(String productType, String sorID) {
        return customerAccountsRefDataBean.getBusinessLine(productType, sorID);
    }

    /**
     * @param bankNumber Bank Number
     * @return Bank Number Description
     */

    private String getBankNumberDescription(String bankNumber) {
        return customerAccountsRefDataBean.getBankNumberDescription(bankNumber);
    }

    /**
     * This method sets the Account Status for Card Accounts.
     * 
     * @param responseBean Response Bean
     * @param acctInfo Credit card Information
     */

    protected void setCardAccountStatus(CustomerAccountsResponse responseBean, CreditCardAcctInfo acctInfo) {

        logger.debug("Enter - setCardAccountStatus method of EnterpriseAccountSummarySyncOrchResponseConverter class");

        if (acctInfo.isClsdInd() != null && acctInfo.isClsdInd().booleanValue()) {
            responseBean.setAccountStatusDescription(Constants.CARD_STATUS_CLOSED);
        } else if (acctInfo.isChrgdOffInd() != null && acctInfo.isChrgdOffInd().booleanValue()) {
            responseBean.setAccountStatusDescription(Constants.CARD_STATUS_CHRG_OFF);
        } else {
            responseBean.setAccountStatusDescription(Constants.CARD_STATUS_OPEN);
        }
        logger.debug("Exit - setCardAccountStatus method of EnterpriseAccountSummarySyncOrchResponseConverter class");
    }

    /**
     * This method gets the productCd for COF Accounts.
     * 
     * @param productCd Product code
     * @return COF product Type
     */

    protected String getCOFProductType(String productCd) {
        return customerAccountsRefDataBean.getCOFProductType(productCd);
    }

}