/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.service.pojo;

import java.math.BigDecimal;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.joda.time.Instant;

public class CustomerAccountsResponse {

    private String businessLine;

    private String productId;

    // private String productCode;

    private String productName;

    private String productTypeCode;

    private String productTypeDescription;

    private Boolean retirementIndicator;

    // private String productClassCode;

    // private String productClassDescription;

    private String accountNumber;

    private String accountId;

    private String sorId;

    private String displayAccountNumber;

    private String accountStatusDescription;

    private String accountNickname;

    private Instant openDate;

    private Instant closedDate;

    private BigDecimal availableBalance;

    private BigDecimal principalBalance;

    private String customerRole;

    private String relationShip;

    private String bankMarketCd;

    private BigDecimal currentBalance;

    private BigDecimal presentBalance;

    private String currencyCode = "USD";

    private String bankNumber;

    private String bankNumberDescription;

    private BigDecimal paymentDueAmount;

    private Instant paymentDueDate;

    private String cardFirstSix;

    private BigDecimal marketingReferneceNumber;

    private BigDecimal currentPrincipal;

    private String loanSeqNum;

    private String appnId;

    private String productImageId;

    private Boolean isHighAvailabilityEnabled;

    private Instant odsLoadTs;
    
    private Instant validAsOfTimestamp;    
    
    private String coiAccountURL;

    public String getCoiAccountURL() {
        return coiAccountURL;
    }

    public void setCoiAccountURL(String coiAccountURL) {
        this.coiAccountURL = coiAccountURL;
    }

    public String getProductImageId() {
        return productImageId;
    }

    public void setProductImageId(String productImageId) {
        this.productImageId = productImageId;
    }

    public String getAppnId() {
        return appnId;
    }

    public void setAppnId(String appnId) {
        this.appnId = appnId;
    }

    public String getLoanSeqNum() {
        return loanSeqNum;
    }

    public void setLoanSeqNum(String loanSeqNum) {
        this.loanSeqNum = loanSeqNum;
    }

    public BigDecimal getCurrentPrincipal() {
        return currentPrincipal;
    }

    public void setCurrentPrincipal(BigDecimal currentPrincipal) {
        this.currentPrincipal = currentPrincipal;
    }

    public BigDecimal getMarketingReferneceNumber() {
        return marketingReferneceNumber;
    }

    public void setMarketingReferneceNumber(BigDecimal marketingReferneceNumber) {
        this.marketingReferneceNumber = marketingReferneceNumber;
    }

    public String getBusinessLine() {
        return businessLine;
    }

    public void setBusinessLine(String businessLine) {
        this.businessLine = businessLine;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    // public String getProductCode() {
    // return productCode;
    // }
    //
    // public void setProductCode(String productCode) {
    // this.productCode = productCode;
    // }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductTypeCode() {
        return productTypeCode;
    }

    public void setProductTypeCode(String productTypeCode) {
        this.productTypeCode = productTypeCode;
    }

    public String getProductTypeDescription() {
        return productTypeDescription;
    }

    public void setProductTypeDescription(String productTypeDescription) {
        this.productTypeDescription = productTypeDescription;
    }

    // public String getProductClassCode() {
    // return productClassCode;
    // }
    //
    // public void setProductClassCode(String productClassCode) {
    // this.productClassCode = productClassCode;
    // }
    //
    // public String getProductClassDescription() {
    // return productClassDescription;
    // }
    //
    // public void setProductClassDescription(String productClassDescription) {
    // this.productClassDescription = productClassDescription;
    // }

    public Boolean getRetirementIndicator() {
        return retirementIndicator;
    }

    public void setRetirementIndicator(Boolean retirementIndicator) {
        this.retirementIndicator = retirementIndicator;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

    public String getDisplayAccountNumber() {
        return displayAccountNumber;
    }

    public void setDisplayAccountNumber(String displayAccountNumber) {
        this.displayAccountNumber = displayAccountNumber;
    }

    public String getAccountStatusDescription() {
        return accountStatusDescription;
    }

    public void setAccountStatusDescription(String accountStatusDescription) {
        this.accountStatusDescription = accountStatusDescription;
    }

    public String getAccountNickname() {
        return accountNickname;
    }

    public void setAccountNickname(String accountNickname) {
        this.accountNickname = accountNickname;
    }

    public BigDecimal getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(BigDecimal availableBalance) {
        this.availableBalance = availableBalance;
    }

    public BigDecimal getPrincipalBalance() {
        return principalBalance;
    }

    public void setPrincipalBalance(BigDecimal principalBalance) {
        this.principalBalance = principalBalance;
    }

    public String getCustomerRole() {
        return customerRole;
    }

    public void setCustomerRole(String customerRole) {
        this.customerRole = customerRole;
    }

    public String getRelationShip() {
        return relationShip;
    }

    public void setRelationShip(String relationShip) {
        this.relationShip = relationShip;
    }

    public String getBankMarketCd() {
        return bankMarketCd;
    }

    public void setBankMarketCd(String bankMarketCd) {
        this.bankMarketCd = bankMarketCd;
    }

    public BigDecimal getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(BigDecimal currentBalance) {
        this.currentBalance = currentBalance;
    }

    public BigDecimal getPresentBalance() {
        return presentBalance;
    }

    public void setPresentBalance(BigDecimal presentBalance) {
        this.presentBalance = presentBalance;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getBankNumber() {
        return bankNumber;
    }

    public void setBankNumber(String bankNumber) {
        this.bankNumber = bankNumber;
    }

    public String getBankNumberDescription() {
        return bankNumberDescription;
    }

    public void setBankNumberDescription(String bankNumberDescription) {
        this.bankNumberDescription = bankNumberDescription;
    }

    public BigDecimal getPaymentDueAmount() {
        return paymentDueAmount;
    }

    public void setPaymentDueAmount(BigDecimal paymentDueAmount) {
        this.paymentDueAmount = paymentDueAmount;
    }

    public String getCardFirstSix() {
        return cardFirstSix;
    }

    public void setCardFirstSix(String cardFirstSix) {
        this.cardFirstSix = cardFirstSix;
    }

    public Instant getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Instant openDate) {
        this.openDate = openDate;
    }

    public Instant getPaymentDueDate() {
        return paymentDueDate;
    }

    public void setPaymentDueDate(Instant paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object rhs) {
        return EqualsBuilder.reflectionEquals(this, rhs, false);
    }

    public Instant getClosedDate() {
        return closedDate;
    }

    public void setClosedDate(Instant closedDate) {
        this.closedDate = closedDate;
    }

    public Boolean getIsHighAvailabilityEnabled() {
        return isHighAvailabilityEnabled;
    }

    public void setIsHighAvailabilityEnabled(Boolean isHighAvailabilityEnabled) {
        this.isHighAvailabilityEnabled = isHighAvailabilityEnabled;
    }

    public Instant getOdsLoadTs() {
        return odsLoadTs;
    }

    public void setOdsLoadTs(Instant odsLoadTs) {
        this.odsLoadTs = odsLoadTs;
    }

    public Instant getValidAsOfTimestamp() {
        return validAsOfTimestamp;
    }

    public void setValidAsOfTimestamp(Instant validAsOfTimestamp) {
        this.validAsOfTimestamp = validAsOfTimestamp;
    }

}