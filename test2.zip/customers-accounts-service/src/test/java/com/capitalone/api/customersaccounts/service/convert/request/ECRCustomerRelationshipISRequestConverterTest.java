package com.capitalone.api.customersaccounts.service.convert.request;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.model.id.CustomerReferenceId;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRq;
import com.capitalone.ecrcustomerrelationshipsis.v1.RegisteredItem3PartKey;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class ECRCustomerRelationshipISRequestConverterTest {

    private ECRCustomerRelationshipISRequestConverter converter;

    // private final static String CUST_REF_ID = "1234";

    // private EPFContext context;

    private final static ProfileReferenceId profileReferenceId = new ProfileReferenceId("12345");

    private final static CustomerReferenceId customerReferenceId = new CustomerReferenceId("1234");

    @Before
    public void setUp() throws Exception {

        converter = new ECRCustomerRelationshipISRequestConverter();

    }

    @Test
    public final void test_Success_WithProfRefId() {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setProfileReferenceId(profileReferenceId);

        CustIdentityMatchedAccountsInqRq request = converter.convert(customerAccountsRequest);

        assertNotNull(request);
        assertNotNull(request.getCmd());

        assertNotNull(request.getCmd().getECRLookUpKey());
        assertNotNull(request.getCmd().getECRLookUpKey().getRegisteredItem3PartKey());

        RegisteredItem3PartKey key = request.getCmd().getECRLookUpKey().getRegisteredItem3PartKey();

        // assertEquals(String.valueOf(Constants.ECR_REGISTRY_SORID),String.valueOf(key.getRgstryRltnshpAssociationSORID()));
        assertEquals("LGIN", key.getRgstryRltnshpAssociationTypeCd());
        // assertEquals(CUST_REF_ID, key.getRgstryRltnshpID());

    }

    @Test
    public final void test_Success_WithCustRefId() {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setCustomerReferenceId(customerReferenceId);

        CustIdentityMatchedAccountsInqRq request = converter.convert(customerAccountsRequest);

        assertNotNull(request);
        assertNotNull(request.getCmd());

        assertNotNull(request.getCmd().getECRLookUpKey());
        assertNotNull(request.getCmd().getECRLookUpKey().getRegisteredItem3PartKey());

        RegisteredItem3PartKey key = request.getCmd().getECRLookUpKey().getRegisteredItem3PartKey();

    }

    @Test
    public final void test_NullResponse_InProfRefId() {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setProfileReferenceId(null);
        CustIdentityMatchedAccountsInqRq request = converter.convert(customerAccountsRequest);

        assertNotNull(request);
        assertNotNull(request);
        assertNotNull(request.getCmd());
        assertNull(request.getCmd().getECRLookUpKey().getAcct3PartKey());
    }

    @Test
    public final void test_NullResponse_InCustRefId() {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setCustomerReferenceId(null);
        CustIdentityMatchedAccountsInqRq request = converter.convert(customerAccountsRequest);

        assertNotNull(request);
        assertNotNull(request);
        assertNotNull(request.getCmd());
        assertNull(request.getCmd().getECRLookUpKey().getAcct3PartKey());
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */