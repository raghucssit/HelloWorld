package com.capitalone.api.customersaccounts.dao.impl;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.entity.IntProfileAccountEntity;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.EndpointManager;
import com.capitalone.epf.servicelocator.model.EndpointProperties;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class ProfileAccountDaoImplTest {

    @InjectMocks
    private ProfileAccountDaoImpl profiledaoImpl;

    @Mock
    private ConversionService conversionService;

    @Mock
    private Client eapiRestClient;

    @Mock
    private WebTarget target;

    @Mock
    private EndpointManager endpointManager;

    @Mock
    private ReferenceIdEncoder encoder;

    @Mock
    private Builder builder;

    @Mock
    private EPFContext context;

    @Mock
    Response responseObject;

    @Mock
    private CustomerAPIRESTException e;

    @Mock
    private IntProfileAccountEntity intProfileAccountEntity;
    
    @Mock 
    private CustomerAccountsUtil customerAccountsUtil;
    
    private static final String ENTITLED = "entitled";

    @Test
    public void retrieve360AccountSummaryTest() throws InterruptedException, ExecutionException {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "int-profile-accounts-Service",
                null, null);
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);

        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("XXXXXX8912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("185"));
        keyList.add(customerAccountKey);

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setAccountNumber("XXXXXX8912");
        profileAccountDetail.setAvailableBalance(new BigDecimal("1200"));

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("XXXXXX8912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));

        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json; v=3")).thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3")).thenReturn(builder);

        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED))
                .thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                        .header("User-Id", "RTM")).thenReturn(builder);

        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                        .header("User-Id", "RTM").get(ProfileAccountDetail.class)).thenReturn(profileAccountDetail);

        Mockito.when(conversionService.convert(profileAccountDetail, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.setCustomerAccountKeyList(keyList);
        Mockito.when(context.getUserId()).thenReturn("RTM");
        Future<REASResponse> response = profiledaoImpl.retrieve360AccountSummary(context, customerAccountKey,false);
        assertNotNull(response);
        // assertThat(response.get().getCustomerAccountsResponseList().get(0).getAccountNumber(),equalTo("XXXXXX8912"));
        // assertThat(response.get().getAddStatList( ).get(0).getNativeErrorCd(),
        // equalTo(Constants.API_360_ERROR_CODE));
        // assertThat(response.get().getAddStatList().get(0).getStatDesc(), equalTo(Constants.BANK360_API_DOWN +
        // customerAccountKey.getAccountNumber()));
    }

    @Test
    public void retrieve360AccountSummaryTestFail() throws InterruptedException, ExecutionException {
        EndpointProperties endpointProperties = new EndpointProperties(null, null, "int-profile-accounts-Service",
                null, null);
        ProfileAccountDetail profileAccountDetail = null;
        ErrorResponse errorResponse = new ErrorResponse();
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);

        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("XXXXXX8912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("185"));
        keyList.add(customerAccountKey);

        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("XXXXXX8912");
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json; v=3")).thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3")).thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED))
                .thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                        .header("User-Id", "RTM")).thenReturn(builder);

        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                        .header("User-Id", "RTM").header("Api-Key", "MOBILE")).thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                        .header("User-Id", "RTM").header("Api-Key", "MOBILE").get()).thenReturn(
                Response.serverError().build());
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                        .header("User-Id", "RTM").header("Api-Key", "MOBILE").get(ProfileAccountDetail.class))
                .thenReturn(profileAccountDetail);

        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                        .header("User-Id", "RTM").header("Api-Key", "MOBILE").get(ErrorResponse.class)).thenReturn(
                errorResponse);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.setCustomerAccountKeyList(keyList);
        Future<REASResponse> response = profiledaoImpl.retrieve360AccountSummary(context, customerAccountKey,false);
        assertThat(response.get().getAddStatList().get(0).getNativeErrorCd(), equalTo(Constants.API_360_ERROR_CODE));
    }

    @Test
    public void retrieve360AccountSummaryTestApiDown() throws InterruptedException, ExecutionException {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "int-profile-accounts-Service",
                null, null);
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);

        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("XXXXXX8912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("185"));
        keyList.add(customerAccountKey);

        ProfileAccountDetail profileAccountDetail = null;

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("XXXXXX8912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));

        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json; v=3")).thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3")).thenReturn(builder);

        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED))
                .thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                        .header("User-Id", "RTM")).thenReturn(builder);

        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(
                target.request().accept("application/json; v=3")
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                        .header("User-Id", "RTM").get(ProfileAccountDetail.class)).thenReturn(profileAccountDetail);

        Mockito.when(conversionService.convert(profileAccountDetail, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.setCustomerAccountKeyList(keyList);
        Mockito.when(context.getUserId()).thenReturn("RTM");
        Future<REASResponse> response = profiledaoImpl.retrieve360AccountSummary(context, customerAccountKey,false);
        assertThat(response.get().getAddStatList().get(0).getNativeErrorCd(), equalTo(Constants.API_360_ERROR_CODE));
        // assertThat(response.get().getAddStatList().get(0).getStatDesc(), equalTo(Constants.BANK360_API_DOWN +
        // customerAccountKey.getAccountNumber()));
    }

    @Test
    public void retrieve360AccountSummaryTest_Exception() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "int-profile-accounts-Service",
                null, null);
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenThrow(e);

        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("XXXXXX8912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("185"));
        keyList.add(customerAccountKey);

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setAccountNumber("XXXXXX8912");
        profileAccountDetail.setAvailableBalance(new BigDecimal("1200"));

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("XXXXXX8912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));

        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404, errorResponse);

        e1.getErrorResponse().setDeveloperText("");
        e1.getErrorResponse().setId("TestID01");
        e1.getErrorResponse().setText("Text");

        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenThrow(e);

        Mockito.when(conversionService.convert(profileAccountDetail, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        Mockito.when(
                intProfileAccountEntity.retiveAccountDetails(customerAccountKey, context,
                        customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()),false))
                .thenReturn(profileAccountDetail);

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.setCustomerAccountKeyList(keyList);
        Mockito.when(context.getUserId()).thenReturn("RTM");
        Mockito.when(e.getCause()).thenReturn(e1);
        Future<REASResponse> response = profiledaoImpl.retrieve360AccountSummary(context, customerAccountKey,false);
        assertNotNull(response);
    }

    @Test
    public void retrieve360AccountSummaryTest_Exception2() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "int-profile-accounts-Service",
                null, null);
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenThrow(e);

        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("XXXXXX8912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("185"));
        keyList.add(customerAccountKey);

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setAccountNumber("XXXXXX8912");
        profileAccountDetail.setAvailableBalance(new BigDecimal("1200"));

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("XXXXXX8912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));

        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(null, errorResponse);
       // Mockito.when(e.getCause()).thenReturn(e1);
        e1.getErrorResponse().setDeveloperText("");
        // e1.getErrorResponse().setId("TestID01");
        e1.getErrorResponse().setText("Text");

         Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenThrow(e);
        Mockito.when(
                intProfileAccountEntity.retiveAccountDetails(customerAccountKey, context,
                        customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()),false))
                .thenThrow(e);

        Mockito.when(conversionService.convert(profileAccountDetail, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.setCustomerAccountKeyList(keyList);
        Mockito.when(context.getUserId()).thenReturn("RTM");
        // Mockito.when(e.getCause()).thenReturn(e1);
        Future<REASResponse> response = profiledaoImpl.retrieve360AccountSummary(context, customerAccountKey,false);
        assertNotNull(response);
    }
    
    @Test
    public void retrieve360AccountSummaryTest_Exception3() throws Exception {      

        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("XXXXXX8912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("185"));
        keyList.add(customerAccountKey);

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setAccountNumber("XXXXXX8912");
        profileAccountDetail.setAvailableBalance(new BigDecimal("1200"));

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("XXXXXX8912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));

        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(null, errorResponse);
        Mockito.when(e.getCause()).thenReturn(e1);
        e1.getErrorResponse().setDeveloperText("");
        // e1.getErrorResponse().setId("TestID01");
        e1.getErrorResponse().setText("Text");
        
        Mockito.when(
                intProfileAccountEntity.retiveAccountDetails(customerAccountKey, context,
                        customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()),false))
                .thenThrow(e);

        Mockito.when(conversionService.convert(profileAccountDetail, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.setCustomerAccountKeyList(keyList);
       
        Future<REASResponse> response = profiledaoImpl.retrieve360AccountSummary(context, customerAccountKey,false);
        assertNotNull(response);
    }
    
    @Test
    public void retrieve360AccountSummaryTest_Exception4() throws Exception {      

        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("XXXXXX8912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("185"));
        keyList.add(customerAccountKey);

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setAccountNumber("XXXXXX8912");
        profileAccountDetail.setAvailableBalance(new BigDecimal("1200"));

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("XXXXXX8912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));

        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404, errorResponse);
        Mockito.when(e.getCause()).thenReturn(e1);
        e1.getErrorResponse().setDeveloperText("Developer Text");
        e1.getErrorResponse().setId("TestID01");
        e1.getErrorResponse().setText("Text");
        
        Mockito.when(
                intProfileAccountEntity.retiveAccountDetails(customerAccountKey, context,
                        customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()),false))
                .thenThrow(e);

        Mockito.when(conversionService.convert(profileAccountDetail, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.setCustomerAccountKeyList(keyList);
       
        Future<REASResponse> response = profiledaoImpl.retrieve360AccountSummary(context, customerAccountKey,false);
        assertNotNull(response);
    }
}
