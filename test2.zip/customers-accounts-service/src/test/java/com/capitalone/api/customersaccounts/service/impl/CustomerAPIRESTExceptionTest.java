package com.capitalone.api.customersaccounts.service.impl;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CustomerAPIRESTExceptionTest {

    @Test
    public void test_CustomerAPIRESTException() {

        Integer httpStatus = null;

        ErrorResponse errorResponse = null;
        CustomerAPIRESTException custAPIRESTException = new CustomerAPIRESTException(httpStatus, errorResponse);
        custAPIRESTException.getHttpStatus();
        custAPIRESTException.getErrorResponse();
    }

}
