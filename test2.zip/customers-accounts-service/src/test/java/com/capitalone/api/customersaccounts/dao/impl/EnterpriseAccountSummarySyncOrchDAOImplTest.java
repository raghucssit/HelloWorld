package com.capitalone.api.customersaccounts.dao.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.powermock.reflect.Whitebox;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountApplicantKey;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRq;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRq.Cmd;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRq.Cmd.AcctSummaryInputKey;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRs;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.EnterpriseAccountSummarySyncOrchSSoap;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;
import com.capitalone.xmlmsgset._2004._07.eil.HdrType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class EnterpriseAccountSummarySyncOrchDAOImplTest {

    @Mock
    private ConversionService converionService;

    @Mock
    private EnterpriseAccountSummarySyncOrchSSoap enterpriseAccountSummarySyncOrchSSoap;

    EnterpriseAccountSummarySyncOrchDaoImpl dao;

    private EPFContext context;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    /*
     * @Mock private PingService pingService;
     */

    @Before
    public void setUp() throws Exception {
        dao = new EnterpriseAccountSummarySyncOrchDaoImpl();
        // Whitebox.setInternalState(dao, PingService.class, pingService);
        Whitebox.setInternalState(dao, converionService);
        Whitebox.setInternalState(dao, EnterpriseAccountSummarySyncOrchSSoap.class,
                enterpriseAccountSummarySyncOrchSSoap);
        Whitebox.setInternalState(dao, customerAccountsUtil);

        context = new EPFContext();
        EPFContextContainer.getcurrentContext().set(context);
    }

    @Test
    public final void test_retrieveAccountSummary() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        AcctSummaryInqRq nativeReq = new AcctSummaryInqRq();
        nativeReq.setHdr(new HdrType());
        AcctSummaryInqRs nativeRes = new AcctSummaryInqRs();

        REASResponse response = new REASResponse();
        when(converionService.convert(request, AcctSummaryInqRq.class)).thenReturn(nativeReq);
        when(enterpriseAccountSummarySyncOrchSSoap.acctSummaryInq(nativeReq)).thenReturn(nativeRes);
        when(converionService.convert(request, REASResponse.class)).thenReturn(response);
        dao.retrieveAccountSummary(context, request);

    }

    @Test
    public final void test_retrieveAccountSummary1() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        ProfileReferenceId profileReferenceId = new ProfileReferenceId("123454");
        request.setProfileReferenceId(profileReferenceId);
        AcctSummaryInqRq nativeReq = new AcctSummaryInqRq();
        AcctSummaryInqRq.Cmd cmd = new Cmd();
        AcctSummaryInputKey inputKey = new AcctSummaryInputKey();
        AccountApplicantKey applnKey = new AccountApplicantKey();
        inputKey.getAccountApplicantKey().add(applnKey);
        cmd.setAcctSummaryInputKey(inputKey);
        nativeReq.setCmd(cmd);
        nativeReq.setHdr(new HdrType());
        AcctSummaryInqRs nativeRes = new AcctSummaryInqRs();

        REASResponse response = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse custAcctRes = new CustomerAccountsResponse();
        custAcctRes.setAccountId("12345");
        customerAccountsResponseList.add(custAcctRes);
        response.setCustomerAccountsResponseList(customerAccountsResponseList);

        when(converionService.convert(request, AcctSummaryInqRq.class)).thenReturn(nativeReq);
        when(enterpriseAccountSummarySyncOrchSSoap.acctSummaryInq(null)).thenReturn(nativeRes);
        when(converionService.convert(nativeRes, REASResponse.class)).thenReturn(response);
        dao.retrieveAccountSummary(context, request);

    }

    @Test
    public final void test_retrieveAccountSummary_validStat() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        AcctSummaryInqRq nativeReq = new AcctSummaryInqRq();
        AcctSummaryInqRs nativeRes = new AcctSummaryInqRs();
        nativeReq.setHdr(new HdrType());
        nativeRes.setCmd(new AcctSummaryInqRs.Cmd());
        StatType statType = new StatType();
        statType.setStatCd(Constants.PARTIAL_SUCCESS);
        nativeRes.getCmd().setStat(statType);

        REASResponse response = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse custAcctRes = new CustomerAccountsResponse();
        custAcctRes.setAccountId("12345");
        customerAccountsResponseList.add(custAcctRes);
        response.setCustomerAccountsResponseList(customerAccountsResponseList);

        when(converionService.convert(request, AcctSummaryInqRq.class)).thenReturn(nativeReq);
        when(enterpriseAccountSummarySyncOrchSSoap.acctSummaryInq(nativeReq)).thenReturn(nativeRes);

        when(converionService.convert(nativeRes, REASResponse.class)).thenReturn(response);
        dao.retrieveAccountSummary(context, request);

    }

    // @Test
    // public final void test_Ping() {
    // pingService.executePing(Mockito.anyObject(), Mockito.any(Class.class));
    // dao.ping();
    // }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

