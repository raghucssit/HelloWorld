package com.capitalone.api.customersaccounts.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.xestdais.v1.AcctInqISRq;
import com.capitalone.xestdais.v1.AcctInqISRq.Cmd;
import com.capitalone.xestdais.v1.AcctInqISRs;
import com.capitalone.xestdais.v1.AcctInqISRs.Cmd.TimeDepositAcctInq;
import com.capitalone.xestdais.v1.XESTDAISSoap;
import com.capitalone.xmlmsgset._2004._07.eil.SevrtyType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)

public class XESTDAISDAOImplTest {

    @InjectMocks
    private XESTDAISDAOImpl dao;

    @Mock
    private ConversionService conversionService;

    @Mock
    private XESTDAISSoap xestdaisSoap;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;   
    
    @Mock
    private CustomerAccountsUtil customerAccountsUtil; 

    @Test
    public final void getSTAccountDetailsTest() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");

        AcctInqISRq acctInqISRq = new AcctInqISRq();
        acctInqISRq.setCmd(new Cmd());
        AcctInqISRs acctInqISRs = null;
        when(conversionService.convert(key, AcctInqISRq.class)).thenReturn(acctInqISRq);
        when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(response);
        when(xestdaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Future<REASResponse> reasResponse = dao.getSTAccountDetails(null, key);
        assertNotNull(reasResponse);
    }

    @Test
    public final void getSTAccountDetailsTest_success() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345");
        key.setSorId((short) 12);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");

        AcctInqISRq acctInqISRq = new AcctInqISRq();
        acctInqISRq.setCmd(new Cmd());
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd1 = new AcctInqISRs.Cmd();
        TimeDepositAcctInq value = new TimeDepositAcctInq();
        value.setAcctID("12345");
        value.setBankAcctTypeCd("01");
        cmd1.setTimeDepositAcctInq(value);
        acctInqISRs.setCmd(cmd1);
        when(conversionService.convert(key, AcctInqISRq.class)).thenReturn(acctInqISRq);
        when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(response);
        when(xestdaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Future<REASResponse> reasResponse = dao.getSTAccountDetails(null, key);
        assertNotNull(reasResponse);
    }

    @Test
    public final void getSTAccountDetailsTest_Exception() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345");
        key.setSorId((short) 12);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");

        AcctInqISRq acctInqISRq = new AcctInqISRq();
        acctInqISRq.setCmd(new Cmd());
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd1 = new AcctInqISRs.Cmd();
        TimeDepositAcctInq value = new TimeDepositAcctInq();
        value.setAcctID("12345");
        value.setBankAcctTypeCd("01");
        cmd1.setTimeDepositAcctInq(value);
        acctInqISRs.setCmd(cmd1);
        when(conversionService.convert(key, AcctInqISRq.class)).thenReturn(acctInqISRq);
        when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(response);
        // when(xestdaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Exception e = new NullPointerException();
        when(xestdaisSoap.acctInq(acctInqISRq)).thenThrow(e);
        Future<REASResponse> reasResponse = dao.getSTAccountDetails(null, key);
        assertNotNull(reasResponse);
    }

    @Test
    public final void getSTAccountDetailsTest_stat() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345");
        key.setSorId((short) 12);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");

        AcctInqISRq acctInqISRq = new AcctInqISRq();
        acctInqISRq.setCmd(new Cmd());
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd1 = new AcctInqISRs.Cmd();
        TimeDepositAcctInq value = new TimeDepositAcctInq();
        value.setAcctID("12345");
        value.setBankAcctTypeCd("01");
        cmd1.setTimeDepositAcctInq(value);
        StatType stat = new StatType();

        stat.setSevrty(SevrtyType.ERROR);
        stat.setSrvrStatCd("TP2006");
        stat.setStatCd(0);
        cmd1.setStat(stat);
        acctInqISRs.setCmd(cmd1);
        when(conversionService.convert(key, AcctInqISRq.class)).thenReturn(acctInqISRq);
        when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(response);
        when(xestdaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Future<REASResponse> reasResponse = dao.getSTAccountDetails(null, key);
        assertNotNull(reasResponse);
    }

    @Test
    public final void getSTAccountDetailsTest_stat1() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345");
        key.setSorId((short) 12);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");

        AcctInqISRq acctInqISRq = new AcctInqISRq();
        acctInqISRq.setCmd(new Cmd());
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd1 = new AcctInqISRs.Cmd();
        TimeDepositAcctInq value = new TimeDepositAcctInq();
        value.setAcctID("12345");
        value.setBankAcctTypeCd("01");
        cmd1.setTimeDepositAcctInq(value);
        StatType stat = new StatType();

        stat.setSevrty(SevrtyType.ERROR);
        stat.setSrvrStatCd("TP2005");
        stat.setStatCd(100);
        cmd1.setStat(stat);
        acctInqISRs.setCmd(cmd1);
        when(conversionService.convert(key, AcctInqISRq.class)).thenReturn(acctInqISRq);
        when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(response);
        when(xestdaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Future<REASResponse> reasResponse = dao.getSTAccountDetails(null, key);
        assertNotNull(reasResponse);
    }
    
    @Test(expected=NullPointerException.class)
    public final void getSTAccountDetailsTest_exception() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");

        AcctInqISRq acctInqISRq = new AcctInqISRq();
        acctInqISRq.setCmd(new Cmd());
        AcctInqISRs acctInqISRs = null;
        when(conversionService.convert(key, AcctInqISRq.class)).thenReturn(acctInqISRq);
        when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(response);
        /*Short sorID = 12;
        PowerMockito.mockStatic(CustomerAccountsUtil.class);
        when(CustomerAccountsUtil.constructAcctSorIDnotfound("1234", sorID)).thenReturn("Desc");  */
        
        NullPointerException exception = new NullPointerException();
        when(xestdaisSoap.acctInq(acctInqISRq)).thenThrow(exception);
        Future<REASResponse> reasResponse = dao.getSTAccountDetails(null, key);
        assertNotNull(reasResponse);
    }

}
