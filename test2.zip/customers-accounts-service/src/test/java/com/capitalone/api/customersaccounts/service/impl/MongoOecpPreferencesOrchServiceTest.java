package com.capitalone.api.customersaccounts.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.MongoOecpPreferencesDefaultDAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class MongoOecpPreferencesOrchServiceTest {

    @InjectMocks
    private MongoOecpPreferencesOrchService mongoOecpPreferencesOrchService;

    @Mock
    private MongoOecpPreferencesDefaultDAO mongoOecpPreferencesDAO;

    @Mock
    private EPFContext context;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        List<String> acctList = new ArrayList<String>();

        Mockito.when(mongoOecpPreferencesDAO.getCustomSortOrderDetails(customerAccountsRequest, context)).thenReturn(
                new AsyncResult<List<String>>(acctList));
        Future<List<String>> response = mongoOecpPreferencesOrchService.execute(customerAccountsRequest, context);

        assertNotNull(response);

    }

}
