package com.capitalone.api.customersaccounts.service.convert.request;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerInfoBean;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRq;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRq.Cmd.PagingRqInfo;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs.PagingRsInfo;
import com.capitalone.xesrelatedacctis.v1.Cursor;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class XESRelatedAcctISRequestConverterTest {

    private XESRelatedAcctISRequestConverter converter;

    private static final String CUST_ID = "20001";

    private final static String OPERATION_NAME = "acctListInq";

    private final static long RECORD_COUNT = 50;

    private final static long CURSOR_COUNT = 50;

    @Before
    public void setUp() throws Exception {

        converter = new XESRelatedAcctISRequestConverter();
    }

    @Test
    public final void test_success_NullRequest() {
        CustomerInfoBean customerInfo = new CustomerInfoBean();
        AcctListInqRq request = converter.convert(customerInfo);

        assertNull(request);

    }

    @Test
    public final void test_success() {
        CustomerInfoBean customerInfo = new CustomerInfoBean();
        customerInfo.setCustomerId("20001");
        AcctListInqRq previousRequest = new AcctListInqRq();
        previousRequest.setCmd(new AcctListInqRq.Cmd());
        previousRequest.getCmd().setName(OPERATION_NAME);
        // Setting RMCustID
        previousRequest.getCmd().setRMCustID(CUST_ID);
        // Creating PagingRsInfo Type
        previousRequest.getCmd().setPagingRqInfo(new PagingRqInfo());
        previousRequest.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);

        AcctListInqRq request = converter.convert(customerInfo);

        assertNotNull(request);
        assertNotNull(request.getCmd());
        assertEquals(OPERATION_NAME, request.getCmd().getName());
        assertEquals(CUST_ID, request.getCmd().getRMCustID());
        assertNotNull(request.getCmd().getPagingRqInfo());
        assertEquals(RECORD_COUNT, request.getCmd().getPagingRqInfo().getRecordControlReturnRecordCnt());
    }

    @Test
    public final void test_Failure() {
        CustomerInfoBean customerInfo = new CustomerInfoBean();
        AcctListInqRq request = converter.convert(customerInfo);

        assertNull(request);

    }

    @Test
    public final void test_valid_pagingInfo() {
        CustomerInfoBean customerInfo = new CustomerInfoBean();
        customerInfo.setCustomerId("234");
        AcctListInqRq previousRequest = new AcctListInqRq();
        previousRequest.setCmd(new AcctListInqRq.Cmd());
        previousRequest.getCmd().setName(OPERATION_NAME);
        // Setting RMCustID
        previousRequest.getCmd().setRMCustID(CUST_ID);
        // Creating PagingRsInfo Type
        PagingRsInfo pagingRsInfo = new PagingRsInfo();
        Cursor cursor = new Cursor();
        cursor.setBinLength(CURSOR_COUNT);
        pagingRsInfo.setCursor(cursor);
        previousRequest.getCmd().setPagingRqInfo(new PagingRqInfo());
        previousRequest.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);

        AcctListInqRq request = converter.convert(customerInfo);

        assertNotNull(request);
        assertNotNull(request.getCmd());
        assertNotNull(request.getCmd().getPagingRqInfo());
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
