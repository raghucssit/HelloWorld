package com.capitalone.api.customersaccounts.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
 
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.Response;

import org.apache.commons.configuration.Configuration;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.entity.LoansAutoLoansEntity;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class AutoLoansAccountsDaoImplTest {

    @InjectMocks
    private AutoLoansAccountsDaoImpl daoImpl;

    @Mock
    private Client eapiRestClient;

    @Mock
    private LoansAutoLoansEntity autoLoansEntity;

    @Mock
    private AutoLoanAccount autoLoanAccount;

    @Mock
    private ConversionService conversionService;
    
    @Mock
    private EPFContext context;

    @Mock
    private Configuration config;

    @Mock
    private Response response;
    
    @Mock
    private CustomerAPIRESTException e;

    @Test
    public void testGetAccountNickName() throws Exception {

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");

        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
        // ProfileReferenceId profRefId = new ProfileReferenceId("");

        Mockito.when(autoLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56", "132"))
                .thenReturn(autoLoanAccount);
        // Mockito.when(response.readEntity(AutoLoanAccount.class)).thenReturn(autoLoanAccount);
        Mockito.when(conversionService.convert(null, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        Future<REASResponse> daoResponse = daoImpl.getCOAFAccounts(context, customerAccountKey, "123");
        assertNotNull(daoResponse);
    }

    @Test
    public void testGetAccountNickNameFail() throws Exception {
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        AutoLoanAccount autoLoanAccount = null;

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
        // ProfileReferenceId profRefId = new ProfileReferenceId("");
        when(autoLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56", "")).thenReturn(
                autoLoanAccount);

        Future<REASResponse> response = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }

    @Test
    public void testAutoLoanAcctNull() throws Exception {
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");

        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);        

        when(autoLoansEntity.retiveAccountDetails(customerAccountKey, context,
                customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()), "")).thenReturn(
                autoLoanAccount);
        Mockito.when(conversionService.convert(autoLoanAccount, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        Future<REASResponse> response = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);

    }

    @Test
    public void testGetAccountNickName_Exception() throws Exception {

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        AutoLoanAccount autoLoanAccount = null;
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
   
        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404, errorResponse);

        e1.getErrorResponse().setDeveloperText("");
        e1.getErrorResponse().setId("TestID01");
        e1.getErrorResponse().setText("Text");

        when(autoLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56", "")).thenReturn(
                autoLoanAccount);
        Mockito.when(conversionService.convert(autoLoanAccount, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);     

        Future<REASResponse> response = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }

    @Test
    public void testGetAccountNickName_Exception1() throws Exception {

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");

        AutoLoanAccount autoLoanAccount = null;
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
       
        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(0, errorResponse);

        e1.getErrorResponse().setDeveloperText("TestDeveloper Text");
        e1.getErrorResponse().setId("");

        when(autoLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56", "")).thenReturn(
                autoLoanAccount);
        Mockito.when(conversionService.convert(autoLoanAccount, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);      

        Future<REASResponse> response = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }

    @Test
    public void testGetAccountNickName_Exception2() throws Exception {
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");

        AutoLoanAccount autoLoanAccount = null;
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);        

        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404, errorResponse);

        e1.getErrorResponse().setDeveloperText("TestDeveloper Text");
        e1.getErrorResponse().setId("TestID01");

        when(autoLoansEntity.retiveAccountDetails(customerAccountKey, context,
                customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()), "")).thenReturn(
                autoLoanAccount);
        Mockito.when(conversionService.convert(autoLoanAccount, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        Future<REASResponse> response = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }

    @Test
    public void testGetAccountNickName_Exception3() throws Exception {

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        AutoLoanAccount autoLoanAccount = null;
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(null,errorResponse);
        Mockito.when(e.getCause()).thenReturn(e1);
        e1.getErrorResponse().setDeveloperText("");   
        //e1.getErrorResponse().setId("TestID01");       
        e1.getErrorResponse().setText("Text");
        Mockito.when(
                autoLoansEntity.retiveAccountDetails(customerAccountKey, context,
                        customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()), ""))
                .thenThrow(e);

        Mockito.when(conversionService.convert(autoLoanAccount, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);        

        Future<REASResponse> response = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }
    
    @Test
    public void testGetAccountNickName_Exception4() throws Exception {

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        AutoLoanAccount autoLoanAccount = null;
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404,errorResponse);
        Mockito.when(e.getCause()).thenReturn(e1);
        e1.getErrorResponse().setDeveloperText("Dev");   
        e1.getErrorResponse().setId("TestID01");       
        e1.getErrorResponse().setText("Text");
        Mockito.when(
                autoLoansEntity.retiveAccountDetails(customerAccountKey, context,
                        customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()), ""))
                .thenThrow(e);

        Mockito.when(conversionService.convert(autoLoanAccount, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);        

        Future<REASResponse> response = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }
    
    @Test
    public void testGetAccountNickName_Exception5() throws Exception {

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        AutoLoanAccount autoLoanAccount = null;
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);           
        
        Mockito.when(
                autoLoansEntity.retiveAccountDetails(customerAccountKey, context,
                        customerAccountKey.getAccountNumber(), String.valueOf(customerAccountKey.getSorId()), ""))
                .thenThrow(e);

        Mockito.when(conversionService.convert(autoLoanAccount, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);         

        Future<REASResponse> response = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }

}
