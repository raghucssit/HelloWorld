package com.capitalone.api.customersaccounts.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.ProfileAccountRelationshipsDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class ProfileAccountsOrchServiceTest {

    private ProfileAccountsOrchService service;

    @Mock
    private ProfileAccountRelationshipsDao dao;

    @Before
    public void setUp() {
        service = new ProfileAccountsOrchService();
        Whitebox.setInternalState(service, dao);
    }

    @Test
    public void testExecute() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        ProfileRelationshipLookup response = new ProfileRelationshipLookup();
        Future<ProfileRelationshipLookup> result = new AsyncResult<ProfileRelationshipLookup>(response);

        key.setSorId((short) 185);
        key.setAccountNumber("1244");
        key.setConsumerId("123");
        customerAccountKeyList.add(key);
        when(
                dao.retrieve((EPFContext) Mockito.anyObject(), Mockito.anyString(), Mockito.anyString(),
                        Mockito.anyString())).thenReturn(result);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        service.execute(request, null);
    }

    @Test
    public void testExecute_1() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        ProfileRelationshipLookup response = new ProfileRelationshipLookup();
        Future<ProfileRelationshipLookup> result = new AsyncResult<ProfileRelationshipLookup>(response);

        key.setSorId((short) 7);
        key.setAccountNumber("1244");
        key.setConsumerId("123");
        customerAccountKeyList.add(key);
        when(
                dao.retrieve((EPFContext) Mockito.anyObject(), Mockito.anyString(), Mockito.anyString(),
                        Mockito.anyString())).thenReturn(result);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        service.execute(request, null);
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
