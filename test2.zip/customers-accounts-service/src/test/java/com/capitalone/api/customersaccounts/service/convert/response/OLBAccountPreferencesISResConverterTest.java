package com.capitalone.api.customersaccounts.service.convert.response;

import java.util.List;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferenceInfo;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRs;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRs.Cmd;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class OLBAccountPreferencesISResConverterTest {

    @InjectMocks
    private OLBAccountPreferencesISResConverter accountPreferencesISResConverter;

    @Test
    public void testConvert() {
        AccountPreferencesInqRs nativeResponse = new AccountPreferencesInqRs();
        Cmd cmd = new Cmd();
        AccountPreferenceInfo accountPreferenceInfo = new AccountPreferenceInfo();
        accountPreferenceInfo.setAcctID("12345678912");
        accountPreferenceInfo.setAcctNknmNm("OLBR Account Nickname");
        accountPreferenceInfo.setSoRID((short) 7);
        cmd.getAccountPreferenceInfo().add(accountPreferenceInfo);
        nativeResponse.setCmd(cmd);
        List<OLBResponse> olbResponses = accountPreferencesISResConverter.convert(nativeResponse);
        assertThat(olbResponses.get(0).getAccountId(), is("12345678912"));
        assertThat(olbResponses.get(0).getOlbAccountNickname(), is("OLBR Account Nickname"));
        assertThat(olbResponses.get(0).getSorId(), equalTo("7"));
    }
}
