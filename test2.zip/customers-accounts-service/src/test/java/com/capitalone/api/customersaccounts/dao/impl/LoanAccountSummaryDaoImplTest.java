package com.capitalone.api.customersaccounts.dao.impl;

import static org.junit.Assert.assertNotNull;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.xesloanacctis.v1.AcctInqISRq;
import com.capitalone.xesloanacctis.v1.AcctInqISRs;
import com.capitalone.xesloanacctis.v1.AcctInqISRs.Cmd.LoanAcctInfo;
import com.capitalone.xesloanacctis.v1.XESLoanAcctISSoap;
import com.capitalone.xmlmsgset._2004._07.eil.SevrtyType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@RunWith(MockitoJUnitRunner.class)
public class LoanAccountSummaryDaoImplTest {

    @Mock
    private XESLoanAcctISSoap xesLoanAcctISSoap;

    @Mock
    private ConversionService conversionService;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @InjectMocks
    private LoanAccountSummaryDaoImpl dao;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testRetrieveLoanAccountummary() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("38"));
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setAcctID("1234");
        loanAcctInfo.setBankAcctTypeCd("LOC");
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqISRs.setCmd(cmd);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("38");

        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);

        Mockito.when(xesLoanAcctISSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getLoanAcctInfo().getBankAcctTypeCd())).thenReturn("123");
        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = dao.retrieveLoanAccountummary(context, customerAccountKey);
        assertNotNull(result);
    }

    @Test
    public void testRetrieveLoanAccountummary_Exception() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("38"));
        customerAccountKey.setAccountNumber("1234567");
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setAcctID("1234");
        loanAcctInfo.setBankAcctTypeCd("LOC");
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqISRs.setCmd(cmd);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("38");

        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);
        NullPointerException e = new NullPointerException();
        Mockito.when(xesLoanAcctISSoap.acctInq(acctInqISRq)).thenThrow(e);
        Future<REASResponse> result = dao.retrieveLoanAccountummary(context, customerAccountKey);
        assertNotNull(result);        
    }

    @Test
    public void testRetrieveLoanAccountummary_SevrtyTypeERROR() throws InterruptedException, ExecutionException {
        //EPFContext context = new EPFContext();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("38"));
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setAcctID("1234");
        loanAcctInfo.setBankAcctTypeCd("LOC");
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqISRs.setCmd(cmd);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("38");

        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);

        Mockito.when(xesLoanAcctISSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getLoanAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        StatType stat = new StatType();

        stat.setSevrty(SevrtyType.ERROR);
        stat.setSrvrStatCd("");
        stat.setStatCd(0);
        acctInqISRs.getCmd().setStat(stat);
        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
//        Future<REASResponse> result = dao.retrieveLoanAccountummary(context, customerAccountKey);
//        assertNotNull(result);

    }

    @Test
    public void testRetrieveLoanAccountummary_SevrtyTypeINFO() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("38"));
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setAcctID("1234");
        loanAcctInfo.setBankAcctTypeCd("LOC");
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqISRs.setCmd(cmd);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("38");

        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);

        Mockito.when(xesLoanAcctISSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getLoanAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        StatType stat = new StatType();

        stat.setSevrty(SevrtyType.INFO);
        stat.setSrvrStatCd("");
        stat.setStatCd(0);
        acctInqISRs.getCmd().setStat(stat);
        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = dao.retrieveLoanAccountummary(context, customerAccountKey);
        assertNotNull(result);

    }

    @Test
    public void testRetrieveLoanAccountummary_SevrtyTypeDEFAULT() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("38"));
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setAcctID("1234");
        loanAcctInfo.setBankAcctTypeCd("LOC");
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqISRs.setCmd(cmd);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("38");

        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);

        Mockito.when(xesLoanAcctISSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getLoanAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        StatType stat = new StatType();

        // stat.setSevrty(SevrtyType.INFO);
        stat.setSrvrStatCd("");
        stat.setStatCd(0);
        acctInqISRs.getCmd().setStat(stat);
        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = dao.retrieveLoanAccountummary(context, customerAccountKey);
        assertNotNull(result);

    }

    @Test
    public void testRetrieveLoanAccountummary_StatCodeNull() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("38"));
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setAcctID("1234");
        loanAcctInfo.setBankAcctTypeCd("LOC");
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqISRs.setCmd(cmd);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("38");

        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);

        Mockito.when(xesLoanAcctISSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getLoanAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        StatType stat = new StatType();
        stat.setStatCd(100);
        stat.setSevrty(SevrtyType.ERROR);
        stat.setSrvrStatCd("");
        acctInqISRs.getCmd().setStat(stat);
        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = dao.retrieveLoanAccountummary(context, customerAccountKey);
        assertNotNull(result);

    }
    
    @Test    
    public void testRetrieveLoanAccountummary_StatCode_500_caseDefault() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("38"));
        customerAccountKey.setAccountNumber("1234567");
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setAcctID("1234");
        loanAcctInfo.setBankAcctTypeCd("LOC");
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqISRs.setCmd(cmd);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("38");

        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);

        Mockito.when(xesLoanAcctISSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getLoanAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        StatType stat = new StatType();
        stat.setStatCd(500);
        stat.setSevrty(SevrtyType.WARNING);
        stat.setSrvrStatCd("");
        acctInqISRs.getCmd().setStat(stat);
        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = dao.retrieveLoanAccountummary(context, customerAccountKey);
        assertNotNull(result);

    }
    
    @Test
    public void testRetrieveLoanAccountummary_StatCode_600() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("38"));
        customerAccountKey.setAccountNumber("XXXXXX8912");
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setAcctID("1234");
        loanAcctInfo.setBankAcctTypeCd("LOC");
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqISRs.setCmd(cmd);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("38");

        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);

        Mockito.when(xesLoanAcctISSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getLoanAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        StatType stat = new StatType();
        stat.setStatCd(600);
        stat.setStatDesc("desc");
        stat.setSevrty(SevrtyType.ERROR);
        stat.setSrvrStatCd("");
        acctInqISRs.getCmd().setStat(stat);
        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = dao.retrieveLoanAccountummary(context, customerAccountKey);
        assertNotNull(result);

    }

}
