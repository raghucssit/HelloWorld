package com.capitalone.api.customersaccounts.service.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.XESDDAISDAO;
import com.capitalone.api.customersaccounts.dao.XESDDAISV2DAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class XESDDAISOrchServiceTest {

    @InjectMocks
    private XESDDAISOrchService service;

    @Mock
    private XESDDAISDAO dao;
    
    @Mock
    private XESDDAISV2DAO daoV2;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;
    
    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {
        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("123456");
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> list = new ArrayList<String>();
        list.add("V3");
        list.add("V4");
        customerAccountsRequest.setEnableXESDDAISCache(list);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("19");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("123456");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Retail");
        customerAccountsResponse.setSorId("12");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);

        EPFContext context = EPFContextContainer.getContext();

        Mockito.when(dao.getIMAccountDetails(context, key,null)).thenReturn(new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge(reasResponse, reasResponse)).thenReturn(reasResponse);

        response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);
    }

    @Test
    public void testExecute_SorId_12() throws InterruptedException, ExecutionException {
        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("123456");
        Short sorId = 16;
        key.setSorId(sorId);
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> list = new ArrayList<String>();
        list.add("V3");
        list.add("V4");
        customerAccountsRequest.setEnableXESDDAISCache(list);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("13");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("123456");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Retail");
        customerAccountsResponse.setSorId("16");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);

        EPFContext context = EPFContextContainer.getContext();

        Mockito.when(dao.getIMAccountDetails(context, key,null)).thenReturn(new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge(reasResponse, reasResponse)).thenReturn(reasResponse);

        response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);

    }

    @Test
    public void testExecute_ReasSupportedSORID() throws InterruptedException, ExecutionException {
        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("123456");
        Short sorId = 12;
        key.setSorId(sorId);
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> list = new ArrayList<String>();
        list.add("V3");
        list.add("V4");
        customerAccountsRequest.setEnableXESDDAISCache(list);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("17");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("123456");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Retail");
        customerAccountsResponse.setSorId("12");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);

        EPFContext context = EPFContextContainer.getContext();

        Mockito.when(dao.getIMAccountDetails(context, key,null)).thenReturn(new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge(reasResponse, reasResponse)).thenReturn(reasResponse);

        response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);

    }

    @Test
    public void testExecute_Null_Request() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = null;
        Future<REASResponse> response = service.execute(customerAccountsRequest, null);
        assertNotNull(response);
    }

    @Test
    public void testExecute_Null_ReasSupportedSORID() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();

        List<String> reasSupportedSORID = null;
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        Future<REASResponse> response = service.execute(customerAccountsRequest, null);
        assertNotNull(response);
    }

    @Test
    public void testExecute_SORID_IM() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();

        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("16");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);
        List<String> list = new ArrayList<String>();
        list.add("V3");
        list.add("V4");
        customerAccountsRequest.setEnableXESDDAISCache(list);

        Future<REASResponse> response = service.execute(customerAccountsRequest, null);
        assertNotNull(response);
    }
        

}
