package com.capitalone.api.customersaccounts.service.impl;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccount;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsOrchResponse;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class FetchLightWeightECROrchServiceTest {

    @InjectMocks
    private FetchLightWeightECROrchService fetchLightWeightECROrchService;

    @Mock
    private CustomerAccountsRefDataBean refDataBean;

    @Mock
    private CustomerAccountsOrchService accountsOrchService;
    
    @Mock
    private CustomerAccountsAggregationService customerAccountsAggregationService;

    @Test
    public void testFetchLightWeightECRKeyBasedOnResponseListContent() {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("PER");
        customerAccountKey.setConsumerId("46540403");
        customerAccountKey.setSorId((short) 185);
        List<CustomerAccountKey> listCustomerAccountKey = new ArrayList<CustomerAccountKey>();
        listCustomerAccountKey.add(customerAccountKey);
        CustomerAccountsOrchResponse accountsOrchResponse = new CustomerAccountsOrchResponse();

        List<String> selectOptionList = new ArrayList<String>();
        selectOptionList.add("businessLine");
        selectOptionList.add("accountReferenceId");
        selectOptionList.add("accountNumber");
        selectOptionList.add("bankNumber");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setCustomerAccountKeyList(listCustomerAccountKey);

        REASResponse reasResponse = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setProductTypeCode("ILA");
        List<CustomerAccountsResponse> listCustomerAccountResponse = new ArrayList<CustomerAccountsResponse>();
        listCustomerAccountResponse.add(customerAccountsResponse);
        reasResponse.setCustomerAccountsResponseList(listCustomerAccountResponse);
        accountsOrchResponse.setFutureProfileCustomerAccountsResponse(new AsyncResult<REASResponse>(reasResponse));
        Mockito.when(refDataBean.getBusinessLineBasedOnSORID("185", "ILA")).thenReturn("LOANS");
        Mockito.when(refDataBean.getBankNumberFromSorId("185")).thenReturn("81");
        Mockito.when(accountsOrchService.execute(customerAccountsRequest)).thenReturn(accountsOrchResponse);
        Mockito.when(customerAccountsAggregationService.execute(accountsOrchResponse,false,false,null)).thenReturn(reasResponse);
        List<CustomerAccount> response = fetchLightWeightECROrchService
                .fetchLightWeightECRKeyBasedOnResponseListContent(customerAccountsRequest, selectOptionList);

        assertThat(response.get(0).getAccountNumber(), equalTo("12345678912"));
        assertThat(response.get(0).getAccountReferenceId().getField("accountId"), equalTo("12345678912"));

    }
}
