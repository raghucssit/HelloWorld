package com.capitalone.api.customersaccounts.dao.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.impl.OLBRBankProdCodeISOrchService;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;
import com.capitalone.api.customersaccounts.service.pojo.OLBRRefData;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class OLBRBankProductDesRefDataTest {
    
    @InjectMocks
    private OLBRBankProductDesRefData olbrRBankProductDesRefData;
    
    @Mock
    private OLBRBankProdCodeISOrchService olbrBankProdCodeISOrchService;
    
    @Test
    public void test_getCategory() throws Exception {
        String categoryName = null;
        int categoryVersion = 0;
        Object resp = olbrRBankProductDesRefData.getCategory(categoryName, categoryVersion);
        assertNotNull(resp);
    }
    
    @Test
    public void test_getCategory1() throws Exception {
        String categoryName = null;
        int categoryVersion = 0;
        List<OLBRRefData> refDataList = new ArrayList<OLBRRefData>();
        OLBRRefData refData = new OLBRRefData();
        refData.setKey("key");
        Map<String, OLBAttributes> attributes = new HashMap<String, OLBAttributes>();
        OLBAttributes olbAttr = new OLBAttributes();
        olbAttr.setProdNm("prodNm");
        attributes.put("key1", olbAttr);
        refData.setAttributes(attributes );
        refDataList.add(refData );
        Mockito.when(olbrBankProdCodeISOrchService.execute()).thenReturn(refDataList);
        Object resp = olbrRBankProductDesRefData.getCategory(categoryName, categoryVersion);
        assertNotNull(resp);
    }

}
