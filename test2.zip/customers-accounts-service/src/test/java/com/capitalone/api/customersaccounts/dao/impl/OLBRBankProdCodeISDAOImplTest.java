package com.capitalone.api.customersaccounts.dao.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import javax.xml.soap.SOAPFault;
import javax.xml.ws.soap.SOAPFaultException;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.remoting.RemoteAccessException;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.OLBRRefData;
import com.capitalone.olbrbankprodcodeis.v1.OLBRBankProdCodeISSoap;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRq;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRs;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRs.Cmd;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRs.Cmd.RefData;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRs.Cmd.RefData.RefDataValue;
import com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRs.Cmd.RefData.RefDataValue.Attributes;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Category(UnitTest.class)
// @RunWith(MockitoJUnitRunner.class)
@RunWith(PowerMockRunner.class)
@PrepareForTest({SOAPFaultException.class})
public class OLBRBankProdCodeISDAOImplTest {

    @InjectMocks
    private OLBRBankProdCodeISDAOImpl daoImpl;

    @Mock
    private OLBRBankProdCodeISSoap bankProdCodeISSoap;

    @Mock
    private RemoteAccessException exce;

    @Mock
    private SOAPFault fault;

    @Test
    public void test() throws Exception {
        ReferenceDataListInqRq referenceDataListRq = new ReferenceDataListInqRq();
        com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRq.Cmd cmdValue = new com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRq.Cmd();

        referenceDataListRq.setCmd(cmdValue);
        ReferenceDataListInqRs referenceDataListInqRs = new ReferenceDataListInqRs();

        Cmd cmd = new Cmd();
        RefData refData = new RefData();
        refData.setRefDataKey("refDataKey");
        RefDataValue refDataValue = new RefDataValue();
        List<Attributes> AttribList = new ArrayList<Attributes>();
        Attributes Attr = new Attributes();
        Attr.setKey("key");
        Attr.setValue("valueKey");
        AttribList.add(Attr);
        refDataValue.getAttributes().add(Attr);
        refData.setRefDataValue(refDataValue);
        cmd.getRefData().add(refData);
        StatType stat = new StatType();
        stat.setStatCd(0);
        cmd.setStat(stat);

        referenceDataListInqRs.setCmd(cmd);

        Mockito.when(bankProdCodeISSoap.referenceDataInq((ReferenceDataListInqRq) Mockito.anyObject())).thenReturn(
                referenceDataListInqRs);

        List<OLBRRefData> response = daoImpl.getProductInfo();
        assertNotNull(response);
    }

    @Test
    public void test_diffStatCode() throws Exception {
        ReferenceDataListInqRq referenceDataListRq = new ReferenceDataListInqRq();
        com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRq.Cmd cmdValue = new com.capitalone.olbrbankprodcodeis.v1.ReferenceDataListInqRq.Cmd();

        referenceDataListRq.setCmd(cmdValue);
        ReferenceDataListInqRs referenceDataListInqRs = new ReferenceDataListInqRs();

        Cmd cmd = new Cmd();
        RefData refData = new RefData();
        refData.setRefDataKey("refDataKey");
        RefDataValue refDataValue = new RefDataValue();
        List<Attributes> AttribList = new ArrayList<Attributes>();
        Attributes Attr = new Attributes();
        Attr.setKey("key");
        Attr.setValue("valueKey");
        AttribList.add(Attr);
        refDataValue.getAttributes().add(Attr);
        refData.setRefDataValue(refDataValue);
        cmd.getRefData().add(refData);
        StatType stat = new StatType();
        stat.setStatCd(1);
        cmd.setStat(stat);

        referenceDataListInqRs.setCmd(cmd);

        Mockito.when(bankProdCodeISSoap.referenceDataInq((ReferenceDataListInqRq) Mockito.anyObject())).thenReturn(
                referenceDataListInqRs);

        List<OLBRRefData> response = daoImpl.getProductInfo();
        assertNotNull(response);
    }

    @Test
    public void test_Exception() throws Exception {
        RemoteAccessException exp = new RemoteAccessException("remoteException");
        Mockito.when(bankProdCodeISSoap.referenceDataInq((ReferenceDataListInqRq) Mockito.anyObject())).thenThrow(exp);

        List<OLBRRefData> response = daoImpl.getProductInfo();
        assertNotNull(response);
    }  
    

    @Test
    public void test_Exception_withGetCause1() throws Exception {

        SOAPFaultException e = new SOAPFaultException(fault);
        Mockito.when((fault.getFaultString())).thenReturn("DataQuality validation failure");
        RemoteAccessException exp = new RemoteAccessException("msg", e);        
        Mockito.when(bankProdCodeISSoap.referenceDataInq((ReferenceDataListInqRq) Mockito.anyObject())).thenThrow(exp);

        List<OLBRRefData> response = daoImpl.getProductInfo();
        assertNotNull(response);
    }
    
    @Test
    public void test_Exception_withGetCause2() throws Exception {

        SOAPFaultException e = new SOAPFaultException(fault);
        
        Mockito.when((fault.getFaultString())).thenReturn("Compilation Errors");
        RemoteAccessException exp = new RemoteAccessException("msg", e);        
        Mockito.when(bankProdCodeISSoap.referenceDataInq((ReferenceDataListInqRq) Mockito.anyObject())).thenThrow(exp);

        List<OLBRRefData> response = daoImpl.getProductInfo();
        assertNotNull(response);
    }
    
   /* @Test
    public void test_Exception_withGetCause3() throws Exception {

        SOAPFaultException e = new SOAPFaultException(fault);
        
        Mockito.when((fault.getFaultString())).thenReturn("TimeoutException");
        RemoteAccessException exp = new RemoteAccessException("msg", e);        
        Mockito.when(bankProdCodeISSoap.referenceDataInq((ReferenceDataListInqRq) Mockito.anyObject())).thenThrow(exp);
        //Mockito.when(exp.getCause().getMessage()).thenReturn("300:ERR_SYSTEM_NOT_AVAILABLE");
        List<OLBRRefData> response = daoImpl.getProductInfo();
        assertNotNull(response);
    } */

}
