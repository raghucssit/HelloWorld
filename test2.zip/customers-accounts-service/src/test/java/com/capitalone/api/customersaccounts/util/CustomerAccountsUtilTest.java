/**
 * Copyright 2014 Capital One Financial Corporation
 * All Rights Reserved.
 *
 * This software contains valuable trade secrets and proprietary
 * information of Capital One and is protected by law. It may not
 * be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior
 * written authorization from Capital One
 */

package com.capitalone.api.customersaccounts.util;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.configuration.Configuration;
import org.joda.time.Instant;
import org.joda.time.LocalDate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.services.util.ApiExceptionService;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.model.link.LinkBuilder;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.xmlmsgset._2004._07.eil.SevrtyType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType.AddnStat;

@SuppressWarnings({"static-access"})
public class CustomerAccountsUtilTest {

    @Autowired
    @InjectMocks
    protected CustomerAccountsUtil customerAccountsUtil;

    protected Set<String> businessLineSet = null;

    protected Set<String> productTypeSet = null;

    protected Set<String> soRIDSet = null;

    protected List<CustomerAccountKey> customerAccountKeyList = null;

    protected CustomerAccountKey customerAccountKey = null;

    protected List<CustomerAccountsResponse> custAccountList = null;

    protected CustomerAccountsResponse customerAccountsResponse = null;

    protected CustomerAccountsRefDataBean customerAccountsRefDataBean = null;

    private static final Object Date = "18062015";

    private static final String AVAILABLE_BAL = "123.00";

    @Mock
    protected ApiExceptionService apiExceptionService = null;

    @Mock
    private LinkBuilder linkBuilder;

    @Mock
    private CustomerAPIRESTException e;

    @Mock
    private Configuration config;

    protected StatType statType = null;

    @SuppressWarnings("unchecked")
    @Before
    public final void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        businessLineSet = mock(TreeSet.class);
        productTypeSet = mock(TreeSet.class);
        soRIDSet = mock(TreeSet.class);
        customerAccountKeyList = mock(ArrayList.class);
        customerAccountKey = mock(CustomerAccountKey.class);
        custAccountList = mock(ArrayList.class);
        customerAccountsResponse = mock(CustomerAccountsResponse.class);
        customerAccountsRefDataBean = mock(CustomerAccountsRefDataBean.class);
        customerAccountsUtil.setCustomerAccountsRefDataBean(customerAccountsRefDataBean);
        apiExceptionService = mock(ApiExceptionService.class);
    }

    @Test
    public void retrieveSoRIDsBasedOnBusinessLineAndProductTypeSuccess() {
        businessLineSet = new TreeSet<String>();
        businessLineSet.add("DEPOSITS");
        productTypeSet.add("IM");
        Set<String> filteredSoRIDSetbyBusinessLine = new TreeSet<String>();
        filteredSoRIDSetbyBusinessLine.add("16");

        Set<String> filteredSoRIDSetbyProductType = new TreeSet<String>();
        filteredSoRIDSetbyProductType.add("16");

        when(customerAccountsRefDataBean.getSoRIDBasedOnBusinessline(businessLineSet)).thenReturn(
                filteredSoRIDSetbyBusinessLine);
        when(customerAccountsRefDataBean.getSoRIDBasedOnProductType(productTypeSet)).thenReturn(
                filteredSoRIDSetbyProductType);

        Assert.assertNotNull(customerAccountsUtil.retrieveSoRIDsBasedOnBusinessLineAndProductType(businessLineSet,
                productTypeSet));
    }

    @Test
    public void retrieveSoRIDsBasedOnBusinessLineAndProductTypeFailure() {
        businessLineSet = null;
        productTypeSet = null;
        Assert.assertNull(customerAccountsUtil.retrieveSoRIDsBasedOnBusinessLineAndProductType(businessLineSet,
                productTypeSet));
    }

    @Test
    public void checkResponseForErrorsSuccess() {

        apiExceptionService = mock(ApiExceptionService.class);
        statType = new StatType();
        SevrtyType sevrtyType = SevrtyType.INFO;
        statType.setSevrty(sevrtyType);
        statType.setStatCd(200);

        customerAccountsUtil.checkResponseForErrors(statType);
    }

    @Test
    public void checkResponseForErrorsForWarningSuccess() {

        apiExceptionService = mock(ApiExceptionService.class);
        statType = new StatType();
        SevrtyType sevrtyType = SevrtyType.WARNING;
        statType.setSevrty(sevrtyType);
        statType.setStatCd(120048);

        customerAccountsUtil.checkResponseForErrors(statType);
    }

    @Test
    public void checkResponseForErrorsForErrorSuccess() {

        apiExceptionService = mock(ApiExceptionService.class);
        statType = new StatType();
        SevrtyType sevrtyType = SevrtyType.ERROR;
        statType.setSevrty(sevrtyType);
        statType.setStatCd(500);

        customerAccountsUtil.checkResponseForErrors(statType);
    }

    @Test
    public void constructApiErrorCodeSuccess() {

        List<String> messageParms = mock(ArrayList.class);
        Assert.assertNotNull(customerAccountsUtil.constructApiErrorCode(120375, messageParms, "DeveloperText"));
    }

    @Test
    public void filterbySoRIDSuccess() {
        customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        soRIDSet = new HashSet<String>();
        soRIDSet.add("17");

        CustomerAccountKey accountKey = new CustomerAccountKey();

        customerAccountKeyList.add(accountKey);

        Assert.assertNotNull(customerAccountsUtil.filterbySoRID(customerAccountKeyList, soRIDSet));

    }

    @Test
    public void filterbySoRIDSuccess1() {
        customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        soRIDSet = new HashSet<String>();
        soRIDSet.add("17");

        CustomerAccountKey accountKey = new CustomerAccountKey();
        accountKey.setSorId((short) 17);

        customerAccountKeyList.add(accountKey);

        Assert.assertNotNull(customerAccountsUtil.filterbySoRID(customerAccountKeyList, soRIDSet));

    }

    @Test
    public void filterbySoRID_Failure() {
        customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        soRIDSet = new HashSet<String>();

        CustomerAccountKey accountKey = new CustomerAccountKey();
        accountKey.setSorId((short) 17);

        customerAccountKeyList.add(accountKey);

        Assert.assertNotNull(customerAccountsUtil.filterbySoRID(customerAccountKeyList, soRIDSet));

    }

    @Test
    public void maptoFinalResponseSuccess() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setAppVersion("V3");
        // request.s
        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("2");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        customerAccount.setAccountId("1234567891234");
        customerAccountList.add(customerAccount);

        when(customerAccountsRefDataBean.getAccountDetailsURL("AL", "2")).thenReturn("desc");

        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponseSuccess_withNicknameSetting() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setAppVersion("V3");

        // request.
        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("2");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        customerAccount.setAccountNickname("nick Name");
        customerAccount.setAccountId("1234567891234");
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponse_withLoanSeqNumNull() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setAppVersion("V3");
        // request.
        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("2");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum(null);
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponse_withNickname_appVerIsNotV3() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("2");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        customerAccount.setAccountNickname("nick Name");
        customerAccount.setAccountId("1234567891234");
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponse_withNickname_sorid199() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setCoiAccountURL("https://www.capitaloneinvesting.com/main/accounts/accountoverview.aspx");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("199");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        customerAccount.setAccountNickname("nick Name");
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponse_AccountUseTypeBUS() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("2");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        customerAccount.setAccountNickname("nick Name");
        customerAccount.setAccountId("1234");
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponse_AccountUseTypePER() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("PER");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("2");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        customerAccount.setAccountNickname("nick Name");
        customerAccount.setAccountId("1234");
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponse_AccountUseTypeEXP() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("EXP");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("2");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        customerAccount.setAccountNickname("nick Name");
        customerAccount.setAccountId("1234");
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponse_AccountUseTypeUnknown() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("Unknown");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        custkey.setConsumerId("456");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("2");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        customerAccount.setAccountNickname("nick Name");
        customerAccount.setAccountId("1234");
        customerAccount.setAppnId("456");
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponse_COBORROWER() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("Unknown");
        custkey.setSorId((short) 2);
        custkey.setAccountNumber("1234");
        custkey.setConsumerId("11456");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("2");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(null);
        customerAccount.setAccountNickname("nick Name");
        customerAccount.setAccountId("1234");
        customerAccount.setAppnId("1456");
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponseSuccess_CardDetails() {
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 7);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setAppVersion("V3");
        // request.s
        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("7");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setProductImageId("imgId");
        customerAccount.setRetirementIndicator(true);
        Instant paymentDueDate = new Instant(Date);
        customerAccount.setPaymentDueDate(paymentDueDate);
        customerAccount.setCurrentBalance(new BigDecimal(AVAILABLE_BAL));
        customerAccount.setAvailableBalance(new BigDecimal(AVAILABLE_BAL));
        customerAccount.setPrincipalBalance(new BigDecimal(AVAILABLE_BAL));
        customerAccount.setCurrentPrincipal(new BigDecimal(AVAILABLE_BAL));
        customerAccount.setPresentBalance(new BigDecimal(AVAILABLE_BAL));
        customerAccount.setPaymentDueAmount(new BigDecimal(AVAILABLE_BAL));
        customerAccountList.add(customerAccount);
        Assert.assertNotNull(customerAccountsUtil.maptoFinalResponse(customerAccountList, request.getAppVersion(),
                customerAccountKeyList));
    }

    @Test
    public void maptoFinalResponse_Failure() {
        Assert.assertNull(customerAccountsUtil.maptoFinalResponse(null, "V3", customerAccountKeyList));
    }

    @Test
    public void findSORID_Test_false() {

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 7);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        int sorid = 7;
        Assert.assertNotNull(customerAccountsUtil.findSORID(request, sorid));
    }

    @Test
    public void findSORID_Test_true() {

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 7);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.getCustomerAccountKeyList().add(custkey);
        int sorid = 7;
        Assert.assertNotNull(customerAccountsUtil.findSORID(request, sorid));
    }

    @Test
    public void merge_test() {
        REASResponse finalREASResponse = new REASResponse();
        Assert.assertNotNull(customerAccountsUtil.merge(finalREASResponse, finalREASResponse));

    }

    @Test
    public void merge_test1() {
        REASResponse finalREASResponse = new REASResponse();

        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 7);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setAppVersion("V3");
        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setProductTypeCode("AL");
        customerAccount.setBusinessLine("BL");
        customerAccount.setSorId("7");
        customerAccount.setAccountNumber("1234");
        customerAccount.setLoanSeqNum("12");
        customerAccount.setDisplayAccountNumber("1234");
        customerAccount.setProductTypeDescription("desc");
        customerAccount.setRetirementIndicator(true);
        Instant paymentDueDate = new Instant(Date);
        customerAccount.setPaymentDueDate(paymentDueDate);
        customerAccount.setCurrentBalance(new BigDecimal(AVAILABLE_BAL));
        customerAccount.setAvailableBalance(new BigDecimal(AVAILABLE_BAL));
        customerAccount.setPrincipalBalance(new BigDecimal(AVAILABLE_BAL));
        customerAccount.setCurrentPrincipal(new BigDecimal(AVAILABLE_BAL));
        customerAccount.setPresentBalance(new BigDecimal(AVAILABLE_BAL));
        customerAccountList.add(customerAccount);

        finalREASResponse.setCustomerAccountsResponseList(customerAccountList);
        List<AdditionalStat> addStatList = new ArrayList<AdditionalStat>();
        AdditionalStat addstat = new AdditionalStat();
        addstat.setSrvrStatCd("2");
        addStatList.add(addstat);
        finalREASResponse.setAddStatList(addStatList);
        Assert.assertNotNull(customerAccountsUtil.merge(finalREASResponse, finalREASResponse));
    }

    @Test
    public void split_test() {
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey custkey = new CustomerAccountKey();
        custkey.setAccountUseType("BUS");
        custkey.setSorId((short) 7);
        custkey.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);
        CustomerAccountKey custkey1 = new CustomerAccountKey();
        custkey1.setAccountUseType("BUS");
        custkey1.setSorId((short) 7);
        custkey1.setAccountNumber("1234");
        customerAccountKeyList.add(custkey);
        customerAccountKeyList.add(custkey1);
        final int splitSize = 50;
        Assert.assertNotNull(customerAccountsUtil.split(customerAccountKeyList, splitSize));
    }

    @Test
    public void addnStatConverter_test() {
        AddnStat addstat = new AddnStat();
        addstat.setNativeErrorCd("200");
        addstat.setSrvrStatCd("01");
        Long L = new Long("01");
        addstat.setStatCd(L);
        addstat.setStatDesc("Stat Desc");
        SevrtyType value = null;
        addstat.setSevrty(value);
        List<AddnStat> addnStatList = new ArrayList<StatType.AddnStat>();
        addnStatList.add(addstat);
        Assert.assertNotNull(customerAccountsUtil.addnStatConverter(addnStatList, Constants.SUCCESS_STATUS_CODE));
    }

    @Test
    public void addnStatConverter_test_null() {
        AddnStat addstat = new AddnStat();
        addstat.setNativeErrorCd(null);
        addstat.setSrvrStatCd(null);
        addstat.setStatCd(null);
        addstat.setStatDesc(null);
        addstat.setSevrty(SevrtyType.INFO);
        List<AddnStat> addnStatList = new ArrayList<StatType.AddnStat>();
        addnStatList.add(addstat);
        Assert.assertNotNull(customerAccountsUtil.addnStatConverter(addnStatList, Constants.SUCCESS_STATUS_CODE));
    }

    @Test
    public void addnStatConverter_test_SetSevrty() {
        AddnStat addstat = new AddnStat();
        addstat.setNativeErrorCd(null);
        addstat.setSrvrStatCd(null);
        addstat.setStatCd(null);
        addstat.setStatDesc(null);
        addstat.setSevrty(SevrtyType.ERROR);
        List<AddnStat> addnStatList = new ArrayList<StatType.AddnStat>();
        addnStatList.add(addstat);
        Assert.assertNotNull(customerAccountsUtil.addnStatConverter(addnStatList, Constants.SUCCESS_STATUS_CODE));
    }

    @Test
    public void addnStatConverter_test_SetSevrty1() {
        AddnStat addstat = new AddnStat();
        addstat.setNativeErrorCd(null);
        addstat.setSrvrStatCd(null);
        addstat.setStatCd(null);
        addstat.setStatDesc(null);
        addstat.setSevrty(SevrtyType.WARNING);
        List<AddnStat> addnStatList = new ArrayList<StatType.AddnStat>();
        addnStatList.add(addstat);
        Assert.assertNotNull(customerAccountsUtil.addnStatConverter(addnStatList, Constants.SUCCESS_STATUS_CODE));
    }

    @Test
    public void convertDateToInstantNoTimezone_test() {
        Instant date = new Instant();
        Assert.assertNotNull(customerAccountsUtil.convertDateToInstantNoTimezone(date));
    }

    @Test
    public void convertDateToInstantNoTimezone_test_null() {
        Instant date = null;
        Assert.assertNull(customerAccountsUtil.convertDateToInstantNoTimezone(date));
    }

    @Test
    public void convertLocalDateToInstant_test() {
        LocalDate date = new LocalDate();
        Assert.assertNotNull(customerAccountsUtil.convertLocalDateToInstant(date));
    }

    @Test
    public void getAdditionalStat_test_StatCd_400() {
        StatType responseStatus = new StatType();
        long value = 400;
        responseStatus.setStatCd(value);
        responseStatus.setSevrty(SevrtyType.ERROR);
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345");
        customerAccountKey.setSorId((short) 7);
        List<AdditionalStat> addStatList = new ArrayList<AdditionalStat>();
        AdditionalStat addStat = new AdditionalStat();
        addStatList.add(addStat);
        Assert.assertNotNull(customerAccountsUtil.getAdditionalStat(responseStatus, customerAccountKey));

    }

    @Test
    public void getAddnStatCaseError_test_StatCd_500() {
        StatType responseStatus = new StatType();
        long value = 500;
        responseStatus.setStatCd(value);
        responseStatus.setSevrty(SevrtyType.ERROR);
        responseStatus.setStatDesc("desc");
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345");
        customerAccountKey.setSorId((short) 7);
        List<AdditionalStat> addStatList = new ArrayList<AdditionalStat>();
        AdditionalStat addStat = new AdditionalStat();
        addStatList.add(addStat);
        Assert.assertNotNull(customerAccountsUtil.getAddnStatCaseError(responseStatus, 500, customerAccountKey));

    }

    @Test
    public void setPartialStatus_test() {
        REASResponse response = new REASResponse();
        List<CustomerAccountsResponse> CustAcctResp = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setAccountId("12345");
        CustAcctResp.add(customerAccount);
        response.setCustomerAccountsResponseList(CustAcctResp);
        long statCd = 0;
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345");
        customerAccountKey.setSorId((short) 7);
        List<CustomerAccountKey> customerAccountskeyList = new ArrayList<CustomerAccountKey>();
        customerAccountskeyList.add(customerAccountKey);

        customerAccountsUtil.setPartialStatus(response, statCd, customerAccountskeyList);
    }

    @Test
    public void setPartialStatus_test1() {
        REASResponse response = new REASResponse();
        List<CustomerAccountsResponse> CustAcctResp = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccount = new CustomerAccountsResponse();
        customerAccount.setAccountId("12345");
        CustAcctResp.add(customerAccount);
        response.setCustomerAccountsResponseList(CustAcctResp);
        long statCd = 0;
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("1234");
        customerAccountKey.setSorId((short) 7);
        List<CustomerAccountKey> customerAccountskeyList = new ArrayList<CustomerAccountKey>();
        customerAccountskeyList.add(customerAccountKey);

        customerAccountsUtil.setPartialStatus(response, statCd, customerAccountskeyList);
    }

    // findSORIDList

    @Test
    public void findSORIDList_test() {
        CustomerAccountsRequest req = new CustomerAccountsRequest();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("1234");
        customerAccountKey.setSorId((short) 7);
        List<CustomerAccountKey> customerAccountskeyList = new ArrayList<CustomerAccountKey>();
        customerAccountskeyList.add(customerAccountKey);
        req.setCustomerAccountKeyList(customerAccountskeyList);

        List<Short> listSorid = new ArrayList<Short>();
        listSorid.add((short) 7);

        customerAccountsUtil.findSORIDList(req, listSorid);
    }

    @Test
    public void setCustomerAPIRESTException_test() {
        AdditionalStat addnStatFail = new AdditionalStat();

        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404, errorResponse);

        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("1234");
        customerAccountKey.setSorId((short) 7);

        Mockito.when(e.getCause()).thenReturn(e1);
        e1.getErrorResponse().setDeveloperText("devTest");
        e1.getErrorResponse().setId("TestID01");
        e1.getErrorResponse().setText("Text");

        customerAccountsUtil.setCustomerAPIRESTException(customerAccountKey, addnStatFail, e);
    }

    @Test
    public void generateCustomPerfLog_test() {

        EPFContext context = new EPFContext();
        long responseTime = 0;
        String statCode = "0";
        String severity = "INFO";
        String statDesc = "Desc";
        String serviceName = "customerAccount";
        int httpstatus = 404;
        customerAccountsUtil.generateCustomPerfLog(context, responseTime, statCode, severity, statDesc, serviceName,
                httpstatus);
    }

    @Test
    public void loadConfigDetails_test() {
        CustomerAccountsRequest request = customerAccountsUtil.loadConfigDetails();
    }

}