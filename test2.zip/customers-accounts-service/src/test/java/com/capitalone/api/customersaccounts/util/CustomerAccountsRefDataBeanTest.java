package com.capitalone.api.customersaccounts.util;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.model.referencedata.ReferenceDataCategory;
import com.capitalone.api.commons.model.referencedata.ReferenceDataEntity;
import com.capitalone.api.commons.services.referencedata.ReferenceDataCategoryService;
import com.capitalone.api.commons.services.referencedata.ReferenceDataService;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class CustomerAccountsRefDataBeanTest {

    @InjectMocks
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Mock
    private ReferenceDataCategoryService<String> refernceDataCategoryService;

    @Mock
    private ReferenceDataCategoryService<OLBAttributes> olbrRefernceDataCategoryService;

    @Mock
    private ReferenceDataService<String> referenceDataService;

    private static final String PROD_TYPE_DESC = "CHECKING";

    private static final String PROD_TYPE_DESC1 = "LOC";

    private static final String PROD_TYPE_CODE = "DDA";

    private static final String FEATURE_TYPE_CD = "PASSBK";

    private static final String BANK_NO = "81";

    // private static final Short SOR_ID = 7;

    private static final Short SOR_ID_LOAN = 38;

    private final String csvAccountCategories = "AccountCategories";

    private final String csvProductTypeCodeRetail = "ProductTypeCodeRetail";

    private final String csvAcctCategory = "AcctCategory";

    private final String csvBankRefData = "BankRefData";

    private final String csvCustAcctRelationshipDesc360 = "CustAcctRelationshipDesc360";

    private final String csvCustAcctRelationshipDescAll = "CustAcctRelationshipDescAllV2";

    private final String csvCustAcctRelationshipDescIm = "CustAcctRelationshipDescIMSTV2";

    private final String csvProfileProductRefData = "ProfileProductTypes";

    private final String csvSupportedEnterpriseAccounts = "SupportedEnterpriseAccounts";

    private final String csvRetailSORIDLookup = "RetailSORIDLookup";

    private final String csvSorIdToBusinessLine = "SoRIDtoBusinessLine";

    private final String csvSorIdToSorIdDetail = "SoRIDtoSoRDetail";

    private final String csvSoRIDtoSoRProductType = "SoRIDtoSoRProductType";

    private final String csvDefaultCustomerAccountSortOrder = "DefaultCustAcntSortOrdr";

    private final String csvAllowableClient360 = "AllowedClientsto360API";

    @Test
    public final void test_getAccountType_success() {

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_DESC, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, PROD_TYPE_DESC);

        when(referenceDataService.getEntity(csvAccountCategories, 1, entityFilterMap)).thenReturn(referenceDataEntity);

        String accountTypeCode = customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_DESC);

        assertNotNull(accountTypeCode);

    }

    @Test
    public final void test_getProductTypeCode_success() {

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_DESC, PROD_TYPE_DESC1);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvProductTypeCodeRetail,
                entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, PROD_TYPE_DESC1);

        List<ReferenceDataEntity<String>> referenceDataEntityList = new ArrayList<ReferenceDataEntity<String>>();
        referenceDataEntityList.add(referenceDataEntity);
        when(
                referenceDataService.getEntities(csvProductTypeCodeRetail, 1, Constants.KEY_BANK_ACCT_TYPE_CD,
                        PROD_TYPE_DESC1)).thenReturn(referenceDataEntityList);
        String accountType = customerAccountsRefDataBean.getProductTypeCode(SOR_ID_LOAN, PROD_TYPE_DESC1);
        assertNotNull(accountType);
    }

    @Test
    public final void test_getAccountType_nullFeatureTypeCode() {

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_DESC, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, PROD_TYPE_DESC);

        when(referenceDataService.getEntity(csvAccountCategories, 1, entityFilterMap)).thenReturn(referenceDataEntity);

        String accountType = customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_DESC);

        assertEquals(PROD_TYPE_DESC, accountType);

    }

    @Test
    public final void test_getAccountType_nullRetirementIndicator() {

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_DESC, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, PROD_TYPE_DESC);

        when(referenceDataService.getEntity(csvAccountCategories, 1, entityFilterMap)).thenReturn(referenceDataEntity);

        String accountType = customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_DESC);

        assertEquals(PROD_TYPE_DESC, accountType);

    }

    @Test
    public final void test_getAccountType_nullProductCode() {

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_DESC, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, PROD_TYPE_DESC);
        entityFilterMap.put(Constants.KEY_RTMT_ACCT_INDICATOR, "TRUE");
        entityFilterMap.put(Constants.KEY_FEATURE_TYPE_CD, FEATURE_TYPE_CD);

        when(referenceDataService.getEntity(csvAccountCategories, 1, entityFilterMap)).thenReturn(referenceDataEntity);

        String accountType = customerAccountsRefDataBean.getProductTypeDescription(null);

        assertEquals(Constants.NOT_AVAILABLE_CD, accountType);

    }

    @Test
    public final void test_getSupportedAccountsList_success() {

        List<CustomerAccountKey> accountsList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setSorId(new Short("13"));
        accountsList.add(key);

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_SOR_ID, "13");

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvSupportedEnterpriseAccounts, entityMap);

        when(
                referenceDataService.getEntity(csvSupportedEnterpriseAccounts, 1, Constants.KEY_SOR_ID, key.getSorId()
                        .toString())).thenReturn(referenceDataEntity);

        accountsList = customerAccountsRefDataBean.getSupportedAccountsList(accountsList);

        assertNotNull(accountsList);

    }

    @Test
    public final void test_getSupportedAccountsList_failure() {

        List<CustomerAccountKey> accountsList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setSorId(new Short("13"));

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_SOR_ID, "13");

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvSupportedEnterpriseAccounts, entityMap);

        when(
                referenceDataService.getEntity(csvSupportedEnterpriseAccounts, 1, Constants.KEY_SOR_ID, key.getSorId()
                        .toString())).thenReturn(referenceDataEntity);

        accountsList = customerAccountsRefDataBean.getSupportedAccountsList(accountsList);

        assertNotNull(accountsList);

    }

    @Test
    public final void test_getBusinessLine_success() {

        String businessLine = "Deposits";

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_BUSINESS_LINE, businessLine);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);

        String productTypeCode = "DDA";
        String sorID = "12";
        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, productTypeCode);
        entityFilterMap.put(Constants.KEY_SOR_ID, sorID);

        when(referenceDataService.getEntity(csvAccountCategories, 1, entityFilterMap)).thenReturn(referenceDataEntity);

        // assertEquals(businessLine, customerAccountsRefDataBean.getBusinessLine(productTypeCode, sorID));

    }

    @Test
    public final void test_getBusinessLine_failure() {

        Map<String, String> entityMap = new HashMap<String, String>();

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);

        String productTypeCode = "DDA";
        String sorID = "12";
        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, productTypeCode);
        entityFilterMap.put(Constants.KEY_SOR_ID, sorID);

        when(referenceDataService.getEntity(csvAccountCategories, 1, entityFilterMap)).thenReturn(referenceDataEntity);

        assertEquals(Constants.NOT_AVAILABLE_CD, customerAccountsRefDataBean.getBusinessLine(productTypeCode, sorID));
    }

    @Test
    public final void test_getAccountDetailsURL_success() {

        String accountDetailsURL = "http://qa:8080/deposits";

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_ACCOUNT_DETAILS_URL, accountDetailsURL);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);

        String productTypeCode = "DDA";
        String sorID = "12";
        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, productTypeCode);
        entityFilterMap.put(Constants.KEY_SOR_ID, sorID);

        when(referenceDataService.getEntity(csvAccountCategories, 1, entityFilterMap)).thenReturn(referenceDataEntity);

        // assertEquals(accountDetailsURL, customerAccountsRefDataBean.getAccountDetailsURL(productTypeCode, sorID));

    }

    @Test
    public final void test_getAccountDetailsURL_failure() {

        Map<String, String> entityMap = new HashMap<String, String>();

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);

        String productTypeCode = "DDA";
        String sorID = "12";
        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_PROD_TYPE_CD, productTypeCode);
        entityFilterMap.put(Constants.KEY_SOR_ID, sorID);

        when(referenceDataService.getEntity(csvAccountCategories, 1, entityFilterMap)).thenReturn(referenceDataEntity);

        // assertEquals(Constants.NOT_AVAILABLE_CD,
        // customerAccountsRefDataBean.getAccountDetailsURL(productTypeCode, sorID));

    }

    @Test
    public final void test_getBankNumberDescription_success() {

        String bankNumberDesc = "NC";

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_BANK_NUM_DESC, bankNumberDesc);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvBankRefData, entityMap);

        when(referenceDataService.getEntity(csvBankRefData, 1, Constants.KEY_BANK_NUM, BANK_NO)).thenReturn(
                referenceDataEntity);

        assertEquals(bankNumberDesc, customerAccountsRefDataBean.getBankNumberDescription(BANK_NO));

    }

    @Test
    public final void test_getBankNumberDescription_failure() {

        Map<String, String> entityMap = new HashMap<String, String>();

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvBankRefData, entityMap);

        when(referenceDataService.getEntity(csvBankRefData, 1, Constants.KEY_BANK_NUM, BANK_NO)).thenReturn(
                referenceDataEntity);

        assertEquals(Constants.NOT_AVAILABLE_CD, customerAccountsRefDataBean.getBankNumberDescription(BANK_NO));

    }

    @Test
    public final void test_getSoRIDBasedOnBusinessline_success() {

        Set<String> businessLineSet = new TreeSet<String>();
        businessLineSet.add("13");

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_SOR_ID, "13");

        List<ReferenceDataEntity<String>> referenceDataEntityList = new ArrayList<ReferenceDataEntity<String>>();

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);
        referenceDataEntityList.add(referenceDataEntity);

        when(referenceDataService.getEntities(csvAccountCategories, 1, Constants.KEY_BUSINESS_LINE, "13")).thenReturn(
                referenceDataEntityList);

        assertNotNull(customerAccountsRefDataBean.getSoRIDBasedOnBusinessline(businessLineSet));

    }

    @Test
    public final void test_getSoRIDBasedOnProductType_success() {

        Set<String> productTypeSet = new TreeSet<String>();
        productTypeSet.add(PROD_TYPE_CODE);

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_SOR_ID, "13");

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);

        when(referenceDataService.getEntity(csvAccountCategories, 1, Constants.KEY_PROD_TYPE_CD, PROD_TYPE_CODE))
                .thenReturn(referenceDataEntity);

        assertNotNull(customerAccountsRefDataBean.getSoRIDBasedOnProductType(productTypeSet));

    }

    @Test
    public final void test_getAllProductTypes_success() {

        Set<String> productTypeSet = new TreeSet<String>();
        productTypeSet.add(PROD_TYPE_DESC);

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_DESC, "13");

        List<ReferenceDataEntity<String>> entities = new ArrayList<ReferenceDataEntity<String>>();
        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);
        entities.add(referenceDataEntity);

        ReferenceDataCategory<String> referenceDataCategory = new ReferenceDataCategory<String>(csvAccountCategories,
                1, entities);

        when(refernceDataCategoryService.getCategory(csvAccountCategories, 1)).thenReturn(referenceDataCategory);

        assertNotNull(customerAccountsRefDataBean.getAllProductTypes());

    }

    @Test
    public final void test_getAllBusinessLines_success() {

        Set<String> businessLineSet = new TreeSet<String>();
        businessLineSet.add("Deposits");

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_BUSINESS_LINE, "13");

        List<ReferenceDataEntity<String>> entities = new ArrayList<ReferenceDataEntity<String>>();
        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAccountCategories,
                entityMap);
        entities.add(referenceDataEntity);

        ReferenceDataCategory<String> referenceDataCategory = new ReferenceDataCategory<String>(csvAccountCategories,
                1, entities);

        when(refernceDataCategoryService.getCategory(csvAccountCategories, 1)).thenReturn(referenceDataCategory);

        assertNotNull(customerAccountsRefDataBean.getAllBusinessLines());

    }

    @Test
    public final void test_getCOFProductType_success() {

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_COF_PROD_TYPE_CD, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvProfileProductRefData,
                entityMap);

        when(
                referenceDataService.getEntity(csvProfileProductRefData, 1, Constants.KEY_PROFILE_PROD_TYPE_CD,
                        PROD_TYPE_DESC)).thenReturn(referenceDataEntity);

        assertNotNull(customerAccountsRefDataBean.getCOFProductType(PROD_TYPE_DESC));

    }

    @Test
    public final void test_getCustRelationshipDesc_success() {

        String relFromCd = "PR";
        String relToCd = "JNT";

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_COF_PROD_TYPE_CD, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvCustAcctRelationshipDescAll, entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.CUST_REL_FROM_CODE, relFromCd.toUpperCase());
        entityFilterMap.put(Constants.CUST_REL_TO_CODE, relToCd.toUpperCase());

        when(referenceDataService.getEntity(csvCustAcctRelationshipDescAll, 1, entityFilterMap)).thenReturn(
                referenceDataEntity);

        assertNotNull(customerAccountsRefDataBean.getCustRelationshipDesc("PR", "JNT"));

    }

    @Test
    public final void test_getCustRelationshipDesc_relFromCd() {

        String relFromCd = "---";
        String relToCd = "JNT";

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_COF_PROD_TYPE_CD, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvCustAcctRelationshipDescAll, entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.CUST_REL_FROM_CODE, relFromCd.toUpperCase());
        entityFilterMap.put(Constants.CUST_REL_TO_CODE, relToCd.toUpperCase());

        when(referenceDataService.getEntity(csvCustAcctRelationshipDescAll, 1, entityFilterMap)).thenReturn(
                referenceDataEntity);

        assertNotNull(customerAccountsRefDataBean.getCustRelationshipDesc("", "JNT"));

    }

    @Test
    public final void test_getCustRelationshipDesc_relToCd() {

        String relFromCd = "PR";
        String relToCd = "---";

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_COF_PROD_TYPE_CD, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvCustAcctRelationshipDescAll, entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.CUST_REL_FROM_CODE, relFromCd.toUpperCase());
        entityFilterMap.put(Constants.CUST_REL_TO_CODE, relToCd.toUpperCase());

        when(referenceDataService.getEntity(csvCustAcctRelationshipDescAll, 1, entityFilterMap)).thenReturn(
                referenceDataEntity);

        assertNotNull(customerAccountsRefDataBean.getCustRelationshipDesc("PR", ""));

    }

    @Test
    public final void test_getCustRelationshipDesc() {

        String relFromCd = "PR";
        String relToCd = "JNT";
        String applCd = "IM";
        String bankMarketCd = "NC";

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_COF_PROD_TYPE_CD, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvCustAcctRelationshipDescIm, entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();

        entityFilterMap.put(Constants.CUST_REL_FROM_CODE, relFromCd);
        entityFilterMap.put(Constants.CUST_REL_TO_CODE, relToCd);
        entityFilterMap.put(Constants.APPL_SYS_CD, applCd);
        entityFilterMap.put(Constants.BANK_MKT_CD, bankMarketCd);

        when(referenceDataService.getEntity(csvCustAcctRelationshipDescIm, 1, entityFilterMap)).thenReturn(
                referenceDataEntity);

        assertNotNull(customerAccountsRefDataBean.getCustRelationshipDesc("PR", "JNT", "IM", "NC"));

    }

    @Test
    public final void test_getCustRelationshipDesc360() {

        String customerAccountRelationshipCode = "PR";
        String ownershipType = "JOINT";
        String trustAcctIndicator = "TRUE";

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.CUST_REL_ROLE_DESC, "PRI OWNER");

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvCustAcctRelationshipDesc360, entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();

        entityFilterMap.put(Constants.CUST_REL_CODE, customerAccountRelationshipCode);
        entityFilterMap.put(Constants.CUST_REL_ROLE_CODE, ownershipType);
        entityFilterMap.put(Constants.CUST_REL_TRUST_CODE, trustAcctIndicator);

        when(referenceDataService.getEntity(csvCustAcctRelationshipDesc360, 1, entityFilterMap)).thenReturn(
                referenceDataEntity);

        assertNotNull(customerAccountsRefDataBean.getCustRelationshipDesc("PR", "JOINT", "TRUE"));

    }

    @Test
    public final void test_getAcctType_success() {

        String prodClassCd = Constants.NILL;
        String prodTypeCd = Constants.NILL;
        String rtirmntAcctInd = Constants.FALSE;
        String feturTypeCd = Constants.NILL;
        String acctUseCd = Constants.NILL;

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_DESC, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAcctCategory, entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put("ProdClassCd", prodClassCd);
        entityFilterMap.put("ProdTypeCd", prodTypeCd);
        entityFilterMap.put("RtirmntAcctInd", rtirmntAcctInd);
        entityFilterMap.put("AcctUseCd", acctUseCd);
        entityFilterMap.put("FeturTypeCd", feturTypeCd);

        when(referenceDataService.getEntity(csvAcctCategory, 1, entityFilterMap)).thenReturn(referenceDataEntity);

        String accountType = customerAccountsRefDataBean.getAcctType(prodClassCd, prodTypeCd, rtirmntAcctInd,
                feturTypeCd, acctUseCd);
        assertThat(accountType, equalTo(null));

    }

    @Test
    public final void test_getBankNumberRetail() {
        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.SOR_ID_KEY, "12");

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvRetailSORIDLookup,
                entityMap);

        when(referenceDataService.getEntity(csvRetailSORIDLookup, 1, entityMap)).thenReturn(referenceDataEntity);

        assertNull(customerAccountsRefDataBean.getBankNumberRetail("12"));

    }

    @Test
    public final void test_getBusinessLineBasedOnSORID() {
        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_CD, "LOC|ILA");

        List<ReferenceDataEntity<String>> referenceDataEntity1 = new ArrayList<ReferenceDataEntity<String>>();

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvSorIdToBusinessLine,
                entityMap);
        referenceDataEntity1.add(referenceDataEntity);

        when(referenceDataService.getEntity(csvSorIdToBusinessLine, 1, Constants.KEY_SOR_ID, "185")).thenReturn(
                referenceDataEntity);
        when(referenceDataService.getEntities(csvSorIdToBusinessLine, 1, Constants.KEY_SOR_ID, "185")).thenReturn(
                referenceDataEntity1);

        assertNull(customerAccountsRefDataBean.getBusinessLineBasedOnSORID("185", "LOC"));

    }

    @Test
    public final void test_getBusinessLineBasedOnSORID_prodIdNull() {
        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_CD, "LOC|ILA");

        List<ReferenceDataEntity<String>> referenceDataEntity1 = new ArrayList<ReferenceDataEntity<String>>();

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvSorIdToBusinessLine,
                entityMap);
        when(referenceDataService.getEntity(csvSorIdToBusinessLine, 1, Constants.KEY_SOR_ID, "185")).thenReturn(
                referenceDataEntity);
        referenceDataEntity1.add(referenceDataEntity);

        when(referenceDataService.getEntities(csvSorIdToBusinessLine, 1, Constants.KEY_SOR_ID, "185")).thenReturn(
                referenceDataEntity1);

        assertNotNull(customerAccountsRefDataBean.getBusinessLineBasedOnSORID("185", ""));

    }

    @Test
    public final void test_getBusinessLineBasedOnSORID_DiffSorId() {
        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_CD, "");

        List<ReferenceDataEntity<String>> referenceDataEntity1 = new ArrayList<ReferenceDataEntity<String>>();

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvSorIdToBusinessLine,
                entityMap);
        when(referenceDataService.getEntity(csvSorIdToBusinessLine, 1, Constants.KEY_SOR_ID, "7")).thenReturn(
                referenceDataEntity);
        referenceDataEntity1.add(referenceDataEntity);

        when(referenceDataService.getEntities(csvSorIdToBusinessLine, 1, Constants.KEY_SOR_ID, "7")).thenReturn(
                referenceDataEntity1);

        assertNull(customerAccountsRefDataBean.getBusinessLineBasedOnSORID("7", ""));

    }

    @Test
    public final void test_getBankNumberFromSorId() {
        String SOR_ID = "12";
        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_DESC, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvSorIdToSorIdDetail,
                entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.SOR_ID_KEY_2, SOR_ID);

        when(referenceDataService.getEntity(csvSorIdToSorIdDetail, 1, entityFilterMap)).thenReturn(referenceDataEntity);
        String bankNumber = customerAccountsRefDataBean.getBankNumberFromSorId(SOR_ID);
        assertNull(bankNumber);

    }

    @Test
    public final void test_getSorProductTypeFromSorId_success() {

        List<CustomerAccountKey> accountsList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setSorId(new Short("6"));
        accountsList.add(key);

        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_SOR_ID, "6");
        entityMap.put(Constants.KEY_SOR_ID, "46");

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvSoRIDtoSoRProductType,
                entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.KEY_SORID, "6");

        when(referenceDataService.getEntity(csvSoRIDtoSoRProductType, 1, entityFilterMap)).thenReturn(
                referenceDataEntity);

        String account = customerAccountsRefDataBean.getSorProductTypeFromSorId(accountsList);
        assertNotNull(account);
    }

    @Test
    public final void test_getSortKey() {
        String sortField = "Primary";
        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.KEY_PROD_TYPE_DESC, PROD_TYPE_DESC);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvDefaultCustomerAccountSortOrder, entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.SOR_ID_KEY_2, sortField);

        when(referenceDataService.getEntity(csvDefaultCustomerAccountSortOrder, 1, Constants.SORT_KEY, sortField))
                .thenReturn(referenceDataEntity);
        List<String> sortKeyList = customerAccountsRefDataBean.getSortKey(sortField);
        assertNotNull(sortKeyList);
    }

    @Test
    public final void test_getSortKey1() {
        String sortField = "Primary";
        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.SORT_KEY, sortField);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvDefaultCustomerAccountSortOrder, entityMap);

        List<ReferenceDataEntity<String>> referenceDataEntityLIst = referenceDataService.getEntities(
                csvDefaultCustomerAccountSortOrder, 1, Constants.SORT_KEY, sortField);
        referenceDataEntityLIst.add(referenceDataEntity);

        when(referenceDataService.getEntities(csvDefaultCustomerAccountSortOrder, 1, Constants.SORT_KEY, sortField))
                .thenReturn(referenceDataEntityLIst);
        List<String> sortKeyList = customerAccountsRefDataBean.getSortKey(sortField);
        assertNotNull(sortKeyList);
    }

    @Test
    public final void test_getSortKey_Empty() {
        List<String> sortKeyList = customerAccountsRefDataBean.getSortKey("");
        assertNotNull(sortKeyList);
    }

    @Test
    public final void test_getTertiarySortKey() {
        String sortFieldField = "Primary";
        Map<String, String> entityMap = new HashMap<String, String>();
        entityMap.put(Constants.SORT_KEY, sortFieldField);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(
                csvDefaultCustomerAccountSortOrder, entityMap);

        List<ReferenceDataEntity<String>> referenceDataEntityLIst = referenceDataService.getEntities(
                csvDefaultCustomerAccountSortOrder, 1, Constants.SORT_KEY, sortFieldField);
        referenceDataEntityLIst.add(referenceDataEntity);

        when(
                referenceDataService.getEntities(csvDefaultCustomerAccountSortOrder, 1, Constants.SORT_KEY,
                        sortFieldField)).thenReturn(referenceDataEntityLIst);
        entityMap = customerAccountsRefDataBean.getTertiarySortKey(sortFieldField);
        assertNotNull(entityMap);
    }

    @Test
    public final void test_getTertiarySortKey_Empty() {
        Map<String, String> entityMap = customerAccountsRefDataBean.getTertiarySortKey("");
        assertNotNull(entityMap);
    }

    @Test
    public final void test_getApiKeySupportedFor360() {
        Map<String, String> entityMap = new HashMap<String, String>();
        String apiKey = "RTM";
        boolean is360_api = Boolean.TRUE;
        entityMap.put(Constants.API_KEY, apiKey);

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAllowableClient360,
                entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.API_KEY, apiKey);

        when(referenceDataService.getEntity(csvAllowableClient360, 1, entityFilterMap)).thenReturn(referenceDataEntity);
        Map<String, Boolean> result = customerAccountsRefDataBean.getApiKeySupportedFor360(apiKey, is360_api);
        assertNotNull(result);
    }

    @Test
    public final void test_getApiKeySupportedFor360_emptyEntityMap() {
        Map<String, String> entityMap = new HashMap<String, String>();
        String apiKey = "RTM1";
        boolean is360_api = Boolean.TRUE;
        // entityMap.put(Constants.API_KEY, apiKey );

        ReferenceDataEntity<String> referenceDataEntity = new ReferenceDataEntity<String>(csvAllowableClient360,
                entityMap);

        Map<String, String> entityFilterMap = new HashMap<String, String>();
        entityFilterMap.put(Constants.API_KEY, apiKey);

        when(referenceDataService.getEntity(csvAllowableClient360, 1, entityFilterMap)).thenReturn(referenceDataEntity);
        Map<String, Boolean> result = customerAccountsRefDataBean.getApiKeySupportedFor360(apiKey, is360_api);
        assertNotNull(result);
    }

}
