package com.capitalone.api.customersaccounts.service.convert.response;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import static org.junit.Assert.*;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs.AcctListInfo;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class XESRelatedAcctISResponseConverterTest {
    @InjectMocks
    private XESRelatedAcctISResponseConverter xesRelatedAcctISResponseConverter;

    @Test
    public void testConvert() {
        // xesRelatedAcctISResponseConverter=new XESRelatedAcctISResponseConverter();
        AcctListInfo acctListInfo = new AcctListInfo();
        acctListInfo.setCustAcctFromRelationshipCd("1212");
        acctListInfo.setCustAcctToRelationshipCd("12122");
        acctListInfo.setAcctID("445455");
        acctListInfo.setFISApplicationSystemCd("fdfsd");
        XESRelationshipResponseBean xesRelationshipResponseBean = xesRelatedAcctISResponseConverter
                .convert(acctListInfo);
        assertNotNull(xesRelationshipResponseBean);
    }

}
