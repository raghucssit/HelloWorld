package com.capitalone.api.customersaccounts.service.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientResponseContext;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.StatusType;
import javax.ws.rs.ext.MessageBodyReader;

import org.apache.commons.configuration.Configuration;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;

import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.test.categories.UnitTest;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class RESTAPIErrorResponseFilterTest {

    @Mock
    private MessageBodyReader<ErrorResponse> autoLoanAccountErrorMessageBodyReader;

    @Mock
    ClientRequestContext reqContext;

    @Mock
    ClientResponseContext resContext;

    @Mock
    StatusType statusType;
    
    @Mock
    private Configuration config;

    private RESTAPIErrorResponseFilter restAPIErrorRespFilter;

    @Before
    public void setUp() {
        restAPIErrorRespFilter = new RESTAPIErrorResponseFilter();
        Whitebox.setInternalState(restAPIErrorRespFilter, autoLoanAccountErrorMessageBodyReader);
        Whitebox.setInternalState(restAPIErrorRespFilter, config);
    }

    // @Test(expected=CustomerAPIRESTException.class)
    @Test
    public void test_filter() throws IOException {
        byte[] byteArray = {2, 3, 4};
        InputStream inputStream = new ByteArrayInputStream(byteArray);
        Mockito.when(resContext.getStatusInfo()).thenReturn(statusType);

        Mockito.when(resContext.getEntityStream()).thenReturn(inputStream);

        Mockito.when(statusType.getFamily()).thenReturn(Response.Status.Family.OTHER);

        restAPIErrorRespFilter.filter(reqContext, resContext);
    }
    
    @Test
    public void test_filter1() throws IOException {
        byte[] byteArray = {2, 3, 4};
        InputStream inputStream = new ByteArrayInputStream(byteArray);
        Mockito.when(resContext.getStatusInfo()).thenReturn(statusType);

        Mockito.when(resContext.getEntityStream()).thenReturn(inputStream);

        Mockito.when(statusType.getFamily()).thenReturn(Response.Status.Family.SUCCESSFUL);

        restAPIErrorRespFilter.filter(reqContext, resContext);
    }
    
    @Test
    public void test_filter2() throws IOException {
        byte[] byteArray = {2, 3, 4};
        InputStream inputStream = new ByteArrayInputStream(byteArray);
        Mockito.when(resContext.getStatusInfo()).thenReturn(statusType);

        Mockito.when(resContext.getEntityStream()).thenReturn(inputStream);

        Mockito.when(statusType.getFamily()).thenReturn(Response.Status.Family.INFORMATIONAL);

        restAPIErrorRespFilter.filter(reqContext, resContext);
    }
    
    @Test
    public void test_filter3() throws IOException {
        //byte[] byteArray = {2, 3, 4};
        //InputStream inputStream = new ByteArrayInputStream(byteArray);
        InputStream inputStream = null;
        Mockito.when(resContext.getStatusInfo()).thenReturn(statusType);

        Mockito.when(resContext.getEntityStream()).thenReturn(inputStream);

        Mockito.when(statusType.getFamily()).thenReturn(Response.Status.Family.INFORMATIONAL);

        restAPIErrorRespFilter.filter(reqContext, resContext);
    }
    
}
