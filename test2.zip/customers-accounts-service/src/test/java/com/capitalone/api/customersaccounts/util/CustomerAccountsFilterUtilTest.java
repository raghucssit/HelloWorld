/**
 * Copyright 2014 Capital One Financial Corporation
 * All Rights Reserved.
 *
 * This software contains valuable trade secrets and proprietary
 * information of Capital One and is protected by law. It may not
 * be copied or distributed in any form or medium, disclosed to third
 * parties, reverse engineered or used in any manner without prior
 * written authorization from Capital One
 */

package com.capitalone.api.customersaccounts.util;

import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;

@SuppressWarnings({"static-access"})
public class CustomerAccountsFilterUtilTest {
    // private final static Log log = LogFactory.getLog(CustomerAccountsFilterUtilTest.class);
    @Autowired
    @InjectMocks
    private CustomerAccountsFilterUtil customerAccountsFilterUtil;

    protected Set<String> businessLineSet = null;

    protected Set<String> productTypeSet = null;

    protected Set<String> soRIDSet = null;

    protected List<CustomerAccountKey> customerAccountKeyList = null;

    protected CustomerAccountKey customerAccountKey = null;

    protected List<CustomerAccountsResponse> custAccountList = null;

    protected CustomerAccountsResponse customerAccountsResponse = null;

    @SuppressWarnings("unchecked")
    @Before
    public final void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        businessLineSet = mock(TreeSet.class);
        productTypeSet = mock(TreeSet.class);
        soRIDSet = mock(TreeSet.class);
        customerAccountKeyList = mock(ArrayList.class);
        customerAccountKey = mock(CustomerAccountKey.class);
        custAccountList = mock(ArrayList.class);
        customerAccountsResponse = mock(CustomerAccountsResponse.class);
    }

    @Test
    public void filterbySoRIDSuccess() {
        soRIDSet = new TreeSet<String>();
        soRIDSet.add("185");
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("185"));
        customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(customerAccountKey);
        Assert.assertNotSame(customerAccountKeyList,
                customerAccountsFilterUtil.filterbySoRID(customerAccountKeyList, soRIDSet));
    }

    @Test
    public void filterbySoRIDFailure1() {
        soRIDSet = new TreeSet<String>();
        customerAccountKey.setSorId(new Short("185"));
        customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(customerAccountKey);
        Assert.assertEquals(customerAccountKeyList,
                customerAccountsFilterUtil.filterbySoRID(customerAccountKeyList, soRIDSet));
    }

    @Test
    public void filterbySoRIDFailure2() {
        soRIDSet = new TreeSet<String>();
        customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        Assert.assertEquals(customerAccountKeyList,
                customerAccountsFilterUtil.filterbySoRID(customerAccountKeyList, soRIDSet));
    }

    @Test
    public void filterbySoRIDS_SettingNullObject1() {
        soRIDSet = null;
        Assert.assertNotSame(customerAccountKeyList, customerAccountsFilterUtil.filterbySoRID(null, soRIDSet));
    }

    @Test
    public void filterbySoRIDS_SettingNullObject2() {
        soRIDSet = new TreeSet<String>();
        Assert.assertNotSame(customerAccountKeyList, customerAccountsFilterUtil.filterbySoRID(null, soRIDSet));
    }

    @Test
    public void filterbySoRIDS_SettingNullObject3() {
        soRIDSet = new TreeSet<String>();
        soRIDSet.add("185");
        Assert.assertNotSame(customerAccountKeyList, customerAccountsFilterUtil.filterbySoRID(null, soRIDSet));
    }

    @Test
    public void filterbyProductTypeSuccess() {
        productTypeSet = new TreeSet<String>();
        productTypeSet.add("CC");
        custAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setProductTypeDescription("CREDITCARD");
        custAccountList.add(customerAccountsResponse);
        Assert.assertNotSame(custAccountList,
                customerAccountsFilterUtil.filterByProductType(custAccountList, productTypeSet));
    }

    @Test
    public void filterbyProductTypeFailure1() {
        productTypeSet = new TreeSet<String>();
        custAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setProductTypeDescription("CREDITCARD");
        custAccountList.add(customerAccountsResponse);
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByProductType(custAccountList, productTypeSet));
    }

    @Test
    public void filterbyProductType_settingNullObject1() {
        productTypeSet = null;
        custAccountList = new ArrayList<CustomerAccountsResponse>();
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByProductType(custAccountList, productTypeSet));
    }

    @Test
    public void filterbyProductType_settingNullObject2() {
        productTypeSet = new TreeSet<String>();
        custAccountList = null;
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByProductType(custAccountList, productTypeSet));
    }

    @Test
    public void filterbyProductType() {
        productTypeSet = new TreeSet<String>();
        List<CustomerAccountsResponse> custAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setProductTypeCode("CC");
        custAccountList.add(response);
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByProductType(custAccountList, productTypeSet));
    }

    @Test
    public void filterbyProductTypeFailure2() {
        productTypeSet = new TreeSet<String>();
        custAccountList = new ArrayList<CustomerAccountsResponse>();
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByProductType(custAccountList, productTypeSet));
    }

    @Test
    public void filterbyBusinessLineSuccess() {
        businessLineSet = new TreeSet<String>();
        businessLineSet.add("DEPOSITS");
        custAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setBusinessLine("deposits");
        custAccountList.add(customerAccountsResponse);
        Assert.assertNotSame(custAccountList,
                customerAccountsFilterUtil.filterByBusinessLine(custAccountList, businessLineSet));
    }

    @Test
    public void filterbyBusinessLineFailure1() {
        businessLineSet = new TreeSet<String>();
        custAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setBusinessLine("deposits");
        custAccountList.add(customerAccountsResponse);
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByBusinessLine(custAccountList, businessLineSet));
    }

    @Test
    public void filterbyBusinessLineFailure2() {
        businessLineSet = new TreeSet<String>();
        custAccountList = new ArrayList<CustomerAccountsResponse>();
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByBusinessLine(custAccountList, businessLineSet));
    }

    @Test
    public void filterbyBusinessLine_passingNullObject() {
        businessLineSet = null;
        custAccountList = new ArrayList<CustomerAccountsResponse>();
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByBusinessLine(custAccountList, businessLineSet));
    }

    @Test
    public void filterbyBusinessLine_passingNullObject1() {
        businessLineSet = new TreeSet<String>();
        custAccountList = null;
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByBusinessLine(custAccountList, businessLineSet));
    }

    @Test
    public void filterbyBusinessLine_passingNullObject2() {
        businessLineSet = new TreeSet<String>();
        List<CustomerAccountsResponse> custAccountFinalList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponse.setBusinessLine("");
        custAccountFinalList.add(customerAccountsResponse);
        custAccountList = new ArrayList<CustomerAccountsResponse>();
        custAccountList.add(customerAccountsResponse);
        Assert.assertEquals(custAccountList,
                customerAccountsFilterUtil.filterByBusinessLine(custAccountList, businessLineSet));
    }

}
