package com.capitalone.api.customersaccounts.dao.impl;

import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.powermock.reflect.Whitebox;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.ProfileAccountRelationshipsDao;
import com.capitalone.api.customersaccounts.service.convert.response.ProfileAccountRelationshipsISResponseConverter;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;
import com.capitalone.profileaccountrelationshipsis.v1.AccountRelationshipRq;
import com.capitalone.profileaccountrelationshipsis.v1.AccountRelationshipRs;
import com.capitalone.profileaccountrelationshipsis.v1.AccountRelationshipRs.Cmd;
import com.capitalone.profileaccountrelationshipsis.v1.DepositAccountCustomerRoleTypes;
import com.capitalone.profileaccountrelationshipsis.v1.ProfileAccountRelationshipsISSOAP;

/**
 * @author oto081
 * 
 */

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class ProfileAccountRelationshipsDAOImplTest {

    ProfileAccountRelationshipsDao profileAccountRelationshipsDAOImpl;

    @Mock
    private ProfileAccountRelationshipsISSOAP profileAccountRelationshipsISSOAP;

    @Mock
    private ConversionService conversionService;

    /*
     * @Mock private PingService pingService;
     */

    @Mock
    private ProfileAccountRelationshipsISResponseConverter profileAccountRelationshipsISResponseConverter;

    private EPFContext context;

    private static final String ACCOUNT_NO = "4000176";

    private static final String CUST_ID = "20001";

    @Before
    public void setUp() throws Exception {
        profileAccountRelationshipsDAOImpl = new ProfileAccountRelationshipsDaoImpl();
        Whitebox.setInternalState(profileAccountRelationshipsDAOImpl, ConversionService.class, conversionService);
        // Whitebox.setInternalState(profileAccountRelationshipsDAOImpl, PingService.class, pingService);
        Whitebox.setInternalState(profileAccountRelationshipsDAOImpl, profileAccountRelationshipsISSOAP);
        Whitebox.setInternalState(profileAccountRelationshipsDAOImpl,
                ProfileAccountRelationshipsISResponseConverter.class, profileAccountRelationshipsISResponseConverter);

        context = new EPFContext();
        EPFContextContainer.getcurrentContext().set(context);

    }

    @SuppressWarnings("unchecked")
    @Test
    public final void test_retrieve() throws InterruptedException, ExecutionException {
        AccountRelationshipRq nativeRequest = new AccountRelationshipRq();

        AccountRelationshipRs nativeResponse = new AccountRelationshipRs();
        nativeResponse.setCmd(new Cmd());

        DepositAccountCustomerRoleTypes depositAccountCustomerRoleTypes = new DepositAccountCustomerRoleTypes();
        depositAccountCustomerRoleTypes.setCustomerID(CUST_ID);
        nativeResponse.getCmd().getDepositAccountCustomerRoleTypes().add(depositAccountCustomerRoleTypes);

        ProfileRelationshipLookup response = new ProfileRelationshipLookup();

        when(conversionService.convert(Mockito.anyObject(), Mockito.any(Class.class))).thenReturn(nativeRequest);

        when(profileAccountRelationshipsISSOAP.profileAccountRelationshipsInq(nativeRequest))
                .thenReturn(nativeResponse);
        when(profileAccountRelationshipsISResponseConverter.convert(nativeResponse, CUST_ID, ACCOUNT_NO)).thenReturn(
                response);

        profileAccountRelationshipsDAOImpl.retrieve(context, CUST_ID, ACCOUNT_NO, "key");

    }

    @SuppressWarnings("unchecked")
    @Test
    public final void test_retrieve_Exception() throws InterruptedException, ExecutionException {
        AccountRelationshipRq nativeRequest = new AccountRelationshipRq();

        AccountRelationshipRs nativeResponse = new AccountRelationshipRs();
        nativeResponse.setCmd(new Cmd());

        DepositAccountCustomerRoleTypes depositAccountCustomerRoleTypes = new DepositAccountCustomerRoleTypes();
        depositAccountCustomerRoleTypes.setCustomerID(CUST_ID);
        nativeResponse.getCmd().getDepositAccountCustomerRoleTypes().add(depositAccountCustomerRoleTypes);

        ProfileRelationshipLookup response = new ProfileRelationshipLookup();

        when(conversionService.convert(Mockito.anyObject(), Mockito.any(Class.class))).thenReturn(nativeRequest);

        when(profileAccountRelationshipsISSOAP.profileAccountRelationshipsInq(nativeRequest)).thenThrow(
                new NullPointerException());
        when(profileAccountRelationshipsISResponseConverter.convert(nativeResponse, CUST_ID, ACCOUNT_NO)).thenReturn(
                response);

        profileAccountRelationshipsDAOImpl.retrieve(context, CUST_ID, ACCOUNT_NO, "key");

    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
