package com.capitalone.api.customersaccounts.service.convert.request;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class CSTBusinessCustomerRqConverterTest {
    private CSTBusinessCustomerRqConverter converter;

    @Test
    public final void test_Convert() {
        converter = new CSTBusinessCustomerRqConverter();
        Assert.assertNotNull(converter.convert("12345"));

    }

}
