package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.exception.NotFoundException;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferenceInfo;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInput;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRq;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRs;
import com.capitalone.olbaccountpreferencesis.v1.OLBAccountPreferencesISSoap;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRq.Cmd;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class OLBAccountPreferencesISDAOImplTest {

    @InjectMocks
    private OLBAccountPreferencesISDAOImpl accountPreferencesISDAOImpl;

    @Mock
    private EPFContext context;

    @Mock
    private ConversionService conversionService;

    @Mock
    private OLBAccountPreferencesISSoap olbAccountPreferencesISSoap;

    @Test
    public void testGetAccountNickname() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableOlbrAccountNickname(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("12");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);
        CustomerAccountKey accountKey = new CustomerAccountKey();
        accountKey.setAccountNumber("12345678912");
        accountKey.setConsumerId("12345");
        accountKey.setSorId((short) 12);
        List<CustomerAccountKey> listCustomerAccountKey = new ArrayList<CustomerAccountKey>();
        listCustomerAccountKey.add(accountKey);
        ProfileReferenceId profileReferenceId = new ProfileReferenceId("49", "eeee871593", "LGIN");
        customerAccountsRequest.setCustomerAccountKeyList(listCustomerAccountKey);
        customerAccountsRequest.setProfileReferenceId(profileReferenceId);

        AccountPreferencesInqRq accountPreferencesInqRq = new AccountPreferencesInqRq();
        Cmd cmd = new Cmd();
        AccountPreferencesInput accountPreferencesInput = new AccountPreferencesInput();
        accountPreferencesInput.setPermLginTxt("eeee871593");
        cmd.setAccountPreferencesInput(accountPreferencesInput);
        accountPreferencesInqRq.setCmd(cmd);

        Mockito.when(conversionService.convert(customerAccountsRequest, AccountPreferencesInqRq.class)).thenReturn(
                accountPreferencesInqRq);

        AccountPreferencesInqRs nativeResponse = new AccountPreferencesInqRs();
        com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRs.Cmd cmdRs = new com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRs.Cmd();
        AccountPreferenceInfo accountPreferenceInfo = new AccountPreferenceInfo();
        accountPreferenceInfo.setAcctID("12345678912");
        accountPreferenceInfo.setAcctNknmNm("olbr Account Nickname");
        accountPreferenceInfo.setSoRID((short) 12);
        cmdRs.getAccountPreferenceInfo().add(accountPreferenceInfo);
        nativeResponse.setCmd(cmdRs);

        Mockito.when(olbAccountPreferencesISSoap.accountPreferencesInq(accountPreferencesInqRq)).thenReturn(
                nativeResponse);

        List<OLBResponse> listOlbrResponse = new ArrayList<OLBResponse>();
        OLBResponse olbResponse = new OLBResponse();
        olbResponse.setAccountId("12345678912");
        olbResponse.setOlbAccountNickname("olbr Account Nickname");
        olbResponse.setSorId("12");
        listOlbrResponse.add(olbResponse);

        Mockito.when(conversionService.convert(nativeResponse, List.class)).thenReturn(listOlbrResponse);

        Future<List<OLBResponse>> futureOlbrResponse = accountPreferencesISDAOImpl.getAccountNickname(context,
                customerAccountsRequest);
        assertThat(futureOlbrResponse.get().get(0).getAccountId(), equalTo("12345678912"));
        assertThat(futureOlbrResponse.get().get(0).getOlbAccountNickname(), equalTo("olbr Account Nickname"));
        assertThat(futureOlbrResponse.get().get(0).getSorId(), equalTo("12"));

    }

    @Test
    public void testGetAccountNicknameException() {
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableOlbrAccountNickname(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("12");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);
        CustomerAccountKey accountKey = new CustomerAccountKey();
        accountKey.setAccountNumber("12345678912");
        accountKey.setConsumerId("12345");
        accountKey.setSorId((short) 12);
        List<CustomerAccountKey> listCustomerAccountKey = new ArrayList<CustomerAccountKey>();
        listCustomerAccountKey.add(accountKey);
        ProfileReferenceId profileReferenceId = new ProfileReferenceId("49", "eeee871593", "LGIN");
        customerAccountsRequest.setCustomerAccountKeyList(listCustomerAccountKey);
        customerAccountsRequest.setProfileReferenceId(profileReferenceId);

        AccountPreferencesInqRq accountPreferencesInqRq = new AccountPreferencesInqRq();
        Cmd cmd = new Cmd();
        AccountPreferencesInput accountPreferencesInput = new AccountPreferencesInput();
        accountPreferencesInput.setPermLginTxt("eeee871593");
        cmd.setAccountPreferencesInput(accountPreferencesInput);
        accountPreferencesInqRq.setCmd(cmd);

        Mockito.when(conversionService.convert(customerAccountsRequest, AccountPreferencesInqRq.class)).thenReturn(
                accountPreferencesInqRq);
        Mockito.when(olbAccountPreferencesISSoap.accountPreferencesInq(accountPreferencesInqRq)).thenThrow(
                NotFoundException.class);
        accountPreferencesISDAOImpl.getAccountNickname(context, customerAccountsRequest);
    }
}
