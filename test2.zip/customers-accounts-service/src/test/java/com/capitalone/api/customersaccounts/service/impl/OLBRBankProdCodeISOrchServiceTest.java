package com.capitalone.api.customersaccounts.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.OLBRBankProdCodeISDAO;
import com.capitalone.api.customersaccounts.service.pojo.OLBRRefData;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class OLBRBankProdCodeISOrchServiceTest {
    
    @InjectMocks
    private OLBRBankProdCodeISOrchService olbrBankProdCodeISOrchService;

    @Mock
    private OLBRBankProdCodeISDAO olbrBankProdCodeISDAO;

    @Mock
    private EPFContext context;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {
        
        List<OLBRRefData> impl = new ArrayList<OLBRRefData>();
        Mockito.when(olbrBankProdCodeISDAO.getProductInfo()).thenReturn(impl);
        List<OLBRRefData> response = olbrBankProdCodeISOrchService.execute();
        
        assertNotNull(response);
    }

}
