package com.capitalone.api.customersaccounts.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.LoansHomeLoansDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class HomeLoansAccountsOrchServiceTest {

    @InjectMocks
    private HomeLoansAccountsOrchService service;

    @Mock
    private LoansHomeLoansDao dao;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId((short) 56);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(customerAccountKey);

        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        REASResponse homeLoanAccountResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        customerAccountResponseList.add(customerAccountsResponse);
        homeLoanAccountResponse.setCustomerAccountsResponseList(customerAccountResponseList);
        EPFContext context = EPFContextContainer.getContext();
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("2");
        // reasSupportedSORID.add("56");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        REASResponse reasResponse = new REASResponse();
        reasResponse.setCustomerAccountsResponseList(customerAccountResponseList);

        Mockito.when(dao.getHomeLoanAccounts(context, customerAccountKey)).thenReturn(
                new AsyncResult<REASResponse>(homeLoanAccountResponse));

        Mockito.when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
        .thenReturn((reasResponse));

        Future<REASResponse> response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);
        // assertThat(response.get().getCustomerAccountsResponseList().get(0).getAccountNumber(),
        // equalTo("12345678912"));
    }

    @Test
    public void testExecute_nullRequest() throws InterruptedException, ExecutionException {

        Future<REASResponse> response = service.execute(null, null);
        assertNotNull(response);

    }

    @Test
    public void testExecute_supportedSorIdNull() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId((short) 56);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(customerAccountKey);

        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        REASResponse homeLoanAccountResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        customerAccountResponseList.add(customerAccountsResponse);
        homeLoanAccountResponse.setCustomerAccountsResponseList(customerAccountResponseList);
        EPFContext context = EPFContextContainer.getContext();

        customerAccountsRequest.setReasSupportedSORID(null);

        REASResponse reasResponse = new REASResponse();
        reasResponse.setCustomerAccountsResponseList(customerAccountResponseList);

        Mockito.when(dao.getHomeLoanAccounts(context, customerAccountKey)).thenReturn(
                new AsyncResult<REASResponse>(homeLoanAccountResponse));

        Future<REASResponse> response = service.execute(customerAccountsRequest, null);
        assertNotNull(response);

    }

    @Test
    public void testExecute_diffSupportedSorId() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId((short) 7);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(customerAccountKey);

        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        REASResponse homeLoanAccountResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        customerAccountResponseList.add(customerAccountsResponse);
        homeLoanAccountResponse.setCustomerAccountsResponseList(customerAccountResponseList);
        EPFContext context = EPFContextContainer.getContext();
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("2");
        // reasSupportedSORID.add("56");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        REASResponse reasResponse = new REASResponse();
        reasResponse.setCustomerAccountsResponseList(customerAccountResponseList);

        Mockito.when(dao.getHomeLoanAccounts(context, customerAccountKey)).thenReturn(
                new AsyncResult<REASResponse>(homeLoanAccountResponse));

     

        Future<REASResponse> response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);
        // assertThat(response.get().getCustomerAccountsResponseList().get(0).getAccountNumber(),
        // equalTo("12345678912"));
    }

}
