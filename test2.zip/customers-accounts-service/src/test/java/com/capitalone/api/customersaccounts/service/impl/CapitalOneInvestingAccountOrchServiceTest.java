package com.capitalone.api.customersaccounts.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.CapitalOneInvestingAccountDAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CapitalOneInvestingAccountOrchServiceTest {

    @InjectMocks
    private CapitalOneInvestingAccountOrchService capitalOneInvestingAccountOrchService;

    @Mock
    private EPFContext context;

    @Mock
    private CapitalOneInvestingAccountDAO capitalOneInvestingAccountDAO;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        List<CustomerAccountKey> listCustomerAccountKey = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("PER");
        customerAccountKey.setConsumerId("123456");
        customerAccountKey.setSorId((short) 199);
        listCustomerAccountKey.add(customerAccountKey);
        accountsRequest.setCustomerAccountKeyList(listCustomerAccountKey);

        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountsResponse> listCustomerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAccountNumber("12345678912");
        customerAccountsResponse.setProductName("Investing");
        customerAccountsResponse.setCurrentBalance(new BigDecimal("1230"));
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1430"));
        customerAccountsResponse.setCurrencyCode("USD");
        customerAccountsResponse.setOpenDate(new Instant());
        listCustomerAccountsResponses.add(customerAccountsResponse);
        reasResponse.setCustomerAccountsResponseList(listCustomerAccountsResponses);
        Mockito.when(capitalOneInvestingAccountDAO.getInvestingAccount(context, accountsRequest)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));
        Mockito.when(customerAccountsUtil.findSORID(accountsRequest, Integer.valueOf(Constants.SOR_ID_COI)))
                .thenReturn(true);
        Future<REASResponse> futureReasResponse = capitalOneInvestingAccountOrchService.execute(accountsRequest,
                context);
        assertThat(futureReasResponse.get().getCustomerAccountsResponseList().get(0).getAccountId(),
                equalTo("12345678912"));

        assertThat(futureReasResponse.get().getCustomerAccountsResponseList().get(0).getAccountNumber(),
                equalTo("12345678912"));
        assertThat(futureReasResponse.get().getCustomerAccountsResponseList().get(0).getProductName(),
                equalTo("Investing"));
        assertThat(futureReasResponse.get().getCustomerAccountsResponseList().get(0).getCurrentBalance(),
                equalTo(new BigDecimal("1230")));
        assertThat(futureReasResponse.get().getCustomerAccountsResponseList().get(0).getAvailableBalance(),
                equalTo(new BigDecimal("1430")));
        assertThat(futureReasResponse.get().getCustomerAccountsResponseList().get(0).getCurrencyCode(), equalTo("USD"));

    }
}
