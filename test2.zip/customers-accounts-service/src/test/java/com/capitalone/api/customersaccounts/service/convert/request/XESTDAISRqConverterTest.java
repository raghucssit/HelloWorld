package com.capitalone.api.customersaccounts.service.convert.request;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xestdais.v1.AcctInqISRq;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class XESTDAISRqConverterTest {

    @InjectMocks
    private XESTDAISRqConverter xestdaisRqConverter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public void testConvertCustomerAccountKey() {

        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("1234");
        AcctInqISRq acctInqISRq = xestdaisRqConverter.convert(customerAccountKey);
        assertThat(acctInqISRq.getCmd().getAcctID(), is("1234"));
    }

}
