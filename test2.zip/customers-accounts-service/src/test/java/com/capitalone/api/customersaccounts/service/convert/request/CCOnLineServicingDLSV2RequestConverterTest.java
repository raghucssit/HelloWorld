package com.capitalone.api.customersaccounts.service.convert.request;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.cconlineservicingdlsv2.v2.AcctSumryDLSInqRq;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CCOnLineServicingDLSV2RequestConverterTest {

    @InjectMocks
    private CCOnLineServicingDLSV2RequestConverter converter;

    @Test
    public void testConvert() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(customerAccountKey);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        request.setAppVersion(Constants.APP_VERSION4);
        request.setEnableModifiedOrchestrationSwitch(true);
        AcctSumryDLSInqRq response = converter.convert(customerAccountKeyList);
        assertThat(response.getCmd().getAcctArray().get(0).getAcct().getAcctID(), is("12345678912"));
    }

    @Test
    public void testConvertNull() {
        // CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        AcctSumryDLSInqRq response = converter.convert(customerAccountKeyList);
        assertThat(response, is(nullValue()));
    }

}
