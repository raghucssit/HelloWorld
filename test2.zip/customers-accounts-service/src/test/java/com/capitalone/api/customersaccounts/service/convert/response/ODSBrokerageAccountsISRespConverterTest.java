package com.capitalone.api.customersaccounts.service.convert.response;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRs;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRs.Cmd;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRs.Cmd.AccountsBalancesArray;
import com.capitalone.xmlmsgset._2004._07.eil.SevrtyType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class ODSBrokerageAccountsISRespConverterTest {
    @InjectMocks
    private ODSBrokerageAccountsISRespConverter odsBrokerageAccountsISRespConverter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public void testConvert() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        acctBal.setAcctID("12345");
        acctBal.setAggMktVal(new BigDecimal("1234"));
        acctBal.setOpenDate(new Instant(20150624));
        acctBal.setSoRID((short) 102);
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        StatType stat = new StatType();
        stat.setSevrty(SevrtyType.ERROR);
        stat.setStatCd((long) 1420);
        cmd.setStat(stat);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }

    @Test
    public void testConvert_WithNullValues() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        short sorId = 0;
        acctBal.setSoRID(sorId);
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        StatType stat = new StatType();
        stat.setSevrty(SevrtyType.ERROR);
        cmd.setStat(stat);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }

    @Test
    public void testConvert_WithSeverityDefault() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        StatType stat = new StatType();
        stat.setSevrty(SevrtyType.INFO);
        stat.setStatCd((long) 1420);
        cmd.setStat(stat);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }

    @Test
    public void testConvert_WithSeverityNull() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        StatType stat = new StatType();
        stat.setSevrty(null);
        stat.setStatCd((long) 1420);
        cmd.setStat(stat);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }

    @Test
    public void testConvert_StatCode_120134() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        acctBal.setAcctID("12345");
        acctBal.setAggMktVal(new BigDecimal("1234"));
        acctBal.setOpenDate(new Instant(20150624));
        acctBal.setSoRID((short) 102);
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        StatType stat = new StatType();
        stat.setSevrty(SevrtyType.ERROR);
        stat.setStatCd((long) 120134);
        cmd.setStat(stat);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }

    @Test
    public void testConvert_StatCode_null() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        acctBal.setAcctID("12345");
        acctBal.setAggMktVal(new BigDecimal("1234"));
        acctBal.setOpenDate(new Instant(20150624));
        acctBal.setSoRID((short) 102);
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        StatType stat = new StatType();
        stat.setSevrty(SevrtyType.ERROR);
        cmd.setStat(stat);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }

    @Test
    public void testConvert_statWithNull() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        acctBal.setAcctID("12345");
        acctBal.setAggMktVal(new BigDecimal("1234"));
        acctBal.setOpenDate(new Instant(20150624));
        acctBal.setSoRID((short) 102);
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }

    @Test
    public void testConvert_nativeResponseCmd_null() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }

    @Test
    public void testConvert_nativeResponse_null() {
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(null);
        assertNotNull(response);
    }

    @Test
    public void testConvert_AccountsBalancesArray_Null() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        Cmd cmd = new Cmd();
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }
    
    @Test
    public void testConvert_populateBalanceInq() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        acctBal.setAcctID("12345");
        acctBal.setAggMktVal(new BigDecimal("1234"));
        acctBal.setOpenDate(new Instant(20150624));
        acctBal.setSoRID((short) 102);
        acctBal.setRecCntlStatDesc("SUCCESS");
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        StatType stat = new StatType();
        stat.setSevrty(SevrtyType.ERROR);
        stat.setStatCd((long) 1420);
        cmd.setStat(stat);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }
    
    @Test
    public void testConvert_populateBalanceInq_withEmptyValue() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        acctBal.setAcctID(" ");
        //acctBal.setAggMktVal(new BigDecimal("1234"));
        //acctBal.setOpenDate(new Instant(20150624));
        //acctBal.setSoRID((short) 102);
        acctBal.setRecCntlStatDesc("SUCCESS");
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        StatType stat = new StatType();
        stat.setSevrty(SevrtyType.ERROR);
        stat.setStatCd((long) 1420);
        cmd.setStat(stat);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }
    
    @Test
    public void testConvert_populateBalanceInq_NotSuccess() {
        BalancesInqRs nativeResponse = new BalancesInqRs();
        BalancesInqRs.Cmd cmd = new BalancesInqRs.Cmd();
        List<AccountsBalancesArray> odsBrokerageaccountslist = new ArrayList<AccountsBalancesArray>();
        AccountsBalancesArray acctBal = new AccountsBalancesArray();
        acctBal.setAcctID(" ");
        //acctBal.setAggMktVal(new BigDecimal("1234"));
        //acctBal.setOpenDate(new Instant(20150624));
        acctBal.setSoRID((short) 0);
        acctBal.setRecCntlStatDesc("FAIL");
        odsBrokerageaccountslist.add(acctBal);
        cmd.getAccountsBalancesArray().add(acctBal);
        StatType stat = new StatType();
        stat.setSevrty(SevrtyType.ERROR);
        stat.setStatCd((long) 1420);
        cmd.setStat(stat);
        nativeResponse.setCmd(cmd);
        REASResponse response = odsBrokerageAccountsISRespConverter.convert(nativeResponse);
        assertNotNull(response);
    }

}
