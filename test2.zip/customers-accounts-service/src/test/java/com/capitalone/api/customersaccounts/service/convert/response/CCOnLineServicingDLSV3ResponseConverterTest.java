package com.capitalone.api.customersaccounts.service.convert.response;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.AcctArray;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.AcctArray.Acct;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.AcctArray.CardImage;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.AcctArray.CardNum;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.AcctArray.CrCdAcct;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.AcctArray.LoanAcct;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.AcctArray.Prod;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.AcctArray.SoR;
import com.capitalone.cconlineservicingdlsv3.v3.AcctSumryDLSInqRs.Cmd.AcctSummary.Parm;
import com.capitalone.xmlmsgset._2004._07.eil.SevrtyType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType.AddnStat;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class CCOnLineServicingDLSV3ResponseConverterTest {

    @InjectMocks
    private CCOnLineServicingDLSV3ResponseConverter converter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Mock
    CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void test_success_addStat_1420() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(1420);
        st.setStatDesc("desc");

        st.setSevrty(SevrtyType.ERROR);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_addStat_120335() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(120335);
        st.setStatDesc("desc");

        st.setSevrty(SevrtyType.ERROR);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_addStat_120135() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(120135);
        st.setStatDesc("desc");

        st.setSevrty(SevrtyType.ERROR);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_addStat_120134() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(120134);
        st.setStatDesc("desc");

        st.setSevrty(SevrtyType.ERROR);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_addStat_100031() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(100031);
        st.setStatDesc("desc");

        st.setSevrty(SevrtyType.ERROR);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_addStat_100000() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(100000);
        st.setStatDesc("desc");

        st.setSevrty(SevrtyType.ERROR);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }// 2300

    @Test
    public void test_success_addStat_2300() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(2300);
        st.setStatDesc("desc");

        st.setSevrty(SevrtyType.ERROR);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_addStat_Default() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(1);
        st.setStatDesc("desc");

        st.setSevrty(SevrtyType.ERROR);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_WARNING_120109() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(120109);
        st.setStatDesc("desc");
        st.setSrvrStatCd("0");
        st.setSevrty(SevrtyType.WARNING);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);
        // getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_WARNING() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(1);
        st.setStatDesc("desc");
        st.setSrvrStatCd("0");
        st.setSevrty(SevrtyType.WARNING);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_settingNullresponse() {
        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();

        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(0);
        st.setStatDesc("desc");
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");

        acctArray1.setProd(prod_value);
        acctArray1.setCardNum(new CardNum());
        acctArray1.getCardNum().setAcctPlstcID("dfgdfhghjj");

        acctArray1.getAcct().setClsdInd(false);
        // Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(null);
        acctArray1.getAcct().setPresBal(null);
        CardImage cardImg = null;
        // cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(null);
        crcdacct.setCurrOustdMinmPmtDueAmt(null);
        crcdacct.setMinmPmtDueDt(null);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        // nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);
        // getAcctArray().add(acctArray1);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_setAcctStat_1() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(100000);
        st.setStatDesc("desc");

        st.setSevrty(SevrtyType.ERROR);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray loanAcctArray = new AcctArray();
        loanAcctArray.setLoanAcct(new LoanAcct());
        loanAcctArray.setAcct(new Acct());

        loanAcctArray.setSoR(new SoR());
        loanAcctArray.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        loanAcctArray.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        loanAcctArray.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        loanAcctArray.setCardImage(cardImg);

        loanAcctArray.getLoanAcct().setChrgdOffInd(true);
        Instant date = new Instant(12345);

        loanAcctArray.getAcct().setOpenDt(null);
        loanAcctArray.getAcct().setClsdInd(false);
        loanAcctArray.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        loanAcctArray.setCrCdAcct(crcdacct);

        value.getAcctArray().add(loanAcctArray);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = null;
        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 12)).thenReturn(additionalStatList);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(loanAcctArray);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);
    }

    @Test
    public void test_success_WARNING_PARTIAL_SUCCESS() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(120109);
        st.setStatDesc("desc");
        st.setSrvrStatCd("0");
        st.setSevrty(SevrtyType.WARNING);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = new AdditionalStat();
        arg0.setStatCd(200091L);

        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 200)).thenReturn(additionalStatList);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_WARNING_PARTIAL_SUCCESS1() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(120109);
        st.setStatDesc("desc");
        st.setSrvrStatCd("0");
        st.setSevrty(SevrtyType.WARNING);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = new AdditionalStat();
        arg0.setStatCd(1L);

        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 200)).thenReturn(additionalStatList);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_WARNING_LOOKASIDE_DATA() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(120148);
        st.setStatDesc("desc");
        st.setSrvrStatCd("0");
        st.setSevrty(SevrtyType.WARNING);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = new AdditionalStat();
        arg0.setStatCd(200091L);

        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 200)).thenReturn(additionalStatList);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_DefaultSevrty() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(120148);
        st.setStatDesc("desc");
        st.setSrvrStatCd("0");
        st.setSevrty(SevrtyType.INFO);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(true);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        cmd.setAcctSummary(value);
        nativeResponse.setCmd(cmd);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = new AdditionalStat();
        arg0.setStatCd(200091L);

        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 200)).thenReturn(additionalStatList);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }

    @Test
    public void test_success_HAModeFields() {

        AcctSumryDLSInqRs nativeResponse = new AcctSumryDLSInqRs();
        AcctSumryDLSInqRs.Cmd cmd = new AcctSumryDLSInqRs.Cmd();
        StatType st = new StatType();
        st.setStatCd(120148);
        st.setStatDesc("desc");
        st.setSrvrStatCd("0");
        st.setSevrty(SevrtyType.INFO);
        cmd.setStat(st);
        AcctSummary value = new AcctSummary();

        AcctArray acctArray1 = new AcctArray();
        acctArray1.setAcct(new Acct());
        acctArray1.getAcct().setAcctID("10000276449");
        acctArray1.setSoR(new SoR());
        acctArray1.getSoR().setSoRID(BigInteger.valueOf(Integer.valueOf(7)));
        Prod prod_value = new Prod();
        prod_value.setProdDesc("Product_Desc");
        acctArray1.setProd(prod_value);

        CardNum cardNum = new CardNum();
        cardNum.setAcctPlstcID("12345678");
        acctArray1.setCardNum(cardNum);

        LoanAcct loanAcct = new LoanAcct();
        loanAcct.setChrgdOffInd(Boolean.TRUE);
        acctArray1.setLoanAcct(loanAcct);

        CardImage cardImg = new CardImage();
        cardImg.setCardImageCode("CardImage");
        acctArray1.setCardImage(cardImg);

        acctArray1.getAcct().setClsdInd(false);
        Instant date = new Instant(12345);

        acctArray1.getAcct().setOpenDt(date);
        acctArray1.getAcct().setPresBal(new BigDecimal(12));

        CrCdAcct crcdacct = new CrCdAcct();
        crcdacct.setOTBAmt(new BigDecimal(32));
        crcdacct.setCurrOustdMinmPmtDueAmt(new BigDecimal(32));
        crcdacct.setMinmPmtDueDt(date);
        acctArray1.setCrCdAcct(crcdacct);

        value.getAcctArray().add(acctArray1);
        Instant odsload = new Instant("20101010");
        Parm parm_value = new Parm();
        parm_value.setODSLoadTS(odsload);
        value.setParm(parm_value);
        cmd.setAcctSummary(value);

        nativeResponse.setCmd(cmd);

        nativeResponse.getCmd().getAcctSummary().getAcctArray().add(acctArray1);

        nativeResponse.getCmd().getAcctSummary().getParm().setODSLoadTS(odsload);

        List<AdditionalStat> additionalStatList = new ArrayList<AdditionalStat>();
        AdditionalStat arg0 = new AdditionalStat();
        arg0.setStatCd(200091L);

        additionalStatList.add(arg0);
        List<AddnStat> addnStatList = new ArrayList<AddnStat>();
        when(customerAccountsUtil.addnStatConverter(addnStatList, 200)).thenReturn(additionalStatList);

        REASResponse reas_response = converter.convert(nativeResponse);
        assertNotNull(reas_response);

    }
}
