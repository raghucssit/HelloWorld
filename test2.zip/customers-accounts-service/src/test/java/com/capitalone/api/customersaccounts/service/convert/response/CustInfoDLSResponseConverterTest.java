package com.capitalone.api.customersaccounts.service.convert.response;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Cust;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.CustAcctRoleType;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class CustInfoDLSResponseConverterTest {

    @InjectMocks
    private CustInfoDLSRsConverter converter;

    @Test
    public void testConvert() {
        List<CustInfo> listCustInfo = new ArrayList<CustInfo>();
        CustInfo custInfo = new CustInfo();
        Acct acct = new Acct();
        acct.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        custInfo.setAcct(acct);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        listCustInfo.add(custInfo);
        Map<String, String> mapCustRole = converter.convert(listCustInfo);
        assertThat(mapCustRole.get("564034|12345678912"), equalTo("Primary"));
    }

}
