
package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.OecpPreferencesDefaultDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class OecpPreferencesOrchServiceTest {

	@InjectMocks
	private OecpPreferencesOrchService oecpPreferencesOrchService;

	@Mock
	private OecpPreferencesDefaultDao oecpPreferencesDao;

	@Mock
	private EPFContext epfContext;

	@Test
    public void testExecute() {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();

        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Personal");
        customerAccountKey.setConsumerId("123");
        customerAccountKey.setSorId((short) 7);
        List<CustomerAccountKey> listCustomerAccountKey = new ArrayList<CustomerAccountKey>();
        listCustomerAccountKey.add(customerAccountKey);
        customerAccountsRequest.setCustomerESCID("999999");
        customerAccountsRequest.setAccountNickNameHystrixEnabled(false);
        customerAccountsRequest.setCustomerAccountKeyList(listCustomerAccountKey);

        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("7");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);
        List<OecpPreferResponse> oecpPreferResponses = new ArrayList<OecpPreferResponse>();
        OecpPreferResponse oecpPreferResponse = new OecpPreferResponse();
        oecpPreferResponse.setAccountId("12345678912");
        oecpPreferResponse.setCustomerId("123");
        oecpPreferResponse.setAccountNickname("BNKNM");
        oecpPreferResponses.add(oecpPreferResponse);
        Mockito.when(oecpPreferencesDao.retrieveAccountNickname(epfContext, customerAccountsRequest.getCustomerESCID()))
                .thenReturn(new AsyncResult<List<OecpPreferResponse>>(oecpPreferResponses));
        oecpPreferencesOrchService.execute(customerAccountsRequest, epfContext);
    }
}
