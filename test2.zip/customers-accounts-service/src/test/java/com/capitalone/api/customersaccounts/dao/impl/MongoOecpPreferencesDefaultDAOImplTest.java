package com.capitalone.api.customersaccounts.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customer.pref.model.v3.DigitalProfile;
import com.capitalone.api.customer.pref.model.v3.DigitalProfiles;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.api.security.CryptoSerializerDeserializer;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.EndpointManager;
import com.capitalone.epf.servicelocator.model.EndpointProperties;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class MongoOecpPreferencesDefaultDAOImplTest {

    @InjectMocks
    private MongoOecpPreferencesDefaultDAOImpl mongoOecpPreferencesDAOImpl;

    @Mock
    private Client eapiRestClient;

    @Mock
    private EndpointManager endpointManager;

    @Mock
    private ReferenceIdEncoder encoder;

    @Mock
    private ConversionService conversionService;

    @Mock
    private WebTarget requestPath;

    @Mock
    private WebTarget target;

    @Mock
    private Builder builder;

    @Mock
    private EPFContext context;

    @Mock
    private Configuration config;

    @Mock
    private CryptoSerializerDeserializer crypto;

    @Mock
    private EndpointProperties endpointProperties;

    @Test
    public void getCustomSortOrderDetailsTest() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "int-mongo-oecp-preferences-Service", null, null);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setProfileReferenceId(new ProfileReferenceId("profileType=LGIN~~sorId=49~~ssoId=eeee460958"));
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-mongo-oecp-preferences-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json")).thenReturn(builder);

        Future<List<String>> response;
        DigitalProfile digitalProfile = new DigitalProfile();
        String[] accountSort = {"12", "11", "13"};
        digitalProfile.setAccountDisplayOrder(accountSort);
        Mockito.when(builder.get(DigitalProfile.class)).thenReturn(digitalProfile);
        Mockito.when(crypto.encrypt("profileType=LGIN~~sorId=49~~ssoId=eeee460958")).thenReturn(
                "KA2sd6Qmlcm926qYtiDcrw==");
        response = mongoOecpPreferencesDAOImpl.getCustomSortOrderDetails(request, context);
    }

    @Test
    public void getCustomSortOrderDetailsTest_nullProfileRefId() throws Exception {
        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "int-mongo-oecp-preferences-Service", null, null);
        Future<List<String>> response;
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setProfileReferenceId(null);

        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-mongo-oecp-preferences-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json")).thenReturn(builder);

        DigitalProfile digitalProfile = new DigitalProfile();
        String[] accountSort = {"12", "11", "13"};
        digitalProfile.setAccountDisplayOrder(accountSort);
        Mockito.when(builder.get(DigitalProfile.class)).thenReturn(digitalProfile);
        response = mongoOecpPreferencesDAOImpl.getCustomSortOrderDetails(request, context);
    }

    @Test
    public void getCustomSortOrderDetailsTest_nullSSOID() throws Exception {
        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "int-mongo-oecp-preferences-Service", null, null);
        Future<List<String>> response;
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setProfileReferenceId(new ProfileReferenceId(" "));

        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-mongo-oecp-preferences-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json")).thenReturn(builder);

        DigitalProfile digitalProfile = new DigitalProfile();
        String[] accountSort = {"12", "11", "13"};
        digitalProfile.setAccountDisplayOrder(accountSort);
        Mockito.when(builder.get(DigitalProfile.class)).thenReturn(digitalProfile);
        response = mongoOecpPreferencesDAOImpl.getCustomSortOrderDetails(request, context);
    }

    @Test
    public void getCustomSortOrderDetailsTest_invalid_SSOID() throws Exception {
        Future<List<String>> response;
        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "int-mongo-oecp-preferences-Service", null, null);

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        request.setProfileReferenceId(new ProfileReferenceId("profileType=LGIN~~sorId=49~~ssoId=eeee460958"));

        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-mongo-oecp-preferences-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json")).thenReturn(builder);

        DigitalProfile digitalProfile = new DigitalProfile();
        String[] accountSort = {"12", "11", "13"};
        digitalProfile.setAccountDisplayOrder(accountSort);
        Mockito.when(builder.get(DigitalProfile.class)).thenReturn(digitalProfile);
        Mockito.when(crypto.encrypt("ssoid")).thenReturn("KA2sd6Qmlcm926qYtiDcrw==");
        response = mongoOecpPreferencesDAOImpl.getCustomSortOrderDetails(request, context);
    }

    @Test
    public void getCustomSortOrderDetailsTest_EmptyAccountDisplayOrder() throws Exception {
        Future<List<String>> response;
        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "int-mongo-oecp-preferences-Service", null, null);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setProfileReferenceId(new ProfileReferenceId("profileType=LGIN~~sorId=49~~ssoId=eeee460958"));
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-mongo-oecp-preferences-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json")).thenReturn(builder);

        DigitalProfile digitalProfile = new DigitalProfile();
        // digitalProfile.setAccountDisplayOrder("12,11,13");
        Mockito.when(builder.get(DigitalProfile.class)).thenReturn(digitalProfile);
        Mockito.when(crypto.encrypt("profileType=LGIN~~sorId=49~~ssoId=eeee460958")).thenReturn(
                "KA2sd6Qmlcm926qYtiDcrw==");
        response = mongoOecpPreferencesDAOImpl.getCustomSortOrderDetails(request, context);
    }
    
    @Test
    public void getCustomSortOrderDetailsTest_withDigitalProfiles() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "int-mongo-oecp-preferences-Service", null, null);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setProfileReferenceId(new ProfileReferenceId("profileType=LGIN~~sorId=49~~ssoId=eeee460958"));
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-mongo-oecp-preferences-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json")).thenReturn(builder);

        Future<List<String>> response;
        DigitalProfiles digitalProfiles = new DigitalProfiles();
        DigitalProfile digitalProfile = new DigitalProfile();
        String[] accountSort = {"12", "11", "13"};
        digitalProfile.setAccountDisplayOrder(accountSort);
        List<DigitalProfile> profiles =new ArrayList<DigitalProfile>();
        profiles.add(digitalProfile);
        digitalProfiles.setProfiles(profiles );
        //digitalProfile.setAccountDisplayOrder(accountSort);
        Mockito.when(builder.get(DigitalProfiles.class)).thenReturn(digitalProfiles);
        Mockito.when(crypto.encrypt("profileType=LGIN~~sorId=49~~ssoId=eeee460958")).thenReturn(
                "KA2sd6Qmlcm926qYtiDcrw==");
        response = mongoOecpPreferencesDAOImpl.getCustomSortOrderDetails(request, context);
    }
    
    @Test
    public void getCustomSortOrderDetailsTest_withNullSortOrder() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "int-mongo-oecp-preferences-Service", null, null);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setProfileReferenceId(new ProfileReferenceId("profileType=LGIN~~sorId=49~~ssoId=eeee460958"));
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-mongo-oecp-preferences-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json")).thenReturn(builder);

        Future<List<String>> response;
        DigitalProfiles digitalProfiles = new DigitalProfiles();
        DigitalProfile digitalProfile = new DigitalProfile();
        //String[] accountSort = {"12", "11", "13"};
        //digitalProfile.setAccountDisplayOrder(accountSort);
        List<DigitalProfile> profiles =new ArrayList<DigitalProfile>();
        profiles.add(digitalProfile);
        digitalProfiles.setProfiles(profiles );
        
        Mockito.when(builder.get(DigitalProfiles.class)).thenReturn(digitalProfiles);
        Mockito.when(crypto.encrypt("profileType=LGIN~~sorId=49~~ssoId=eeee460958")).thenReturn(
                "KA2sd6Qmlcm926qYtiDcrw==");
        response = mongoOecpPreferencesDAOImpl.getCustomSortOrderDetails(request, context);
    }
    
    @Test
    public void getCustomSortOrderDetailsTest_Excep() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "int-mongo-oecp-preferences-Service", null, null);

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setProfileReferenceId(new ProfileReferenceId("profileType=LGIN~~sorId=49~~ssoId=eeee460958"));
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-mongo-oecp-preferences-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json")).thenReturn(null);

        Future<List<String>> response;
        DigitalProfiles digitalProfiles = new DigitalProfiles();
        DigitalProfile digitalProfile = new DigitalProfile();
        //String[] accountSort = {"12", "11", "13"};
        //digitalProfile.setAccountDisplayOrder(accountSort);
        List<DigitalProfile> profiles =new ArrayList<DigitalProfile>();
        profiles.add(digitalProfile);
        digitalProfiles.setProfiles(profiles );
        
        Mockito.when(builder.get(DigitalProfiles.class)).thenReturn(digitalProfiles);
        Mockito.when(crypto.encrypt("profileType=LGIN~~sorId=49~~ssoId=eeee460958")).thenReturn(
                "KA2sd6Qmlcm926qYtiDcrw==");
        response = mongoOecpPreferencesDAOImpl.getCustomSortOrderDetails(request, context);
    }

}
