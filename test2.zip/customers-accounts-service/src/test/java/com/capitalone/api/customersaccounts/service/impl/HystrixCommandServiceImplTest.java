
package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.MongoOecpPreferencesHystrixDAO;
import com.capitalone.api.customersaccounts.dao.OecpPreferencesHystrixDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class HystrixCommandServiceImplTest {

	@InjectMocks
	private HystrixCommandServiceImpl hystrixCommandService;

	@Mock
	private EPFContext context;

	@Mock
	private OecpPreferencesHystrixDao oecpPreferencesDao;

	@Mock
	private MongoOecpPreferencesHystrixDAO mongoOecpPreferencesDAO;

	@Test
	public void testRetrieveAccountNickname() throws Exception {
		CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
		customerAccountsRequest.setCustomerESCID("123456");
		OecpPreferResponse oecpPreferResponse = new OecpPreferResponse();
		List<OecpPreferResponse> listNickname = new ArrayList<OecpPreferResponse>();
		listNickname.add(oecpPreferResponse);
		Future<List<OecpPreferResponse>> response = new AsyncResult<List<OecpPreferResponse>>(listNickname);
		Mockito.when(oecpPreferencesDao.retrieveAccountNickname(context, customerAccountsRequest.getCustomerESCID()))
			   .thenReturn(response);

		hystrixCommandService.retrieveAccountNickname(context, customerAccountsRequest);

	}

	@Test
	public void testFallbackOecpNickName() throws Exception {
		CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
		customerAccountsRequest.setCustomerESCID("123456");
		OecpPreferResponse oecpPreferResponse = new OecpPreferResponse();
		List<OecpPreferResponse> listNickname = new ArrayList<OecpPreferResponse>();
		listNickname.add(oecpPreferResponse);
		Future<List<OecpPreferResponse>> response = new AsyncResult<List<OecpPreferResponse>>(listNickname);
		Mockito.when(oecpPreferencesDao.retrieveAccountNickname(context, customerAccountsRequest.getCustomerESCID()))
			   .thenReturn(response);

		List<OecpPreferResponse> responseNickname = hystrixCommandService.fallbackOecpNickName(context,
																							   customerAccountsRequest);
		Assert.assertNull(responseNickname);
	}

	@Test
	public void testRetriveCustomSortOrderDetails() throws Exception {
		CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
		customerAccountsRequest.setCustomerESCID("123456");
		List<String> listSortOrder = new ArrayList<String>();
		listSortOrder.add("r9tQDqnpsSkg2qUEOFvXq8f37AkF4vzQxutIfmlRRqY=");
		listSortOrder.add("r9tQDqnpsSkg2qUEOFvXq3t9G2hI3TFxIirQbgw+OVY=");
		Future<List<String>> sortOrderResponse = new AsyncResult<List<String>>(listSortOrder);
		Mockito.when(mongoOecpPreferencesDAO.getCustomSortOrderDetails(customerAccountsRequest, context))
			   .thenReturn(sortOrderResponse);

		hystrixCommandService.retriveCustomSortOrderDetails(customerAccountsRequest, context);

	}

	@Test
	public void testFallBackSortOrder() throws Exception {
		CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
		customerAccountsRequest.setCustomerESCID("123456");
		List<String> listSortOrder = new ArrayList<String>();
		listSortOrder.add("r9tQDqnpsSkg2qUEOFvXq8f37AkF4vzQxutIfmlRRqY=");
		listSortOrder.add("r9tQDqnpsSkg2qUEOFvXq3t9G2hI3TFxIirQbgw+OVY=");
		Future<List<String>> sortOrderResponse = new AsyncResult<List<String>>(listSortOrder);
		Mockito.when(mongoOecpPreferencesDAO.getCustomSortOrderDetails(customerAccountsRequest, context))
			   .thenReturn(sortOrderResponse);

		List<String> responseSortOrder = hystrixCommandService.fallBackSortOrder(customerAccountsRequest, context);
		Assert.assertNull(responseSortOrder);
	}

}
