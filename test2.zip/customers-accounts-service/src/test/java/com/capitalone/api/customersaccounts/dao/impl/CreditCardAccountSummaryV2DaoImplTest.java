package com.capitalone.api.customersaccounts.dao.impl;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.cconlineservicingdlsv2.v2.AcctSumryDLSInqRq;
import com.capitalone.cconlineservicingdlsv2.v2.AcctSumryDLSInqRq.Cmd;
import com.capitalone.cconlineservicingdlsv2.v2.AcctSumryDLSInqRq.Cmd.AcctArray;
import com.capitalone.cconlineservicingdlsv2.v2.AcctSumryDLSInqRq.Cmd.AcctArray.Acct;
import com.capitalone.cconlineservicingdlsv2.v2.AcctSumryDLSInqRq.Cmd.AcctArray.SoR;
import com.capitalone.cconlineservicingdlsv2.v2.AcctSumryDLSInqRs;
import com.capitalone.cconlineservicingdlsv2.v2.CCOnLineServicingDLSSoap;

import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CreditCardAccountSummaryV2DaoImplTest {

    @InjectMocks
    private CreditCardAccountSummaryV2DaoImpl daoImpl;

    @Mock
    private ConversionService conversionService;

    @Mock
    private CCOnLineServicingDLSSoap ccOnLineServicingDLSSoap;
    
    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testRetrieveCreditCardAccountummary() throws InterruptedException, ExecutionException {

        EPFContext context = EPFContextContainer.getContext();

        // REASResponse response1;
        Future<REASResponse> response = null;
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12334");
        keyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);
        String appVersion ="V3";
        String appversionSwitch="V4";
        AcctArray acctArray = new AcctArray();
        SoR soR = new SoR();
        soR.setSoRID(new BigInteger("12"));
        acctArray.setSoR(soR);

        AcctSumryDLSInqRq nativeRequest = new AcctSumryDLSInqRq();
        AcctSumryDLSInqRq.Cmd cmd = new AcctSumryDLSInqRq.Cmd();
        AcctSumryDLSInqRq.Cmd.AcctArray acctarray = new AcctSumryDLSInqRq.Cmd.AcctArray();
        Acct acct = new Acct();
        acct.setAcctID("12345678912");
        acctarray.setAcct(acct);
        cmd.setName("name");
        cmd.getAcctArray().add(acctarray);
        nativeRequest.setCmd(cmd);
        /*
         * nativeRequest.getCmd().setName("AcctSumryDLSInqRq"); nativeRequest.getCmd().getAcctArray().add(acctArray);
         */

        AcctSumryDLSInqRs acctSumryDLSInqRs = new AcctSumryDLSInqRs();
        acctSumryDLSInqRs.setCmd(new AcctSumryDLSInqRs.Cmd());
        acctSumryDLSInqRs.getCmd().setName("AcctSumryDLSInqRs");

        REASResponse convertedResponse = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Cards");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(customerAccountsResponse);
        convertedResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        Mockito.when(conversionService.convert(keyList, AcctSumryDLSInqRq.class)).thenReturn(nativeRequest);

        Mockito.when(ccOnLineServicingDLSSoap.accountSummaryInq(nativeRequest)).thenReturn(acctSumryDLSInqRs);

        Mockito.when(conversionService.convert(acctSumryDLSInqRs, REASResponse.class)).thenReturn(convertedResponse);

        response = daoImpl.retrieveCreditCardAccountSummary(context, keyList,appVersion,appversionSwitch);
        assertThat(response.get().getCustomerAccountsResponseList().get(0).getBusinessLine(), equalTo("Cards"));

    }

    @Test
    public void testRetrieveCreditCardAccountummaryFail() {
        EPFContext context = EPFContextContainer.getContext();

        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        // customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);

        AcctArray acctArray = new AcctArray();
        SoR soR = new SoR();
        soR.setSoRID(new BigInteger("12"));
        acctArray.setSoR(soR);
        String appVersion ="V3";
        String appversionSwitch="V4";
        AcctSumryDLSInqRq nativeRequest = new AcctSumryDLSInqRq();
        nativeRequest.setCmd(new Cmd());
        nativeRequest.getCmd().setName("AcctSumryDLSInqRq");
        nativeRequest.getCmd().getAcctArray().add(acctArray);

        AcctSumryDLSInqRs acctSumryDLSInqRs = new AcctSumryDLSInqRs();
        acctSumryDLSInqRs.setCmd(new AcctSumryDLSInqRs.Cmd());
        acctSumryDLSInqRs.getCmd().setName("AcctSumryDLSInqRs");

        List<CustomerAccountsResponse> convertedResponse = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Cards");
        convertedResponse.add(customerAccountsResponse);
        reasResponse.setCustomerAccountsResponseList(convertedResponse);

        Mockito.when(conversionService.convert(keyList, AcctSumryDLSInqRq.class)).thenReturn(nativeRequest);

        Mockito.when(ccOnLineServicingDLSSoap.accountSummaryInq(nativeRequest)).thenThrow(new NullPointerException());

        Mockito.when(conversionService.convert(acctSumryDLSInqRs, List.class)).thenReturn(convertedResponse);

        daoImpl.retrieveCreditCardAccountSummary(context, keyList,appVersion,appversionSwitch);

    }
    
    @Test
    public void testRetrieveCreditCardAccount_Null() {
        EPFContext context = EPFContextContainer.getContext();

        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        // customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);

        AcctArray acctArray = new AcctArray();
        SoR soR = new SoR();
        soR.setSoRID(new BigInteger("12"));
        acctArray.setSoR(soR);
        String appVersion ="V3";
        String appversionSwitch="V4";
        AcctSumryDLSInqRq nativeRequest = new AcctSumryDLSInqRq();
        nativeRequest.setCmd(new Cmd());
        nativeRequest.getCmd().setName("AcctSumryDLSInqRq");
        nativeRequest.getCmd().getAcctArray().add(acctArray);

        AcctSumryDLSInqRs acctSumryDLSInqRs = new AcctSumryDLSInqRs();
        acctSumryDLSInqRs.setCmd(new AcctSumryDLSInqRs.Cmd());
        acctSumryDLSInqRs.getCmd().setName("AcctSumryDLSInqRs");

        List<CustomerAccountsResponse> convertedResponse = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Cards");
        convertedResponse.add(customerAccountsResponse);
        reasResponse.setCustomerAccountsResponseList(convertedResponse);

        Mockito.when(conversionService.convert(keyList, AcctSumryDLSInqRq.class)).thenReturn(nativeRequest);

        Mockito.when(ccOnLineServicingDLSSoap.accountSummaryInq(nativeRequest)).thenReturn(null);

        Mockito.when(conversionService.convert(acctSumryDLSInqRs, List.class)).thenReturn(convertedResponse);

        daoImpl.retrieveCreditCardAccountSummary(context, keyList,appVersion,appversionSwitch);

    }
    
    @Test
    public void testRetrieveCreditCardAccount_cmdNull() {
        EPFContext context = EPFContextContainer.getContext();

        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        // customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);

        AcctArray acctArray = new AcctArray();
        SoR soR = new SoR();
        soR.setSoRID(new BigInteger("12"));
        acctArray.setSoR(soR);
        String appVersion ="V3";
        String appversionSwitch="V4";
        AcctSumryDLSInqRq nativeRequest = new AcctSumryDLSInqRq();
        nativeRequest.setCmd(new Cmd());
        nativeRequest.getCmd().setName("AcctSumryDLSInqRq");
        nativeRequest.getCmd().getAcctArray().add(acctArray);

        AcctSumryDLSInqRs acctSumryDLSInqRs = new AcctSumryDLSInqRs();
        //acctSumryDLSInqRs.setCmd(new AcctSumryDLSInqRs.Cmd());
        //acctSumryDLSInqRs.getCmd().setName("AcctSumryDLSInqRs");

        List<CustomerAccountsResponse> convertedResponse = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Cards");
        convertedResponse.add(customerAccountsResponse);
        reasResponse.setCustomerAccountsResponseList(convertedResponse);

        Mockito.when(conversionService.convert(keyList, AcctSumryDLSInqRq.class)).thenReturn(nativeRequest);

        Mockito.when(ccOnLineServicingDLSSoap.accountSummaryInq(nativeRequest)).thenReturn(acctSumryDLSInqRs);

        Mockito.when(conversionService.convert(acctSumryDLSInqRs, List.class)).thenReturn(convertedResponse);

        daoImpl.retrieveCreditCardAccountSummary(context, keyList,appVersion,appversionSwitch);

    }
    
    @Test
    public void testRetrieveCreditCardAccount_withCardAcctBlocked() throws InterruptedException, ExecutionException {

        EPFContext context = EPFContextContainer.getContext();

        // REASResponse response1;
        Future<REASResponse> response = null;
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12334");
        keyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);
        String appVersion ="V3";
        String appversionSwitch="V3";
        AcctArray acctArray = new AcctArray();
        SoR soR = new SoR();
        soR.setSoRID(new BigInteger("12"));
        acctArray.setSoR(soR);

        AcctSumryDLSInqRq nativeRequest = new AcctSumryDLSInqRq();
        AcctSumryDLSInqRq.Cmd cmd = new AcctSumryDLSInqRq.Cmd();
        AcctSumryDLSInqRq.Cmd.AcctArray acctarray = new AcctSumryDLSInqRq.Cmd.AcctArray();
        Acct acct = new Acct();
        acct.setAcctID("12345678912");
        acctarray.setAcct(acct);
        cmd.setName("name");
        cmd.getAcctArray().add(acctarray);
        nativeRequest.setCmd(cmd);
        /*
         * nativeRequest.getCmd().setName("AcctSumryDLSInqRq"); nativeRequest.getCmd().getAcctArray().add(acctArray);
         */

        AcctSumryDLSInqRs acctSumryDLSInqRs = new AcctSumryDLSInqRs();
        acctSumryDLSInqRs.setCmd(new AcctSumryDLSInqRs.Cmd());
        acctSumryDLSInqRs.getCmd().setName("AcctSumryDLSInqRs");
        acctSumryDLSInqRs.getCmd().setStat(new StatType());
        acctSumryDLSInqRs.getCmd().getStat().setStatCd(120148);

        REASResponse convertedResponse = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Cards");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(customerAccountsResponse);
        convertedResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        Mockito.when(conversionService.convert(keyList, AcctSumryDLSInqRq.class)).thenReturn(nativeRequest);

        Mockito.when(ccOnLineServicingDLSSoap.accountSummaryInq(nativeRequest)).thenReturn(acctSumryDLSInqRs);

        Mockito.when(conversionService.convert(acctSumryDLSInqRs, REASResponse.class)).thenReturn(convertedResponse);

        response = daoImpl.retrieveCreditCardAccountSummary(context, keyList,appVersion,appversionSwitch);
        //assertThat(response.get().getCustomerAccountsResponseList().get(0).getBusinessLine(), equalTo("Cards"));

    }
    
    @Test
    public void testRetrieveCreditCardAccount_withPartialSuccess() throws InterruptedException, ExecutionException {

        EPFContext context = EPFContextContainer.getContext();

        // REASResponse response1;
        Future<REASResponse> response = null;
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12334");
        keyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);
        String appVersion ="V3";
        String appversionSwitch="V3";
        AcctArray acctArray = new AcctArray();
        SoR soR = new SoR();
        soR.setSoRID(new BigInteger("12"));
        acctArray.setSoR(soR);

        AcctSumryDLSInqRq nativeRequest = new AcctSumryDLSInqRq();
        AcctSumryDLSInqRq.Cmd cmd = new AcctSumryDLSInqRq.Cmd();
        AcctSumryDLSInqRq.Cmd.AcctArray acctarray = new AcctSumryDLSInqRq.Cmd.AcctArray();
        Acct acct = new Acct();
        acct.setAcctID("12345678912");
        acctarray.setAcct(acct);
        cmd.setName("name");
        cmd.getAcctArray().add(acctarray);
        nativeRequest.setCmd(cmd);
        /*
         * nativeRequest.getCmd().setName("AcctSumryDLSInqRq"); nativeRequest.getCmd().getAcctArray().add(acctArray);
         */

        AcctSumryDLSInqRs acctSumryDLSInqRs = new AcctSumryDLSInqRs();
        acctSumryDLSInqRs.setCmd(new AcctSumryDLSInqRs.Cmd());
        acctSumryDLSInqRs.getCmd().setName("AcctSumryDLSInqRs");
        acctSumryDLSInqRs.getCmd().setStat(new StatType());
        acctSumryDLSInqRs.getCmd().getStat().setStatCd(120109);

        REASResponse convertedResponse = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Cards");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(customerAccountsResponse);
        convertedResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        Mockito.when(conversionService.convert(keyList, AcctSumryDLSInqRq.class)).thenReturn(nativeRequest);

        Mockito.when(ccOnLineServicingDLSSoap.accountSummaryInq(nativeRequest)).thenReturn(acctSumryDLSInqRs);

        Mockito.when(conversionService.convert(acctSumryDLSInqRs, REASResponse.class)).thenReturn(convertedResponse);

        response = daoImpl.retrieveCreditCardAccountSummary(context, keyList,appVersion,appversionSwitch);
        //assertThat(response.get().getCustomerAccountsResponseList().get(0).getBusinessLine(), equalTo("Cards"));

    }


    @Test
    public void testRetrieveCreditCardAccountummaryNull() {
        EPFContext context = EPFContextContainer.getContext();

        Future<REASResponse> response = null;
        List<CustomerAccountKey> keyList = null;
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        String appVersion= "V3";
        String appversionSwitch="V4";
        AcctSumryDLSInqRq nativeRequest = new AcctSumryDLSInqRq();
        nativeRequest.setCmd(new Cmd());

        Mockito.when(conversionService.convert(keyList, AcctSumryDLSInqRq.class)).thenReturn(nativeRequest);

        response = daoImpl.retrieveCreditCardAccountSummary(context, keyList,appVersion,appversionSwitch);

        assertThat(response, equalTo(null));
    }
}
