package com.capitalone.api.customersaccounts.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.springframework.scheduling.annotation.AsyncResult;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.OLBAccountPreferencesISDAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class OLBAccountPreferencesISOrchServiceTest {

    @InjectMocks
    private OLBAccountPreferencesISOrchService olbAccountPreferencesISOrchService;

    @Mock
    private OLBAccountPreferencesISDAO accountPreferencesISDAO;

    @Mock
    private EPFContext context;

    @Test
    public void testExecuteRetail() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableOlbrAccountNickname(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("2");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);
        CustomerAccountKey accountKey = new CustomerAccountKey();
        accountKey.setAccountNumber("12345678912");
        accountKey.setConsumerId("12345");
        accountKey.setSorId((short) 12);
        List<CustomerAccountKey> listCustomerAccountKey = new ArrayList<CustomerAccountKey>();
        listCustomerAccountKey.add(accountKey);
        customerAccountsRequest.setCustomerAccountKeyList(listCustomerAccountKey);

        ProfileReferenceId profileReferenceId = new ProfileReferenceId("49", "eeee81050322", "LGIN");
        customerAccountsRequest.setProfileReferenceId(profileReferenceId);
        List<OLBResponse> listOlbrResponse = new ArrayList<OLBResponse>();
        OLBResponse olbResponse = new OLBResponse();
        olbResponse.setAccountId("12345678912");
        olbResponse.setOlbAccountNickname("olbr Account Nickname");
        olbResponse.setSorId("12");
        listOlbrResponse.add(olbResponse);
        Mockito.when(accountPreferencesISDAO.getAccountNickname(context, customerAccountsRequest)).thenReturn(
                new AsyncResult<List<OLBResponse>>(listOlbrResponse));
        Future<List<OLBResponse>> listOlbrResponseDao = olbAccountPreferencesISOrchService.execute(
                customerAccountsRequest, context);
        assertThat(listOlbrResponseDao.get().get(0).getAccountId(), equalTo("12345678912"));
        assertThat(listOlbrResponseDao.get().get(0).getOlbAccountNickname(), equalTo("olbr Account Nickname"));
        assertThat(listOlbrResponseDao.get().get(0).getSorId(), equalTo("12"));
    }

    @Test
    public void testExecuteBrokerage() throws InterruptedException, ExecutionException {
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableOlbrAccountNickname(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("2");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);
        CustomerAccountKey accountKey = new CustomerAccountKey();
        accountKey.setAccountNumber("12345678912");
        accountKey.setConsumerId("12345");
        accountKey.setSorId((short) 102);
        List<CustomerAccountKey> listCustomerAccountKey = new ArrayList<CustomerAccountKey>();
        listCustomerAccountKey.add(accountKey);
        customerAccountsRequest.setCustomerAccountKeyList(listCustomerAccountKey);
        ProfileReferenceId profileReferenceId = new ProfileReferenceId("49", "eeee81050322", "LGIN");
        customerAccountsRequest.setProfileReferenceId(profileReferenceId);

        List<OLBResponse> listOlbrResponse = new ArrayList<OLBResponse>();
        OLBResponse olbResponse = new OLBResponse();
        olbResponse.setAccountId("12345678912");
        olbResponse.setOlbAccountNickname("olbr Account Nickname");
        olbResponse.setSorId("102");
        listOlbrResponse.add(olbResponse);
        Mockito.when(accountPreferencesISDAO.getAccountNickname(context, customerAccountsRequest)).thenReturn(
                new AsyncResult<List<OLBResponse>>(listOlbrResponse));
        Future<List<OLBResponse>> listOlbrResponseDao = olbAccountPreferencesISOrchService.execute(
                customerAccountsRequest, context);
        assertThat(listOlbrResponseDao.get().get(0).getAccountId(), equalTo("12345678912"));
        assertThat(listOlbrResponseDao.get().get(0).getOlbAccountNickname(), equalTo("olbr Account Nickname"));
        assertThat(listOlbrResponseDao.get().get(0).getSorId(), equalTo("102"));
    }
}
