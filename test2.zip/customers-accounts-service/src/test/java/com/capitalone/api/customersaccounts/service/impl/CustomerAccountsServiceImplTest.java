package com.capitalone.api.customersaccounts.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Future;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.exception.ApiBusinessException;
import com.capitalone.api.commons.exception.RequestValidationException;
import com.capitalone.api.commons.model.EntityCollectionRequest;
import com.capitalone.api.commons.services.api.EapiServiceableAccountProvider;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.CustomerAccountsKeyDao;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccount;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsOrchResponse;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.CustomerReferenceId;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.api.model.id.ReferenceId;

/**
 * @author Generated
 * @since 1.0
 */
@Category(UnitTest.class)
@RunWith(PowerMockRunner.class)
@PrepareForTest(CollectionUtils.class)
@SuppressWarnings("unchecked")
public class CustomerAccountsServiceImplTest {

    private CustomerAccountsServiceImpl service;

    @Mock
    private CustomerAccountsKeyDao customerAccountsKeyDao;

    @Mock
    private CustomerAccountsKeyDao customerAccountsDao;

    @Mock
    private CustomerAccountsOrchService customerAccountsOrchService;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @Mock
    private CustomerAccountsAggregationService customerAccountsAggregationService;

    @Mock
    private FetchLightWeightECROrchService fetchLightWeightECROrchService;

    @Mock
    private CollectionUtils collectionUtils;

    @Mock
    @Named("restfulApiServiceableAccountProvider")
    private EapiServiceableAccountProvider serviceableAccountProvider;

    @Before
    public void setUp() {
        service = new CustomerAccountsServiceImpl();
        customerAccountsUtil = new CustomerAccountsUtil();
        Whitebox.setInternalState(service, customerAccountsKeyDao);
        Whitebox.setInternalState(service, customerAccountsDao);
        Whitebox.setInternalState(service, customerAccountsOrchService);
        Whitebox.setInternalState(service, customerAccountsRefDataBean);
        Whitebox.setInternalState(service, customerAccountsUtil);
        Whitebox.setInternalState(service, customerAccountsAggregationService);
        Whitebox.setInternalState(service, serviceableAccountProvider);
        Whitebox.setInternalState(service, fetchLightWeightECROrchService);
    }

    @Test(expected = ApiBusinessException.class)
    public void testFetchAccountsAndRelationShip_custId() throws Exception {
        List<CustomerAccount> customerAccountList = new ArrayList<CustomerAccount>();
        CustomerAccount obj = new CustomerAccount();
        customerAccountList.add(obj);
        CustomerAccountsUtil customerAccountsUtil = Mockito.mock(CustomerAccountsUtil.class);
        Whitebox.setInternalState(service, customerAccountsUtil);
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        List<CustomerAccountKey> customerAccountKeyList = null;
        Set<String> filteredSoRIDSet = new HashSet<String>();
        // ReferenceId refereceID = new ReferenceId("3214");
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        request.setCustomerReferenceId(customerReferenceID);
        request.setAppVersion("V3");

        request.setEnableErrorHandlingSwitch(true);
        REASResponse customerAccountsResponseList = new REASResponse();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        customerAccountsResponseList.setCustomerAccountsResponseList(new ArrayList<CustomerAccountsResponse>());
        customerAccountsResponseList.getCustomerAccountsResponseList().add(response);
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        List<CustomerAccountKey> supportedAccountList = new ArrayList<CustomerAccountKey>();
        supportedAccountList.add(key);
        EntityCollectionRequest entityRequest = new EntityCollectionRequest();

        when(customerAccountsRefDataBean.getSupportedAccountsList(customerAccountKeyList)).thenReturn(
                supportedAccountList);
        when(
                customerAccountsUtil.maptoFinalResponse((List<CustomerAccountsResponse>) Mockito.anyObject(),
                        Mockito.anyString(), (List<CustomerAccountKey>) Mockito.anyObject())).thenReturn(
                customerAccountList);
        when(
                customerAccountsUtil.retrieveSoRIDsBasedOnBusinessLineAndProductType((Set<String>) Mockito.anyObject(),
                        (Set<String>) Mockito.anyObject())).thenReturn(filteredSoRIDSet);
        when(customerAccountsOrchService.execute(request)).thenReturn(orchResponse);
        when(customerAccountsAggregationService.execute(orchResponse, true,false,null)).thenReturn(customerAccountsResponseList);
        service.fetchAccountsAndRelationShip(entityRequest, request, "");
    }

    // @Test
    @Test(expected = RequestValidationException.class)
    public void testFetchAccountsAndRelationShip_profRefId() throws Exception {
        List<CustomerAccount> customerAccountList = new ArrayList<CustomerAccount>();
        CustomerAccount obj = new CustomerAccount();
        customerAccountList.add(obj);
        CustomerAccountsUtil customerAccountsUtil = Mockito.mock(CustomerAccountsUtil.class);
        Whitebox.setInternalState(service, customerAccountsUtil);
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableErrorHandlingSwitch(true);
        // ReferenceId refereceID = new ReferenceId("3214");
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("3124");
        request.setCustomerReferenceId(customerReferenceID);
        // request.setProfileReferenceId("3214");
        Set<String> businessLineSet = new HashSet<String>();
        Set<String> productTypeSet = new HashSet<String>();
        businessLineSet.add("CREDITS-CARDS");
        businessLineSet.add("LOANS");
        productTypeSet.add("Business Card");
        request.setBusinessLineSet(businessLineSet);
        request.setProductTypeSet(productTypeSet);
        request.setAppVersion("V3");
        CustomerAccountKey key = new CustomerAccountKey();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        key.setAccountNumber("12345678912");
        customerAccountKeyList.add(key);
        Set<String> filteredSoRIDSet = new HashSet<String>();

        REASResponse customerAccountsResponseList = new REASResponse();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        List<CustomerAccountsResponse> list = new ArrayList<CustomerAccountsResponse>();
        list.add(response);
        customerAccountsResponseList.setCustomerAccountsResponseList(list);
        customerAccountsResponseList.getCustomerAccountsResponseList().add(response);
        response.setAccountNickname("CARD_PLSTC");
        response.setBusinessLine("CREDITS-CARDS");
        response.setProductTypeCode("Business Card");
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        List<CustomerAccountKey> supportedAccountList = new ArrayList<CustomerAccountKey>();
        supportedAccountList.add(key);

        Set<String> allBusinessLines = new HashSet<String>();
        allBusinessLines.add("AL");
        allBusinessLines.add("BL");
        EntityCollectionRequest entityRequest = new EntityCollectionRequest();
        when(customerAccountsDao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request)).thenReturn(
                customerAccountKeyList);
        when(customerAccountsRefDataBean.getSupportedAccountsList(customerAccountKeyList)).thenReturn(
                supportedAccountList);
        when(customerAccountsRefDataBean.getAllBusinessLines()).thenReturn(allBusinessLines);

        when(
                customerAccountsUtil.maptoFinalResponse((List<CustomerAccountsResponse>) Mockito.anyObject(),
                        Mockito.anyString(), (List<CustomerAccountKey>) Mockito.anyObject())).thenReturn(
                customerAccountList);
        when(
                customerAccountsUtil.retrieveSoRIDsBasedOnBusinessLineAndProductType((Set<String>) Mockito.anyObject(),
                        (Set<String>) Mockito.anyObject())).thenReturn(filteredSoRIDSet);
        when(customerAccountsOrchService.execute(request)).thenReturn(orchResponse);
        when(customerAccountsAggregationService.execute(orchResponse, true,false,null)).thenReturn(customerAccountsResponseList);
        
        String select = "businessLine";
        service.fetchAccountsAndRelationShip(entityRequest, request, select);
    }

    @Test
    public void testFetchAccountsAndRelationShip_profRefId1() throws Exception {
        List<CustomerAccount> customerAccountList = new ArrayList<CustomerAccount>();
        CustomerAccount obj = new CustomerAccount();
        customerAccountList.add(obj);
        CustomerAccountsUtil customerAccountsUtil = Mockito.mock(CustomerAccountsUtil.class);
        Whitebox.setInternalState(service, customerAccountsUtil);
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableErrorHandlingSwitch(true);
        // ReferenceId refereceID = new ReferenceId("3214");
        CustomerReferenceId customerReferenceID = null;
        request.setCustomerReferenceId(customerReferenceID);
        // request.setProfileReferenceId("3214");
        request.setAppVersion("V3");
        List<String> listCOI = new ArrayList<String>();
        listCOI.add("V5");
        request.setCoiSwitch(listCOI);

        Set<String> businessLineSet = new HashSet<String>(Arrays.asList("a", "b"));

        // Set<String> productTypeSet = new HashSet<String>(Arrays.asList("a", "b"));
        Set<String> filteredSoRIDSet = new HashSet<String>(Arrays.asList("a", "b"));

        request.setBusinessLineSet(businessLineSet);
        CustomerAccountKey key = new CustomerAccountKey();
        key.setSorId((short) 56);
        List<CustomerAccountKey> customerAccountKeyList = null;

        REASResponse customerAccountsResponseList = new REASResponse();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        List<CustomerAccountsResponse> list = new ArrayList<CustomerAccountsResponse>();
        list.add(response);
        customerAccountsResponseList.setCustomerAccountsResponseList(list);
        customerAccountsResponseList.getCustomerAccountsResponseList().add(response);
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        List<CustomerAccountKey> supportedAccountList = new ArrayList<CustomerAccountKey>();
        List<CustomerAccountKey> unSupportedAccountList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey unsupportedAccount = new CustomerAccountKey();
        unSupportedAccountList.add(unsupportedAccount);
        unsupportedAccount.setAccountNumber("12345678912");
        supportedAccountList.add(key);
        EntityCollectionRequest entityRequest = new EntityCollectionRequest();
        when(customerAccountsUtil.filterbySoRID(supportedAccountList, filteredSoRIDSet)).thenReturn(
                supportedAccountList);
        when(customerAccountsDao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request)).thenReturn(
                customerAccountKeyList);
        when(customerAccountsRefDataBean.getSupportedAccountsList(customerAccountKeyList)).thenReturn(
                supportedAccountList);
        when(
                customerAccountsUtil.maptoFinalResponse((List<CustomerAccountsResponse>) Mockito.anyObject(),
                        Mockito.anyString(), (List<CustomerAccountKey>) Mockito.anyObject())).thenReturn(
                customerAccountList);
        when(
                customerAccountsUtil.retrieveSoRIDsBasedOnBusinessLineAndProductType((Set<String>) Mockito.anyObject(),
                        (Set<String>) Mockito.anyObject())).thenReturn(filteredSoRIDSet);
        when(customerAccountsOrchService.execute(request)).thenReturn(orchResponse);
        when(customerAccountsAggregationService.execute(orchResponse, true,false,null)).thenReturn(customerAccountsResponseList);
        PowerMockito.mockStatic(CollectionUtils.class);
        when(CollectionUtils.subtract(supportedAccountList, supportedAccountList)).thenReturn(unSupportedAccountList);

        service.fetchAccountsAndRelationShip(entityRequest, request, null);
    }

    @Test
    public void testfetchCustomerRefID() throws Exception {
        List<CustomerAccount> customerAccountList = new ArrayList<CustomerAccount>();
        CustomerAccount obj = new CustomerAccount();
        customerAccountList.add(obj);
        CustomerAccountsUtil customerAccountsUtil = Mockito.mock(CustomerAccountsUtil.class);
        Whitebox.setInternalState(service, customerAccountsUtil);
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableErrorHandlingSwitch(true);
        CustomerAccountKey key = new CustomerAccountKey();
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        request.setCustomerReferenceId(customerReferenceID);

        EntityCollectionRequest entityRequest = new EntityCollectionRequest();
        REASResponse customerAccountsResponseList = new REASResponse();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        customerAccountsResponseList.setCustomerAccountsResponseList(new ArrayList<CustomerAccountsResponse>());
        customerAccountsResponseList.getCustomerAccountsResponseList().add(response);

        List<CustomerAccountKey> supportedAccountList = new ArrayList<CustomerAccountKey>();
        supportedAccountList.add(key);

        service.fetchCustomerRefID(entityRequest, request);

    }

    @Test
    public void testfetchProfileRefID() throws Exception {
        List<CustomerAccount> customerAccountList = new ArrayList<CustomerAccount>();
        CustomerAccount obj = new CustomerAccount();
        customerAccountList.add(obj);
        CustomerAccountsUtil customerAccountsUtil = Mockito.mock(CustomerAccountsUtil.class);
        Whitebox.setInternalState(service, customerAccountsUtil);
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableErrorHandlingSwitch(true);
        CustomerAccountKey key = new CustomerAccountKey();
        ProfileReferenceId profileReferenceId = new ProfileReferenceId("ssoid");
        request.setProfileReferenceId(profileReferenceId);
        EntityCollectionRequest entityRequest = new EntityCollectionRequest();
        REASResponse customerAccountsResponseList = new REASResponse();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        customerAccountsResponseList.setCustomerAccountsResponseList(new ArrayList<CustomerAccountsResponse>());
        customerAccountsResponseList.getCustomerAccountsResponseList().add(response);
        List<CustomerAccountKey> supportedAccountList = new ArrayList<CustomerAccountKey>();
        supportedAccountList.add(key);

        service.fetchCustomerRefID(entityRequest, request);

    }

    // @Test
    @Test(expected = NullPointerException.class)
    public void testFetchAccountwithEntitelments_profRefId() throws Exception {
        List<CustomerAccount> customerAccountList = new ArrayList<CustomerAccount>();
        CustomerAccount obj = new CustomerAccount();
        customerAccountList.add(obj);
        CustomerAccountsUtil customerAccountsUtil = Mockito.mock(CustomerAccountsUtil.class);
        Whitebox.setInternalState(service, customerAccountsUtil);
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableErrorHandlingSwitch(true);
        ReferenceId refereceID = new ReferenceId("accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805");
        ReferenceId refereceID1 = new ReferenceId("accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510806");
        List<ReferenceId> serviceableAccounts = new ArrayList<ReferenceId>();
        serviceableAccounts.add(refereceID);
        serviceableAccounts.add(refereceID1);
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        request.setCustomerReferenceId(customerReferenceID);

        request.setAppVersion("V3");
        CustomerAccountKey key = new CustomerAccountKey();
        Short sorId = 12;
        key.setSorId(sorId);
        List<CustomerAccountKey> customerAccountKeyList = null;
        Set<String> businessLineSet = new HashSet<String>();
        Set<String> productTypeSet = new HashSet<String>();
        businessLineSet.add("CREDITS-CARDS");
        businessLineSet.add("LOANS");
        productTypeSet.add("Business Card");
        request.setBusinessLineSet(businessLineSet);
        request.setProductTypeSet(productTypeSet);
        Set<String> filteredSoRIDSet = new HashSet<String>();
        filteredSoRIDSet.add("102");
        filteredSoRIDSet.add("23");
        request.setBusinessLineSet(businessLineSet);
        request.setProductTypeSet(productTypeSet);
        REASResponse customerAccountsResponseList = new REASResponse();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNickname("CARD_PLSTC");
        response.setBusinessLine("CREDITS-CARDS");
        response.setProductTypeCode("Business Card");
        List<CustomerAccountsResponse> list = new ArrayList<CustomerAccountsResponse>();
        list.add(response);
        customerAccountsResponseList.setCustomerAccountsResponseList(list);
        // customerAccountsResponseList.getCustomerAccountsResponseList().add(response);
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        List<OecpPreferResponse> oecpResponseList = new ArrayList<OecpPreferResponse>();

        Future<List<OecpPreferResponse>> futureOecpPrefResponse = new AsyncResult<List<OecpPreferResponse>>(
                oecpResponseList);
        orchResponse.setFutureOecpPrefResponse(futureOecpPrefResponse);

        List<CustomerAccountKey> supportedAccountList = null;
        // supportedAccountList.add(key);
        EntityCollectionRequest entityRequest = new EntityCollectionRequest();
        when(customerAccountsDao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request)).thenReturn(
                customerAccountKeyList);
        when(customerAccountsRefDataBean.getSupportedAccountsList(customerAccountKeyList)).thenReturn(
                supportedAccountList);
        when(
                customerAccountsUtil.maptoFinalResponse((List<CustomerAccountsResponse>) Mockito.anyObject(),
                        Mockito.anyString(), (List<CustomerAccountKey>) Mockito.anyObject())).thenReturn(
                customerAccountList);
        when(
                customerAccountsUtil.retrieveSoRIDsBasedOnBusinessLineAndProductType((Set<String>) Mockito.anyObject(),
                        (Set<String>) Mockito.anyObject())).thenReturn(filteredSoRIDSet);

        when(serviceableAccountProvider.getServiceableAccounts()).thenReturn(serviceableAccounts);

        when(serviceableAccountProvider.canProvideServiceableAccounts()).thenReturn(true);
        when(customerAccountsOrchService.execute(request)).thenReturn(orchResponse);
        when(customerAccountsAggregationService.execute(orchResponse, true,false,null)).thenReturn(customerAccountsResponseList);
        
        when(
                customerAccountsAggregationService.retrieveNicknameFromOecp(customerAccountsResponseList,
                        orchResponse.getFutureOecpPrefResponse())).thenReturn(customerAccountsResponseList);
        service.fetchAccountwithEntitelments(entityRequest, request, null);
    }

    // @Test(expected = NotFoundException.class)
    @Test
    public void testFetchAccountwithEntitelments_custId() throws Exception {
        List<CustomerAccount> customerAccountList = new ArrayList<CustomerAccount>();
        CustomerAccount obj = new CustomerAccount();
        customerAccountList.add(obj);
        CustomerAccountsUtil customerAccountsUtil = Mockito.mock(CustomerAccountsUtil.class);
        Whitebox.setInternalState(service, customerAccountsUtil);
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableErrorHandlingSwitch(true);
        CustomerAccountKey key = new CustomerAccountKey();
        List<CustomerAccountKey> customerAccountKeyList = null;

        Set<String> businessLineSet = new HashSet<String>();
        Set<String> productTypeSet = new HashSet<String>();
        Set<String> soRIDSet = new HashSet<String>();
        soRIDSet.add("7");
        businessLineSet.add("CREDITS-CARDS");
        businessLineSet.add("LOANS");
        productTypeSet.add("Business Card");
        request.setBusinessLineSet(businessLineSet);
        request.setProductTypeSet(productTypeSet);
        Set<String> filteredSoRIDSet = new HashSet<String>();
        filteredSoRIDSet.add("7");
        // ReferenceId refereceID = new ReferenceId("3214");
        CustomerReferenceId customerReferenceID = null;
        request.setCustomerReferenceId(customerReferenceID);
        request.setAppVersion("V3");
        REASResponse customerAccountsResponseList = new REASResponse();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNickname("CARD_PLSTC");
        response.setBusinessLine("CREDITS-CARDS");
        response.setProductTypeCode("Business Card");
        customerAccountsResponseList.setCustomerAccountsResponseList(new ArrayList<CustomerAccountsResponse>());
        customerAccountsResponseList.getCustomerAccountsResponseList().add(response);
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        List<CustomerAccountKey> supportedAccountList = new ArrayList<CustomerAccountKey>();
        key.setSorId((short) 7);
        supportedAccountList.add(key);
        when(customerAccountsDao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request)).thenReturn(
                customerAccountKeyList);
        when(customerAccountsRefDataBean.getSupportedAccountsList(customerAccountKeyList)).thenReturn(
                supportedAccountList);
        when(
                customerAccountsUtil.maptoFinalResponse((List<CustomerAccountsResponse>) Mockito.anyObject(),
                        Mockito.anyString(), (List<CustomerAccountKey>) Mockito.anyObject())).thenReturn(
                customerAccountList);
        when(
                customerAccountsUtil.retrieveSoRIDsBasedOnBusinessLineAndProductType((Set<String>) Mockito.anyObject(),
                        (Set<String>) Mockito.anyObject())).thenReturn(filteredSoRIDSet);
        when(customerAccountsUtil.filterbySoRID(supportedAccountList, filteredSoRIDSet)).thenReturn(
                supportedAccountList);
        when(customerAccountsOrchService.execute(request)).thenReturn(orchResponse);
        when(customerAccountsAggregationService.execute(orchResponse, true,false,null)).thenReturn(customerAccountsResponseList);
       
        // service.fetchAccountwithEntitelments(entityRequest, request,null);
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
