package com.capitalone.api.customersaccounts.entity.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.EndpointManager;
import com.capitalone.epf.servicelocator.model.EndpointProperties;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class IntProfileAccountEntityImplTest {
    
    
    @InjectMocks
    private IntProfileAccountEntityImpl impl;

    @Mock
    private ConversionService conversionService;

    @Mock
    private Client eapiRestClient;

    @Mock
    private WebTarget target;

    @Mock
    private EndpointManager endpointManager;

    @Mock
    private ReferenceIdEncoder encoder;

    @Mock
    private Builder builder;

    @Mock
    private EPFContext context;

    @Mock
    Response responseObject;
    
    @Mock
    private CustomerAPIRESTException e;
    
    @Mock
    private CustomerAccountsUtil customerAccountsUtil;
    
    private static final String ENTITLED = "entitled";
    
    @Test
    public void retiveAccountDetailsTest() throws Exception{
    
    EndpointProperties endpointProperties = new EndpointProperties(null, null, "int-profile-accounts-Service",
            null, null);
    Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
            .thenReturn(endpointProperties);
    Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);

    List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
    CustomerAccountKey customerAccountKey = new CustomerAccountKey();
    customerAccountKey.setAccountNumber("123435");
    customerAccountKey.setAccountUseType("Open");
    customerAccountKey.setConsumerId("ID01");
    customerAccountKey.setSorId(new Short("2"));
    keyList.add(customerAccountKey);

    ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
    profileAccountDetail.setAccountNumber("XXXXXX8912");
    profileAccountDetail.setAvailableBalance(new BigDecimal("1200"));

    CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
    customerAccountsResponse.setAccountNumber("XXXXXX8912");
    customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));

    Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
    Mockito.when(target.request()).thenReturn(builder);
    Mockito.when(target.request().accept("application/json; v=3")).thenReturn(builder);
    Mockito.when(
            target.request().accept("application/json; v=3")
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3")).thenReturn(builder);

    Mockito.when(
            target.request().accept("application/json; v=3")
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED))
            .thenReturn(builder);
    Mockito.when(
            target.request().accept("application/json; v=3")
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                    .header("User-Id", "RTM")).thenReturn(builder);

   


    Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
            .thenReturn(endpointProperties);
    Mockito.when(
            target.request().accept("application/json; v=3")
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                    .header("User-Id", "RTM").get(ProfileAccountDetail.class))
            .thenReturn(profileAccountDetail);

    Mockito.when(conversionService.convert(profileAccountDetail, CustomerAccountsResponse.class)).thenReturn(
            customerAccountsResponse);

    CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
    customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
    customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
    customerAccountsRequest.setCustomerAccountKeyList(keyList);
    
    Mockito.when(context.getUserId()).thenReturn("RTM");
    Mockito.when(customerAccountsUtil.getEndpointProperties("int-profile-accounts-Service")).thenReturn(endpointProperties);
    
 profileAccountDetail = impl.retiveAccountDetails(customerAccountKey, context, "123435", "2",true);
   
 assertNotNull(profileAccountDetail);  
        
        
    }
    
    @Test(expected=NullPointerException.class)
    public void retiveAccountDetailsTest_withFalse360ApiKey() throws Exception{
    
    EndpointProperties endpointProperties = new EndpointProperties(null, null, "int-profile-accounts-Service",
            null, null);
    Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
            .thenReturn(endpointProperties);
    Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);

    List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
    CustomerAccountKey customerAccountKey = new CustomerAccountKey();
    customerAccountKey.setAccountNumber("123435");
    customerAccountKey.setAccountUseType("Open");
    customerAccountKey.setConsumerId("ID01");
    customerAccountKey.setSorId(new Short("2"));
    keyList.add(customerAccountKey);

    ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
    profileAccountDetail.setAccountNumber("XXXXXX8912");
    profileAccountDetail.setAvailableBalance(new BigDecimal("1200"));

    CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
    customerAccountsResponse.setAccountNumber("XXXXXX8912");
    customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));

    Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
    Mockito.when(target.request()).thenReturn(builder);
    Mockito.when(target.request().accept("application/json; v=3")).thenReturn(builder);
    Mockito.when(
            target.request().accept("application/json; v=3")
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3")).thenReturn(builder);

    Mockito.when(
            target.request().accept("application/json; v=3")
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED))
            .thenReturn(builder);
    Mockito.when(
            target.request().accept("application/json; v=3")
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                    .header("User-Id", "RTM")).thenReturn(builder);

   


    Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "int-profile-accounts-Service", null))
            .thenReturn(endpointProperties);
    Mockito.when(
            target.request().accept("application/json; v=3")
                    .header(HttpHeaders.CONTENT_TYPE, "application/json; v=3").header("entitled", ENTITLED)
                    .header("User-Id", "RTM").get(ProfileAccountDetail.class))
            .thenReturn(profileAccountDetail);

    Mockito.when(conversionService.convert(profileAccountDetail, CustomerAccountsResponse.class)).thenReturn(
            customerAccountsResponse);

    CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
    customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
    customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
    customerAccountsRequest.setCustomerAccountKeyList(keyList);
    
    Mockito.when(context.getUserId()).thenReturn("RTM");
    Mockito.when(customerAccountsUtil.getEndpointProperties("int-profile-accounts-Service")).thenReturn(endpointProperties);
    
 profileAccountDetail = impl.retiveAccountDetails(customerAccountKey, context, "123435", "2",false);
   
 assertNotNull(profileAccountDetail);  
        
        
    }

}
