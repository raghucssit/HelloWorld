package com.capitalone.api.customersaccounts.entity.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.ext.MessageBodyReader;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.EndpointManager;
import com.capitalone.epf.servicelocator.model.EndpointProperties;


@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class LoansAutoLoansEntityImplTest {
   
    @InjectMocks
    private LoansAutoLoansEntityImpl impl;

    @Mock
    private Client eapiRestClient;
    
    @Mock
    private EndpointManager endpointManager;

    @Mock
    private ReferenceIdEncoder encoder;
    
    @Mock
    private WebTarget requestPath;

    @Mock
    private WebTarget target;

    @Mock
    private Builder builder;

    @Mock
    private EPFContext context;

    @Mock
    private Configuration config;

    @SuppressWarnings("rawtypes")
    @Mock
    private MessageBodyReader messageBodyReader;

    @Mock
    private AutoLoanAccount response;

    @Mock
    private CustomerAPIRESTException e;
    
    @Mock
    private CustomerAccountsUtil customerAccountsUtil;
    
    @Test
    public void testretiveAccountDetails() throws Exception {
        
        EndpointProperties endpointProperties = new EndpointProperties(null, null, "loan-autoloan-account-Service",
                null, null);

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        String coafAPIVersion = "4";
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("123456");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
        // ProfileReferenceId profRefId = new ProfileReferenceId("");

        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "loan-autoloan-account-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(config.getString(Constants.COAF_API_VERSION)).thenReturn(coafAPIVersion);
        Mockito.when(config.getBoolean(Constants.COAF_API_ENTITLEMENT)).thenReturn(true);
        Mockito.when(target.register(messageBodyReader)).thenReturn(target);
        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json; v=" + coafAPIVersion)).thenReturn(builder);
        Mockito.when(target.request().header("SSOID", context.getUserId())).thenReturn(builder);
        Mockito.when(target.request().header("entitled", "entitled")).thenReturn(builder);

        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json; v=" + coafAPIVersion))
                .thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=" + coafAPIVersion)
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=" + coafAPIVersion)
                        .header("SSOID", context.getUserId()).header("entitled", "entitled").get(AutoLoanAccount.class))
                .thenReturn(autoLoanAccount);
        Mockito.when(customerAccountsUtil.getEndpointProperties("loan-autoloan-account-Service")).thenReturn(endpointProperties);
        response= impl.retiveAccountDetails(customerAccountKey, context, "123456", "2", "2563");

       // Future<REASResponse> daoResponse = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }
    
    @Test
    public void testretiveAccountDetails2() throws Exception {
        
        EndpointProperties endpointProperties = new EndpointProperties(null, null, "loan-autoloan-account-Service",
                null, null);

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        String coafAPIVersion = "4";
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("123456");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
        // ProfileReferenceId profRefId = new ProfileReferenceId("");

        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "loan-autoloan-account-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(config.getString(Constants.COAF_API_VERSION)).thenReturn(coafAPIVersion);
        Mockito.when(config.getBoolean(Constants.COAF_API_ENTITLEMENT)).thenReturn(false);
        Mockito.when(target.register(messageBodyReader)).thenReturn(target);
        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json; v=" + coafAPIVersion)).thenReturn(builder);
        Mockito.when(target.request().header("SSOID", context.getUserId())).thenReturn(builder);
        Mockito.when(target.request().header("entitled", "entitled")).thenReturn(builder);

        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json; v=" + coafAPIVersion))
                .thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=" + coafAPIVersion)
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=" + coafAPIVersion)
                        .header("SSOID", context.getUserId()).header("entitled", "entitled").get(AutoLoanAccount.class))
                .thenReturn(autoLoanAccount);
        Mockito.when(customerAccountsUtil.getEndpointProperties("loan-autoloan-account-Service")).thenReturn(endpointProperties);
        response= impl.retiveAccountDetails(customerAccountKey, context, "123456", "2", "2563");

       // Future<REASResponse> daoResponse = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }
    
    @Test
    public void testretiveAccountDetails_SSOID_Null() throws Exception {
        
        EndpointProperties endpointProperties = new EndpointProperties(null, null, "loan-autoloan-account-Service",
                null, null);

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
        String coafAPIVersion = "4";
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("123456");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
        // ProfileReferenceId profRefId = new ProfileReferenceId("");

        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "loan-autoloan-account-Service", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(config.getString(Constants.COAF_API_VERSION)).thenReturn(coafAPIVersion);
        Mockito.when(config.getBoolean(Constants.COAF_API_ENTITLEMENT)).thenReturn(false);
        Mockito.when(target.register(messageBodyReader)).thenReturn(target);
        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json; v=" + coafAPIVersion)).thenReturn(builder);
        Mockito.when(target.request().header("SSOID", context.getUserId())).thenReturn(builder);
        Mockito.when(target.request().header("entitled", "entitled")).thenReturn(builder);

        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json; v=" + coafAPIVersion))
                .thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=" + coafAPIVersion)
                        .header(HttpHeaders.CONTENT_TYPE, "application/json; v=" + coafAPIVersion)
                        .header("SSOID", context.getUserId()).header("entitled", "entitled").get(AutoLoanAccount.class))
                .thenReturn(autoLoanAccount);
        Mockito.when(customerAccountsUtil.getEndpointProperties("loan-autoloan-account-Service")).thenReturn(endpointProperties);
        response= impl.retiveAccountDetails(customerAccountKey, context, "123456", "2", null);

       // Future<REASResponse> daoResponse = daoImpl.getCOAFAccounts(context, customerAccountKey, "");
        assertNotNull(response);
    }
        
        
    

}
