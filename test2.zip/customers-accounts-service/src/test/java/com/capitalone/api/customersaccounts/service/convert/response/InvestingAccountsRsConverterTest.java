package com.capitalone.api.customersaccounts.service.convert.response;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.model.v1.CustomerRole;
import com.capitalone.api.customersaccounts.model.v1.GetAccountResponse;
import com.capitalone.api.customersaccounts.model.v1.InvestingAccounts;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class InvestingAccountsRsConverterTest {
    
    @InjectMocks
    private InvestingAccountsRsConverter converter;
    private CustomerRole customerRole = CustomerRole.Primary;
    
    
    @Test
    public void test_convert() {
        
        InvestingAccounts investingAccounts = new InvestingAccounts();
        
        List<GetAccountResponse> getAccountsResponse = new ArrayList<GetAccountResponse>();
        GetAccountResponse getAcctResp = new GetAccountResponse();
        getAcctResp.setAccountDetailsUrl("accountDetailsUrl");
        getAcctResp.setAccountNickname("accountNickname");
        getAcctResp.setAccountNumber("12345678912");
        getAcctResp.setAccountType("Individual");
        getAcctResp.setAvailableBalance(BigDecimal.TEN);
        getAcctResp.setBusinessLine("COI");
        //CustomerRole customerRole = new CustomerRole();
        getAcctResp.setCustomerRole(customerRole);
        getAcctResp.setEntitled(Boolean.TRUE);
        getAcctResp.setError("error");
        getAcctResp.setInvestorId(0);
        getAcctResp.setProductName("prodName");
        getAcctResp.setLastUpdateDate(new Instant ("12356"));
        getAcctResp.setTotalAccountValue(BigDecimal.TEN);
        getAcctResp.setOpenDate(new Instant ("12356"));
        getAccountsResponse.add(getAcctResp);
        investingAccounts.setAccount(getAccountsResponse );
        REASResponse response = converter.convert(investingAccounts);
        assertNotNull(response);        
    }
    
    @Test
    public void test_convert_Null() {
        InvestingAccounts investingAccounts = new InvestingAccounts();
        
        List<GetAccountResponse> getAccountsResponse = new ArrayList<GetAccountResponse>();
        GetAccountResponse getAcctResp = new GetAccountResponse();
       
        getAccountsResponse.add(getAcctResp);
        investingAccounts.setAccount(getAccountsResponse );
        REASResponse response = converter.convert(investingAccounts);
        assertNotNull(response); 
        
    }
    
    @Test
    public void test_convert_AcctNotEntitled() {
        InvestingAccounts investingAccounts = new InvestingAccounts();
        
        List<GetAccountResponse> getAccountsResponse = new ArrayList<GetAccountResponse>();
        GetAccountResponse getAcctResp = new GetAccountResponse();
        getAcctResp.setEntitled(Boolean.FALSE);
        getAccountsResponse.add(getAcctResp);
        investingAccounts.setAccount(getAccountsResponse );
        REASResponse response = converter.convert(investingAccounts);
        assertNotNull(response); 
        
    }

}
