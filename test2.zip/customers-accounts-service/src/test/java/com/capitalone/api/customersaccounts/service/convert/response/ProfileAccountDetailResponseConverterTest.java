package com.capitalone.api.customersaccounts.service.convert.response;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.math.BigDecimal;

import org.joda.time.LocalDate;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.model.product.Product;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class ProfileAccountDetailResponseConverterTest {

    @InjectMocks
    private ProfileAccountDetailResponseConverter converter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testSuccessPrincipalBal() {
        CustomerAccountsResponse custAcctResp = new CustomerAccountsResponse();

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setRetirementAccountIndicator(true);
        profileAccountDetail.setAvailableBalance(new BigDecimal("123456"));
        profileAccountDetail.setPrincipalBalance(new BigDecimal("123456"));
        profileAccountDetail.setAccountNumber("12345");
        profileAccountDetail.setAccountStatus("status");
        profileAccountDetail.setAccountNickname("Name");
        profileAccountDetail.setOpenDate(new LocalDate("123456"));
        profileAccountDetail.setPaymentDueDate(new LocalDate("123456"));
        profileAccountDetail.setLoanAmountDue(new BigDecimal("123456"));
        profileAccountDetail.setLedgerBalance(new BigDecimal("123456"));
        Product product = new Product();
        product.setProductId("3000");
        product.setProductName("SAVING");
        product.setProductTypeCode("SA");
        product.setProductTypeDescription("DEPOSITS");
        product.setProductClassDescription("SAVING");
        product.setProductCode("SA");
        profileAccountDetail.setProduct(product);
        // customerAccountsRefDataBean.getBusinessLine
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription((Mockito.anyString()))).thenReturn(
                "ProductTypeDescription");
        Mockito.when(customerAccountsRefDataBean.getBusinessLine("SA", "185")).thenReturn("DEPOSITS");

        custAcctResp = converter.convert(profileAccountDetail);

        assertThat(custAcctResp.getProductId(), equalTo("3000"));

    }

    @Test
    public void testSuccessLedgerBal() {
        CustomerAccountsResponse custAcctResp = new CustomerAccountsResponse();

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setRetirementAccountIndicator(true);
        profileAccountDetail.setAvailableBalance(new BigDecimal("123456"));
        profileAccountDetail.setPrincipalBalance(new BigDecimal("123456"));
        profileAccountDetail.setLedgerBalance(new BigDecimal("123456"));
        profileAccountDetail.setAccountNumber("12345");
        profileAccountDetail.setAccountStatus("status");
        profileAccountDetail.setAccountNickname("Name");
        profileAccountDetail.setOpenDate(new LocalDate("123456"));
        profileAccountDetail.setPaymentDueDate(new LocalDate("123456"));
        profileAccountDetail.setLoanAmountDue(new BigDecimal("123456"));
        Product product = new Product();
        product.setProductId("3500");
        product.setProductName("SAVING");
        product.setProductTypeCode("SA");
        product.setProductTypeDescription("LOANS");
        product.setProductClassDescription("SAVING");
        product.setProductCode("SA");
        profileAccountDetail.setProduct(product);

        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription((Mockito.anyString()))).thenReturn(
                "ProductTypeDescription");
        Mockito.when(customerAccountsRefDataBean.getBusinessLine("SA", "185")).thenReturn("LOANS");

        custAcctResp = converter.convert(profileAccountDetail);

        assertThat(custAcctResp.getProductId(), equalTo("3500"));

    }

    @Test
    public void test_null() {
        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setAvailableBalance(null);
        profileAccountDetail.setPrincipalBalance(null);
        profileAccountDetail.setAccountNumber(null);
        profileAccountDetail.setAccountStatus(null);
        profileAccountDetail.setAccountNickname(null);
        Product product = new Product();
        product.setProductId(null);
        product.setProductName(null);
        product.setProductTypeCode(null);
        product.setProductTypeDescription(null);
        product.setProductClassDescription(null);
        product.setProductCode(null);
        profileAccountDetail.setProduct(product);
        CustomerAccountsResponse custAcctResp = converter.convert(profileAccountDetail);
        assertNotNull(custAcctResp);
    }

    @Test
    public void test_nullProduct() {
        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setAvailableBalance(null);
        profileAccountDetail.setPrincipalBalance(null);
        profileAccountDetail.setAccountNumber(null);
        profileAccountDetail.setAccountStatus(null);
        profileAccountDetail.setAccountNickname(null);

        profileAccountDetail.setProduct(null);
        CustomerAccountsResponse custAcctResp = converter.convert(profileAccountDetail);
        assertNotNull(custAcctResp);
    }

    @Test
    public void test_nullProductId() {
        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setAvailableBalance(null);
        profileAccountDetail.setPrincipalBalance(null);
        profileAccountDetail.setAccountNumber(null);
        profileAccountDetail.setAccountStatus(null);
        profileAccountDetail.setAccountNickname(null);
        Product product = new Product();
        product.setProductId(null);
        profileAccountDetail.setProduct(product);
        CustomerAccountsResponse custAcctResp = converter.convert(profileAccountDetail);
        assertNotNull(custAcctResp);
    }

    @Test
    public void test_nullprofileAccountDetail() {
        CustomerAccountsResponse custAcctResp = converter.convert(null);
        assertNotNull(custAcctResp);
    }

    @Test
    public void testRetirementAccountIndicator() {
        CustomerAccountsResponse custAcctResp = new CustomerAccountsResponse();

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();

        profileAccountDetail.setAvailableBalance(new BigDecimal("123456"));
        profileAccountDetail.setPrincipalBalance(new BigDecimal("123456"));
        profileAccountDetail.setLedgerBalance(null);
        profileAccountDetail.setAccountNumber("12345");
        profileAccountDetail.setAccountStatus("status");
        profileAccountDetail.setAccountNickname("Name");
        profileAccountDetail.setOpenDate(new LocalDate("123456"));
        profileAccountDetail.setClosedDate(new LocalDate("123456"));
        profileAccountDetail.setPaymentDueDate(new LocalDate("123456"));
        profileAccountDetail.setLoanAmountDue(new BigDecimal("123456"));
        profileAccountDetail.setRetirementAccountIndicator(false);
        Product product = new Product();
        product.setProductId("3500");
        product.setProductName("SAVING");
        product.setProductTypeCode("SA");
        product.setProductTypeDescription("LOANS");
        product.setProductClassDescription("SAVING");
        product.setProductCode("SA");
        profileAccountDetail.setProduct(product);

        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription((Mockito.anyString()))).thenReturn(
                "ProductTypeDescription");
        Mockito.when(customerAccountsRefDataBean.getBusinessLine("SA","185")).thenReturn("LOANS");

        custAcctResp = converter.convert(profileAccountDetail);

        assertThat(custAcctResp.getProductId(), equalTo("3500"));

    }

    @Test
    public void testNullRetirementAccountIndicator() {
        CustomerAccountsResponse custAcctResp = new CustomerAccountsResponse();

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setRetirementAccountIndicator(null);
        profileAccountDetail.setAvailableBalance(new BigDecimal("123456"));
        profileAccountDetail.setPrincipalBalance(null);
        profileAccountDetail.setAccountNumber("12345");
        profileAccountDetail.setAccountStatus("status");
        profileAccountDetail.setAccountNickname("Name");
        profileAccountDetail.setOpenDate(new LocalDate("123456"));
        profileAccountDetail.setPaymentDueDate(new LocalDate("123456"));
        profileAccountDetail.setLoanAmountDue(new BigDecimal("123456"));
        profileAccountDetail.setLedgerBalance(new BigDecimal("123456"));
        Product product = new Product();
        product.setProductId("4000");
        product.setProductName("SAVING");
        product.setProductTypeCode("SA");
        product.setProductTypeDescription("DEPOSITS");
        product.setProductClassDescription("SAVING");
        product.setProductCode("SA");
        profileAccountDetail.setProduct(product);
        // customerAccountsRefDataBean.getBusinessLine
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription((Mockito.anyString()))).thenReturn(
                "ProductTypeDescription");
        Mockito.when(customerAccountsRefDataBean.getBusinessLine("SA","185")).thenReturn("DEPOSITS");

        custAcctResp = converter.convert(profileAccountDetail);

        assertThat(custAcctResp.getProductId(), equalTo("4000"));

    }

    @Test
    public void testNullLedgerBalance() {
        CustomerAccountsResponse custAcctResp = new CustomerAccountsResponse();

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();
        profileAccountDetail.setRetirementAccountIndicator(false);
        profileAccountDetail.setAvailableBalance(new BigDecimal("123456"));
        profileAccountDetail.setPrincipalBalance(null);
        profileAccountDetail.setAccountNumber("12345");
        profileAccountDetail.setAccountStatus("status");
        profileAccountDetail.setAccountNickname("Name");
        profileAccountDetail.setOpenDate(new LocalDate("123456"));
        profileAccountDetail.setPaymentDueDate(new LocalDate("123456"));
        profileAccountDetail.setLoanAmountDue(new BigDecimal("123456"));
        profileAccountDetail.setLedgerBalance(null);
        Product product = new Product();
        product.setProductId("3000");
        product.setProductName("SAVING");
        product.setProductTypeCode("SA");
        product.setProductTypeDescription("DEPOSITS");
        product.setProductClassDescription("SAVING");
        product.setProductCode("SA");
        profileAccountDetail.setProduct(product);
        // customerAccountsRefDataBean.getBusinessLine
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription((Mockito.anyString()))).thenReturn(
                "ProductTypeDescription");
        Mockito.when(customerAccountsRefDataBean.getBusinessLine("SA","185")).thenReturn("DEPOSITS");

        custAcctResp = converter.convert(profileAccountDetail);

        assertThat(custAcctResp.getProductId(), equalTo("3000"));

    }

    @Test
    public void testNullPrincipalBalance() {
        CustomerAccountsResponse custAcctResp = new CustomerAccountsResponse();

        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();

        profileAccountDetail.setAvailableBalance(new BigDecimal("123456"));
        profileAccountDetail.setPrincipalBalance(null);
        profileAccountDetail.setLedgerBalance(null);
        profileAccountDetail.setAccountNumber("12345");
        profileAccountDetail.setAccountStatus("status");
        profileAccountDetail.setAccountNickname("Name");
        profileAccountDetail.setOpenDate(new LocalDate("123456"));
        profileAccountDetail.setPaymentDueDate(new LocalDate("123456"));
        profileAccountDetail.setLoanAmountDue(new BigDecimal("123456"));
        profileAccountDetail.setRetirementAccountIndicator(false);
        Product product = new Product();
        product.setProductId("3500");
        product.setProductName("SAVING");
        product.setProductTypeCode("SA");
        product.setProductTypeDescription("LOANS");
        product.setProductClassDescription("SAVING");
        product.setProductCode("SA");
        profileAccountDetail.setProduct(product);

        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription((Mockito.anyString()))).thenReturn(
                "ProductTypeDescription");
        Mockito.when(customerAccountsRefDataBean.getBusinessLine("SA","185")).thenReturn("LOANS");

        custAcctResp = converter.convert(profileAccountDetail);

        assertThat(custAcctResp.getProductId(), equalTo("3500"));

    }

}
