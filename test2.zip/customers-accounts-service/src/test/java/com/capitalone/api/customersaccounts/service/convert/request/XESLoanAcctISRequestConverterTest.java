package com.capitalone.api.customersaccounts.service.convert.request;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xesloanacctis.v1.AcctInqISRq;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class XESLoanAcctISRequestConverterTest {

    @InjectMocks
    XESLoanAcctISRequestConverter converter;

    @Mock
    CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public void testConvertSorId38() {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("1234");
        customerAccountKey.setSorId(new Short("38"));
        customerAccountKey.setConsumerId("1234565");
        customerAccountKey.setAccountUseType("PER");

        AcctInqISRq acctInqISRq = converter.convert(customerAccountKey);
        assertThat(acctInqISRq.getCmd().getAcctID(), is("1234"));
        // assertThat(acctInqISRq.getCmd().getBankNum(), is("30"));
    }

    @Test
    public void testConvertSorId39() {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("1234");
        customerAccountKey.setSorId(new Short("39"));

        AcctInqISRq acctInqISRq = converter.convert(customerAccountKey);
        assertThat(acctInqISRq.getCmd().getAcctID(), is("1234"));
        // assertThat(acctInqISRq.getCmd().getBankNum(), is("81"));
    }

}
