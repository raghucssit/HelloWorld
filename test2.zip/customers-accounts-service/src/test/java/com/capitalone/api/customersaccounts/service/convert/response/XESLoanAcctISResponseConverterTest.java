package com.capitalone.api.customersaccounts.service.convert.response;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xesloanacctis.v1.AcctInqISRs;
import com.capitalone.xesloanacctis.v1.AcctInqISRs.Cmd;
import com.capitalone.xesloanacctis.v1.AcctInqISRs.Cmd.LoanAcctInfo;
import com.capitalone.xesloanacctis.v1.AcctInqISRs.Cmd.LoanAcctInfo.LoanAcctBalancesInfo;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class XESLoanAcctISResponseConverterTest {

    @InjectMocks
    private XESLoanAcctISResponseConverter converter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public void testConvert() {
        AcctInqISRs acctInqRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setProdID("01");
        loanAcctInfo.setProdDesc("loan");
        LoanAcctBalancesInfo balInfo = new LoanAcctBalancesInfo();
        balInfo.setCurrentBal(new BigDecimal(123));
        balInfo.setAvailableBal(new BigDecimal(124));
        balInfo.setPrinBal(new BigDecimal(125));
        balInfo.setNextPaymentAmt(new BigDecimal(125));
        loanAcctInfo.setLoanAcctBalancesInfo(balInfo);
        loanAcctInfo.setAcctID("12345");
        loanAcctInfo.setBankNum("23");
        loanAcctInfo.setBankAcctStatusDesc("BankAcctStatus");
        loanAcctInfo.setOpenDt(new Instant("1234"));
        loanAcctInfo.setNextPaymentDt(new Instant("1234"));
        loanAcctInfo.setClosedDate(new Instant("1234"));
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqRs.setCmd(cmd);
        CustomerAccountsResponse response = converter.convert(acctInqRs);
        assertNotNull(response);
    }

    @Test
    public void testConvert_nativeResponseHavingNullValues() {
        AcctInqISRs acctInqRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        LoanAcctBalancesInfo balInfo = new LoanAcctBalancesInfo();
        loanAcctInfo.setLoanAcctBalancesInfo(balInfo);
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqRs.setCmd(cmd);
        CustomerAccountsResponse response = converter.convert(acctInqRs);
        assertNotNull(response);
    }

    @Test
    public void testConvert_PrinBalNullValues() {
        AcctInqISRs acctInqRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new Cmd();
        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        LoanAcctBalancesInfo balInfo = new LoanAcctBalancesInfo();
        balInfo.setAvailableBal(new BigDecimal(125));
        balInfo.setPrinBal(null);
        loanAcctInfo.setLoanAcctBalancesInfo(balInfo);
        cmd.setLoanAcctInfo(loanAcctInfo);
        acctInqRs.setCmd(cmd);
        CustomerAccountsResponse response = converter.convert(acctInqRs);
        assertNotNull(response);
    }

    @Test
    public void testConvert_nativeResponseIsNull() {
        AcctInqISRs acctInqRs = null;
        CustomerAccountsResponse response = converter.convert(acctInqRs);
        assertNull(response);
    }

    @Test
    public void testConvert_nativeResponseCmdIsNull() {
        AcctInqISRs acctInqRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = null;
        acctInqRs.setCmd(cmd);
        CustomerAccountsResponse response = converter.convert(acctInqRs);
        assertNull(response);
    }

    @Test
    public void testConvert_LoanAcctInfoIsNull() {
        AcctInqISRs acctInqRs = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new Cmd();
        acctInqRs.setCmd(cmd);
        CustomerAccountsResponse response = converter.convert(acctInqRs);
        assertNull(response);
    }

}
