package com.capitalone.api.customersaccounts.service.impl;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.impl.CustInfoDLSDaoImpl;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CustInfoDLSOrchServiceTest {

    @InjectMocks
    private CustInfoDLSOrchService custInfoDLSOrchService;

    @Mock
    private CustInfoDLSDaoImpl custInfoDLSDaoImpl;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345678912");
        key.setConsumerId("12345");
        key.setSorId((short) 7);
        customerAccountKeyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("V3");
        customerAccountsRequest.setEnableappVersionV4("V4");
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("15");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        EPFContext context = EPFContextContainer.getContext();
        Map<String, String> mapRole = new HashMap<String, String>();
        mapRole.put("12345|12345678912", "Primary");
        Mockito.when(customerAccountsUtil.findSORID(customerAccountsRequest, Constants.CREDIT_CARD_SORID)).thenReturn(
                true);
        Mockito.when(custInfoDLSDaoImpl.getCustomerRole(context, key)).thenReturn(
                new AsyncResult<Map<String, String>>(mapRole));

        Future<Map<String, String>> mapRes = custInfoDLSOrchService.execute(customerAccountsRequest, context);
        assertThat(mapRes.get().get("12345|12345678912"), equalTo("Primary"));
    }

}
