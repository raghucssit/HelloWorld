package com.capitalone.api.customersaccounts.entity.impl;

import java.util.concurrent.ExecutionException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRq;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRq.Cmd;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs;
import com.capitalone.ecrcustomerrelationshipsis.v1.ECRCustomerRelationshipsISSoap;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class ECRCustomerRelationshipsEntityImplTest {
    
    @InjectMocks
    private ECRCustomerRelationshipsEntityImpl Impl;
    
    @Mock
    private ECRCustomerRelationshipsISSoap ecrCustomerRelationshipsService; 
    
    @Test
    public void testcustIdentityMatchedAccountsInq() throws InterruptedException, ExecutionException {

        CustIdentityMatchedAccountsInqRq request = new CustIdentityMatchedAccountsInqRq();
        request.setCmd(new Cmd());
        CustIdentityMatchedAccountsInqRs response= new CustIdentityMatchedAccountsInqRs();
    Mockito.when(ecrCustomerRelationshipsService.custIdentityMatchedAccountsInq(request)).thenReturn(response);
       Assert.assertNotNull(Impl.custIdentityMatchedAccountsInq(request, ""));
}
}