package com.capitalone.api.customersaccounts.service.convert.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class ECRCustomerRelationshipISResponseConverterTest {

    private ECRCustomerRelationshipISResponseConverter converter;

    private static final String ACCOUNT_NO = "4000176";

    private static final String CUST_ID = "20001";

    private static final String SOR_ID = "185";

    @Before
    public void setUp() throws Exception {

        converter = new ECRCustomerRelationshipISResponseConverter();
    }

    @Test
    public final void test_success() {

        CustIdentityMatchedAccountsInqRs response = new CustIdentityMatchedAccountsInqRs();

        ECRMatchedAccounts ecrMatchedAccounts = new ECRMatchedAccounts();
        EntSvcgGrping entSvcgGrping = new EntSvcgGrping();
        AcctDetails acctDetails = new AcctDetails();
        acctDetails.setApplctnAcctID(ACCOUNT_NO);
        acctDetails.setSORCnsmrID(CUST_ID);
        acctDetails.setSoRID(new Short(SOR_ID));
        entSvcgGrping.getAcctDetails().add(acctDetails);

        ecrMatchedAccounts.getEntSvcgGrping().add(entSvcgGrping);

        response.setCmd(new CustIdentityMatchedAccountsInqRs.Cmd());

        response.getCmd().setStat(new StatType());

        response.getCmd().setECRMatchedAccounts(ecrMatchedAccounts);
        CustomerAccountKey customerAccountKey = converter.convert(acctDetails);

        assertNotNull(customerAccountKey);
        assertEquals(ACCOUNT_NO, customerAccountKey.getAccountNumber());
        assertEquals(CUST_ID, customerAccountKey.getConsumerId());
        assertEquals(SOR_ID, String.valueOf(customerAccountKey.getSorId()));
    }

    @Test
    public final void test_nullResponse() {

        AcctDetails acctDetails = null;

        CustomerAccountKey customerAccountKey = converter.convert(acctDetails);

        assertNull(customerAccountKey);

    }
    
    @Test
    public final void test_success_withSorId_7() {

        CustIdentityMatchedAccountsInqRs response = new CustIdentityMatchedAccountsInqRs();

        ECRMatchedAccounts ecrMatchedAccounts = new ECRMatchedAccounts();
        EntSvcgGrping entSvcgGrping = new EntSvcgGrping();
        AcctDetails acctDetails = new AcctDetails();
        acctDetails.setApplctnAcctID(ACCOUNT_NO);
        acctDetails.setSORCnsmrID(CUST_ID);
        acctDetails.setSoRID(new Short("7"));
        entSvcgGrping.getAcctDetails().add(acctDetails);

        ecrMatchedAccounts.getEntSvcgGrping().add(entSvcgGrping);

        response.setCmd(new CustIdentityMatchedAccountsInqRs.Cmd());

        response.getCmd().setStat(new StatType());

        response.getCmd().setECRMatchedAccounts(ecrMatchedAccounts);
        CustomerAccountKey customerAccountKey = converter.convert(acctDetails);

        assertNotNull(customerAccountKey);
        //assertEquals(ACCOUNT_NO, customerAccountKey.getAccountNumber());
        assertEquals(CUST_ID, customerAccountKey.getConsumerId());
        assertEquals("7", String.valueOf(customerAccountKey.getSorId()));
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
