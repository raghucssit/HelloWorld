package com.capitalone.api.customersaccounts.service.convert.request;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRq;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CustInfoDLSRequestConverterTest {

    @InjectMocks
    private CustInfoDLSRqConverter converter;

    @Test
    public void testConvert() {

        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));
        CustInfoDLSInqRq infoDLSInqRq = converter.convert(customerAccountKey);
        assertThat(infoDLSInqRq.getCmd().getAcct().getAcctID(), equalTo("12345678912"));
    }

}
