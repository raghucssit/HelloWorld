package com.capitalone.api.customersaccounts.service.convert.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.math.BigDecimal;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xesddais.v1.AcctInqISRs;
import com.capitalone.xesddais.v1.AcctInqISRs.Cmd.DemandDepositAcctInfo;
import com.capitalone.xesddais.v1.AcctInqISRs.Cmd.DemandDepositAcctInfo.DemandDepAcctBalancesInfo;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class XESDDAISRsConverterTest {

    @InjectMocks
    private XESDDAISRsConverter converter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public void test_success() {
        AcctInqISRs nativeResponse = new AcctInqISRs();
        DemandDepAcctBalancesInfo info = new DemandDepAcctBalancesInfo();
        info.setAvailableBal(new BigDecimal(12));
        info.setCapOneCurrentBal(new BigDecimal(13));

        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        DemandDepositAcctInfo DDA_Info = new DemandDepositAcctInfo();
        DDA_Info.setProdID("01");
        DDA_Info.setProdDesc("Saving");
        DDA_Info.setAcctID("12345");
        DDA_Info.setBankNum("IM30");
        DDA_Info.setBankAcctStatusDesc("status");
        DDA_Info.setOpenDt(new Instant("123456"));
        DDA_Info.setClosedDate(new Instant("123456"));
        cmd.setDemandDepositAcctInfo(DDA_Info);

        nativeResponse.setCmd(cmd);
        nativeResponse.getCmd().getDemandDepositAcctInfo().setDemandDepAcctBalancesInfo(info);

        CustomerAccountsResponse response = converter.convert(nativeResponse);
        assertNotNull(response);
    }

   // @Test(expected=NullPointerException.class)
    public final void test_nullResponse() {

        AcctInqISRs nativeResponse = new AcctInqISRs();
        DemandDepAcctBalancesInfo info = new DemandDepAcctBalancesInfo();
        info.setAvailableBal(null);
        info.setCapOneCurrentBal(null);

        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        DemandDepositAcctInfo DDA_Info = new DemandDepositAcctInfo();
        DDA_Info.setProdID(null);
        DDA_Info.setProdDesc(null);
        DDA_Info.setAcctID(null);
        DDA_Info.setBankNum(null);
        DDA_Info.setBankAcctStatusDesc(null);
        DDA_Info.setOpenDt(null);

        cmd.setDemandDepositAcctInfo(DDA_Info);

        nativeResponse.setCmd(cmd);
        nativeResponse.getCmd().getDemandDepositAcctInfo().setDemandDepAcctBalancesInfo(info);

        CustomerAccountsResponse response = converter.convert(nativeResponse);
        assertNotNull(response);

    }

    @Test
    public final void test_nullResponse1() {
        AcctInqISRs nativeResponse = null;

        CustomerAccountsResponse response = converter.convert(nativeResponse);
        assertNull(response);
    }

    @Test
    public final void test_nullResponse2() {
        AcctInqISRs nativeResponse = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = null;
        nativeResponse.setCmd(cmd);

        CustomerAccountsResponse response = converter.convert(nativeResponse);
        assertNull(response);
    }

    @Test
    public final void test_nullResponse3() {
        AcctInqISRs nativeResponse = new AcctInqISRs();
        AcctInqISRs.Cmd cmd = new AcctInqISRs.Cmd();
        nativeResponse.setCmd(cmd);

        CustomerAccountsResponse response = converter.convert(nativeResponse);
        assertNull(response);
    }

}
