package com.capitalone.api.customersaccounts.dao.impl;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.entity.CustInfoDLSEntity;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRq;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Cust;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.CustAcctRoleType;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CustInfoDLSDaoImplTest {

    @InjectMocks
    private CustInfoDLSDaoImpl daoImpl;

    @Mock
    private ConversionService conversionService;

    @Mock
    private CustInfoDLSEntity custInfoDLSEntityImpl;

    @Mock
    private EPFContext context;

    @Test
    public void testGetCustomerRole() throws Exception {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));

        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();
        CustInfoDLSInqRq.Cmd.Acct acct = new CustInfoDLSInqRq.Cmd.Acct();
        acct.setAcctID("12345678912");
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        CustInfoDLSInqRs custInfoDLSInqRs = new CustInfoDLSInqRs();
        CustInfoDLSInqRs.Cmd cmdRs = new CustInfoDLSInqRs.Cmd();

        CustInfoDLSInqRs.Cmd.CustInformation custInformation = new CustInfoDLSInqRs.Cmd.CustInformation();
        com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct acctRs = new com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct();
        acctRs.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        CustInfo custInfo = new CustInfo();
        custInfo.setAcct(acctRs);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        custInformation.getCustInfo().add(custInfo);
        cmdRs.setCustInformation(custInformation);
        custInfoDLSInqRs.setCmd(cmdRs);
        // custInfoDLSInqRs.

        Map<String, String> mapRole = new HashMap<String, String>();
        mapRole.put("564034|12345678912", "Primary");

        Mockito.when(context.getUserId()).thenReturn("MOBILE");

        Mockito.when(conversionService.convert(customerAccountKey, CustInfoDLSInqRq.class))
                .thenReturn(custInfoDLSInqRq);

        Mockito.when(custInfoDLSEntityImpl.retiveAccountDetails(custInfoDLSInqRq, "MOBILE12345678912")).thenReturn(
                custInfoDLSInqRs);

        Mockito.when(conversionService.convert(custInfoDLSInqRs.getCmd().getCustInformation().getCustInfo(), Map.class))
                .thenReturn(mapRole);

        Future<Map<String, String>> mapRes = daoImpl.getCustomerRole(context, customerAccountKey);
        assertThat(mapRes.get().get("564034|12345678912"), equalTo("Primary"));
    }

    @Test
    public void testGetCustomerRoleNull() throws Exception {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));

        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();
        CustInfoDLSInqRq.Cmd.Acct acct = new CustInfoDLSInqRq.Cmd.Acct();
        acct.setAcctID("12345678912");
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        CustInfoDLSInqRs custInfoDLSInqRs = new CustInfoDLSInqRs();
        CustInfoDLSInqRs.Cmd cmdRs = new CustInfoDLSInqRs.Cmd();

        CustInfoDLSInqRs.Cmd.CustInformation custInformation = new CustInfoDLSInqRs.Cmd.CustInformation();
        com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct acctRs = new com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct();
        acctRs.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        CustInfo custInfo = new CustInfo();
        custInfo.setAcct(acctRs);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        custInformation.getCustInfo().add(custInfo);
        cmdRs.setCustInformation(custInformation);
        custInfoDLSInqRs.setCmd(cmdRs);
        // custInfoDLSInqRs.

        Map<String, String> mapRole = new HashMap<String, String>();
        mapRole.put("564034|12345678912", "Primary");

        Mockito.when(context.getUserId()).thenReturn("MOBILE");

        Mockito.when(conversionService.convert(customerAccountKey, CustInfoDLSInqRq.class))
                .thenReturn(custInfoDLSInqRq);

        Mockito.when(custInfoDLSEntityImpl.retiveAccountDetails(custInfoDLSInqRq, "MOBILE12345678912")).thenReturn(
                custInfoDLSInqRs);

        Future<Map<String, String>> mapRes =  daoImpl.getCustomerRole(context, customerAccountKey);
        assertNull(mapRes);
    }
    
    @Test
    public void testGetCustomerRole_Exce() throws Exception {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));

        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();
        CustInfoDLSInqRq.Cmd.Acct acct = new CustInfoDLSInqRq.Cmd.Acct();
        acct.setAcctID("12345678912");
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        CustInfoDLSInqRs custInfoDLSInqRs = new CustInfoDLSInqRs();
        CustInfoDLSInqRs.Cmd cmdRs = new CustInfoDLSInqRs.Cmd();

        CustInfoDLSInqRs.Cmd.CustInformation custInformation = new CustInfoDLSInqRs.Cmd.CustInformation();
        com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct acctRs = new com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct();
        acctRs.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        CustInfo custInfo = new CustInfo();
        custInfo.setAcct(acctRs);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        custInformation.getCustInfo().add(custInfo);
        cmdRs.setCustInformation(custInformation);
        custInfoDLSInqRs.setCmd(cmdRs);
        // custInfoDLSInqRs.

        Map<String, String> mapRole = new HashMap<String, String>();
        mapRole.put("564034|12345678912", "Primary");

        Mockito.when(context.getUserId()).thenReturn("MOBILE");

        Exception e = new Exception("");
        Mockito.when(conversionService.convert(customerAccountKey, CustInfoDLSInqRq.class))
        .thenReturn(custInfoDLSInqRq);

        Mockito.when(custInfoDLSEntityImpl.retiveAccountDetails(custInfoDLSInqRq, "MOBILE12345678912")).thenThrow(
                e);

        Mockito.when(conversionService.convert(custInfoDLSInqRs.getCmd().getCustInformation().getCustInfo(), Map.class))
                .thenReturn(mapRole);

        Future<Map<String, String>> mapRes = daoImpl.getCustomerRole(context, customerAccountKey);
        
    }
    
    @Test
    public void testGetCustomerRole_NullReq() throws Exception {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));

        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();
        CustInfoDLSInqRq.Cmd.Acct acct = new CustInfoDLSInqRq.Cmd.Acct();
        acct.setAcctID("12345678912");
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        CustInfoDLSInqRs custInfoDLSInqRs = new CustInfoDLSInqRs();
        CustInfoDLSInqRs.Cmd cmdRs = new CustInfoDLSInqRs.Cmd();

        CustInfoDLSInqRs.Cmd.CustInformation custInformation = new CustInfoDLSInqRs.Cmd.CustInformation();
        com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct acctRs = new com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct();
        acctRs.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        CustInfo custInfo = new CustInfo();
        custInfo.setAcct(acctRs);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        custInformation.getCustInfo().add(custInfo);
        cmdRs.setCustInformation(custInformation);
        custInfoDLSInqRs.setCmd(cmdRs);
        // custInfoDLSInqRs.

        Map<String, String> mapRole = new HashMap<String, String>();
        mapRole.put("564034|12345678912", "Primary");

        Mockito.when(context.getUserId()).thenReturn("MOBILE");

        Exception e = new Exception("");
        Mockito.when(conversionService.convert(customerAccountKey, CustInfoDLSInqRq.class))
        .thenReturn(null);

        Mockito.when(custInfoDLSEntityImpl.retiveAccountDetails(custInfoDLSInqRq, "MOBILE12345678912")).thenThrow(
                e);

        Mockito.when(conversionService.convert(custInfoDLSInqRs.getCmd().getCustInformation().getCustInfo(), Map.class))
                .thenReturn(mapRole);

        Future<Map<String, String>> mapRes = daoImpl.getCustomerRole(context, customerAccountKey);
        
    }
    
    @Test
    public void testGetCustomerRoleNull_NullRes() throws Exception {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));

        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();
        CustInfoDLSInqRq.Cmd.Acct acct = new CustInfoDLSInqRq.Cmd.Acct();
        acct.setAcctID("12345678912");
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        CustInfoDLSInqRs custInfoDLSInqRs = new CustInfoDLSInqRs();
        CustInfoDLSInqRs.Cmd cmdRs = new CustInfoDLSInqRs.Cmd();

        CustInfoDLSInqRs.Cmd.CustInformation custInformation = new CustInfoDLSInqRs.Cmd.CustInformation();
        com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct acctRs = new com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct();
        acctRs.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        CustInfo custInfo = new CustInfo();
        custInfo.setAcct(acctRs);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        custInformation.getCustInfo().add(custInfo);
        cmdRs.setCustInformation(custInformation);
        custInfoDLSInqRs.setCmd(cmdRs);
        // custInfoDLSInqRs.

        Map<String, String> mapRole = new HashMap<String, String>();
        mapRole.put("564034|12345678912", "Primary");

        Mockito.when(context.getUserId()).thenReturn("MOBILE");

        Mockito.when(conversionService.convert(customerAccountKey, CustInfoDLSInqRq.class))
                .thenReturn(custInfoDLSInqRq);

        Mockito.when(custInfoDLSEntityImpl.retiveAccountDetails(custInfoDLSInqRq, "MOBILE12345678912")).thenReturn(
                null);

        Mockito.when(conversionService.convert(custInfoDLSInqRs.getCmd().getCustInformation().getCustInfo(), Map.class))
                .thenReturn(mapRole);

        Future<Map<String, String>> mapRes = daoImpl.getCustomerRole(context, customerAccountKey);
        
    }
    
    @Test
    public void testGetCustomerRoleNull_NullCmd() throws Exception {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));

        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();
        CustInfoDLSInqRq.Cmd.Acct acct = new CustInfoDLSInqRq.Cmd.Acct();
        acct.setAcctID("12345678912");
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        CustInfoDLSInqRs custInfoDLSInqRs = new CustInfoDLSInqRs();
        CustInfoDLSInqRs.Cmd cmdRs = new CustInfoDLSInqRs.Cmd();

        CustInfoDLSInqRs.Cmd.CustInformation custInformation = new CustInfoDLSInqRs.Cmd.CustInformation();
        com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct acctRs = new com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct();
        acctRs.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        CustInfo custInfo = new CustInfo();
        custInfo.setAcct(acctRs);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        custInformation.getCustInfo().add(custInfo);
        cmdRs.setCustInformation(custInformation);
        //custInfoDLSInqRs.setCmd(cmdRs);
        // custInfoDLSInqRs.

        Map<String, String> mapRole = new HashMap<String, String>();
        mapRole.put("564034|12345678912", "Primary");

        Mockito.when(context.getUserId()).thenReturn("MOBILE");

        Mockito.when(conversionService.convert(customerAccountKey, CustInfoDLSInqRq.class))
                .thenReturn(custInfoDLSInqRq);

        Mockito.when(custInfoDLSEntityImpl.retiveAccountDetails(custInfoDLSInqRq, "MOBILE12345678912")).thenReturn(
                custInfoDLSInqRs);

        Future<Map<String, String>> mapRes =  daoImpl.getCustomerRole(context, customerAccountKey);
        assertNull(mapRes);
    }
    
    @Test
    public void testGetCustomerRoleNull_NullCustInfo() throws Exception {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));

        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();
        CustInfoDLSInqRq.Cmd.Acct acct = new CustInfoDLSInqRq.Cmd.Acct();
        acct.setAcctID("12345678912");
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        CustInfoDLSInqRs custInfoDLSInqRs = new CustInfoDLSInqRs();
        CustInfoDLSInqRs.Cmd cmdRs = new CustInfoDLSInqRs.Cmd();

        CustInfoDLSInqRs.Cmd.CustInformation custInformation = new CustInfoDLSInqRs.Cmd.CustInformation();
        com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct acctRs = new com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct();
        acctRs.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        CustInfo custInfo = new CustInfo();
        custInfo.setAcct(acctRs);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        custInformation.getCustInfo().add(custInfo);
        //cmdRs.setCustInformation(custInformation);
        custInfoDLSInqRs.setCmd(cmdRs);
        // custInfoDLSInqRs.

        Map<String, String> mapRole = new HashMap<String, String>();
        mapRole.put("564034|12345678912", "Primary");

        Mockito.when(context.getUserId()).thenReturn("MOBILE");

        Mockito.when(conversionService.convert(customerAccountKey, CustInfoDLSInqRq.class))
                .thenReturn(custInfoDLSInqRq);

        Mockito.when(custInfoDLSEntityImpl.retiveAccountDetails(custInfoDLSInqRq, "MOBILE12345678912")).thenReturn(
                custInfoDLSInqRs);

        Future<Map<String, String>> mapRes =  daoImpl.getCustomerRole(context, customerAccountKey);
        assertNull(mapRes);
    }
    
    @Test
    public void testGetCustomerRoleNull_CustInfoWithNullValue() throws Exception {
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("7"));

        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();
        CustInfoDLSInqRq.Cmd.Acct acct = new CustInfoDLSInqRq.Cmd.Acct();
        acct.setAcctID("12345678912");
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        CustInfoDLSInqRs custInfoDLSInqRs = new CustInfoDLSInqRs();
        CustInfoDLSInqRs.Cmd cmdRs = new CustInfoDLSInqRs.Cmd();

        CustInfoDLSInqRs.Cmd.CustInformation custInformation = new CustInfoDLSInqRs.Cmd.CustInformation();
        com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct acctRs = new com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct();
        acctRs.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        CustInfo custInfo = new CustInfo();
        custInfo.setAcct(acctRs);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        //custInformation.getCustInfo().add(custInfo);
        cmdRs.setCustInformation(custInformation);
        custInfoDLSInqRs.setCmd(cmdRs);
        // custInfoDLSInqRs.

        Map<String, String> mapRole = new HashMap<String, String>();
        mapRole.put("564034|12345678912", "Primary");

        Mockito.when(context.getUserId()).thenReturn("MOBILE");

        Mockito.when(conversionService.convert(customerAccountKey, CustInfoDLSInqRq.class))
                .thenReturn(custInfoDLSInqRq);

        Mockito.when(custInfoDLSEntityImpl.retiveAccountDetails(custInfoDLSInqRq, "MOBILE12345678912")).thenReturn(
                custInfoDLSInqRs);

        Future<Map<String, String>> mapRes =  daoImpl.getCustomerRole(context, customerAccountKey);
        assertNull(mapRes);
    }

}
