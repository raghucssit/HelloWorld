package com.capitalone.api.customersaccounts.entity.impl;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRq;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Cust;
import com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.CustAcctRoleType;
import com.capitalone.customerinformationdls.v1.CustomerInformationDLSSoap;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CustInfoEntityImplTest {

    @InjectMocks
    private CustInfoDLSEntityImpl Impl;

    @Mock
    private CustomerInformationDLSSoap customerInformationDLSSoap;

    @Test
    public void testcustIdentityMatchedAccountsInq() throws Exception {

        CustInfoDLSInqRq custInfoDLSInqRq = new CustInfoDLSInqRq();
        CustInfoDLSInqRq.Cmd cmd = new CustInfoDLSInqRq.Cmd();
        CustInfoDLSInqRq.Cmd.Acct acct = new CustInfoDLSInqRq.Cmd.Acct();
        acct.setAcctID("12345678912");
        cmd.setAcct(acct);
        custInfoDLSInqRq.setCmd(cmd);

        CustInfoDLSInqRs custInfoDLSInqRs = new CustInfoDLSInqRs();
        CustInfoDLSInqRs.Cmd cmdRs = new CustInfoDLSInqRs.Cmd();

        CustInfoDLSInqRs.Cmd.CustInformation custInformation = new CustInfoDLSInqRs.Cmd.CustInformation();
        com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct acctRs = new com.capitalone.customerinformationdls.v1.CustInfoDLSInqRs.Cmd.CustInformation.CustInfo.Acct();
        acctRs.setAcctID("12345678912");
        Cust cust = new Cust();
        cust.setCustID("564034");
        CustAcctRoleType custAcctRoleType = new CustAcctRoleType();
        custAcctRoleType.setCustAcctRoleTypeDesc("Primary");
        CustInfo custInfo = new CustInfo();
        custInfo.setAcct(acctRs);
        custInfo.setCust(cust);
        custInfo.setCustAcctRoleType(custAcctRoleType);
        custInformation.getCustInfo().add(custInfo);
        cmdRs.setCustInformation(custInformation);
        custInfoDLSInqRs.setCmd(cmdRs);

        Mockito.when(customerInformationDLSSoap.customerInformationInq(custInfoDLSInqRq)).thenReturn(custInfoDLSInqRs);
        CustInfoDLSInqRs custInfoDLSInqRs_2 = Impl.retiveAccountDetails(custInfoDLSInqRq, "MOBILE12345678912");

        assertThat(custInfoDLSInqRs_2.getCmd().getCustInformation().getCustInfo().get(0).getAcct().getAcctID(),
                equalTo("12345678912"));
    }
}