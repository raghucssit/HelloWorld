package com.capitalone.api.customersaccounts.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.UriBuilder;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.model.v1.GetAccountResponse;
import com.capitalone.api.customersaccounts.model.v1.InvestingAccounts;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.model.EndpointProperties;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CapitalOneInvestingAccountDAOImplTest {

    @InjectMocks
    private CapitalOneInvestingAccountDAOImpl capitalOneInvestingAccountDAOImpl;

    @Mock
    private EPFContext context;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Mock
    private Client eapiRestClient;

    @Mock
    private WebTarget webTarget;

    @Mock
    private Builder builder;

    @Test
    public void testGetInvestingAccount() {

        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        List<CustomerAccountKey> listCustomerAccountKey = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("PER");
        customerAccountKey.setConsumerId("123456");
        customerAccountKey.setSorId((short) 199);
        listCustomerAccountKey.add(customerAccountKey);
        accountsRequest.setCustomerAccountKeyList(listCustomerAccountKey);

        InvestingAccounts investingAccounts = null;

        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountsResponse> listCustomerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAccountNumber("12345678912");
        customerAccountsResponse.setProductName("Investing");
        customerAccountsResponse.setCurrentBalance(new BigDecimal("1230"));
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1430"));
        customerAccountsResponse.setCurrencyCode("USD");
        customerAccountsResponse.setOpenDate(new Instant());
        listCustomerAccountsResponses.add(customerAccountsResponse);
        reasResponse.setCustomerAccountsResponseList(listCustomerAccountsResponses);

        investingAccounts = new InvestingAccounts();

        GetAccountResponse getAccountResponse = new GetAccountResponse();
        getAccountResponse.setAccountNumber("12345678912");
        getAccountResponse.setProductName("Investing");
        getAccountResponse.setTotalAccountValue(new BigDecimal("1230"));
        getAccountResponse.setAvailableBalance(new BigDecimal("1430"));

        List<GetAccountResponse> getAccountResponses = new ArrayList<GetAccountResponse>();
        getAccountResponses.add(getAccountResponse);

        investingAccounts.setAccount(getAccountResponses);

        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "https://sbmt.sharebuilder.com/api/investing/getAccounts", null, null);

        Mockito.when(customerAccountsUtil.getEndpointProperties("sharebuilder-investing-account-Service")).thenReturn(
                endpointProperties);

        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(webTarget);

        Mockito.when(webTarget.request()).thenReturn(builder);

        Mockito.when(builder.accept("application/json")).thenReturn(builder);

        Mockito.when(builder.header("Content-Type", "application/json")).thenReturn(builder);

        /*Mockito.when(builder.post(Entity.json((AccountApplicants) Mockito.anyObject()), InvestingAccounts.class))
                .thenReturn(investingAccounts);*/

        capitalOneInvestingAccountDAOImpl.getInvestingAccount(context, accountsRequest);
    }
    
    @Test
    public void testGetInvestingAccount_Exception() {

        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        List<CustomerAccountKey> listCustomerAccountKey = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("PER");
        customerAccountKey.setConsumerId("123456");
        customerAccountKey.setSorId((short) 199);
        listCustomerAccountKey.add(customerAccountKey);
        accountsRequest.setCustomerAccountKeyList(listCustomerAccountKey);

        InvestingAccounts investingAccounts = null;

        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountsResponse> listCustomerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAccountNumber("12345678912");
        customerAccountsResponse.setProductName("Investing");
        customerAccountsResponse.setCurrentBalance(new BigDecimal("1230"));
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1430"));
        customerAccountsResponse.setCurrencyCode("USD");
        customerAccountsResponse.setOpenDate(new Instant());
        listCustomerAccountsResponses.add(customerAccountsResponse);
        reasResponse.setCustomerAccountsResponseList(listCustomerAccountsResponses);

        investingAccounts = new InvestingAccounts();

        GetAccountResponse getAccountResponse = new GetAccountResponse();
        getAccountResponse.setAccountNumber("12345678912");
        getAccountResponse.setProductName("Investing");
        getAccountResponse.setTotalAccountValue(new BigDecimal("1230"));
        getAccountResponse.setAvailableBalance(new BigDecimal("1430"));

        List<GetAccountResponse> getAccountResponses = new ArrayList<GetAccountResponse>();
        getAccountResponses.add(getAccountResponse);

        investingAccounts.setAccount(getAccountResponses);

        EndpointProperties endpointProperties = new EndpointProperties(null, null,
                "https://sbmt.sharebuilder.com/api/investing/getAccounts", null, null);

        Mockito.when(customerAccountsUtil.getEndpointProperties("sharebuilder-investing-account-Service")).thenReturn(
                endpointProperties);

        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(webTarget);

        Mockito.when(webTarget.request()).thenReturn(null);

        Mockito.when(builder.accept("application/json")).thenReturn(builder);

        Mockito.when(builder.header("Content-Type", "application/json")).thenReturn(builder);

        /*Mockito.when(builder.post(Entity.json((AccountApplicants) Mockito.anyObject()), InvestingAccounts.class))
                .thenReturn(investingAccounts);*/

        capitalOneInvestingAccountDAOImpl.getInvestingAccount(context, accountsRequest);
    }    
    
}
