package com.capitalone.api.customersaccounts.service.convert.request;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xesddais.v1.AcctInqISRq;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class XESDDAISRqConverterTest {
    private static final String ACCOUNT_NO = "4000176";

    private static final String CONSUMER_ID = "20001";

    private static final Short SOR_ID = 16;

    @InjectMocks
    private XESDDAISRqConverter converter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public final void test_success_NullRequest() {
        CustomerAccountKey custAccountKey = new CustomerAccountKey();
        custAccountKey.setAccountNumber(null);
        AcctInqISRq request = converter.convert(custAccountKey);
        assertNotNull(request);
    }

    @Test
    public final void test_success() {
        CustomerAccountKey custAccountKey = new CustomerAccountKey();
        custAccountKey.setAccountNumber(ACCOUNT_NO);
        custAccountKey.setAccountUseType("PER");
        custAccountKey.setConsumerId(CONSUMER_ID);
        custAccountKey.setSorId(SOR_ID);
        AcctInqISRq request = converter.convert(custAccountKey);
        assertNotNull(request);

    }

}
