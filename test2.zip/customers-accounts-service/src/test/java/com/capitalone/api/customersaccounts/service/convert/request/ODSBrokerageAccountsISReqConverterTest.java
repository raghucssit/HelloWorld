package com.capitalone.api.customersaccounts.service.convert.request;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRq;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class ODSBrokerageAccountsISReqConverterTest {

    @InjectMocks
    private ODSBrokerageAccountsISReqConverter odsBrokerageAccountsISReqConverter;

    @Test
    public void testConvert() {
        // CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("102"));
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(customerAccountKey);
        BalancesInqRq response = odsBrokerageAccountsISReqConverter.convert(customerAccountKeyList);

        assertThat(response.getCmd().getAccountsArray().get(0).getAcctID(), is("12345678912"));
    }
    
    @Test
    public void testConvert_NullRequest() {        
        BalancesInqRq response = odsBrokerageAccountsISReqConverter.convert(null);
        assertNull(response);
    }  

}
