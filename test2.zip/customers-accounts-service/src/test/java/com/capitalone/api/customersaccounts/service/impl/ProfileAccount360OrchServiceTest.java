package com.capitalone.api.customersaccounts.service.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.equalTo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.ProfileAccountDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class ProfileAccount360OrchServiceTest {

    @InjectMocks
    private ProfileAccount360OrchService profileAccount360OrchService;

    @Mock
    private ProfileAccountDao profileAccountDAO;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {
        EPFContext epfContext = EPFContextContainer.getContext();

        Future<REASResponse> response;

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("2");
        reasSupportedSORID.add("56");
        reasSupportedSORID.add("102");
        reasSupportedSORID.add("7");
        reasSupportedSORID.add("12");
        reasSupportedSORID.add("15");
        reasSupportedSORID.add("19");
        reasSupportedSORID.add("16");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);
        REASResponse reasResponse = new REASResponse();

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("185"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
        
        customerAccountsRequest.setApi360AllowedClient(true);

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Cards");

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponses.add(customerAccountsResponse);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);
        Mockito.when(profileAccountDAO.retrieve360AccountSummary(epfContext, customerAccountKey,false)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
                .thenReturn((reasResponse));

        response = profileAccount360OrchService.execute(customerAccountsRequest, epfContext);
        assertThat(response.get().getCustomerAccountsResponseList().get(0).getBusinessLine(), is("Cards"));

    }
    @Test
    public void testExecute_Fail() throws InterruptedException, ExecutionException {
        EPFContext epfContext = EPFContextContainer.getContext();

        Future<REASResponse> response;

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("2");
        reasSupportedSORID.add("56");
        reasSupportedSORID.add("102");
        reasSupportedSORID.add("7");
        reasSupportedSORID.add("12");
        reasSupportedSORID.add("15");
        reasSupportedSORID.add("19");
        reasSupportedSORID.add("16");
        reasSupportedSORID.add("185");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);
        REASResponse reasResponse = new REASResponse();

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("185"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Cards");

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponses.add(customerAccountsResponse);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);
        Mockito.when(profileAccountDAO.retrieve360AccountSummary(epfContext, customerAccountKey,false)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
                .thenReturn((reasResponse));

        response = profileAccount360OrchService.execute(customerAccountsRequest, epfContext);
        assertThat(response.get().getCustomerAccountsResponseList(), equalTo(null));

    }

}
