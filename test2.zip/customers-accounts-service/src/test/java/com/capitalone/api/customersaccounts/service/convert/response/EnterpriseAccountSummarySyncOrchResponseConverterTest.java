package com.capitalone.api.customersaccounts.service.convert.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.Instant;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.powermock.reflect.Whitebox;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.BrokerageAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.CreditCardAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.DepositAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.LoanAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo.MortgageAcctInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountPreferenceInfo;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRs;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.FeturType;
import com.capitalone.xmlmsgset._2004._07.eil.SevrtyType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType.AddnStat;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class EnterpriseAccountSummarySyncOrchResponseConverterTest {

    private EnterpriseAccountSummarySyncOrchResponseConverter converter = null;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    private static final String BANK_MARKET_CD = "NC";

    private static final String PROD_TYPE_CD = "CHECKING";

    private static final String PROD_DESC = "Money Market Account";

    private static final String BANK_NO = "81";

    private static final String FEATURE_TYPE_CD = "PASSBK";

    private static final String ACCT_ID = "1234";

    private static final String STATUS = "OPEN";

    private static final String NICK_NAME = "My Personal Account";

    private static final String OPEN_DATE = "12/12/2007";

    private static final String AVAILABLE_BAL = "123.00";

    private static final String CURRENT_BAL = "123.00";

    private static final String PRINCIPLE_BAL = "675.00";

    private static final String PRESENT_BAL = "675.00";

    private static final String CAPONE_BALANCE = "999.00";

    private static final String PROD_ID = "IM182";

    private static final String CARD_PLASTIC_ID = "1234";

    private static final String MASKED_PLASTIC_ID = "XXXX-XXXX-XXXX-1234";

    private static final String PAYMENT_AMT = "1908.00";

    private static final String PAYMENT_DUE_DATE = "12/12/2007";

    private static final String BUSINESS_LINE = "DEPOSITS";

    private static final String SOR_ID = "13";

    private static final String SOR_ID_HL = "56";

    @Before
    public void setUp() throws Exception {

        converter = new EnterpriseAccountSummarySyncOrchResponseConverter();

        Whitebox.setInternalState(converter, customerAccountsRefDataBean);
        Whitebox.setInternalState(converter, customerAccountsUtil);
    }

    @Test
    public final void test_convert() {

        AcctSummaryInqRs nativeResponse = new AcctSummaryInqRs();

        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        customerAccountsResponseList.add(response);

        // when(converter.processNativeResponse(null, customerAccountsResponseList));
        // when(customerAccountsRefDataBean.getBusinessLine(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);

        nativeResponse.setCmd(new AcctSummaryInqRs.Cmd());
        nativeResponse.getCmd().setStat(new StatType());

        REASResponse reasResponse = converter.convert(nativeResponse);

        assertNotNull(reasResponse);
    }

    @Test
    public final void test_convert_nullNativeResponse() {

        REASResponse reasResponse = converter.convert(null);

        assertNotNull(reasResponse);
    }

    @Test
    public final void test_processNativeResponse_success() {

        com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo nativeAccountInfo = new com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountInfo();

        // List<DepositAcctInfo> depositAcctInfoList = new
        DepositAcctInfo depositAcctInfo = new DepositAcctInfo();
        nativeAccountInfo.getDepositAcctInfo().add(depositAcctInfo);

        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        nativeAccountInfo.getLoanAcctInfo().add(loanAcctInfo);

        CreditCardAcctInfo CreditCardAcctInfo = new CreditCardAcctInfo();
        nativeAccountInfo.getCreditCardAcctInfo().add(CreditCardAcctInfo);

        BrokerageAcctInfo brokerageAcctInfo = new BrokerageAcctInfo();
        nativeAccountInfo.getBrokerageAcctInfo().add(brokerageAcctInfo);

        MortgageAcctInfo MortgageAcctInfo = new MortgageAcctInfo();
        nativeAccountInfo.getMortgageAcctInfo().add(MortgageAcctInfo);
        // depositAcctInfo.setAcctID(arg0);

        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();

        converter.processNativeResponse(nativeAccountInfo, customerAccountsResponseList);

        assertNotNull(customerAccountsResponseList);

        // REASResponse reasResponse = converter.convert(nativeResponse);
    }

    @Test
    public final void test_processDepositAccount_success() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        DepositAcctInfo depositAcctInfo = new DepositAcctInfo();
        depositAcctInfo.setBankMarketCd(BANK_MARKET_CD);
        depositAcctInfo.setProdTypeCd(PROD_TYPE_CD);
        depositAcctInfo.setProdDesc(PROD_DESC);
        depositAcctInfo.setBankNum(BANK_NO);
        FeturType feturType = new FeturType();
        feturType.setFeturTypeCd(FEATURE_TYPE_CD);
        depositAcctInfo.setFeturType(feturType);
        depositAcctInfo.setAcctID(ACCT_ID);
        depositAcctInfo.setBankAcctStatusDesc(STATUS);

        AccountPreferenceInfo accountPreferenceInfo = new AccountPreferenceInfo();
        accountPreferenceInfo.setAcctNknmNm(NICK_NAME);
        depositAcctInfo.setAccountPreferenceInfo(accountPreferenceInfo);
        depositAcctInfo.setOpenDt(getInstant(OPEN_DATE));
        depositAcctInfo.setAvailableBal(new BigDecimal(AVAILABLE_BAL));
        depositAcctInfo.setCapOneCurrentBal(new BigDecimal(CAPONE_BALANCE));
        depositAcctInfo.setProdID(PROD_ID);
        depositAcctInfo.setRtirmntAcctInd(true);
        depositAcctInfo.setSoRID(new Short(SOR_ID));

        when(converter.getCOFProductType(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getBusinessLine(PROD_TYPE_CD, "13")).thenReturn(BUSINESS_LINE);
        converter.processDepositAccount(responseBean, depositAcctInfo);

        assertEquals(BANK_MARKET_CD, responseBean.getBankMarketCd());
        assertEquals(BUSINESS_LINE, responseBean.getBusinessLine());

    }

    @Test
    public final void test_processLoanAccount_success() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        // loanAcctInfo.setBankMarketCd(BANK_MARKET_CD);
        loanAcctInfo.setProdTypeCd(PROD_TYPE_CD);
        loanAcctInfo.setProdDesc(PROD_DESC);
        loanAcctInfo.setBankNum(BANK_NO);
        loanAcctInfo.setAcctID(ACCT_ID);
        loanAcctInfo.setBankAcctStatusDesc(STATUS);
        loanAcctInfo.setSoRID(new Short("56"));
        AccountPreferenceInfo accountPreferenceInfo = new AccountPreferenceInfo();
        accountPreferenceInfo.setAcctNknmNm(NICK_NAME);
        loanAcctInfo.setAccountPreferenceInfo(accountPreferenceInfo);
        loanAcctInfo.setOpenDt(getInstant(OPEN_DATE));
        loanAcctInfo.setAvailableBal(new BigDecimal(AVAILABLE_BAL));
        loanAcctInfo.setCurrentBal(new BigDecimal(CURRENT_BAL));
        loanAcctInfo.setNextPaymentAmt(new BigDecimal(PAYMENT_AMT));
        loanAcctInfo.setNextPaymentDt(getInstant(PAYMENT_DUE_DATE));
        loanAcctInfo.setProdID(PROD_ID);
        loanAcctInfo.setLoanSeqNum("12");
        loanAcctInfo.setCurrAmtDueAmt(new BigDecimal(PAYMENT_AMT));
        loanAcctInfo.setPrinBal(new BigDecimal(PAYMENT_AMT));
        loanAcctInfo.setAppnID(new BigDecimal(1));

        when(converter.getCOFProductType(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getBusinessLine(PROD_TYPE_CD, "56")).thenReturn(BUSINESS_LINE);
        converter.processLoanAccount(responseBean, loanAcctInfo);

        // assertEquals(PROD_TYPE_CD, responseBean.getProductType());
        assertEquals(PROD_DESC, responseBean.getProductName());
        assertEquals(NICK_NAME, responseBean.getAccountNickname());
        assertEquals(ACCT_ID, responseBean.getAccountNumber());

        assertEquals(STATUS, responseBean.getAccountStatusDescription());
        assertEquals(new BigDecimal(AVAILABLE_BAL), responseBean.getAvailableBalance());
        assertEquals(new BigDecimal(CURRENT_BAL), responseBean.getCurrentBalance());
        assertEquals(new BigDecimal(PAYMENT_AMT), responseBean.getPaymentDueAmount());
        assertEquals(PROD_ID, responseBean.getProductId());
        assertEquals(BUSINESS_LINE, responseBean.getBusinessLine());

    }

    @Test
    public final void test_processLoanAccount_withProdTyp_AL() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        LoanAcctInfo loanAcctInfo = new LoanAcctInfo();
        loanAcctInfo.setProdTypeCd("AL");
        loanAcctInfo.setProdDesc(PROD_DESC);
        loanAcctInfo.setBankNum(BANK_NO);
        loanAcctInfo.setAcctID(ACCT_ID);
        loanAcctInfo.setBankAcctStatusDesc(STATUS);
        loanAcctInfo.setSoRID(new Short("2"));
        AccountPreferenceInfo accountPreferenceInfo = new AccountPreferenceInfo();
        accountPreferenceInfo.setAcctNknmNm(NICK_NAME);
        loanAcctInfo.setAccountPreferenceInfo(accountPreferenceInfo);
        loanAcctInfo.setOpenDt(getInstant(OPEN_DATE));
        loanAcctInfo.setAvailableBal(new BigDecimal(AVAILABLE_BAL));
        loanAcctInfo.setCurrentBal(new BigDecimal(CURRENT_BAL));
        loanAcctInfo.setNextPaymentAmt(new BigDecimal(PAYMENT_AMT));
        loanAcctInfo.setNextPaymentDt(getInstant(PAYMENT_DUE_DATE));
        loanAcctInfo.setProdID(PROD_ID);
        loanAcctInfo.setLoanSeqNum("12");
        loanAcctInfo.setCurrAmtDueAmt(new BigDecimal(PAYMENT_AMT));
        loanAcctInfo.setPrinBal(new BigDecimal(PAYMENT_AMT));
        loanAcctInfo.setAppnID(new BigDecimal(1));
        loanAcctInfo.setCurrAmtDueAmt(new BigDecimal(PAYMENT_AMT));
        loanAcctInfo.setOldstUnpdPmtDueDt(getInstant(PAYMENT_DUE_DATE));
        // setPaymentDueAmount setPaymentDueDate getCurrAmtDueAmt getOldstUnpdPmtDueDt

        when(converter.getCOFProductType(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getBusinessLine(PROD_TYPE_CD, "2")).thenReturn(BUSINESS_LINE);
        converter.processLoanAccount(responseBean, loanAcctInfo);

        // assertEquals(PROD_TYPE_CD, responseBean.getProductType());
        assertEquals(PROD_DESC, responseBean.getProductName());
        assertEquals(NICK_NAME, responseBean.getAccountNickname());
        assertEquals(ACCT_ID, responseBean.getAccountNumber());

        assertEquals(STATUS, responseBean.getAccountStatusDescription());
        assertEquals(new BigDecimal(AVAILABLE_BAL), responseBean.getAvailableBalance());
        assertEquals(new BigDecimal(CURRENT_BAL), responseBean.getCurrentBalance());
        assertEquals(new BigDecimal(PAYMENT_AMT), responseBean.getPaymentDueAmount());
        assertEquals(PROD_ID, responseBean.getProductId());

    }

    @Test
    public final void test_processCreditCardAccount_success() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        CreditCardAcctInfo creditCardAcctInfo = new CreditCardAcctInfo();

        creditCardAcctInfo.setProdTypeCd(PROD_TYPE_CD);
        creditCardAcctInfo.setProdDesc(PROD_DESC);

        creditCardAcctInfo.setAcctID(ACCT_ID);
        creditCardAcctInfo.setAcctPlstcID(CARD_PLASTIC_ID);
        creditCardAcctInfo.setOTBAmt(new BigDecimal(PAYMENT_AMT));

        AccountPreferenceInfo accountPreferenceInfo = new AccountPreferenceInfo();
        accountPreferenceInfo.setAcctNknmNm(NICK_NAME);
        creditCardAcctInfo.setAccountPreferenceInfo(accountPreferenceInfo);
        creditCardAcctInfo.setOpenDt(getInstant(OPEN_DATE));
        creditCardAcctInfo.setCurrOutstdMinmPmtDueAmt(new BigDecimal(PAYMENT_AMT));
        creditCardAcctInfo.setMinmPmtDueDt(getInstant(PAYMENT_DUE_DATE));
        creditCardAcctInfo.setPresBal(new BigDecimal(PRESENT_BAL));
        creditCardAcctInfo.setAcctPlstcID(CARD_PLASTIC_ID);
        creditCardAcctInfo.setSoRID(new Short(SOR_ID));
        creditCardAcctInfo.setCardFirstSix("1234");
        creditCardAcctInfo.setSoRID(new Short("7"));
        when(converter.getCOFProductType(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getBusinessLine(PROD_TYPE_CD, "7")).thenReturn(BUSINESS_LINE);
        converter.processCreditCardAccount(responseBean, creditCardAcctInfo);

        assertEquals(PROD_DESC, responseBean.getProductName());
        // assertEquals(PROD_TYPE_CD, responseBean.getProductType());
        assertEquals(NICK_NAME, responseBean.getAccountNickname());
        assertEquals(MASKED_PLASTIC_ID, responseBean.getAccountNumber());
        assertEquals(MASKED_PLASTIC_ID, responseBean.getDisplayAccountNumber());
        assertEquals(BUSINESS_LINE, responseBean.getBusinessLine());

    }

    @Test
    public final void test_processBrokerageAccount_success() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        BrokerageAcctInfo brokerageAcctInfo = new BrokerageAcctInfo();
        brokerageAcctInfo.setAcctID(ACCT_ID);
        AccountPreferenceInfo accountPreferenceInfo = new AccountPreferenceInfo();
        accountPreferenceInfo.setAcctNknmNm(NICK_NAME);
        brokerageAcctInfo.setAccountPreferenceInfo(accountPreferenceInfo);
        brokerageAcctInfo.setSoRID(new Short(SOR_ID));
        converter.processBrokerageAccount(responseBean, brokerageAcctInfo);
        assertEquals(NICK_NAME, responseBean.getAccountNickname());
        assertEquals(ACCT_ID, responseBean.getAccountNumber());
        assertEquals(ACCT_ID, responseBean.getDisplayAccountNumber());
    }

    @Test
    public final void test_processMortgageAccount_success() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        MortgageAcctInfo mortgageAcctInfo = new MortgageAcctInfo();

        mortgageAcctInfo.setProdTypeCd(PROD_TYPE_CD);
        mortgageAcctInfo.setProdDesc(PROD_DESC);
        mortgageAcctInfo.setAcctID(ACCT_ID);
        mortgageAcctInfo.setBankAcctStatusDesc(STATUS);

        mortgageAcctInfo.setAcctNknmNm(NICK_NAME);
        mortgageAcctInfo.setOpenDt(getInstant(OPEN_DATE));
        mortgageAcctInfo.setSoRID(new Short("102"));
        mortgageAcctInfo.setAvailableBal(new BigDecimal(AVAILABLE_BAL));
        mortgageAcctInfo.setPrincipalBal(new BigDecimal(PRINCIPLE_BAL));
        mortgageAcctInfo.setProdID("7100");
        mortgageAcctInfo.setSoRID(new Short(SOR_ID_HL));

        when(converter.getCOFProductType(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getBusinessLine(PROD_TYPE_CD, "102")).thenReturn(BUSINESS_LINE);
        converter.processMortgageAccount(responseBean, mortgageAcctInfo);

        // assertEquals(PROD_TYPE_CD, responseBean.getProductType());
        assertEquals(PROD_DESC, responseBean.getProductName());
        assertEquals(ACCT_ID, responseBean.getAccountNumber());
        assertEquals(ACCT_ID, responseBean.getDisplayAccountNumber());
        assertEquals(STATUS, responseBean.getAccountStatusDescription());
        assertEquals(NICK_NAME, responseBean.getAccountNickname());
        assertEquals(new BigDecimal(AVAILABLE_BAL), responseBean.getAvailableBalance());
        assertEquals(new BigDecimal(PRINCIPLE_BAL), responseBean.getPrincipalBalance());
        // assertEquals(PROD_ID, responseBean.getProductId());
        // assertEquals(BUSINESS_LINE, responseBean.getBusinessLine());

    }

    @Test
    public final void test_processMortgageAcct_success_withProdNameHIL() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        MortgageAcctInfo mortgageAcctInfo = new MortgageAcctInfo();

        mortgageAcctInfo.setProdTypeCd(PROD_TYPE_CD);
        mortgageAcctInfo.setProdDesc("Home Equity Installment Loan");
        mortgageAcctInfo.setAcctID(ACCT_ID);
        mortgageAcctInfo.setBankAcctStatusDesc(STATUS);

        mortgageAcctInfo.setAcctNknmNm(NICK_NAME);
        mortgageAcctInfo.setOpenDt(getInstant(OPEN_DATE));
        mortgageAcctInfo.setSoRID(new Short("102"));
        mortgageAcctInfo.setAvailableBal(new BigDecimal(AVAILABLE_BAL));
        mortgageAcctInfo.setPrincipalBal(new BigDecimal(PRINCIPLE_BAL));
        mortgageAcctInfo.setProdID("7100");
        mortgageAcctInfo.setSoRID(new Short(SOR_ID_HL));

        when(converter.getCOFProductType(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getBusinessLine(PROD_TYPE_CD, "102")).thenReturn(BUSINESS_LINE);
        converter.processMortgageAccount(responseBean, mortgageAcctInfo);

        // assertEquals(PROD_TYPE_CD, responseBean.getProductType());
        // assertEquals(PROD_DESC, responseBean.getProductName());
        assertEquals(ACCT_ID, responseBean.getAccountNumber());
        assertEquals(ACCT_ID, responseBean.getDisplayAccountNumber());
        assertEquals(STATUS, responseBean.getAccountStatusDescription());
        assertEquals(NICK_NAME, responseBean.getAccountNickname());
        assertEquals(new BigDecimal(AVAILABLE_BAL), responseBean.getAvailableBalance());
        assertEquals(new BigDecimal(PRINCIPLE_BAL), responseBean.getPrincipalBalance());
        // assertEquals(PROD_ID, responseBean.getProductId());
        // assertEquals(BUSINESS_LINE, responseBean.getBusinessLine());Home Equity Line Of Credit

    }

    @Test
    public final void test_processMortgageAcct_success_withProdNameHLC() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        MortgageAcctInfo mortgageAcctInfo = new MortgageAcctInfo();

        mortgageAcctInfo.setProdTypeCd(PROD_TYPE_CD);
        mortgageAcctInfo.setProdDesc("Home Equity Line Of Credit");
        mortgageAcctInfo.setAcctID(ACCT_ID);
        mortgageAcctInfo.setBankAcctStatusDesc(STATUS);

        mortgageAcctInfo.setAcctNknmNm(NICK_NAME);
        mortgageAcctInfo.setOpenDt(getInstant(OPEN_DATE));
        mortgageAcctInfo.setSoRID(new Short("102"));
        mortgageAcctInfo.setAvailableBal(new BigDecimal(AVAILABLE_BAL));
        mortgageAcctInfo.setPrincipalBal(new BigDecimal(PRINCIPLE_BAL));
        mortgageAcctInfo.setProdID("7100");
        mortgageAcctInfo.setSoRID(new Short(SOR_ID_HL));

        when(converter.getCOFProductType(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(customerAccountsRefDataBean.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getProductTypeDescription(PROD_TYPE_CD)).thenReturn(PROD_TYPE_CD);
        when(converter.getBusinessLine(PROD_TYPE_CD, "102")).thenReturn(BUSINESS_LINE);
        converter.processMortgageAccount(responseBean, mortgageAcctInfo);

        // assertEquals(PROD_TYPE_CD, responseBean.getProductType());Home Equity
        // assertEquals(PROD_DESC, responseBean.getProductName());
        assertEquals(ACCT_ID, responseBean.getAccountNumber());
        assertEquals(ACCT_ID, responseBean.getDisplayAccountNumber());
        assertEquals(STATUS, responseBean.getAccountStatusDescription());
        assertEquals(NICK_NAME, responseBean.getAccountNickname());
        assertEquals(new BigDecimal(AVAILABLE_BAL), responseBean.getAvailableBalance());
        assertEquals(new BigDecimal(PRINCIPLE_BAL), responseBean.getPrincipalBalance());

    }

    @Test
    public final void test_getAdditionalStat_nullResponseStat() {

        StatType responseStatus = null;

        converter.getAdditionalStat(responseStatus);

        assertNull(converter.getAdditionalStat(responseStatus));

    }

    @Test
    public final void test_getAdntStat_validRespStat_WARNING_PARTIAL_SUCCESS() {

        StatType responseStatus = new StatType();
        AddnStat addnStat = new AddnStat();
        addnStat.setStatCd(123L);
        responseStatus.setStatCd(Constants.PARTIAL_SUCCESS);
        responseStatus.setSevrty(SevrtyType.WARNING);
        responseStatus.setSrvrStatCd("123");
        responseStatus.setStatDesc("abc");
        responseStatus.getAddnStat().add(addnStat);

        converter.getAdditionalStat(responseStatus);

        assertNotNull(responseStatus.getAddnStat());

    }

    @Test
    public final void test_getAdntStat_validRespStat_WARNING_DEFAULT() {

        StatType responseStatus = new StatType();
        AddnStat addnStat = new AddnStat();
        addnStat.setStatCd(123L);
        responseStatus.setStatCd(120);
        responseStatus.setSevrty(SevrtyType.WARNING);
        responseStatus.setSrvrStatCd("123");
        responseStatus.setStatDesc("abc");
        responseStatus.getAddnStat().add(addnStat);

        converter.getAdditionalStat(responseStatus);

        assertNotNull(responseStatus.getAddnStat());

    }

    @Test
    public final void test_getAdntStat_validRespStat_ERROR() {

        StatType responseStatus = new StatType();
        AddnStat addnStat = new AddnStat();
        addnStat.setStatCd(123L);
        responseStatus.setStatCd(1420);
        responseStatus.setSevrty(SevrtyType.ERROR);
        responseStatus.setSrvrStatCd("123");
        responseStatus.setStatDesc("abc");
        responseStatus.getAddnStat().add(addnStat);

        converter.getAdditionalStat(responseStatus);

        assertNotNull(responseStatus.getAddnStat());

    }

    @Test
    public final void test_getAdntStat_validRespStat_ERROR_Default() {

        StatType responseStatus = new StatType();
        AddnStat addnStat = new AddnStat();
        addnStat.setStatCd(123L);
        responseStatus.setStatCd(1);
        responseStatus.setSevrty(SevrtyType.ERROR);
        responseStatus.setSrvrStatCd("123");
        responseStatus.setStatDesc("abc");
        responseStatus.getAddnStat().add(addnStat);

        converter.getAdditionalStat(responseStatus);

        assertNotNull(responseStatus.getAddnStat());

    }

    @Test
    public final void test_getAdntStat_validRespStat_Default() {

        StatType responseStatus = new StatType();
        AddnStat addnStat = new AddnStat();
        addnStat.setStatCd(123L);
        responseStatus.setStatCd(1420);
        responseStatus.setSevrty(SevrtyType.INFO);
        responseStatus.setSrvrStatCd("123");
        responseStatus.setStatDesc("abc");
        responseStatus.getAddnStat().add(addnStat);

        converter.getAdditionalStat(responseStatus);

        assertNotNull(responseStatus.getAddnStat());

    }

    @Test
    public final void test_getAdditionalStat_failure() {

        StatType responseStatus = new StatType();
        responseStatus.setStatCd(Constants.PARTIAL_SUCCESS);

        converter.getAdditionalStat(responseStatus);

        assertNull(converter.getAdditionalStat(responseStatus));

    }

    @Test
    public final void test_setCardAccountStatus_closedStatus_success() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        CreditCardAcctInfo creditCardAcctInfo = new CreditCardAcctInfo();
        creditCardAcctInfo.setClsdInd(new Boolean(true));

        converter.setCardAccountStatus(responseBean, creditCardAcctInfo);

        assertEquals(Constants.CARD_STATUS_CLOSED, responseBean.getAccountStatusDescription());

    }

    @Test
    public final void test_setCardAccountStatus_closedStatus_failure() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        CreditCardAcctInfo creditCardAcctInfo = new CreditCardAcctInfo();

        converter.setCardAccountStatus(responseBean, creditCardAcctInfo);

        assertNotEquals(Constants.CARD_STATUS_CLOSED, responseBean.getAccountStatusDescription());

    }

    @Test
    public final void test_setCardAccountStatus_chargeOffStatus_success() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        CreditCardAcctInfo creditCardAcctInfo = new CreditCardAcctInfo();
        creditCardAcctInfo.setChrgdOffInd(new Boolean(true));

        converter.setCardAccountStatus(responseBean, creditCardAcctInfo);

        assertEquals(Constants.CARD_STATUS_CHRG_OFF, responseBean.getAccountStatusDescription());

    }

    @Test
    public final void test_setCardAccountStatus_chargeOffStatus_failure() {

        CustomerAccountsResponse responseBean = new CustomerAccountsResponse();

        CreditCardAcctInfo creditCardAcctInfo = new CreditCardAcctInfo();

        converter.setCardAccountStatus(responseBean, creditCardAcctInfo);

        assertNotEquals(Constants.CARD_STATUS_CHRG_OFF, responseBean.getAccountStatusDescription());

    }

    @Test
    public final void test_getBusinessLine() {

        when(customerAccountsRefDataBean.getBusinessLine(PROD_TYPE_CD, String.valueOf(Constants.PROFILE_SOR_ID_INT)))
                .thenReturn(PROD_TYPE_CD);

        String businessLine = converter.getBusinessLine(PROD_TYPE_CD, "185");
        assertEquals(PROD_TYPE_CD, businessLine);

    }

    public static XMLGregorianCalendar getXMLGregorianCalendar(String date) {
        XMLGregorianCalendar xmlCalender = null;
        GregorianCalendar calender = new GregorianCalendar();
        try {
            calender.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).parse(date));
        } catch (ParseException e1) {
            // TODO Auto-generated catch block
            // e1.printStackTrace();
        }
        try {
            xmlCalender = DatatypeFactory.newInstance().newXMLGregorianCalendar(calender);
        } catch (DatatypeConfigurationException e) {
            // TODO Auto-generated catch block
            // e.printStackTrace();
        }
        return xmlCalender;
    }

    public static Instant getInstant(String date) {
        Instant instant = null;
        DateTimeFormatter dateTimeFormatter = null;
        dateTimeFormatter = DateTimeFormat.forPattern("MM/dd/yyyy");
        instant = Instant.parse(date, dateTimeFormatter);
        return instant;
    }
}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */