package com.capitalone.api.customersaccounts.entity.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.api.loans.homeloans.accounts.model.v3.Account;
import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.EndpointManager;
import com.capitalone.epf.servicelocator.model.EndpointProperties;


@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class LoansHomeLoansEntityImplTest {
    
    @InjectMocks
    private LoansHomeLoansEntityImpl Impl;

    @Mock
    private Client eapiRestClient;

    @Mock
    private EndpointManager endpointManager;

    @Mock
    private ReferenceIdEncoder encoder;

    @Mock
    private AutoLoanAccount autoLoanAccount;

    @Mock
    private ConversionService conversionService;

    @Mock
    private WebTarget requestPath;

    @Mock
    private WebTarget target;

    @Mock
    private Builder builder;

    @Mock
    private EPFContext context;

    @Mock
    private Configuration config;
    
    @Mock
    private CustomerAPIRESTException e;
    
    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    private static final String APPLICATION_JSON_V_3 = "application/json; v=3";

    @Test
    public void retiveAccountDetailsTest() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "loans-homeloans-accounts-Service",
                null, null);

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();

        customerAccountsResponse.setAccountNumber("12345678912");
        String apiVersion = "3";
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("56"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
        AccountReferenceId accountRefID = new AccountReferenceId(customerAccountKey.getAccountNumber(),
                customerAccountKey.getSorId().toString());

        Account account = new Account();
        account.setAvailableCreditLimit(new BigDecimal("1200"));

        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "loans-homeloans-accounts-Service", null))
                .thenReturn(endpointProperties);

        Mockito.when(encoder.encode(accountRefID.getReferenceId())).thenReturn("12345");

        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json; v=" + apiVersion)).thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=" + apiVersion)
                        .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V_3)).thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=" + apiVersion)
                        .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V_3).header("entitled", "entitled"))
                .thenReturn(builder);
        Mockito.when(
                target.request().accept("application/json; v=" + apiVersion)
                        .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_V_3).header("entitled", "entitled")
                        .get(Account.class)).thenReturn(account);
        
        Mockito.when(conversionService.convert(account,
                            CustomerAccountsResponse.class)).thenReturn(customerAccountsResponse);
        Mockito.when(customerAccountsUtil.getEndpointProperties("loans-homeloans-accounts-Service")).thenReturn(endpointProperties);
        account = Impl.retiveAccountDetails(customerAccountKey, context, "12345678912", "56");
        assertNotNull(account);
        //assertThat(response.get().getCustomerAccountsResponseList().get(0).getAccountNumber(), equalTo("12345678912"));
        
    }

}
