package com.capitalone.api.customersaccounts.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.impl.ODSBrokerageAccountsISDAOImpl;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class ODSBrokerageAccountsISOrchServiceTest {

    @InjectMocks
    private ODSBrokerageAccountsISOrchService odsBrokerageAccountsISOrchService;

    @Mock
    private ODSBrokerageAccountsISDAOImpl odsBrokerageAccountsISDAOImpl;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    private static final int ACCOUNT_LIMIT = 25;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {

        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();

        CustomerAccountKey key1 = new CustomerAccountKey();
        key.setAccountNumber("12345678913");
        key.setSorId((short) 102);
        // customerAccountKeyList.add(key);
        customerAccountKeyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();

        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("7");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("102");
        customerAccountsResponse.setAccountId("12345678913");
        customerAccountsResponse.setBusinessLine("Brokerage");
        customerAccountsResponse.setCurrencyCode("USD");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);

        EPFContext context = EPFContextContainer.getContext();

        Mockito.when(odsBrokerageAccountsISDAOImpl.getBrokerageAccounts(context, customerAccountKeyList)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));

        Object keyList = key1;
        List<Object> key1ObjectList = new ArrayList<Object>();
        key1ObjectList.add(keyList);
        List<List<Object>> splitAccountKeyList = new ArrayList<List<Object>>();
        splitAccountKeyList.add(key1ObjectList);
        List<Object> list = new ArrayList<Object>();
        list.add(key1);
        List<List<Object>> value = new ArrayList<List<Object>>();
        value.add(list);

        Mockito.when(customerAccountsUtil.split(list, ACCOUNT_LIMIT)).thenReturn(splitAccountKeyList);

        Mockito.when(customerAccountsUtil.findSORID(customerAccountsRequest, (short) 102)).thenReturn(true);
        response = odsBrokerageAccountsISOrchService.execute(customerAccountsRequest, context);

        assertNotNull(response);
    }
}
