package com.capitalone.api.customersaccounts.dao.impl;

import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.powermock.reflect.Whitebox;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.CSTBusinessCustomerDAO;
import com.capitalone.api.customersaccounts.service.convert.request.CSTBusinessCustomerRqConverter;
import com.capitalone.api.customersaccounts.service.convert.response.CSTBusinessCustomerRsConverter;
import com.capitalone.api.customersaccounts.service.pojo.CSTBusinessCustomerResponse;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRoleTypes;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRq;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerSignersRs;
import com.capitalone.cstbusinesscustomeris.v1.BusinessDetailsRs;
import com.capitalone.cstbusinesscustomeris.v1.CSTBusinessCustomerSignersISSOAP;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class CSTBusinessCustomerDAOImplTest {

    CSTBusinessCustomerDAO CSTBusinessCustomerDAOImpl;

    @Mock
    private CSTBusinessCustomerSignersISSOAP cstBusinessCustomerISService;

    @Mock
    private CSTBusinessCustomerRqConverter cSTBusinessCustomerRqConverter;

    @Mock
    private CSTBusinessCustomerRsConverter cSTBusinessCustomerRsConverter;

    private static final String CUSTOMER_ID = "20001";

    @Before
    public void setUp() throws Exception {
        CSTBusinessCustomerDAOImpl = new CSTBusinessCustomerDAOImpl();
        Whitebox.setInternalState(CSTBusinessCustomerDAOImpl, cstBusinessCustomerISService);
        Whitebox.setInternalState(CSTBusinessCustomerDAOImpl, CSTBusinessCustomerRqConverter.class,
                cSTBusinessCustomerRqConverter);
        Whitebox.setInternalState(CSTBusinessCustomerDAOImpl, CSTBusinessCustomerRsConverter.class,
                cSTBusinessCustomerRsConverter);

    }

    @Test
    public final void getAccountRelTest() throws InterruptedException, ExecutionException {
        CSTBusinessCustomerResponse response = new CSTBusinessCustomerResponse();
        BusinessCustomerSignersRs businessCustomerSignersRs = new BusinessCustomerSignersRs();
        BusinessCustomerSignersRs.Cmd cmd1 = new BusinessCustomerSignersRs.Cmd();

        StatType stat1 = new StatType();
        stat1.setSrvrStatCd("1");

        BusinessCustomerRoleTypes custRole = new BusinessCustomerRoleTypes();
        custRole.setFullName("name");
        custRole.setOwnershipType("primary");
        custRole.setPrimaryCustomerID(CUSTOMER_ID);

        cmd1.setName("bus_signer");
        cmd1.getBusinessCustomerRoleTypes().add(custRole);
        cmd1.setStat(stat1);
        businessCustomerSignersRs.setCmd(cmd1);

        BusinessDetailsRs businessDetailsRs = new BusinessDetailsRs();
        BusinessDetailsRs.Cmd cmd2 = new BusinessDetailsRs.Cmd();
        StatType stat = new StatType();
        stat.setSrvrStatCd("1");

        cmd2.setName("name2");
        cmd2.setCustomerAccountRelationshipCode(CUSTOMER_ID);
        cmd2.setStat(stat);
        businessDetailsRs.setCmd(cmd2);

        BusinessCustomerRq businessCustomerRq = cSTBusinessCustomerRqConverter.convert((String) Mockito.anyObject());
        when(cstBusinessCustomerISService.businessCustomerSignersInq(businessCustomerRq)).thenReturn(
                businessCustomerSignersRs);

        when(cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq)).thenReturn(businessDetailsRs);

        // businessCustomerSignersRs = cstBusinessCustomerISService.businessCustomerSignersInq(businessCustomerRq);
        // businessDetailsRs = cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq);

        Pair<BusinessCustomerSignersRs, BusinessDetailsRs> inputPair = Pair.of(businessCustomerSignersRs,
                businessDetailsRs);
        response = cSTBusinessCustomerRsConverter.convert(inputPair);
        CSTBusinessCustomerDAOImpl.getAccountRelationships(CUSTOMER_ID);

    }

    @Test
    public final void getAccountRelNullTest() throws InterruptedException, ExecutionException {
        CSTBusinessCustomerResponse response = null;
        BusinessCustomerSignersRs businessCustomerSignersRs = null;
        BusinessDetailsRs businessDetailsRs = null;

        BusinessCustomerRq businessCustomerRq = cSTBusinessCustomerRqConverter.convert("");

        businessCustomerSignersRs = cstBusinessCustomerISService.businessCustomerSignersInq(businessCustomerRq);
        businessDetailsRs = cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq);

        Pair<BusinessCustomerSignersRs, BusinessDetailsRs> inputPair = Pair.of(businessCustomerSignersRs,
                businessDetailsRs);
        response = cSTBusinessCustomerRsConverter.convert(inputPair);
        CSTBusinessCustomerDAOImpl.getAccountRelationships(CUSTOMER_ID);

    }

}
