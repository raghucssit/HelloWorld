/**
 * 
 */
package com.capitalone.api.customersaccounts.service.convert.request;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerInfoBean;
import com.capitalone.profileaccountrelationshipsis.v1.AccountRelationshipRq;

/**
 * @author oto081
 * 
 */
@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class ProfileAccountRelationshipsISRequestConverterTest {

    private static final String ACCOUNT_NO = "4000176";

    private static final String OPERATION_NAME = "acctRelRqCmd";

    ProfileAccountRelationshipsISRequestConverter converter;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        converter = new ProfileAccountRelationshipsISRequestConverter();
    }

    @Test
    public final void test() {
        CustomerInfoBean custInfo = new CustomerInfoBean();
        custInfo.setAccountNumber(ACCOUNT_NO);
        AccountRelationshipRq request = converter.convert(custInfo);

        assertNotNull(request);
        assertNotNull(request);
        assertNotNull(request.getCmd());
        assertEquals(ACCOUNT_NO, request.getCmd().getAccountNumber());
        assertEquals(OPERATION_NAME, request.getCmd().getName());

    }

    @Test
    public final void test_Failure() {
        CustomerInfoBean custInfo = new CustomerInfoBean();
        AccountRelationshipRq request = converter.convert(custInfo);

        assertNotNull(request);
        assertNotNull(request);
        assertNotNull(request.getCmd());
        assertNull(request.getCmd().getAccountNumber());

    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
