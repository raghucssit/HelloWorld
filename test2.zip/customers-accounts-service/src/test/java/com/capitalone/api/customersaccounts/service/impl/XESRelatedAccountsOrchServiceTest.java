package com.capitalone.api.customersaccounts.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.XESRelatedAccountDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class XESRelatedAccountsOrchServiceTest {

    private XESRelatedAccountsOrchService service;

    @Mock
    private XESRelatedAccountDao xesRelatedAccountDAO;

    @Before
    public void setUp() {
        service = new XESRelatedAccountsOrchService();
        Whitebox.setInternalState(service, xesRelatedAccountDAO);
    }

    @Test
    public void testExecute() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        List<XESRelationshipResponseBean> finalXESResponseList = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> result = new AsyncResult<List<XESRelationshipResponseBean>>(
                finalXESResponseList);

        key.setSorId((short) 185);
        key.setSorId((short) 56);
        key.setSorId((short) 51);
        key.setConsumerId("123");
        String accountId = "1234";
        when(
                xesRelatedAccountDAO.retrieve((EPFContext) Mockito.anyObject(), Mockito.anyString(),
                        Mockito.anyString(), Mockito.anyString())).thenReturn(result);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        service.execute(request, null);
    }

    @Test
    public void testExecute1() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        List<XESRelationshipResponseBean> finalXESResponseList = new ArrayList<XESRelationshipResponseBean>();
        XESRelationshipResponseBean bean = new XESRelationshipResponseBean();
        bean.setAccountNumber("1234");
        bean.setCustAcctFromRelationshipCd("PRI");
        bean.setCustAcctToRelationshipCd("");
        bean.setCustomerId("123");
        bean.setfISApplicationSystemCd("");
        finalXESResponseList.add(bean);
        Future<List<XESRelationshipResponseBean>> result = new AsyncResult<List<XESRelationshipResponseBean>>(
                finalXESResponseList);

        key.setSorId((short) 12);
        key.setSorId((short) 13);
        key.setSorId((short) 14);
        key.setConsumerId("123");
        // String accountId="1234";
        customerAccountKeyList.add(key);
        when(
                xesRelatedAccountDAO.retrieve((EPFContext) Mockito.anyObject(), Mockito.anyString(),
                        Mockito.anyString(), Mockito.anyString())).thenReturn(result);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        service.execute(request, null);
    }

    @Test
    public void testExecute2() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        List<XESRelationshipResponseBean> finalXESResponseList = new ArrayList<XESRelationshipResponseBean>();
        XESRelationshipResponseBean bean = new XESRelationshipResponseBean();
        bean.setAccountNumber("1234");
        bean.setCustAcctFromRelationshipCd("PRI");
        bean.setCustAcctToRelationshipCd("");
        bean.setCustomerId("123");
        bean.setfISApplicationSystemCd("");
        finalXESResponseList.add(bean);
        Future<List<XESRelationshipResponseBean>> result = new AsyncResult<List<XESRelationshipResponseBean>>(
                finalXESResponseList);

        key.setSorId((short) 7);
        key.setConsumerId("123");
        // String accountId="1234";
        customerAccountKeyList.add(key);
        when(
                xesRelatedAccountDAO.retrieve((EPFContext) Mockito.anyObject(), Mockito.anyString(),
                        Mockito.anyString(), Mockito.anyString())).thenReturn(result);
        request.setCustomerAccountKeyList(customerAccountKeyList);
        service.execute(request, null);
    }
}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
