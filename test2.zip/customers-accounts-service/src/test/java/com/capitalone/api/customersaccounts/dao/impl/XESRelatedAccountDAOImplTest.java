package com.capitalone.api.customersaccounts.dao.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.powermock.reflect.Whitebox;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.XESRelatedAccountDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRq;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRq.Cmd.PagingRqInfo;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs.AcctListInfo;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs.PagingRsInfo;
import com.capitalone.xesrelatedacctis.v1.Cursor;
import com.capitalone.xesrelatedacctis.v1.XESRelatedAcctISSoap;
import com.capitalone.xmlmsgset._2004._07.eil.HdrType;
import com.capitalone.xmlmsgset._2004._07.eil.SevrtyType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@SuppressWarnings("unchecked")
@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class XESRelatedAccountDAOImplTest {

    private XESRelatedAccountDao dao;

    @Mock
    private XESRelatedAcctISSoap xesRelatedAcctISSoap;

    @Mock
    private ConversionService conversionService;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;
    
    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    /*
     * @Mock private PingService pingService;
     */

    private EPFContext context;

    private static final String API_KEY = "ARGOTELLER";

    private static final String CUST_ID = "20001";

    private final static long CURSOR_COUNT = 100;

    private final static long RECORD_COUNT = 100;

    // private CustomerInfoBean customerInfoBean;

    @Before
    public void setUp() throws Exception {

        dao = new XESRelatedAccountDaoImpl();
        // Whitebox.setInternalState(dao, PingService.class, pingService);
        Whitebox.setInternalState(dao, XESRelatedAcctISSoap.class, xesRelatedAcctISSoap);
        Whitebox.setInternalState(dao, ConversionService.class, conversionService);
        Whitebox.setInternalState(dao, CustomerAccountsUtil.class, customerAccountsUtil);
        Whitebox.setInternalState(dao, CustomerAccountsRefDataBean.class, customerAccountsRefDataBean);
        context = new EPFContext();
        EPFContextContainer.getcurrentContext().set(context);
    }

    @Test
    public final void test_retrieve_nullRequest() throws InterruptedException, ExecutionException {

        AcctListInqRq nativeRequest = null;
        AcctListInqRs acctListInqISRs = null;
        String accountId = null;
        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(accountId);
        when(conversionService.convert(Mockito.anyObject(), Mockito.any(Class.class))).thenReturn(nativeRequest);
        when(xesRelatedAcctISSoap.acctListInq(nativeRequest)).thenReturn(acctListInqISRs);

        Future<List<XESRelationshipResponseBean>> actualResponse = dao.retrieve(context, CUST_ID, accountId, API_KEY);

        Future<REASResponse> actualResponse1 = dao.retrieve(context, CUST_ID, accountIdList, (short) 69);
        assertNotNull(actualResponse);
        assertNotNull(actualResponse1);
        // verify(conversionService).convert(customerInfoBean, AcctListInqRq.class);
        // verify(xesRelatedAcctISSoap).acctListInq(nativeRequest);

    }

    @Test
    public final void test_retrieve_validRequest() throws InterruptedException, ExecutionException {
        // customerInfoBean = new CustomerInfoBean();
        AcctListInqRq nativeRequest = new AcctListInqRq();
        nativeRequest.setHdr(new HdrType());
        nativeRequest.setCmd(new AcctListInqRq.Cmd());

        // Creating PagingRsInfo Type
        nativeRequest.getCmd().setPagingRqInfo(new PagingRqInfo());
        nativeRequest.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);

        AcctListInqRs acctListInqISRs = new AcctListInqRs();
        AcctListInqRs.Cmd cmd = new AcctListInqRs.Cmd();
        AcctListRs acctList = Mockito.mock(AcctListRs.class);
        List<AcctListInfo> list = new ArrayList<AcctListInqRs.Cmd.AcctListRs.AcctListInfo>();
        AcctListInfo info = new AcctListInfo();
        list.add(info);

        cmd.setAcctListRs(acctList);
        acctListInqISRs.setCmd(cmd);

        PagingRsInfo pagingRsInfo = new PagingRsInfo();
        Cursor cursor = new Cursor();
        cursor.setBinLength(CURSOR_COUNT);
        pagingRsInfo.setCursor(cursor);

        AcctListRs acctListRs = new AcctListRs();
        AcctListInfo acctListInfo = new AcctListInfo();
        acctListInfo.setAcctID("1234");

        acctListRs.getAcctListInfo().add(acctListInfo);
        acctListInqISRs.getCmd().setAcctListRs(acctListRs);
        acctListRs.setPagingRsInfo(pagingRsInfo);
        acctListInqISRs.getCmd().setAcctListRs(null);

        String accountId = "1234";
        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(accountId);

        when(acctList.getAcctListInfo()).thenReturn(list);
        when(conversionService.convert(Mockito.anyObject(), Mockito.any(Class.class))).thenReturn(nativeRequest);
        when(xesRelatedAcctISSoap.acctListInq(nativeRequest)).thenReturn(acctListInqISRs);

        Future<List<XESRelationshipResponseBean>> actualResponse = dao.retrieve(context, CUST_ID, accountId, API_KEY);
        Future<REASResponse> actualResponse1 = dao.retrieve(context, CUST_ID, accountIdList, (short) 70);

        assertNotNull(actualResponse);
        assertNotNull(actualResponse1);

    }

    @Test
    public final void test_retrieve_validRequest1() throws InterruptedException, ExecutionException {
        AcctListInqRq nativeRequest = new AcctListInqRq();
        nativeRequest.setHdr(new HdrType());
        nativeRequest.setCmd(new AcctListInqRq.Cmd());

        // Creating PagingRsInfo Type
        nativeRequest.getCmd().setPagingRqInfo(new PagingRqInfo());
        nativeRequest.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);

        AcctListInqRs acctListInqISRs = new AcctListInqRs();
        AcctListInqRs.Cmd cmd = new AcctListInqRs.Cmd();
        AcctListRs value = new AcctListRs();
        PagingRsInfo pagingRsInfo = new PagingRsInfo();
        Cursor cursor = new Cursor();
        cursor.setBinLength(CURSOR_COUNT);
        pagingRsInfo.setCursor(cursor);

        value.setPagingRsInfo(pagingRsInfo);
        AcctListInfo acctListInfo = new AcctListInfo();
        acctListInfo.setAcctID("1234");
        acctListInfo.setProdID("SD");
        value.getAcctListInfo().add(acctListInfo);

        cmd.setAcctListRs(value);
        cmd.setName("Name");
        StatType value2 = new StatType();
        value2.setStatCd(CURSOR_COUNT);
        cmd.setStat(value2);

        List<AcctListInfo> list = new ArrayList<AcctListInqRs.Cmd.AcctListRs.AcctListInfo>();
        AcctListInfo info = new AcctListInfo();
        info.setAcctID("1234");
        info.setProdID("SD");
        list.add(info);

        acctListInqISRs.setCmd(cmd);

        String accountId = "1234";

        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(accountId);

        Object relationshipInfo = null;
        // when(conversionService.convert(Mockito.anyObject(), Mockito.any(Class.class))).thenReturn(nativeRequest);
        when(conversionService.convert(relationshipInfo, AcctListInqRq.class)).thenReturn(nativeRequest);
        REASResponse sdbResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("1234");
        response.setAccountNumber(accountId);
        response.setSorId("70");
        customerAccountsResponseList.add(response);
        // sdbResponse.getCustomerAccountsResponseList().add(response);
        sdbResponse.setCustomerAccountsResponseList(customerAccountsResponseList);
        when(conversionService.convert(info, REASResponse.class)).thenReturn(sdbResponse);

        when(xesRelatedAcctISSoap.acctListInq(null)).thenReturn(acctListInqISRs);

        REASResponse reasResponse = new REASResponse();
        Mockito.when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
        .thenReturn((reasResponse));
        Future<REASResponse> actualResponse1 = dao.retrieve(context, CUST_ID, accountIdList, (short) 70);

        assertNotNull(actualResponse1);

    }

    @Test
    public final void test_retrieve_acctListNull() throws InterruptedException, ExecutionException {
        AcctListInqRq nativeRequest = new AcctListInqRq();
        nativeRequest.setHdr(new HdrType());
        nativeRequest.setCmd(new AcctListInqRq.Cmd());

        // Creating PagingRsInfo Type
        nativeRequest.getCmd().setPagingRqInfo(new PagingRqInfo());
        nativeRequest.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);

        AcctListInqRs acctListInqISRs = new AcctListInqRs();
        AcctListInqRs.Cmd cmd = new AcctListInqRs.Cmd();
        AcctListRs value = new AcctListRs();
        PagingRsInfo pagingRsInfo = new PagingRsInfo();
        Cursor cursor = new Cursor();
        cursor.setBinLength(CURSOR_COUNT);
        pagingRsInfo.setCursor(cursor);

        value.setPagingRsInfo(pagingRsInfo);
        AcctListInfo acctListInfo = new AcctListInfo();
        acctListInfo.setAcctID("1234");
        acctListInfo.setProdID("SD");
        value.getAcctListInfo().add(acctListInfo);

        // cmd.setAcctListRs(value );
        cmd.setName("Name");
        StatType value2 = new StatType();
        value2.setStatCd(CURSOR_COUNT);
        cmd.setStat(value2);

        List<AcctListInfo> list = new ArrayList<AcctListInqRs.Cmd.AcctListRs.AcctListInfo>();
        AcctListInfo info = new AcctListInfo();
        info.setAcctID("1234");
        info.setProdID("SD");
        list.add(info);

        acctListInqISRs.setCmd(cmd);

        String accountId = "1234";

        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(accountId);

        Object relationshipInfo = null;
        when(conversionService.convert(relationshipInfo, AcctListInqRq.class)).thenReturn(nativeRequest);
        REASResponse sdbResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("1234");
        response.setAccountNumber(accountId);
        response.setSorId("70");
        customerAccountsResponseList.add(response);
        sdbResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        when(conversionService.convert(info, REASResponse.class)).thenReturn(sdbResponse);

        when(xesRelatedAcctISSoap.acctListInq(null)).thenReturn(acctListInqISRs);

        Future<REASResponse> actualResponse1 = dao.retrieve(context, CUST_ID, accountIdList, (short) 70);

        assertNotNull(actualResponse1);

    }

    @Test
    public final void test_retrieve_settingBankAcctTypeCode() throws InterruptedException, ExecutionException {
        AcctListInqRq nativeRequest = new AcctListInqRq();
        nativeRequest.setHdr(new HdrType());
        nativeRequest.setCmd(new AcctListInqRq.Cmd());

        // Creating PagingRsInfo Type
        nativeRequest.getCmd().setPagingRqInfo(new PagingRqInfo());
        nativeRequest.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);

        AcctListInqRs acctListInqISRs = new AcctListInqRs();
        AcctListInqRs.Cmd cmd = new AcctListInqRs.Cmd();
        AcctListRs value = new AcctListRs();
        PagingRsInfo pagingRsInfo = new PagingRsInfo();
        Cursor cursor = new Cursor();
        cursor.setBinLength(CURSOR_COUNT);
        pagingRsInfo.setCursor(cursor);

        value.setPagingRsInfo(pagingRsInfo);
        AcctListInfo acctListInfo = new AcctListInfo();
        acctListInfo.setAcctID("1234");
        acctListInfo.setProdID("SB");
        acctListInfo.setBankAcctTypeCd("SD");
        value.getAcctListInfo().add(acctListInfo);

        cmd.setAcctListRs(value);
        cmd.setName("Name");
        StatType value2 = new StatType();
        value2.setStatCd(CURSOR_COUNT);
        cmd.setStat(value2);

        List<AcctListInfo> list = new ArrayList<AcctListInqRs.Cmd.AcctListRs.AcctListInfo>();
        AcctListInfo info = new AcctListInfo();
        info.setAcctID("1234");
        info.setProdID("SB");
        info.setBankAcctTypeCd("SD");
        list.add(info);

        acctListInqISRs.setCmd(cmd);

        String accountId = "1234";

        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(accountId);

        Object relationshipInfo = null;
        when(conversionService.convert(relationshipInfo, AcctListInqRq.class)).thenReturn(nativeRequest);
        REASResponse sdbResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("1234");
        response.setAccountNumber(accountId);
        response.setSorId("70");
        customerAccountsResponseList.add(response);
        sdbResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        when(conversionService.convert(info, REASResponse.class)).thenReturn(sdbResponse);

        when(xesRelatedAcctISSoap.acctListInq(null)).thenReturn(acctListInqISRs);

        Future<REASResponse> actualResponse1 = dao.retrieve(context, CUST_ID, accountIdList, (short) 70);
        assertNotNull(actualResponse1);

    }

    @Test
    public final void test_retrieve_pagination() throws InterruptedException, ExecutionException {
        // customerInfoBean = new CustomerInfoBean();
        PagingRqInfo pagingRqInfo = new PagingRqInfo();
        AcctListInqRq nativeRequest = new AcctListInqRq();
        nativeRequest.setHdr(new HdrType());
        AcctListInqRq.Cmd reqCmd = new AcctListInqRq.Cmd();
        reqCmd.setPagingRqInfo(pagingRqInfo);
        nativeRequest.setCmd(reqCmd);
        // PagingRsInfo pagingRsInfo = null;

        AcctListInqRs acctListInqISRs = new AcctListInqRs();
        acctListInqISRs.setCmd(new AcctListInqRs.Cmd());

        PagingRsInfo pagingRsInfo = new PagingRsInfo();
        Cursor cursor = new Cursor();
        cursor.setBinLength(CURSOR_COUNT);
        pagingRsInfo.setCursor(cursor);

        AcctListRs acctListRs = new AcctListRs();
        AcctListInfo acctListInfo = new AcctListInfo();
        acctListInfo.setAcctID("1234");
        acctListRs.getAcctListInfo().add(acctListInfo);
        acctListInqISRs.getCmd().setAcctListRs(null);
        acctListRs.setPagingRsInfo(pagingRsInfo);

        Map<String, AcctListRs> response = new HashMap<String, AcctListRs>();
        response.put("1234", new AcctListRs());

        String accountId = "1234";

        when(conversionService.convert(Mockito.anyObject(), Mockito.any(Class.class))).thenReturn(nativeRequest);
        when(xesRelatedAcctISSoap.acctListInq(nativeRequest)).thenReturn(acctListInqISRs);

        Future<List<XESRelationshipResponseBean>> actualResponse = dao.retrieve(context, CUST_ID, accountId, API_KEY);

        assertNotNull(actualResponse);

        // verify(conversionService).convert(customerInfoBean, AcctListInqRq.class);
        // verify(xesRelatedAcctISSoap).acctListInq(nativeRequest);
    }

    @Test
    public final void test_retrieve_exception() throws InterruptedException, ExecutionException {
        // customerInfoBean = new CustomerInfoBean();
        AcctListInqRq nativeRequest = new AcctListInqRq();
        nativeRequest.setHdr(new HdrType());

        String accountId = "1234";

        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(accountId);

        when(conversionService.convert(Mockito.anyObject(), Mockito.any(Class.class))).thenReturn(nativeRequest);
        when(xesRelatedAcctISSoap.acctListInq(nativeRequest)).thenThrow(new RuntimeException());

        Future<List<XESRelationshipResponseBean>> actualResponse = dao.retrieve(context, CUST_ID, accountId, API_KEY);

        Future<REASResponse> actualResponse1 = dao.retrieve(context, CUST_ID, accountIdList, (short) 69);

        assertNotNull(actualResponse);
        assertNotNull(actualResponse1);

    }

    @Test
    public final void test_retrieve_settingSevrty() throws InterruptedException, ExecutionException {
        AcctListInqRq nativeRequest = new AcctListInqRq();
        nativeRequest.setHdr(new HdrType());
        nativeRequest.setCmd(new AcctListInqRq.Cmd());

        // Creating PagingRsInfo Type
        nativeRequest.getCmd().setPagingRqInfo(new PagingRqInfo());
        nativeRequest.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);

        AcctListInqRs acctListInqISRs = new AcctListInqRs();
        AcctListInqRs.Cmd cmd = new AcctListInqRs.Cmd();
        AcctListRs value = new AcctListRs();
        PagingRsInfo pagingRsInfo = new PagingRsInfo();
        Cursor cursor = new Cursor();
        cursor.setBinLength(CURSOR_COUNT);
        pagingRsInfo.setCursor(cursor);

        value.setPagingRsInfo(pagingRsInfo);
        AcctListInfo acctListInfo = new AcctListInfo();
        acctListInfo.setAcctID("1234");
        acctListInfo.setProdID("SB");
        acctListInfo.setBankAcctTypeCd("SD");
        value.getAcctListInfo().add(acctListInfo);

        cmd.setAcctListRs(value);
        cmd.setName("Name");
        StatType value2 = new StatType();
        value2.setStatCd(1120);
        SevrtyType value3 = SevrtyType.INFO;
        value2.setSevrty(value3);
        cmd.setStat(value2);

        List<AcctListInfo> list = new ArrayList<AcctListInqRs.Cmd.AcctListRs.AcctListInfo>();
        AcctListInfo info = new AcctListInfo();
        info.setAcctID("1234");
        info.setProdID("SB");
        info.setBankAcctTypeCd("SD");
        list.add(info);

        acctListInqISRs.setCmd(cmd);

        String accountId = "1234";

        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(accountId);

        Object relationshipInfo = null;
        when(conversionService.convert(relationshipInfo, AcctListInqRq.class)).thenReturn(nativeRequest);
        REASResponse sdbResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("1234");
        response.setAccountNumber(accountId);
        response.setSorId("70");
        customerAccountsResponseList.add(response);
        sdbResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        when(conversionService.convert(info, REASResponse.class)).thenReturn(sdbResponse);

        when(xesRelatedAcctISSoap.acctListInq(null)).thenReturn(acctListInqISRs);

        Future<REASResponse> actualResponse1 = dao.retrieve(context, CUST_ID, accountIdList, (short) 70);
        assertNotNull(actualResponse1);

    }

    @Test
    public final void test_retrieve_settingSevrty1() throws InterruptedException, ExecutionException {
        AcctListInqRq nativeRequest = new AcctListInqRq();
        nativeRequest.setHdr(new HdrType());
        nativeRequest.setCmd(new AcctListInqRq.Cmd());

        // Creating PagingRsInfo Type
        nativeRequest.getCmd().setPagingRqInfo(new PagingRqInfo());
        nativeRequest.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);

        AcctListInqRs acctListInqISRs = new AcctListInqRs();
        AcctListInqRs.Cmd cmd = new AcctListInqRs.Cmd();
        AcctListRs value = new AcctListRs();
        PagingRsInfo pagingRsInfo = new PagingRsInfo();
        Cursor cursor = new Cursor();
        cursor.setBinLength(CURSOR_COUNT);
        pagingRsInfo.setCursor(cursor);

        value.setPagingRsInfo(pagingRsInfo);
        AcctListInfo acctListInfo = new AcctListInfo();
        acctListInfo.setAcctID("1234");
        acctListInfo.setProdID("SB");
        acctListInfo.setBankAcctTypeCd("SD");
        value.getAcctListInfo().add(acctListInfo);

        cmd.setAcctListRs(value);
        cmd.setName("Name");
        StatType value2 = new StatType();
        value2.setStatCd(120052);
        SevrtyType value3 = SevrtyType.ERROR;
        value2.setSevrty(value3);
        cmd.setStat(value2);

        List<AcctListInfo> list = new ArrayList<AcctListInqRs.Cmd.AcctListRs.AcctListInfo>();
        AcctListInfo info = new AcctListInfo();
        info.setAcctID("1234");
        info.setProdID("SB");
        info.setBankAcctTypeCd("SD");
        list.add(info);

        acctListInqISRs.setCmd(cmd);

        String accountId = "1234";

        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(accountId);

        Object relationshipInfo = null;
        when(conversionService.convert(relationshipInfo, AcctListInqRq.class)).thenReturn(nativeRequest);
        REASResponse sdbResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("1234");
        response.setAccountNumber(accountId);
        response.setSorId("70");
        customerAccountsResponseList.add(response);
        sdbResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        when(conversionService.convert(info, REASResponse.class)).thenReturn(sdbResponse);

        when(xesRelatedAcctISSoap.acctListInq(null)).thenReturn(acctListInqISRs);

        Future<REASResponse> actualResponse1 = dao.retrieve(context, CUST_ID, accountIdList, (short) 70);
        assertNotNull(actualResponse1);

    }

    @Test
    public final void test_retrieve_settingSevrty2() throws InterruptedException, ExecutionException {
        AcctListInqRq nativeRequest = new AcctListInqRq();
        nativeRequest.setHdr(new HdrType());
        nativeRequest.setCmd(new AcctListInqRq.Cmd());

        // Creating PagingRsInfo Type
        nativeRequest.getCmd().setPagingRqInfo(new PagingRqInfo());
        nativeRequest.getCmd().getPagingRqInfo().setRecordControlReturnRecordCnt(RECORD_COUNT);

        AcctListInqRs acctListInqISRs = new AcctListInqRs();
        AcctListInqRs.Cmd cmd = new AcctListInqRs.Cmd();
        AcctListRs value = new AcctListRs();
        PagingRsInfo pagingRsInfo = new PagingRsInfo();
        Cursor cursor = new Cursor();
        cursor.setBinLength(CURSOR_COUNT);
        pagingRsInfo.setCursor(cursor);

        value.setPagingRsInfo(pagingRsInfo);
        AcctListInfo acctListInfo = new AcctListInfo();
        acctListInfo.setAcctID("1234");
        acctListInfo.setProdID("SB");
        acctListInfo.setBankAcctTypeCd("SD");
        value.getAcctListInfo().add(acctListInfo);

        cmd.setAcctListRs(value);
        cmd.setName("Name");
        StatType value2 = new StatType();
        value2.setStatCd(100106);
        SevrtyType value3 = SevrtyType.ERROR;
        value2.setSevrty(value3);
        cmd.setStat(value2);

        List<AcctListInfo> list = new ArrayList<AcctListInqRs.Cmd.AcctListRs.AcctListInfo>();
        AcctListInfo info = new AcctListInfo();
        info.setAcctID("1234");
        info.setProdID("SB");
        info.setBankAcctTypeCd("SD");
        list.add(info);

        acctListInqISRs.setCmd(cmd);

        String accountId = "1234";

        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(accountId);

        Object relationshipInfo = null;
        when(conversionService.convert(relationshipInfo, AcctListInqRq.class)).thenReturn(nativeRequest);
        REASResponse sdbResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("1234");
        response.setAccountNumber(accountId);
        response.setSorId("70");
        customerAccountsResponseList.add(response);
        sdbResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        when(conversionService.convert(info, REASResponse.class)).thenReturn(sdbResponse);

        when(xesRelatedAcctISSoap.acctListInq(null)).thenReturn(acctListInqISRs);

        Future<REASResponse> actualResponse1 = dao.retrieve(context, CUST_ID, accountIdList, (short) 70);
        assertNotNull(actualResponse1);

    }

    // @Test
    // public final void test_Ping() {
    // pingService.executePing(Mockito.anyObject(), Mockito.any(Class.class));
    // dao.ping();
    // }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */