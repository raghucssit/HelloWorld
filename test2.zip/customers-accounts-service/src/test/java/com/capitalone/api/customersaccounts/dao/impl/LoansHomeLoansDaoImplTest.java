package com.capitalone.api.customersaccounts.dao.impl;


import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;

import org.apache.commons.configuration.Configuration;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.entity.LoansHomeLoansEntity;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.api.loans.homeloans.accounts.model.v3.Account;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class LoansHomeLoansDaoImplTest {

    @InjectMocks
    private LoansHomeLoansDaoImpl daoImpl;
    
    @Mock
    private LoansHomeLoansEntity homeLoansEntity;    

    @Mock
    private Client eapiRestClient;

    
    @Mock
    private AutoLoanAccount autoLoanAccount;

    @Mock
    private ConversionService conversionService;

    @Mock
    private WebTarget requestPath;

    @Mock
    private EPFContext context;

    @Mock
    private Configuration config;
    
    @Mock
    private CustomerAPIRESTException e;   
    
    @Mock 
    private CustomerAccountsUtil customerAccountsUtil;
    
    @Test
    public void testGetHomeLoanAccounts() throws Exception {      

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();

        customerAccountsResponse.setAccountNumber("12345678912");

        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("56"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
       // AccountReferenceId accountRefID = new AccountReferenceId(customerAccountKey.getAccountNumber(),
               // customerAccountKey.getSorId().toString());

        Account account = new Account();
        account.setAvailableCreditLimit(new BigDecimal("1200"));

        when(homeLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56")).thenReturn(account);
        Mockito.when(conversionService.convert(account,
                            CustomerAccountsResponse.class)).thenReturn(customerAccountsResponse);
        Future<REASResponse> response = daoImpl.getHomeLoanAccounts(context, customerAccountKey);
        assertNotNull(response);
        //assertThat(response.get().getCustomerAccountsResponseList().get(0).getAccountNumber(), equalTo("12345678912"));
        
    }
    
    @Test
    public void testGetHomeLoanAccounts_Null() throws Exception {

       
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();

        customerAccountsResponse.setAccountNumber("12345678912");

        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("56"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
       
        Account account = null;
        //account.setAvailableCreditLimit(new BigDecimal("1200"));

        when(homeLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56")).thenReturn(account);
        Mockito.when(conversionService.convert(account,
                            CustomerAccountsResponse.class)).thenReturn(customerAccountsResponse);
        Future<REASResponse> response = daoImpl.getHomeLoanAccounts(context, customerAccountKey);
        assertNotNull(response);
        
    }
    
    @Test
    public void testGetHomeLoanAccounts_Exception() throws Exception {

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();

        customerAccountsResponse.setAccountNumber("12345678912");
       
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("56"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
       

        Account account = null;
        when(homeLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56")).thenThrow(e);
        Mockito.when(conversionService.convert(account,
                            CustomerAccountsResponse.class)).thenReturn(customerAccountsResponse);
        Future<REASResponse> response = daoImpl.getHomeLoanAccounts(context, customerAccountKey);
        assertNotNull(response);
        
    }    
    
    @Test
    public void testGetHomeLoanAccounts_Exception1() throws Exception {
       
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();

        customerAccountsResponse.setAccountNumber("12345678912");

        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("56"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
      
        Account account = null;
        //account.setAvailableCreditLimit(new BigDecimal("1200"));
        
        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404, errorResponse);
        
        e1.getErrorResponse().setDeveloperText("TestDeveloper Text");   
        e1.getErrorResponse().setId("TestID01");       

        when(homeLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56")).thenReturn(account);
        Mockito.when(conversionService.convert(account,
                            CustomerAccountsResponse.class)).thenReturn(customerAccountsResponse);
        
        Mockito.when(e.getCause()).thenReturn(e1);
        
        
        Future<REASResponse> response = daoImpl.getHomeLoanAccounts(context, customerAccountKey);
        assertNotNull(response);
        
    }
    @Test
    public void testGetHomeLoanAccounts_DeveloperTextEmpty() throws Exception {

    
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();

        customerAccountsResponse.setAccountNumber("12345678912");
    
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("56"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
       
        Account account = null;
        //account.setAvailableCreditLimit(new BigDecimal("1200"));
        
        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404, errorResponse);
        
        e1.getErrorResponse().setDeveloperText("");   
        e1.getErrorResponse().setId("TestID01");       
        e1.getErrorResponse().setText("Text");
        when(homeLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56")).thenReturn(account);
        
        Mockito.when(conversionService.convert(account,
                            CustomerAccountsResponse.class)).thenReturn(customerAccountsResponse);
        
        Mockito.when(e.getCause()).thenReturn(e1);        
        
        Future<REASResponse> response = daoImpl.getHomeLoanAccounts(context, customerAccountKey);
        assertNotNull(response);
        
    }

    @Test
    public void testGetHomeLoanAccounts_Exception2() throws Exception {

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();

        customerAccountsResponse.setAccountNumber("12345678912");
       
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("56"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
       

        Account account = null;
        //account.setAvailableCreditLimit(new BigDecimal("1200"));
        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404, errorResponse);
        Mockito.when(e.getCause()).thenReturn(e1);
        e1.getErrorResponse().setDeveloperText("developerText");   
        e1.getErrorResponse().setId("TestID01");       
        e1.getErrorResponse().setText("Text");

        when(homeLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56")).thenThrow(e);
        Mockito.when(conversionService.convert(account,
                            CustomerAccountsResponse.class)).thenReturn(customerAccountsResponse);
        Future<REASResponse> response = daoImpl.getHomeLoanAccounts(context, customerAccountKey);
        assertNotNull(response);
        
    } 
    
    @Test
    public void testGetHomeLoanAccounts_Exception3() throws Exception {

        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountNumber("12345678912");
       
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setAccountNickname("AutoLoans");
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("4");
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setAccountUseType("Open");
        customerAccountKey.setConsumerId("ID01");
        customerAccountKey.setSorId(new Short("56"));
        customerAccountKeyList.add(customerAccountKey);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);       

        Account account = null;
        //account.setAvailableCreditLimit(new BigDecimal("1200"));
        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(null,errorResponse);
        Mockito.when(e.getCause()).thenReturn(e1);
        e1.getErrorResponse().setDeveloperText("");   
        //e1.getErrorResponse().setId("TestID01");       
        e1.getErrorResponse().setText("Text");

        when(homeLoansEntity.retiveAccountDetails(customerAccountKey, context, "12345678912", "56")).thenThrow(e);
        Mockito.when(conversionService.convert(account,
                            CustomerAccountsResponse.class)).thenReturn(customerAccountsResponse);
        Future<REASResponse> response = daoImpl.getHomeLoanAccounts(context, customerAccountKey);
        assertNotNull(response);
        
    } 
        
    
}
