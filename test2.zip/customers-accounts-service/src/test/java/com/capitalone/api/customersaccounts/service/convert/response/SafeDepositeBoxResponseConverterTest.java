package com.capitalone.api.customersaccounts.service.convert.response;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xesrelatedacctis.v1.AcctListInqRs.Cmd.AcctListRs.AcctListInfo;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class SafeDepositeBoxResponseConverterTest {

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @InjectMocks
    private SafeDepositeBoxResponseConverter converter;

    @Test
    public void test_convert() {
        AcctListInfo acctListInfo = new AcctListInfo();
        REASResponse reasRelationshipAcct = new REASResponse();
        acctListInfo.setProdID("SD");
        acctListInfo.setProdDesc("proddesc");
        acctListInfo.setCustAcctToRelationshipCd("IND");
        acctListInfo.setCustAcctFromRelationshipCd("BNK");
        acctListInfo.setAccountRelationshipID("AC90PDPRIIND0030000100000000101041851S0002904800000230");
        acctListInfo.setAcctID("1234");
        acctListInfo.setBankNum("81");
        Map<String, String> relationShip = new HashMap<String, String>();
        relationShip.put("CustAcctRelationshipDesc", "SIngle Owner");
        Mockito.when(
                customerAccountsRefDataBean.getCustRelationshipDesc(acctListInfo.getCustAcctFromRelationshipCd(),
                        acctListInfo.getCustAcctToRelationshipCd())).thenReturn(relationShip);
        reasRelationshipAcct = converter.convert(acctListInfo);
        assertNotNull(reasRelationshipAcct);
        assertThat(reasRelationshipAcct.getCustomerAccountsResponseList().get(0).getProductTypeDescription(),
                equalTo(acctListInfo.getProdDesc()));
        assertThat(reasRelationshipAcct.getCustomerAccountsResponseList().get(0).getDisplayAccountNumber(),
                equalTo("00110100000230"));
        assertThat(reasRelationshipAcct.getCustomerAccountsResponseList().get(0).getBankNumber(), equalTo("81"));

    }

}
