package com.capitalone.api.customersaccounts.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.CustomerAccountSummaryDao;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsOrchResponse;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CustomerAccountsOrchServiceTest {

    private CustomerAccountsOrchService service;

    @Mock
    private CustomerAccountSummaryDao enterpriseAccountSummarySyncOrchDAO;

    @Mock
    private ProfileAccountsOrchService profileAccountsOrchService;

    @Mock
    private XESRelatedAccountsOrchService xesRelatedAccountsOrchService;

    @Mock
    private AutoLoansAccountsOrchService autoLoansAccountsOrchService;

    @Mock
    private ProfileAccount360OrchService profileAccount360OrchService;

    @Mock
    private CreditCardAccountSummaryOrchService creditCardAccountSummaryOrchService;

    @Mock
    private SafeDepoBoxAccountSummaryOrchService safeDepoBoxAccountSummaryOrchService;

    @Mock
    private HomeLoansAccountsOrchService homeLoansAccountsOrchService;

    @Mock
    private OecpPreferencesOrchService oecpPreferencesOrchService;

    @Mock
    private XESDDAISOrchService xesDDAISOrchService;

    @Mock
    private XESTDAISOrchService xesTDAISOrchService;

    @Mock
    private LoanAccountSummaryOrchService loanAccountSummaryOrchService;

    @Mock
    private ODSBrokerageAccountsISOrchService brokerageAccountsISOrchService;
    

    @Mock
    private OLBAccountPreferencesISOrchService olbAccountPreferencesISOrchService;
    
    @Mock 
    private CapitalOneInvestingAccountOrchService accountOrchService;
    
    @Mock
    private CustInfoDLSOrchService custInfoDLSOrchService;

    @Before
    public void setup() {
        service = new CustomerAccountsOrchService();
        Whitebox.setInternalState(service, enterpriseAccountSummarySyncOrchDAO);
        Whitebox.setInternalState(service, profileAccountsOrchService);
        Whitebox.setInternalState(service, xesRelatedAccountsOrchService);
        Whitebox.setInternalState(service, autoLoansAccountsOrchService);
        Whitebox.setInternalState(service, profileAccount360OrchService);
        Whitebox.setInternalState(service, creditCardAccountSummaryOrchService);
        Whitebox.setInternalState(service, safeDepoBoxAccountSummaryOrchService);
        Whitebox.setInternalState(service, homeLoansAccountsOrchService);
        Whitebox.setInternalState(service, oecpPreferencesOrchService);
        Whitebox.setInternalState(service, xesDDAISOrchService);
        Whitebox.setInternalState(service, xesTDAISOrchService);
        Whitebox.setInternalState(service, loanAccountSummaryOrchService);
        Whitebox.setInternalState(service, brokerageAccountsISOrchService);
        Whitebox.setInternalState(service, olbAccountPreferencesISOrchService);
        Whitebox.setInternalState(service, accountOrchService);
        Whitebox.setInternalState(service, custInfoDLSOrchService);
        /*
         * Whitebox.setInternalState(service, xesDDAISOrchService); Whitebox.setInternalState(service,
         * xesTDAISOrchService); Whitebox.setInternalState(service, loanAccountSummaryOrchService);
         * Whitebox.setInternalState(service, homeLoansAccountsOrchService);
         */
    }

    @Test
    public void testExecute() throws Exception {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableModifiedOrchestrationSwitch(true);
        List<String> listSDB = new ArrayList<String>();
        listSDB.add("v3");
        listSDB.add("v4");
        request.setEnableModifiedSafeDepositBoxSwitch(listSDB);
        request.setEnableOECPPreferenceSwitch(true);
        REASResponse reasResponse = new REASResponse();
        reasResponse.setAddStatList(new ArrayList<AdditionalStat>());
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> finalXESResponseList = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                finalXESResponseList);

        List<ProfileRelationshipLookup> response = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                response);

        // List<ECRPrefResponse> finalReas = new ArrayList<ECRPrefResponse>();

        REASResponse profileCustomerAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<AdditionalStat> listStat = new ArrayList<AdditionalStat>();
        AdditionalStat statType = new AdditionalStat();
        listStat.add(statType);
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountList.add(customerAccountsResponse);
        profileCustomerAccountsResponse.setCustomerAccountsResponseList(customerAccountList);
        profileCustomerAccountsResponse.setAddStatList(listStat);
        REASResponse creditCardsAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> creditCardAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse creditCardResponse = new CustomerAccountsResponse();
        creditCardAccountList.add(creditCardResponse);
        creditCardsAccountsResponse.setCustomerAccountsResponseList(creditCardAccountList);
        creditCardsAccountsResponse.setAddStatList(listStat);

        REASResponse autoLoanAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> autoLoanAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse autoLoanAccountResponse = new CustomerAccountsResponse();
        autoLoanAccountList.add(autoLoanAccountResponse);
        autoLoanAccountsResponse.setCustomerAccountsResponseList(autoLoanAccountList);
        autoLoanAccountsResponse.setAddStatList(listStat);

        when(
                enterpriseAccountSummarySyncOrchDAO.retrieveAccountSummary((EPFContext) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject())).thenReturn(futureReasResponse);
        when(
                xesRelatedAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(futureXESRelatedAcctResponse);

        when(
                profileAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(futureProfileAccountRelationshipsResponse);

        when(
                autoLoansAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(
                new AsyncResult<REASResponse>(autoLoanAccountsResponse));

        when(
                profileAccount360OrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(
                new AsyncResult<REASResponse>(profileCustomerAccountsResponse));

        when(
                homeLoansAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(
                new AsyncResult<REASResponse>(profileCustomerAccountsResponse));

        when(
                creditCardAccountSummaryOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(
                new AsyncResult<REASResponse>(creditCardsAccountsResponse));
        when(
                safeDepoBoxAccountSummaryOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(
                new AsyncResult<REASResponse>(creditCardsAccountsResponse));
        /*
         * when( ecrPreferencesISOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(), (EPFContext)
         * Mockito.anyObject())).thenReturn( new AsyncResult<ECRPrefResponse>(finalReas));
         */

        CustomerAccountsOrchResponse result = service.execute(request);
        assertNotNull(result);
    }

    @Test
    public void testExecute1() throws Exception {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableModifiedOrchestrationSwitch(true);
        List<String> listSDB = new ArrayList<String>();
        listSDB.add("v3");
        listSDB.add("v4");
        request.setEnableModifiedSafeDepositBoxSwitch(listSDB);
        request.setEnableOECPPreferenceSwitch(false);
        REASResponse reasResponse = new REASResponse();
        reasResponse.setAddStatList(new ArrayList<AdditionalStat>());
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> finalXESResponseList = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                finalXESResponseList);

        List<ProfileRelationshipLookup> response = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                response);

        REASResponse profileCustomerAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<AdditionalStat> listStat = new ArrayList<AdditionalStat>();
        AdditionalStat statType = new AdditionalStat();
        listStat.add(statType);
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountList.add(customerAccountsResponse);
        profileCustomerAccountsResponse.setCustomerAccountsResponseList(customerAccountList);
        profileCustomerAccountsResponse.setAddStatList(listStat);
        REASResponse creditCardsAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> creditCardAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse creditCardResponse = new CustomerAccountsResponse();
        creditCardAccountList.add(creditCardResponse);
        creditCardsAccountsResponse.setCustomerAccountsResponseList(creditCardAccountList);
        creditCardsAccountsResponse.setAddStatList(listStat);

        REASResponse autoLoanAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> autoLoanAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse autoLoanAccountResponse = new CustomerAccountsResponse();
        autoLoanAccountList.add(autoLoanAccountResponse);
        autoLoanAccountsResponse.setCustomerAccountsResponseList(autoLoanAccountList);
        autoLoanAccountsResponse.setAddStatList(listStat);
        when(
                enterpriseAccountSummarySyncOrchDAO.retrieveAccountSummary((EPFContext) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject())).thenReturn(futureReasResponse);
        when(
                xesRelatedAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(futureXESRelatedAcctResponse);

        when(
                profileAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(futureProfileAccountRelationshipsResponse);

        when(
                autoLoansAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(
                new AsyncResult<REASResponse>(autoLoanAccountsResponse));

        when(
                profileAccount360OrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(
                new AsyncResult<REASResponse>(profileCustomerAccountsResponse));
        when(
                homeLoansAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(
                new AsyncResult<REASResponse>(profileCustomerAccountsResponse));

        when(
                creditCardAccountSummaryOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(
                new AsyncResult<REASResponse>(creditCardsAccountsResponse));

        CustomerAccountsOrchResponse result = service.execute(request);
        assertNotNull(result);
    }

    @Test
    public void testExecute2() throws Exception {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableModifiedOrchestrationSwitch(false);
        List<String> listSDB = new ArrayList<String>();
        listSDB.add("v3");
        listSDB.add("v4");
        request.setEnableModifiedSafeDepositBoxSwitch(listSDB);
        request.setEnableOECPPreferenceSwitch(false);
        request.setAppVersion("V4");
        REASResponse reasResponse = new REASResponse();
        reasResponse.setAddStatList(new ArrayList<AdditionalStat>());
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> finalXESResponseList = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                finalXESResponseList);

        List<ProfileRelationshipLookup> response = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                response);

        when(
                enterpriseAccountSummarySyncOrchDAO.retrieveAccountSummary((EPFContext) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject())).thenReturn(futureReasResponse);
        when(
                xesRelatedAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(futureXESRelatedAcctResponse);

        when(
                profileAccountsOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                        (EPFContext) Mockito.anyObject())).thenReturn(futureProfileAccountRelationshipsResponse);

        CustomerAccountsOrchResponse result = service.execute(request);
        assertNotNull(result);
    }
    
    @Test
    public void testExecute3() throws Exception {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableModifiedOrchestrationSwitch(true);
        List<String> listSDB = new ArrayList<String>();
        listSDB.add("v3");
        listSDB.add("v4");
        request.setEnableModifiedSafeDepositBoxSwitch(listSDB);
        request.setEnableOECPPreferenceSwitch(true);
        REASResponse reasResponse = new REASResponse();
        reasResponse.setAddStatList(new ArrayList<AdditionalStat>());
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);       

        REASResponse profileCustomerAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<AdditionalStat> listStat = new ArrayList<AdditionalStat>();
        AdditionalStat statType = new AdditionalStat();
        listStat.add(statType);
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountList.add(customerAccountsResponse);
        profileCustomerAccountsResponse.setCustomerAccountsResponseList(customerAccountList);
        profileCustomerAccountsResponse.setAddStatList(listStat);
        REASResponse creditCardsAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> creditCardAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse creditCardResponse = new CustomerAccountsResponse();
        creditCardAccountList.add(creditCardResponse);
        creditCardsAccountsResponse.setCustomerAccountsResponseList(creditCardAccountList);
        creditCardsAccountsResponse.setAddStatList(listStat);

        REASResponse autoLoanAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> autoLoanAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse autoLoanAccountResponse = new CustomerAccountsResponse();
        autoLoanAccountList.add(autoLoanAccountResponse);
        autoLoanAccountsResponse.setCustomerAccountsResponseList(autoLoanAccountList);
        autoLoanAccountsResponse.setAddStatList(listStat);
        
        REASResponse xesAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> xesAccountsList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse xesResponse = new CustomerAccountsResponse();
        xesAccountsList.add(xesResponse);
        xesAccountsResponse.setCustomerAccountsResponseList(xesAccountsList );

        when(
                enterpriseAccountSummarySyncOrchDAO.retrieveAccountSummary((EPFContext) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject())).thenReturn(futureReasResponse);        
         
         when(
                 xesDDAISOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                         (EPFContext) Mockito.anyObject())).thenReturn(
                 new AsyncResult<REASResponse>(xesAccountsResponse));
         when(
                 xesTDAISOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                         (EPFContext) Mockito.anyObject())).thenReturn(
                 new AsyncResult<REASResponse>(xesAccountsResponse));
         when(
                 loanAccountSummaryOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                         (EPFContext) Mockito.anyObject())).thenReturn(
                 new AsyncResult<REASResponse>(xesAccountsResponse));
         
         when(
                 brokerageAccountsISOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                         (EPFContext) Mockito.anyObject())).thenReturn(
                 new AsyncResult<REASResponse>(xesAccountsResponse));

        CustomerAccountsOrchResponse result = service.execute(request);
        assertNotNull(result);
    }
    
    @Test
    public void testExecute_WithUnsupportedkeyList() throws Exception {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        request.setEnableModifiedOrchestrationSwitch(true);
        List<String> listSDB = new ArrayList<String>();
        listSDB.add("v3");
        listSDB.add("v4");
        request.setEnableModifiedSafeDepositBoxSwitch(listSDB);
        request.setEnableOECPPreferenceSwitch(true);
        List<CustomerAccountKey> unSupportedAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        Short sorId = 6;
        key.setSorId(sorId);
        unSupportedAccountKeyList.add(key );
        request.setUnSupportedAccountKeyList(unSupportedAccountKeyList);
        REASResponse reasResponse = new REASResponse();
        reasResponse.setAddStatList(new ArrayList<AdditionalStat>());
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);       

        REASResponse profileCustomerAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountList = new ArrayList<CustomerAccountsResponse>();
        List<AdditionalStat> listStat = new ArrayList<AdditionalStat>();
        AdditionalStat statType = new AdditionalStat();
        listStat.add(statType);
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountList.add(customerAccountsResponse);
        profileCustomerAccountsResponse.setCustomerAccountsResponseList(customerAccountList);
        profileCustomerAccountsResponse.setAddStatList(listStat);
        REASResponse creditCardsAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> creditCardAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse creditCardResponse = new CustomerAccountsResponse();
        creditCardAccountList.add(creditCardResponse);
        creditCardsAccountsResponse.setCustomerAccountsResponseList(creditCardAccountList);
        creditCardsAccountsResponse.setAddStatList(listStat);

        REASResponse autoLoanAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> autoLoanAccountList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse autoLoanAccountResponse = new CustomerAccountsResponse();
        autoLoanAccountList.add(autoLoanAccountResponse);
        autoLoanAccountsResponse.setCustomerAccountsResponseList(autoLoanAccountList);
        autoLoanAccountsResponse.setAddStatList(listStat);
        
        REASResponse xesAccountsResponse = new REASResponse();
        List<CustomerAccountsResponse> xesAccountsList = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse xesResponse = new CustomerAccountsResponse();
        xesAccountsList.add(xesResponse);
        xesAccountsResponse.setCustomerAccountsResponseList(xesAccountsList );

        when(
                enterpriseAccountSummarySyncOrchDAO.retrieveAccountSummary((EPFContext) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject())).thenReturn(futureReasResponse);        
         
         when(
                 xesDDAISOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                         (EPFContext) Mockito.anyObject())).thenReturn(
                 new AsyncResult<REASResponse>(xesAccountsResponse));
         when(
                 xesTDAISOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                         (EPFContext) Mockito.anyObject())).thenReturn(
                 new AsyncResult<REASResponse>(xesAccountsResponse));
         when(
                 loanAccountSummaryOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                         (EPFContext) Mockito.anyObject())).thenReturn(
                 new AsyncResult<REASResponse>(xesAccountsResponse));
         
         when(
                 brokerageAccountsISOrchService.execute((CustomerAccountsRequest) Mockito.anyObject(),
                         (EPFContext) Mockito.anyObject())).thenReturn(
                 new AsyncResult<REASResponse>(xesAccountsResponse));
     
        CustomerAccountsOrchResponse result = service.execute(request);
        assertNotNull(result);
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
