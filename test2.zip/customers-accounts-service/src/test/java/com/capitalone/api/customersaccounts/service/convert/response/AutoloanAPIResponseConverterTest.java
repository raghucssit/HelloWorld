package com.capitalone.api.customersaccounts.service.convert.response;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.math.BigDecimal;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AccountStatus;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.api.model.id.AccountReferenceId;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.api.model.id.ReferenceId.Builder;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class AutoloanAPIResponseConverterTest {

    @InjectMocks
    private AutoloanAPIResponseConverter converter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public void testConvert() {
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setLoanBalance(new BigDecimal("1200"));
        AccountStatus accountStatus = new AccountStatus();
        accountStatus.setStatusDescription("Open");
        autoLoanAccount.setAccountStatus(accountStatus);
        autoLoanAccount.setAccountNickname("AL");
        autoLoanAccount.setMinimumPaymentAmount(new BigDecimal("1000"));
        autoLoanAccount.setDueDate(new Instant());
        autoLoanAccount.setOpenDate(new Instant());
        autoLoanAccount.setLoanApplicationId(01);
        autoLoanAccount.setPaidOffDate(new Instant());
        Builder builder = new Builder();
        builder.field("accountId", "62021400068781001");
        ReferenceId refID = builder.build();
        autoLoanAccount.setAutoLoanAccountReferenceId(refID);
        autoLoanAccount.setAccountReferenceId(refID);
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription(Constants.AUTO_LOAN_PRODUCT_CD)).thenReturn(
                "LoanAccount");
        CustomerAccountsResponse response = converter.convert(autoLoanAccount);
        assertThat(response.getAccountNumber(), equalTo("62021400068781001"));
    }

    @Test
    public void testConvertNullAccntRefID() {
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setLoanBalance(new BigDecimal("1200"));
        AccountStatus accountStatus = new AccountStatus();
        accountStatus.setStatusDescription("Open");
        autoLoanAccount.setAccountStatus(accountStatus);
        autoLoanAccount.setAccountNickname("AL");
        autoLoanAccount.setIsAccountClosed(true);
        autoLoanAccount.setTotalAmountDue(new BigDecimal("1000"));
        autoLoanAccount.setMinimumPaymentAmount(new BigDecimal("1000"));
        autoLoanAccount.setDueDate(new Instant());
        autoLoanAccount.setLoanApplicationId(01);
        Builder builder = new Builder();
        builder.field("accountId", "62021400068781001");
        ReferenceId refID = builder.build();
        autoLoanAccount.setAutoLoanAccountReferenceId(refID);
        autoLoanAccount.setDisplayAccountNumber("12345678912");
        AccountReferenceId accountReferenceId = new AccountReferenceId("12345678912", "2");
        ReferenceId referenceid = accountReferenceId.getReferenceId();
        autoLoanAccount.setAccountReferenceId(referenceid);
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription(Constants.AUTO_LOAN_PRODUCT_CD)).thenReturn(
                "LoanAccount");
        CustomerAccountsResponse response = converter.convert(autoLoanAccount);
        assertThat(response.getAccountNumber(), equalTo("12345678912"));
    }

    @Test
    public void testConvertResponseWithNullValue() {
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setLoanBalance(new BigDecimal("1200"));
        // AccountStatus accountStatus = new AccountStatus();
        // accountStatus.setStatusDescription("Open");
        autoLoanAccount.setLoanBalance(null);
        autoLoanAccount.setAccountStatus(null);
        autoLoanAccount.setAccountNickname(null);
        autoLoanAccount.setMinimumPaymentAmount(new BigDecimal("1000"));
        autoLoanAccount.setDueDate(null);
        autoLoanAccount.setLoanApplicationId(null);
        Builder builder = new Builder();
        builder.field("accountId", "1234");
        // ReferenceId refID = builder.build();
        autoLoanAccount.setAutoLoanAccountReferenceId(null);
        autoLoanAccount.setDisplayAccountNumber(null);
        // AccountReferenceId accountReferenceId = new AccountReferenceId("12345678912","2");
        // ReferenceId referenceid = accountReferenceId.getReferenceId();
        autoLoanAccount.setAccountReferenceId(null);
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription(null)).thenReturn(null);
        CustomerAccountsResponse response = converter.convert(autoLoanAccount);
        assertNotNull(response);
    }

    @Test
    public void testConvert_withAutoLoanAcctRefId_Null() {
        AutoLoanAccount autoLoanAccount = new AutoLoanAccount();
        autoLoanAccount.setLoanBalance(new BigDecimal("1200"));
        AccountStatus accountStatus = new AccountStatus();
        accountStatus.setStatusDescription("Open");
        autoLoanAccount.setAccountStatus(accountStatus);
        autoLoanAccount.setAccountNickname("AL");
        autoLoanAccount.setMinimumPaymentAmount(new BigDecimal("1000"));
        autoLoanAccount.setDueDate(new Instant());
        autoLoanAccount.setOpenDate(new Instant());
        autoLoanAccount.setLoanApplicationId(01);
        autoLoanAccount.setPaidOffDate(new Instant());
        Builder builder = new Builder();
        builder.field("accountId", "1234");
        ReferenceId refID = builder.build();
        autoLoanAccount.setAutoLoanAccountReferenceId(null);
        autoLoanAccount.setAccountReferenceId(refID);
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription(Constants.AUTO_LOAN_PRODUCT_CD)).thenReturn(
                "LoanAccount");
        CustomerAccountsResponse response = converter.convert(autoLoanAccount);
        assertThat(response.getAccountNumber(), equalTo("1234"));
    }

    @Test
    public void testConvertWithNullResponse() {
        CustomerAccountsResponse response = converter.convert(null);
        assertNotNull(response);

    }

}
