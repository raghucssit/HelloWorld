package com.capitalone.api.customersaccounts.service.impl;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.AutoLoansAccountsDAO;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.epf.context.model.EPFContext;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class AutoLoansAccountsOrchServiceTest {

    @InjectMocks
    AutoLoansAccountsOrchService autoLoansAccountsOrchservice;

    @Mock
    private AutoLoansAccountsDAO autoLoansAccountsDAO;

    @Mock
    private EPFContext context;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Before
    public void setUp() {
        autoLoansAccountsOrchservice = new AutoLoansAccountsOrchService();
        Whitebox.setInternalState(autoLoansAccountsOrchservice, autoLoansAccountsDAO);
        Whitebox.setInternalState(autoLoansAccountsOrchservice, customerAccountsUtil);
    }

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("185");
        request.setReasSupportedSORID(reasSupportedSORID);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        REASResponse response = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(customerAccountsResponse);
        response.setCustomerAccountsResponseList(customerAccountsResponseList);

        Future<REASResponse> future = new AsyncResult<REASResponse>(response);

        key.setSorId((short) 2);
        key.setAccountNumber("1234");
        key.setConsumerId("456");
        customerAccountKeyList.add(key);

        ProfileReferenceId profileReferenceId = new ProfileReferenceId("49", "123", "LGIN");

        request.setCustomerAccountKeyList(customerAccountKeyList);
        request.setProfileReferenceId(profileReferenceId);

        when(autoLoansAccountsDAO.getCOAFAccounts(context, key, "123")).thenReturn(future);
        when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
                .thenReturn(response);
        Future<REASResponse> finalResponse = autoLoansAccountsOrchservice.execute(request, context);
        assertThat(finalResponse.get().getCustomerAccountsResponseList().get(0).getAccountId(), equalTo("12345678912"));
    }
    
    @Test
    public void testExecute_CustAcctReq_Null() throws InterruptedException, ExecutionException {
        Future<REASResponse> finalResponse = autoLoansAccountsOrchservice.execute(null, context);
        assertNotNull(finalResponse);
    }
    @Test
    public void testExecute_ReasSupportedSORID_Null() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<String> reasSupportedSORID = null;
        //reasSupportedSORID.add("185");
        request.setReasSupportedSORID(reasSupportedSORID);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        REASResponse response = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(customerAccountsResponse);
        response.setCustomerAccountsResponseList(customerAccountsResponseList);

        Future<REASResponse> future = new AsyncResult<REASResponse>(response);

        key.setSorId((short) 2);
        key.setAccountNumber("1234");
        key.setConsumerId("456");
        customerAccountKeyList.add(key);

        ProfileReferenceId profileReferenceId = new ProfileReferenceId("49", "123", "LGIN");

        request.setCustomerAccountKeyList(customerAccountKeyList);
        request.setProfileReferenceId(profileReferenceId);

        when(autoLoansAccountsDAO.getCOAFAccounts(context, key, "123")).thenReturn(future);
        when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
                .thenReturn(response);
        Future<REASResponse> finalResponse = autoLoansAccountsOrchservice.execute(request, context);
        assertNotNull(finalResponse);
    }
    
    @Test
    public void testExecute_ReasSupportedSORID_AUTOLOAN() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<String> reasSupportedSORID = new ArrayList<String>();;
        reasSupportedSORID.add("2");
        request.setReasSupportedSORID(reasSupportedSORID);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        REASResponse response = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(customerAccountsResponse);
        response.setCustomerAccountsResponseList(customerAccountsResponseList);

        Future<REASResponse> future = new AsyncResult<REASResponse>(response);

        key.setSorId((short) 2);
        key.setAccountNumber("1234");
        key.setConsumerId("456");
        customerAccountKeyList.add(key);

        ProfileReferenceId profileReferenceId = new ProfileReferenceId("49", "123", "LGIN");

        request.setCustomerAccountKeyList(customerAccountKeyList);
        request.setProfileReferenceId(profileReferenceId);

        when(autoLoansAccountsDAO.getCOAFAccounts(context, key, "123")).thenReturn(future);
        when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
                .thenReturn(response);
        Future<REASResponse> finalResponse = autoLoansAccountsOrchservice.execute(request, context);
        assertNotNull(finalResponse);
    }   
    
    @Test
    public void testExecute_ReasSupportedSORID_OtherThan_AUTOLOAN() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest request = new CustomerAccountsRequest();
        List<String> reasSupportedSORID = new ArrayList<String>();;
        reasSupportedSORID.add("3");
        request.setReasSupportedSORID(reasSupportedSORID);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        REASResponse response = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(customerAccountsResponse);
        response.setCustomerAccountsResponseList(customerAccountsResponseList);

        Future<REASResponse> future = new AsyncResult<REASResponse>(response);

        key.setSorId((short) 6);
        key.setAccountNumber("1234");
        key.setConsumerId("456");
        customerAccountKeyList.add(key);

        ProfileReferenceId profileReferenceId = new ProfileReferenceId("49", "123", "LGIN");

        request.setCustomerAccountKeyList(customerAccountKeyList);
        request.setProfileReferenceId(profileReferenceId);

        when(autoLoansAccountsDAO.getCOAFAccounts(context, key, "123")).thenReturn(future);
        when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
                .thenReturn(response);
        Future<REASResponse> finalResponse = autoLoansAccountsOrchservice.execute(request, context);
        assertNotNull(finalResponse);
    }   
}
