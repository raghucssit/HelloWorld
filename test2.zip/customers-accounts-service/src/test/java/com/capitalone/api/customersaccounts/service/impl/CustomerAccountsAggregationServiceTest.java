package com.capitalone.api.customersaccounts.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.exception.ApiBusinessException;
import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.exception.NotFoundException;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.AdditionalStat;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsOrchResponse;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.OLBResponse;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.service.pojo.XESRelationshipResponseBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CustomerAccountsAggregationServiceTest {

    CustomerAccountsAggregationService customerAccountsAggregationService;

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    private CustomerAccountsAggregationService service;

    @Before
    public void setup() {
        service = new CustomerAccountsAggregationService();
        Whitebox.setInternalState(service, customerAccountsRefDataBean);
        Whitebox.setInternalState(service, CustomerAccountsUtil.class, customerAccountsUtil);
    }

    @Test
    public void testExecute_Map360Role() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        // xesRelatedAcctResponse.add(xesInfo);

        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileInfo.setAccountNumber("1234");
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        when(
                customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString(),
                        Mockito.anyString())).thenReturn("role");
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_Map360RoleNull() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        // xesRelatedAcctResponse.add(xesInfo);

        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileInfo.setAccountNumber("1234");
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        when(
                customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString(),
                        Mockito.anyString())).thenReturn(null);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_MapXesRole() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("ST");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        // profileInfo.setAccountNumber("1234");
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(
                customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString(),
                        Mockito.anyString(), Mockito.anyString())).thenReturn(map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_MapXesRole2() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("12345");
        xesInfo.setCustAcctToRelationshipCd("ST");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        // profileInfo.setAccountNumber("1234");
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(
                customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString(),
                        Mockito.anyString(), Mockito.anyString())).thenReturn(map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_MapXesRoleNull() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("ST");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        // profileInfo.setAccountNumber("1234");
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);
        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, null);
        when(
                customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString(),
                        Mockito.anyString(), Mockito.anyString())).thenReturn(map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_MapXesRole1() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        // List<AutoLoansAccountsBean> autoLoanList = new ArrayList<AutoLoansAccountsBean>();
        // Future<List<AutoLoansAccountsBean>> futureAutoLoanList = new
        // AsyncResult<List<AutoLoansAccountsBean>>(autoLoanList);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        // profileInfo.setAccountNumber("1234");
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_withErrorSwitch_false() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);

        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        // profileInfo.setAccountNumber("1234");
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, false,false,null);
    }

    @Test(expected = NotFoundException.class)
    public void testExecute_OrchResponseNull() {
        CustomerAccountsOrchResponse orchResponse = null;

        service.execute(orchResponse, true,false,null);
    }

    @Test(expected = NotFoundException.class)
    public void testExecute_REASResponseNull() {

        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = null;

        /*
         * CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
         * customerAccountsResponse.setSorId("185"); List<CustomerAccountsResponse> customerAccountsResponseList = new
         * ArrayList<CustomerAccountsResponse>(); customerAccountsResponseList.add(customerAccountsResponse);
         * reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);
         */

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        response.setSorId("185");
        response.setAccountNickname("asd");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        // reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        // profileInfo.setAccountNumber("1234");
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);

        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_fornickname() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        response.setSorId("2");
        response.setProductTypeCode("CC");
        response.setProductTypeDescription("prod_desc");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);
        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        AdditionalStat stat = new AdditionalStat();
        stat.setSrvrStatCd("TP1065");
        AdditionalStat stat1 = new AdditionalStat();
        stat1.setSrvrStatCd("TP1067");
        addnStatList.add(stat);
        addnStatList.add(stat1);
        reasResponse.setAddStatList(addnStatList);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileInfo.setAccountNumber("1234");
        profileAccountRelationshipsResponse.add(profileInfo);

        // List<AutoLoansAccountsBean> autoLoanList = new ArrayList<AutoLoansAccountsBean>();
        // Future<List<AutoLoansAccountsBean>> futureAutoLoanList = new
        // AsyncResult<List<AutoLoansAccountsBean>>(autoLoanList);
        // AutoLoansAccountsBean autoinfo = new AutoLoansAccountsBean();
        // autoinfo.setAccountNumber("1234");
        // autoinfo.setNickName(null);
        // autoLoanList.add(autoinfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_map360CustomerRelationToAccount() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        response.setSorId("56");
        response.setProductTypeCode("CA");
        response.setProductTypeDescription("prod_desc");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        AdditionalStat stat = new AdditionalStat();
        stat.setSrvrStatCd("TP1065");
        AdditionalStat stat1 = new AdditionalStat();
        stat1.setSrvrStatCd("TP1067");
        addnStatList.add(stat);
        addnStatList.add(stat1);
        reasResponse.setAddStatList(addnStatList);

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileInfo.setAccountNumber("1234");
        profileInfo.setCustomerCount(1);
        profileInfo.setOwnershipType("1");
        profileAccountRelationshipsResponse.add(profileInfo);

        // List<AutoLoansAccountsBean> autoLoanList = new ArrayList<AutoLoansAccountsBean>();
        // Future<List<AutoLoansAccountsBean>> futureAutoLoanList = new
        // AsyncResult<List<AutoLoansAccountsBean>>(autoLoanList);
        // AutoLoansAccountsBean autoinfo = new AutoLoansAccountsBean();
        // autoinfo.setAccountNumber("1234");
        // autoinfo.setNickName("nickname");
        // autoLoanList.add(autoinfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_mapXESCustomerRelationToAccount() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        response.setSorId("12");
        response.setProductTypeCode("CA");
        response.setProductTypeDescription("prod_desc");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        AdditionalStat stat = new AdditionalStat();
        stat.setSrvrStatCd("TP1065");
        AdditionalStat stat1 = new AdditionalStat();
        stat1.setSrvrStatCd("TP1067");
        addnStatList.add(stat);
        addnStatList.add(stat1);
        reasResponse.setAddStatList(addnStatList);

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileInfo.setAccountNumber("1234");
        profileInfo.setCustomerCount(1);
        profileInfo.setOwnershipType("1");
        profileAccountRelationshipsResponse.add(profileInfo);

        // List<AutoLoansAccountsBean> autoLoanList = new ArrayList<AutoLoansAccountsBean>();
        // Future<List<AutoLoansAccountsBean>> futureAutoLoanList = new
        // AsyncResult<List<AutoLoansAccountsBean>>(autoLoanList);
        // AutoLoansAccountsBean autoinfo = new AutoLoansAccountsBean();
        // autoinfo.setAccountNumber("1234");
        // autoinfo.setNickName("nickname");
        // autoLoanList.add(autoinfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_xesRoleNotFoundAccounts() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        response.setSorId("12");
        response.setProductTypeCode("CA");
        response.setProductTypeDescription("prod_desc");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        AdditionalStat stat = new AdditionalStat();
        stat.setSrvrStatCd("TP1065");
        AdditionalStat stat1 = new AdditionalStat();
        stat1.setSrvrStatCd("TP1067");
        addnStatList.add(stat);
        addnStatList.add(stat1);
        reasResponse.setAddStatList(addnStatList);

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        // xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesInfo.setErrorCd("201441");
        xesRelatedAcctResponse.add(xesInfo);

        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileInfo.setAccountNumber("1234");
        profileInfo.setCustomerCount(1);
        profileInfo.setOwnershipType("1");
        profileAccountRelationshipsResponse.add(profileInfo);

        // List<AutoLoansAccountsBean> autoLoanList = new ArrayList<AutoLoansAccountsBean>();
        // Future<List<AutoLoansAccountsBean>> futureAutoLoanList = new
        // AsyncResult<List<AutoLoansAccountsBean>>(autoLoanList);
        // AutoLoansAccountsBean autoinfo = new AutoLoansAccountsBean();
        // autoinfo.setAccountNumber("1234");
        // autoinfo.setNickName("nickname");
        // autoLoanList.add(autoinfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_profileAccountsProdType1() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        response.setSorId("12");
        response.setProductTypeCode("CA");
        response.setProductTypeDescription("prod_desc");
        response.setSorId("185");
        response.setProductId("3000");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        AdditionalStat stat = new AdditionalStat();
        stat.setSrvrStatCd("TP1065");
        AdditionalStat stat1 = new AdditionalStat();
        stat1.setSrvrStatCd("TP1067");
        addnStatList.add(stat);
        addnStatList.add(stat1);
        reasResponse.setAddStatList(addnStatList);

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        // xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesInfo.setErrorCd("201441");
        xesRelatedAcctResponse.add(xesInfo);

        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileInfo.setAccountNumber("1234");
        profileInfo.setCustomerCount(1);
        profileInfo.setOwnershipType("1");
        profileInfo.setErrorCd("300");
        profileInfo.setTrustAccountInd(true);
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_profileAccountsProdType2() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        response.setSorId("12");
        response.setProductTypeCode("CA");
        response.setProductTypeDescription("prod_desc");
        response.setSorId("185");
        response.setProductId("3500");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        AdditionalStat stat = new AdditionalStat();
        stat.setSrvrStatCd("TP1065");
        AdditionalStat stat1 = new AdditionalStat();
        stat1.setSrvrStatCd("TP1067");
        addnStatList.add(stat);
        addnStatList.add(stat1);
        reasResponse.setAddStatList(addnStatList);

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        // xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesInfo.setErrorCd("201441");
        xesRelatedAcctResponse.add(xesInfo);

        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileInfo.setAccountNumber("1234");
        profileInfo.setCustomerCount(2);
        profileInfo.setOwnershipType("2");
        profileInfo.setErrorCd("300");
        profileInfo.setTrustAccountInd(true);
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_profileAccountsProdType3() throws Exception {
        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountNumber("1234");
        response.setSorId("12");
        response.setProductTypeCode("CA");
        response.setProductTypeDescription("prod_desc");
        response.setSorId("185");
        response.setProductId("4000");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        AdditionalStat stat = new AdditionalStat();
        stat.setSrvrStatCd("TP1065");
        AdditionalStat stat1 = new AdditionalStat();
        stat1.setSrvrStatCd("TP1067");
        addnStatList.add(stat);
        addnStatList.add(stat1);
        reasResponse.setAddStatList(addnStatList);

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        // xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesInfo.setErrorCd("201441");
        xesRelatedAcctResponse.add(xesInfo);

        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileInfo.setAccountNumber("1234");
        profileInfo.setCustomerCount(2);
        profileInfo.setOwnershipType("1");
        profileInfo.setErrorCd("300");
        profileInfo.setTrustAccountInd(true);
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, true,false,null);
    }

    @Test(expected = NotFoundException.class)
    public void testExecute_CustAcct_ResponseNull() {

        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList1 = new ArrayList<CustomerAccountsResponse>();
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList1);

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);
        service.execute(orchResponse, true,false,null);
    }

    @Test(expected = ApiBusinessException.class)
    public void testExecute_CustAcct_ResponseWithAddStatList() {

        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList1 = new ArrayList<CustomerAccountsResponse>();
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList1);

        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        AdditionalStat stat = new AdditionalStat();
        // stat.setSrvrStatCd("TP1065");
        stat.setHttpStatus(500);
        stat.setNativeErrorCd("201823");
        stat.setAccountId("12345");
        stat.setStatDesc("Account Not Found");
        AdditionalStat stat1 = new AdditionalStat();
        stat1.setHttpStatus(500);
        stat1.setNativeErrorCd("201824");
        stat1.setAccountId("123456");
        stat1.setStatDesc("Account Not Found");
        addnStatList.add(stat);
        addnStatList.add(stat1);

        reasResponse.setAddStatList(addnStatList);

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);

        ApiErrorCode error = new ApiErrorCode();
        error.setDeveloperText("developerText");
        List<String> messageParms = new ArrayList<String>();
        when(customerAccountsUtil.constructApiErrorCode(12, messageParms, error.getDeveloperText())).thenReturn(error);
        service.execute(orchResponse, true,false,null);
    }

    @Test(expected = ApiBusinessException.class)
    public void testExecute_CustAcct_ResponseWithAddStatList1() {

        CustomerAccountsOrchResponse orchResponse = new CustomerAccountsOrchResponse();
        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountsResponse> customerAccountsResponseList1 = new ArrayList<CustomerAccountsResponse>();
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList1);

        List<AdditionalStat> addnStatList = new ArrayList<AdditionalStat>();
        AdditionalStat stat = new AdditionalStat();
        stat.setStatDesc("errorDescription");
        stat.setHttpStatus(400);
        stat.setNativeErrorCd(null);
        stat.setAccountId("12345");
        addnStatList.add(stat);

        reasResponse.setAddStatList(addnStatList);

        Future<REASResponse> futureReasResponse = new AsyncResult<REASResponse>(reasResponse);

        List<XESRelationshipResponseBean> xesRelatedAcctResponse = new ArrayList<XESRelationshipResponseBean>();
        Future<List<XESRelationshipResponseBean>> futureXESRelatedAcctResponse = new AsyncResult<List<XESRelationshipResponseBean>>(
                xesRelatedAcctResponse);
        XESRelationshipResponseBean xesInfo = new XESRelationshipResponseBean();
        xesInfo.setAccountNumber("1234");
        xesInfo.setCustAcctToRelationshipCd("OTHER");
        xesRelatedAcctResponse.add(xesInfo);

        List<ProfileRelationshipLookup> profileAccountRelationshipsResponse = new ArrayList<ProfileRelationshipLookup>();
        Future<List<ProfileRelationshipLookup>> futureProfileAccountRelationshipsResponse = new AsyncResult<List<ProfileRelationshipLookup>>(
                profileAccountRelationshipsResponse);
        ProfileRelationshipLookup profileInfo = new ProfileRelationshipLookup();
        profileAccountRelationshipsResponse.add(profileInfo);

        orchResponse.setFutureReasResponse(futureReasResponse);
        orchResponse.setFutureXESRelatedAcctResponse(futureXESRelatedAcctResponse);
        orchResponse.setFutureProfileAccountRelationshipsResponse(futureProfileAccountRelationshipsResponse);

        Map<String, String> map = new HashMap<String, String>();
        map.put(Constants.CUST_REL_DESC, "Role");
        when(customerAccountsRefDataBean.getCustRelationshipDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(
                map);

        ApiErrorCode error = new ApiErrorCode();
        error.setDeveloperText("developerText");
        List<String> messageParms = new ArrayList<String>();
        when(customerAccountsUtil.constructApiErrorCode(12, messageParms, "")).thenReturn(error);
        service.execute(orchResponse, true,false,null);
    }

    @Test
    public void testExecute_retrieveNicknameFromOecp() throws Exception {
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");
        response.setSorId("7");
        response.setAccountNickname("");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);
        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<OecpPreferResponse> oecpPreferResponse = new ArrayList<OecpPreferResponse>();
        OecpPreferResponse oecpInfo = new OecpPreferResponse();
        oecpInfo.setAccountId("12345");
        oecpInfo.setSorId("8");
        oecpInfo.setAccountNickname("Nickname");
        oecpPreferResponse.add(oecpInfo);

        Future<List<OecpPreferResponse>> futureECRPrefResponse = new AsyncResult<List<OecpPreferResponse>>(
                oecpPreferResponse);
        service.retrieveNicknameFromOecp(reasResponse, futureECRPrefResponse);

    }
    
    @Test
    public void testExecute_retrieveNicknameFromOecp_emptyNickName() throws Exception {

        REASResponse reasResponse = new REASResponse();
        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");
        response.setSorId("7");
        response.setAccountNickname("");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<OecpPreferResponse> oecpPreferResponse = new ArrayList<OecpPreferResponse>();
        OecpPreferResponse oecpInfo = new OecpPreferResponse();
        oecpInfo.setAccountId("12345");
        oecpInfo.setSorId("8");
        oecpInfo.setAccountNickname("");
        oecpPreferResponse.add(oecpInfo);

        Future<List<OecpPreferResponse>> futureECRPrefResponse = new AsyncResult<List<OecpPreferResponse>>(
                oecpPreferResponse);
        service.retrieveNicknameFromOecp(reasResponse, futureECRPrefResponse);

    }
    
    @Test
    public void testExecute_retrieveNicknameFromOecp_nullReasRes() throws Exception {    

        List<OecpPreferResponse> oecpPreferResponse = new ArrayList<OecpPreferResponse>();
        OecpPreferResponse oecpInfo = new OecpPreferResponse();
        oecpInfo.setAccountId("12345");
        oecpInfo.setSorId("8");
        oecpInfo.setAccountNickname("");
        oecpPreferResponse.add(oecpInfo);

        Future<List<OecpPreferResponse>> futureECRPrefResponse = new AsyncResult<List<OecpPreferResponse>>(
                oecpPreferResponse);
        service.retrieveNicknameFromOecp(null, futureECRPrefResponse);

    }
    
    @Test
    public void testExecute_retrieveNicknameFromOecp_DiffAcctId() throws Exception {

        REASResponse reasResponse = new REASResponse();

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");
        response.setSorId("7");
        response.setAccountNickname("");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<OecpPreferResponse> oecpPreferResponse = new ArrayList<OecpPreferResponse>();
        OecpPreferResponse oecpInfo = new OecpPreferResponse();
        
        oecpInfo.setSorId("8");
        oecpInfo.setAccountNickname("");
        oecpInfo.setAccountId("1234");
        oecpPreferResponse.add(oecpInfo);

        Future<List<OecpPreferResponse>> futureECRPrefResponse = new AsyncResult<List<OecpPreferResponse>>(
                oecpPreferResponse);
        service.retrieveNicknameFromOecp(reasResponse, futureECRPrefResponse);

    }
    
    @Test
    public void testExecute_retrieveNicknameFromOLBR() throws Exception {
        
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsResponse response = new CustomerAccountsResponse();
        response.setAccountId("12345");
        response.setSorId("12");
        response.setAccountNickname("");
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(response);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponseList);

        List<OLBResponse> olbResponse = new ArrayList<OLBResponse>();
        OLBResponse olbinfo = new OLBResponse();
        olbinfo.setAccountId("12345");
        olbinfo.setOlbAccountNickname("olbAccountNickname");
        olbinfo.setSorId("12");
        
        olbResponse.add(olbinfo);
        
        Future<List<OLBResponse>> futureOLBResponse = new AsyncResult<List<OLBResponse>>(olbResponse);
        service.retrieveNicknameFromOLBR(reasResponse, futureOLBResponse);
    }
}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
