package com.capitalone.api.customersaccounts.dao.impl;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRq;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRq.Cmd;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRq.Cmd.AccountsArray;
import com.capitalone.odsbrokerageaccountsis.v1.BalancesInqRs;
import com.capitalone.odsbrokerageaccountsis.v1.ODSBrokerageAccountsISSoap;


@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class ODSBrokerageAccountsISDAOImplTest{
    
  
    @InjectMocks
    private ODSBrokerageAccountsISDAOImpl doaimpl;
    
    @Mock
    private ConversionService conversionService;
    
    @Mock
    private ODSBrokerageAccountsISSoap odsBrokerageAccountsISSoap;
    
    @Test
    public void testgetBrokerageAccounts() throws InterruptedException, ExecutionException {
        EPFContext context = EPFContextContainer.getContext();
        
        Future<REASResponse> response = null;
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12334");
        key.setSorId(new Short("102"));
        keyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);
        AccountsArray accountsArray = null;
        accountsArray = new AccountsArray();
        accountsArray.setAcctID("12345678912");
        accountsArray.setSoRID(new Short("102"));
        BalancesInqRq nativerequest = new BalancesInqRq();
        Cmd cmd = new Cmd();     
        cmd.getAccountsArray().add(accountsArray);
        nativerequest.setCmd(cmd);
        
        BalancesInqRs balancesInqRs = new BalancesInqRs();
        balancesInqRs.setCmd(new BalancesInqRs.Cmd());
        
        REASResponse convertedResponse = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setBusinessLine("Brokerage");
        customerAccountsResponse.setCurrencyCode("USD");
       // customerAccountsResponse.setOpenDate(new Instant("12-05-2010"));
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(customerAccountsResponse);
        convertedResponse.setCustomerAccountsResponseList(customerAccountsResponseList);
        
        Mockito.when(conversionService.convert(keyList,BalancesInqRq.class)).thenReturn(nativerequest);
        Mockito.when(odsBrokerageAccountsISSoap.balancesInq(nativerequest)).thenReturn(balancesInqRs);
        
        Mockito.when(conversionService.convert(balancesInqRs,REASResponse.class)).thenReturn(convertedResponse);
        response=doaimpl.getBrokerageAccounts(context, keyList);
        assertThat(response.get().getCustomerAccountsResponseList().get(0).getBusinessLine(), equalTo("Brokerage"));
    }
    
    @Test
    public void testgetBrokerageAccounts_balancesInqRq_Null() throws InterruptedException, ExecutionException {
        EPFContext context = EPFContextContainer.getContext();
        
        Future<REASResponse> response = null;
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12334");
        key.setSorId(new Short("102"));
        keyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);
        BalancesInqRq nativerequest = null;       
        
        Mockito.when(conversionService.convert(keyList,BalancesInqRq.class)).thenReturn(nativerequest);      
        response=doaimpl.getBrokerageAccounts(context, keyList);
        assertNotNull(response);
    }
    
    @Test
    public void testgetBrokerageAccounts_getAccountsArray_Empty() throws InterruptedException, ExecutionException {
        EPFContext context = EPFContextContainer.getContext();
        
        Future<REASResponse> response = null;
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12334");
        key.setSorId(new Short("102"));
        keyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);       
        
        BalancesInqRq nativerequest = new BalancesInqRq();;
        Cmd cmd = new Cmd();     
        //cmd.getAccountsArray().add(accountsArray);
        nativerequest.setCmd(cmd);       
        
        Mockito.when(conversionService.convert(keyList,BalancesInqRq.class)).thenReturn(nativerequest);       
        response=doaimpl.getBrokerageAccounts(context, keyList);
        assertNull(response);
    }
    
    @Test
    public void testgetBrokerageAccounts_Exception() throws InterruptedException, ExecutionException {        
        EPFContext context = EPFContextContainer.getContext();        
        Future<REASResponse> response = null;
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12334");
        key.setSorId(new Short("102"));
        keyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);        
        BalancesInqRq nativerequest = new BalancesInqRq();       
        BalancesInqRs balancesInqRs = new BalancesInqRs();
        balancesInqRs.setCmd(new BalancesInqRs.Cmd());        
        Mockito.when(conversionService.convert(keyList,BalancesInqRq.class)).thenReturn(nativerequest);
        NullPointerException e = new NullPointerException();
        Mockito.when(odsBrokerageAccountsISSoap.balancesInq(nativerequest)).thenThrow(e);      
        
        response=doaimpl.getBrokerageAccounts(context, keyList);       
        assertNotNull(response);
    }
    
    @Test
    public void testgetBrokerageAccounts_1() throws InterruptedException, ExecutionException {
        EPFContext context = EPFContextContainer.getContext();
        
        Future<REASResponse> response = null;
        List<CustomerAccountKey> keyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345678912");
        key.setSorId(new Short("102"));
        keyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        customerAccountsRequest.getCustomerAccountKeyList().addAll(keyList);
        AccountsArray accountsArray = null;
        accountsArray = new AccountsArray();
        accountsArray.setAcctID("12345678912");
        accountsArray.setSoRID(new Short("102"));
        BalancesInqRq nativerequest = new BalancesInqRq();
        Cmd cmd = new Cmd();     
        cmd.getAccountsArray().add(accountsArray);
        nativerequest.setCmd(cmd);
        
        BalancesInqRs balancesInqRs = new BalancesInqRs();
        balancesInqRs.setCmd(new BalancesInqRs.Cmd());
        
        REASResponse convertedResponse = new REASResponse();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setBusinessLine("Brokerage");
        customerAccountsResponse.setCurrencyCode("USD");
       // customerAccountsResponse.setOpenDate(new Instant("12-05-2010"));
        List<CustomerAccountsResponse> customerAccountsResponseList = new ArrayList<CustomerAccountsResponse>();
        customerAccountsResponseList.add(customerAccountsResponse);
        convertedResponse.setCustomerAccountsResponseList(customerAccountsResponseList);
        
        Mockito.when(conversionService.convert(keyList,BalancesInqRq.class)).thenReturn(nativerequest);
        Mockito.when(odsBrokerageAccountsISSoap.balancesInq(nativerequest)).thenReturn(balancesInqRs);
        
        Mockito.when(conversionService.convert(balancesInqRs,REASResponse.class)).thenReturn(convertedResponse);
        response=doaimpl.getBrokerageAccounts(context, keyList);
        assertThat(response.get().getCustomerAccountsResponseList().get(0).getBusinessLine(), equalTo("Brokerage"));
    }
    

}
