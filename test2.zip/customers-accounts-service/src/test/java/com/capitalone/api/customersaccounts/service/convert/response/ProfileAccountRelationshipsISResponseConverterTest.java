/**
 * 
 */

package com.capitalone.api.customersaccounts.service.convert.response;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.convert.request.BifToBusinessCustomerRqConverter;
import com.capitalone.api.customersaccounts.service.pojo.ProfileRelationshipLookup;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRq;
import com.capitalone.cstbusinesscustomeris.v1.BusinessDetailsRs;
import com.capitalone.cstbusinesscustomeris.v1.CSTBusinessCustomerSignersISSOAP;
import com.capitalone.profileaccountrelationshipsis.v1.AccountRelationshipRs;
import com.capitalone.profileaccountrelationshipsis.v1.DepositAccountCustomerRoleTypes;

/**
 * @author oto081
 * 
 */

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class ProfileAccountRelationshipsISResponseConverterTest {
    @InjectMocks
    private ProfileAccountRelationshipsISResponseConverter converter;

    @Mock
    private BifToBusinessCustomerRqConverter bifToBusinessCustomerRqConverter = Mockito
            .mock(BifToBusinessCustomerRqConverter.class);

    @Mock
    private CSTBusinessCustomerSignersISSOAP cstBusinessCustomerISService;

    private static final String ACCOUNT_NO = "4000176";

    private static final String CUST_ID = "20001";

    private static final boolean TRUST_INDICATOR = false;

    /**
     * @throws java.lang.Exception
     */

    @Test
    public void test_success() {

        AccountRelationshipRs accountRelationshipRs = new AccountRelationshipRs();
        AccountRelationshipRs.Cmd cmd = new AccountRelationshipRs.Cmd();
        cmd.setCustomerAccountRelationshipCode("abc");
        cmd.setProductType("bbb");
        cmd.setTrustAccountInd(true);
        accountRelationshipRs.setCmd(cmd);

        ProfileRelationshipLookup profileRelationshipLookup = new ProfileRelationshipLookup();
        profileRelationshipLookup.setAccountNumber("aaa");
        profileRelationshipLookup.setCustomerAccountRelationshipCode("sss");
        profileRelationshipLookup.setCustomerCount(12);
        profileRelationshipLookup.setCustomerId("20001");
        profileRelationshipLookup.setOwnershipType("ss");
        profileRelationshipLookup.setTrustAccountInd(true);
        profileRelationshipLookup.setErrorCd("aaa");

        BusinessCustomerRq businessCustomerRq = new BusinessCustomerRq();
        BusinessCustomerRq.Cmd cmd1 = new BusinessCustomerRq.Cmd();
        cmd1.setPrimaryCustomerID(CUST_ID);
        businessCustomerRq.setCmd(cmd1);

        when(bifToBusinessCustomerRqConverter.convert(CUST_ID)).thenReturn(businessCustomerRq);

        DepositAccountCustomerRoleTypes depositAccountCustomerRoleTypes = new DepositAccountCustomerRoleTypes();
        depositAccountCustomerRoleTypes.setCustomerID(CUST_ID);
        accountRelationshipRs.getCmd().getDepositAccountCustomerRoleTypes().add(depositAccountCustomerRoleTypes);

        accountRelationshipRs.getCmd().setTrustAccountInd(TRUST_INDICATOR);
        accountRelationshipRs.getCmd().setProductType("3000");

        // businessDetailsRs = cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq);
        BusinessDetailsRs businessDetailsRs = new BusinessDetailsRs();
        BusinessDetailsRs.Cmd cmd2 = new BusinessDetailsRs.Cmd();
        cmd2.setCustomerAccountRelationshipCode("aaa");
        businessDetailsRs.setCmd(cmd2);

        when(cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq)).thenReturn(businessDetailsRs);

        ProfileRelationshipLookup response = converter.convert(accountRelationshipRs, CUST_ID, ACCOUNT_NO);

        assertNotNull(response);

    }

    @Test
    public final void test_nullResponse() {

        /*
         * AccountRelationshipsInqRs nativeResponse = new AccountRelationshipsInqRs(); AccountRelationshipRs
         * accountRelationshipRs = new AccountRelationshipRs(); accountRelationshipRs.setCmd(new Cmd());
         * 
         * DepositAccountCustomerRoleTypes depositAccountCustomerRoleTypes = new DepositAccountCustomerRoleTypes();
         * depositAccountCustomerRoleTypes.setCustomerID(CUST_ID);
         * accountRelationshipRs.getCmd().getDepositAccountCustomerRoleTypes().add(depositAccountCustomerRoleTypes);
         * 
         * nativeResponse.setAccountRelationshipRs(accountRelationshipRs);
         */

        ProfileRelationshipLookup response = converter.convert(null, null, null);

        assertNull(response);

    }

    @Test
    public void test_success1() {

        AccountRelationshipRs accountRelationshipRs = new AccountRelationshipRs();
        AccountRelationshipRs.Cmd cmd = new AccountRelationshipRs.Cmd();
        cmd.setCustomerAccountRelationshipCode("abc");
        cmd.setProductType("bbb");
        cmd.setTrustAccountInd(true);
        DepositAccountCustomerRoleTypes roleType = new DepositAccountCustomerRoleTypes();
        roleType.setOwnershipType("1");
        roleType.setCustomerID("20001");
        cmd.getDepositAccountCustomerRoleTypes().add(roleType);
        accountRelationshipRs.setCmd(cmd);

        ProfileRelationshipLookup profileRelationshipLookup = new ProfileRelationshipLookup();
        profileRelationshipLookup.setAccountNumber("aaa");
        profileRelationshipLookup.setCustomerAccountRelationshipCode("sss");
        profileRelationshipLookup.setCustomerCount(12);
        profileRelationshipLookup.setCustomerId("20001");
        profileRelationshipLookup.setOwnershipType("ss");
        profileRelationshipLookup.setTrustAccountInd(true);
        profileRelationshipLookup.setErrorCd("aaa");

        BusinessCustomerRq businessCustomerRq = new BusinessCustomerRq();
        BusinessCustomerRq.Cmd cmd1 = new BusinessCustomerRq.Cmd();
        cmd1.setPrimaryCustomerID(CUST_ID);
        businessCustomerRq.setCmd(cmd1);

        when(bifToBusinessCustomerRqConverter.convert(CUST_ID)).thenReturn(businessCustomerRq);

        DepositAccountCustomerRoleTypes depositAccountCustomerRoleTypes = new DepositAccountCustomerRoleTypes();
        depositAccountCustomerRoleTypes.setCustomerID(CUST_ID);
        accountRelationshipRs.getCmd().getDepositAccountCustomerRoleTypes().add(depositAccountCustomerRoleTypes);

        accountRelationshipRs.getCmd().setTrustAccountInd(TRUST_INDICATOR);
        accountRelationshipRs.getCmd().setProductType("4500");

        // businessDetailsRs = cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq);
        BusinessDetailsRs businessDetailsRs = new BusinessDetailsRs();
        BusinessDetailsRs.Cmd cmd2 = new BusinessDetailsRs.Cmd();
        cmd2.setCustomerAccountRelationshipCode("aaa");
        businessDetailsRs.setCmd(cmd2);

        when(cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq)).thenReturn(businessDetailsRs);

        ProfileRelationshipLookup response = converter.convert(accountRelationshipRs, CUST_ID, ACCOUNT_NO);

        assertNotNull(response);

    }

    @Test
    public void test_success2() {

        AccountRelationshipRs accountRelationshipRs = new AccountRelationshipRs();
        AccountRelationshipRs.Cmd cmd = new AccountRelationshipRs.Cmd();
        cmd.setCustomerAccountRelationshipCode("abc");
        cmd.setProductType("bbb");
        cmd.setTrustAccountInd(true);
        DepositAccountCustomerRoleTypes roleType = new DepositAccountCustomerRoleTypes();
        roleType.setOwnershipType("1");
        roleType.setCustomerID("123456");
        cmd.getDepositAccountCustomerRoleTypes().add(roleType);
        accountRelationshipRs.setCmd(cmd);

        ProfileRelationshipLookup profileRelationshipLookup = new ProfileRelationshipLookup();
        profileRelationshipLookup.setAccountNumber("aaa");
        profileRelationshipLookup.setCustomerAccountRelationshipCode("sss");
        profileRelationshipLookup.setCustomerCount(12);
        profileRelationshipLookup.setCustomerId("20001");
        profileRelationshipLookup.setOwnershipType("ss");
        profileRelationshipLookup.setTrustAccountInd(true);
        profileRelationshipLookup.setErrorCd("aaa");

        BusinessCustomerRq businessCustomerRq = new BusinessCustomerRq();
        BusinessCustomerRq.Cmd cmd1 = new BusinessCustomerRq.Cmd();
        cmd1.setPrimaryCustomerID(CUST_ID);
        businessCustomerRq.setCmd(cmd1);

        when(bifToBusinessCustomerRqConverter.convert(CUST_ID)).thenReturn(businessCustomerRq);

        DepositAccountCustomerRoleTypes depositAccountCustomerRoleTypes = new DepositAccountCustomerRoleTypes();
        depositAccountCustomerRoleTypes.setCustomerID(CUST_ID);
        accountRelationshipRs.getCmd().getDepositAccountCustomerRoleTypes().add(depositAccountCustomerRoleTypes);

        accountRelationshipRs.getCmd().setTrustAccountInd(TRUST_INDICATOR);
        accountRelationshipRs.getCmd().setProductType("4500");

        // businessDetailsRs = cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq);
        BusinessDetailsRs businessDetailsRs = new BusinessDetailsRs();
        BusinessDetailsRs.Cmd cmd2 = new BusinessDetailsRs.Cmd();
        cmd2.setCustomerAccountRelationshipCode("aaa");
        businessDetailsRs.setCmd(cmd2);

        when(cstBusinessCustomerISService.businessDetailsInq(businessCustomerRq)).thenReturn(businessDetailsRs);

        ProfileRelationshipLookup response = converter.convert(accountRelationshipRs, CUST_ID, ACCOUNT_NO);

        assertNotNull(response);

    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */