package com.capitalone.api.customersaccounts.service.convert.request;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.olbaccountpreferencesis.v1.AccountPreferencesInqRq;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class OLBAccountPreferencesISReqConverterTest {

    @InjectMocks
    private OLBAccountPreferencesISReqConverter accountPreferencesISReqConverter;

    @Test
    public void testConvert() {
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        ProfileReferenceId profileReferenceId = new ProfileReferenceId("49", "eeee871593", "LGIN");
        customerAccountsRequest.setProfileReferenceId(profileReferenceId);
        AccountPreferencesInqRq nativeRequest = accountPreferencesISReqConverter.convert(customerAccountsRequest);
        assertThat(nativeRequest.getCmd().getAccountPreferencesInput().getPermLginTxt(), is("eeee871593"));
    }

}
