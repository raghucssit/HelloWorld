package com.capitalone.api.customersaccounts.dao.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;
import org.powermock.reflect.Whitebox;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.CustomerAccountsKeyDao;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.entity.ECRCustomerRelationshipsEntity;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.CustomerReferenceId;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRq;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping;
import com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails;
import com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd;
import com.capitalone.ecrcustomerrelationshipsisv2.v2.ECRCustomerRelationshipsISV2Soap;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class ECRDaoImplTest {

    @Mock
    private ConversionService converionService;
    
    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Mock
    private ReferenceIdEncoder encoder;

    @Mock
    ECRCustomerRelationshipsEntity ecrCustomerRelationshipsEntity;
    
    @Mock
    ECRCustomerRelationshipsISV2Soap ecrCustomerRelationshipIsServiceV2;

    private CustomerAccountsKeyDao dao;

    @Mock
    ECRDaoImpl ecrDaoImpl;

    @Before
    public void setUp() {
        dao = new ECRDaoImpl();
        Whitebox.setInternalState(dao, ConversionService.class, converionService);
        Whitebox.setInternalState(dao, ReferenceIdEncoder.class, encoder);
        Whitebox.setInternalState(dao, CustomerAccountsUtil.class, customerAccountsUtil);
        Whitebox.setInternalState(dao, ECRCustomerRelationshipsEntity.class, ecrCustomerRelationshipsEntity);
        Whitebox.setInternalState(dao, ECRCustomerRelationshipsISV2Soap.class, ecrCustomerRelationshipIsServiceV2);

    }

    @Test
    public void testRetrieveECRCustomerRelationshipResponse_CustIdNotMach() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        request.setCustomerReferenceId(customerReferenceID);
        request.setEcrCachedConfig(Collections.singletonList("V5"));
        request.setAppVersion("V4");
        CustIdentityMatchedAccountsInqRq nativeReq = new CustIdentityMatchedAccountsInqRq();
        CustIdentityMatchedAccountsInqRs response = new CustIdentityMatchedAccountsInqRs();
        CustIdentityMatchedAccountsInqRs.Cmd cmd = Mockito.mock(CustIdentityMatchedAccountsInqRs.Cmd.class);
        response.setCmd(cmd);
        ECRMatchedAccounts accounts = Mockito.mock(ECRMatchedAccounts.class);
        when(cmd.getECRMatchedAccounts()).thenReturn(accounts);
        List<EntSvcgGrping> list = new ArrayList<CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping>();
        EntSvcgGrping obj = Mockito.mock(CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.class);
        list.add(obj);
        when(accounts.getEntSvcgGrping()).thenReturn(list);
        when(obj.getEntSvcgCustID()).thenReturn(null);
        when(cmd.getStat()).thenReturn(new StatType());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        when(converionService.convert(request, CustIdentityMatchedAccountsInqRq.class)).thenReturn(nativeReq);
        //when(ecrCustomerRelationshipsISSoap.custIdentityMatchedAccountsInq(nativeReq)).thenReturn(response);
        when(ecrCustomerRelationshipsEntity.custIdentityMatchedAccountsInq(nativeReq, "")).thenReturn(response);
        when(converionService.convert(response, CustomerAccountKey.class)).thenReturn(customerAccountKey);
        dao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request);
    }

    @Test
    public void testRetrieveECRCustomerRelationshipResponse_MultiRecordsFound() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        request.setCustomerReferenceId(customerReferenceID);
        request.setEcrCachedConfig(Collections.singletonList("V5"));
        request.setAppVersion("V4");
        CustIdentityMatchedAccountsInqRq nativeReq = new CustIdentityMatchedAccountsInqRq();
        CustIdentityMatchedAccountsInqRs response = new CustIdentityMatchedAccountsInqRs();
        CustIdentityMatchedAccountsInqRs.Cmd cmd = Mockito.mock(CustIdentityMatchedAccountsInqRs.Cmd.class);
        response.setCmd(cmd);
        ECRMatchedAccounts accounts = Mockito.mock(ECRMatchedAccounts.class);
        when(cmd.getECRMatchedAccounts()).thenReturn(accounts);
        List<EntSvcgGrping> list = new ArrayList<CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping>();
        EntSvcgGrping obj = Mockito.mock(CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.class);
        list.add(obj);
        when(accounts.getEntSvcgGrping()).thenReturn(list);
        when(obj.getEntSvcgCustID()).thenReturn("1234");
        when(cmd.getStat()).thenReturn(null);
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        when(converionService.convert(request, CustIdentityMatchedAccountsInqRq.class)).thenReturn(nativeReq);
        //when(ecrCustomerRelationshipsISSoap.custIdentityMatchedAccountsInq(nativeReq)).thenReturn(response);
        when(ecrCustomerRelationshipsEntity.custIdentityMatchedAccountsInq(nativeReq, "")).thenReturn(response);
        when(converionService.convert(response, CustomerAccountKey.class)).thenReturn(customerAccountKey);
        dao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request);
    }

    @Test
    public void testRetrieveECRCustomerRelationshipResponse_InvalidNativeResponse() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        request.setCustomerReferenceId(customerReferenceID);
        request.setEcrCachedConfig(Collections.singletonList("V5"));
        request.setAppVersion("V4");
        CustIdentityMatchedAccountsInqRq nativeReq = new CustIdentityMatchedAccountsInqRq();
        CustIdentityMatchedAccountsInqRs response = Mockito.mock(CustIdentityMatchedAccountsInqRs.class);
        when(converionService.convert(request, CustIdentityMatchedAccountsInqRq.class)).thenReturn(nativeReq);
        when(ecrCustomerRelationshipsEntity.custIdentityMatchedAccountsInq(nativeReq, "")).thenReturn(response);
        com.capitalone.ecrcustomerrelationshipsis.v1.CustIdentityMatchedAccountsInqRs.Cmd cmd = Mockito.mock(CustIdentityMatchedAccountsInqRs.Cmd.class);
		when(response.getCmd()).thenReturn(cmd);
		StatType statValue=new StatType();
		when(cmd.getStat()).thenReturn(statValue);
        List<CustomerAccountKey> daoResponse = dao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request);
		Assert.assertNull(daoResponse);
    }

    @Test
    public void testRetrieveECRCustomerRelationshipResponse_InvalidNativeResponse1() {
        CustomerAccountsRequest request = new CustomerAccountsRequest();
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        request.setCustomerReferenceId(customerReferenceID);
        request.setEcrCachedConfig(Collections.singletonList("V5"));
        request.setAppVersion("V4");
        CustIdentityMatchedAccountsInqRq nativeReq = new CustIdentityMatchedAccountsInqRq();
        CustIdentityMatchedAccountsInqRs response = new CustIdentityMatchedAccountsInqRs();
        CustIdentityMatchedAccountsInqRs.Cmd cmd = Mockito.mock(CustIdentityMatchedAccountsInqRs.Cmd.class);
        response.setCmd(cmd);
        when(cmd.getStat()).thenReturn(null);
        when(converionService.convert(request, CustIdentityMatchedAccountsInqRq.class)).thenReturn(nativeReq);
        //when(ecrCustomerRelationshipsISSoap.custIdentityMatchedAccountsInq(nativeReq)).thenReturn(response);
        when(ecrCustomerRelationshipsEntity.custIdentityMatchedAccountsInq(nativeReq, "")).thenReturn(response);
        Assert.assertNull(dao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request));
    }

    @Test
    public void testCreateCustomerReferenceURL() {
        String customerRefID = "1234";
        CustomerReferenceId customerReferenceID = new CustomerReferenceId(customerRefID);
        ecrDaoImpl.createCustomerReferenceURL(customerReferenceID);
    }

    @Test
    public void testRetrieveECRCustomerRelationshipResponse() {

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        List<AcctDetails> list1 = new ArrayList<AcctDetails>();
        AcctDetails acct = new AcctDetails();
        acct.setSoRID((short) 12);
        acct.setSORCnsmrID("1234");
        acct.setApplctnAcctID("4567");
        // acct.setDrvrAcctInd(true);
        list1.add(acct);
        request.setCustomerReferenceId(customerReferenceID);
        request.setAppVersion("V4");
        List<String> ecrList=new ArrayList<String>();
        //ecrList.add("V3");
        //ecrList.add("V4");
        ecrList.add("V5");
        request.setEcrCachedConfig(ecrList);
        CustIdentityMatchedAccountsInqRq nativeReq = new CustIdentityMatchedAccountsInqRq();
        CustIdentityMatchedAccountsInqRs response = new CustIdentityMatchedAccountsInqRs();
        CustIdentityMatchedAccountsInqRs.Cmd cmd = Mockito.mock(CustIdentityMatchedAccountsInqRs.Cmd.class);
        response.setCmd(cmd);
        ECRMatchedAccounts accounts = Mockito.mock(ECRMatchedAccounts.class);
        when(cmd.getECRMatchedAccounts()).thenReturn(accounts);
        List<EntSvcgGrping> list = new ArrayList<CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping>();
        EntSvcgGrping obj = Mockito.mock(CustIdentityMatchedAccountsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.class);
        list.add(obj);
        when(accounts.getEntSvcgGrping()).thenReturn(list);
        // when(obj.getEntSvcgCustID()).thenReturn("1234");
        when(obj.getAcctDetails()).thenReturn(list1);
        when(cmd.getStat()).thenReturn(new StatType());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        when(converionService.convert(request, CustIdentityMatchedAccountsInqRq.class)).thenReturn(nativeReq);
        //when(ecrCustomerRelationshipsISSoap.custIdentityMatchedAccountsInq(nativeReq)).thenReturn(response);
        when(ecrCustomerRelationshipsEntity.custIdentityMatchedAccountsInq(nativeReq, "")).thenReturn(response);
        when(converionService.convert(response, CustomerAccountKey.class)).thenReturn(customerAccountKey);
        Mockito.doNothing().when(ecrDaoImpl).createCustomerReferenceURL(customerReferenceID);

        dao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request);
    }
    
    @Test
    public void testRetrieveECRCustomerRelationshipResponseForV2() {

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        List<com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails> list1 = new ArrayList<com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails>();
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails acct = new com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails();
        acct.setSoRID((short) 12);
        acct.setSORCnsmrID("1234");
        acct.setApplctnAcctID("4567");
        list1.add(acct);
        request.setCustomerReferenceId(customerReferenceID);
        request.setAppVersion("V3");
        request.setEcrCachedConfig(Collections.singletonList("V3"));
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRq nativeReq = new com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRq();
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs response = new com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs();
        Cmd cmd = Mockito.mock(Cmd.class);
        response.setCmd(cmd);
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts accounts = Mockito.mock(com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.class);
        when(cmd.getECRMatchedAccounts()).thenReturn(accounts);
        List<com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping> list = new ArrayList<com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping>();
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping obj = Mockito.mock(com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.class);
        list.add(obj);
        when(accounts.getEntSvcgGrping()).thenReturn(list);
        when(obj.getAcctDetails()).thenReturn(list1);
        when(cmd.getStat()).thenReturn(new StatType());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        when(converionService.convert(request, com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRq.class)).thenReturn(nativeReq);
        when(ecrCustomerRelationshipIsServiceV2.custIdentityMatchedAccountsDetailsInq(nativeReq)).thenReturn(response);
        when(converionService.convert(response, CustomerAccountKey.class)).thenReturn(customerAccountKey);
        Mockito.doNothing().when(ecrDaoImpl).createCustomerReferenceURL(customerReferenceID);

        List<CustomerAccountKey> customerAccountList = dao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request);
        Assert.assertNotNull("Response from ECRDaoImpl is null", customerAccountList);
    }
    
    @Test
    public void testCachedVersionInV4AppVersion() {

        CustomerAccountsRequest request = new CustomerAccountsRequest();

        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        List<com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails> list1 = new ArrayList<com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails>();
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails acct = new com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.AcctDetails();
        acct.setSoRID((short) 12);
        acct.setSORCnsmrID("1234");
        acct.setApplctnAcctID("4567");
        list1.add(acct);
        request.setCustomerReferenceId(customerReferenceID);
        request.setAppVersion("V4");
        List<String> configList=new ArrayList<String>();
        configList.add("V4");
        configList.add("V5");
		request.setEcrCachedConfig(configList);
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRq nativeReq = new com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRq();
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs response = new com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs();
        Cmd cmd = Mockito.mock(Cmd.class);
        response.setCmd(cmd);
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts accounts = Mockito.mock(com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.class);
        when(cmd.getECRMatchedAccounts()).thenReturn(accounts);
        List<com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping> list = new ArrayList<com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping>();
        com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping obj = Mockito.mock(com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRs.Cmd.ECRMatchedAccounts.EntSvcgGrping.class);
        list.add(obj);
        when(accounts.getEntSvcgGrping()).thenReturn(list);
        when(obj.getAcctDetails()).thenReturn(list1);
        when(cmd.getStat()).thenReturn(new StatType());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        when(converionService.convert(request, com.capitalone.ecrcustomerrelationshipsisv2.v2.CustIdentityMatchedAccountsDetailsInqRq.class)).thenReturn(nativeReq);
        when(ecrCustomerRelationshipIsServiceV2.custIdentityMatchedAccountsDetailsInq(nativeReq)).thenReturn(response);
        when(converionService.convert(response, CustomerAccountKey.class)).thenReturn(customerAccountKey);
        Mockito.doNothing().when(ecrDaoImpl).createCustomerReferenceURL(customerReferenceID);

        List<CustomerAccountKey> customerAccountList = dao.retrieveCustomerAccountsKeyBasedOnProfileReferenceId(request);
        Assert.assertNotNull("Response from ECRDaoImpl is null", customerAccountList);
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */