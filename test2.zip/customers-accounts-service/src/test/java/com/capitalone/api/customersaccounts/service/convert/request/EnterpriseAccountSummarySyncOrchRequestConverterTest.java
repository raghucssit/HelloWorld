package com.capitalone.api.customersaccounts.service.convert.request;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.model.id.CustomerReferenceId;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AccountApplicantKey;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.AcctSummaryInqRq;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class EnterpriseAccountSummarySyncOrchRequestConverterTest {

    private EnterpriseAccountSummarySyncOrchRequestConverter converter;

    private final static String CUST_REF_ID = "1234";

    private final static String ACCOUNT_NO = "10000000908";

    private final static String SOR_ID = "185";

    private final static String profileReferenceId = "12345";

    private EPFContext context;

    @Before
    public void setUp() throws Exception {

        converter = new EnterpriseAccountSummarySyncOrchRequestConverter();

        context = new EPFContext();
        EPFContextContainer.getcurrentContext().set(context);

    }

    @Test
    public final void test_success() {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        customerAccountsRequest.setCustomerReferenceId(customerReferenceID);
        // customerAccountsRequest.setCustomerReferenceId(CUST_REF_ID);

        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber(ACCOUNT_NO);
        key.setConsumerId(CUST_REF_ID);
        key.setSorId(new Short(SOR_ID));

        customerAccountsRequest.getCustomerAccountKeyList().add(key);
        ProfileReferenceId id = new ProfileReferenceId("123456");
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("185");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        customerAccountsRequest.setProfileReferenceId(id);

        AcctSummaryInqRq request = converter.convert(customerAccountsRequest);

        assertNotNull(request);
        assertNotNull(request.getCmd());

        assertNotNull(request.getCmd().getAcctSummaryInputKey());
        assertNotNull(request.getCmd().getAcctSummaryInputKey().getAccountApplicantKey());

        List<AccountApplicantKey> customerAccountsKeyList = request.getCmd().getAcctSummaryInputKey()
                .getAccountApplicantKey();

        for (AccountApplicantKey accountApplicantKey : customerAccountsKeyList) {
            assertEquals(ACCOUNT_NO, accountApplicantKey.getApplctnAcctID());
            assertEquals(CUST_REF_ID, accountApplicantKey.getSORCnsmrID());
            assertEquals(SOR_ID, String.valueOf(accountApplicantKey.getSoRID()));
        }
    }

    @Test
    public final void test_failure() {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        customerAccountsRequest.setCustomerReferenceId(customerReferenceID);
        // customerAccountsRequest.setCustomerReferenceId(CUST_REF_ID);

        AcctSummaryInqRq request = converter.convert(customerAccountsRequest);

        assertNull(request);

    }

    @Test
    public final void test_null_profileReferenceId() {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        customerAccountsRequest.setCustomerReferenceId(customerReferenceID);
        // customerAccountsRequest.setCustomerReferenceId(CUST_REF_ID);

        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber(ACCOUNT_NO);
        key.setConsumerId(CUST_REF_ID);
        key.setSorId(new Short(SOR_ID));

        customerAccountsRequest.getCustomerAccountKeyList().add(key);

        AcctSummaryInqRq request = converter.convert(customerAccountsRequest);

        assertNotNull(request);
        assertNotNull(request.getCmd());
        // assertEquals(EnterpriseAccountSummarySyncOrchRequestConverter.OPERATION_NAME, request.getCmd().getName());

        assertNotNull(request.getCmd().getAcctSummaryInputKey());
        assertNotNull(request.getCmd().getAcctSummaryInputKey().getAccountApplicantKey());
        assertNull(request.getCmd().getAcctSummaryInputKey().getPermLginTxt());

    }

    @Test
    public final void test_valid_profileReferenceId() {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerReferenceId customerReferenceID = new CustomerReferenceId("1234");
        customerAccountsRequest.setCustomerReferenceId(customerReferenceID);
        // customerAccountsRequest.setCustomerReferenceId(CUST_REF_ID);

        //EPFContextContainer.getcurrentContext().get().setUserId(profileReferenceId);
        ProfileReferenceId id = new ProfileReferenceId("12345");
        customerAccountsRequest.setProfileReferenceId(id);

        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber(ACCOUNT_NO);
        key.setConsumerId(CUST_REF_ID);
        key.setSorId(new Short(SOR_ID));

        customerAccountsRequest.getCustomerAccountKeyList().add(key);

        AcctSummaryInqRq request = converter.convert(customerAccountsRequest);

        assertNotNull(request);
        assertNotNull(request.getCmd());
        // assertEquals(EnterpriseAccountSummarySyncOrchRequestConverter.OPERATION_NAME, request.getCmd().getName());

        assertNotNull(request.getCmd().getAcctSummaryInputKey());
        assertNotNull(request.getCmd().getAcctSummaryInputKey().getAccountApplicantKey());
        assertEquals(profileReferenceId, request.getCmd().getAcctSummaryInputKey().getPermLginTxt());

    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
