package com.capitalone.api.customersaccounts.service.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.impl.XESRelatedAccountDaoImpl;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class SafeDepoBoxAccountSummaryOrchServiceTest {

    @InjectMocks
    private SafeDepoBoxAccountSummaryOrchService safeDepoBoxAccountSummaryOrchService;

    @Mock
    private XESRelatedAccountDaoImpl dao;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {

        EPFContext context = EPFContextContainer.getContext();

        String custId = "1234";
        String acctId = "12345678912";
        List<String> acctIdList = new ArrayList<String>();
        acctIdList.add(acctId);
        Future<REASResponse> response;

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345678912");
        key.setSorId((short) 69);
        key.setConsumerId("1234");
        customerAccountKeyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        // customerAccountsRequest.setAppVersion("v4");
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
        REASResponse reasResponse = new REASResponse();

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("DEPOSITS");
        customerAccountsResponse.setProductId("SD");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);

        Mockito.when(dao.retrieve(context, custId, acctIdList, (short) 69)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
                .thenReturn((reasResponse));

        response = safeDepoBoxAccountSummaryOrchService.execute(customerAccountsRequest, context);
        assertNotNull(response);
    }

    @Test
    public void testExecute_diffSorId() throws InterruptedException, ExecutionException {

        EPFContext context = EPFContextContainer.getContext();

        String custId = "1234";
        String acctId = "12345678912";
        List<String> accountIdList = new ArrayList<String>();
        accountIdList.add(acctId);
        Future<REASResponse> response;

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345678912");
        key.setSorId((short) 16);
        key.setConsumerId("1234");
        customerAccountKeyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        // customerAccountsRequest.setAppVersion("v4");
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);
        REASResponse reasResponse = new REASResponse();

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("DEPOSITS");
        customerAccountsResponse.setProductId("SD");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);

        Mockito.when(dao.retrieve(context, custId, accountIdList, (short) 16)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge((REASResponse) Mockito.anyObject(), (REASResponse) Mockito.anyObject()))
                .thenReturn((reasResponse));

        response = safeDepoBoxAccountSummaryOrchService.execute(customerAccountsRequest, context);
        assertNotNull(response);
    }

}
