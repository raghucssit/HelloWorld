package com.capitalone.api.customersaccounts.dao.impl;

import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.exception.ApiSystemException;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.model.id.ReferenceId;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class ReferenceIdEncoderImplTest {

    @Mock
    private ReferenceId.NpiXmlAdapter adapter;

    @InjectMocks
    ReferenceIdEncoderImpl encoderImpl;

    @Test
    public void testencode() throws Exception {

        ReferenceId id = new ReferenceId(Mockito.anyString());
        Mockito.when(adapter.marshal(id)).thenReturn("AnyString");
        String a = encoderImpl.encode(id);
        Assert.assertEquals(a, "AnyString");

    }

    @SuppressWarnings("unchecked")
    @Test(expected = ApiSystemException.class)
    public void testencode1() throws Exception {

        ReferenceId id = new ReferenceId(Mockito.anyString());
        Mockito.when(adapter.marshal(id)).thenThrow(ApiSystemException.class);
        String a = encoderImpl.encode(id);
        Assert.assertEquals(a, null);

    }
}
