package com.capitalone.api.customersaccounts.service.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.dao.LoanAccountSummaryDao;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class LoanAccountSummaryOrchServiceTest {

    @InjectMocks
    private LoanAccountSummaryOrchService service;

    @Mock
    private LoanAccountSummaryDao dao;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {

        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("123456");
        Short sorId = 38;
        key.setSorId(sorId);
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("44");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("123456");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setSorId("38");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);

        EPFContext context = EPFContextContainer.getContext();

        Mockito.when(dao.retrieveLoanAccountummary(context, key)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge(reasResponse, reasResponse)).thenReturn(reasResponse);

        response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);

    }

    @Test
    public void testExecute_38() throws InterruptedException, ExecutionException {

        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("38");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("123456");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setSorId("38");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);

        EPFContext context = EPFContextContainer.getContext();

        Mockito.when(dao.retrieveLoanAccountummary(context, key)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge(reasResponse, reasResponse)).thenReturn(reasResponse);

        response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);

    }

    @Test
    public void testExecute_39() throws InterruptedException, ExecutionException {

        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("39");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("123456");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setSorId("39");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);
        EPFContext context = EPFContextContainer.getContext();
        Mockito.when(dao.retrieveLoanAccountummary(context, key)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));
        Mockito.when(customerAccountsUtil.merge(reasResponse, reasResponse)).thenReturn(reasResponse);

        response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);

    }

    @Test
    public void testExecute_SorId_39() throws InterruptedException, ExecutionException {

        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("123456");
        Short sorId = 39;
        key.setSorId(sorId);
        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("44");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("123456");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setSorId("39");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);
        EPFContext context = EPFContextContainer.getContext();

        Mockito.when(dao.retrieveLoanAccountummary(context, key)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge(reasResponse, reasResponse)).thenReturn(reasResponse);

        response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);

    }

    @Test
    public void testExecute_SorId39_NotInRequest() throws InterruptedException, ExecutionException {

        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        CustomerAccountKey key = new CustomerAccountKey();

        customerAccountsRequest.setAppVersion(Constants.APP_VERSION4);
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("44");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        customerAccountKeyList.add(key);
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setAccountId("123456");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setSorId("39");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);
        EPFContext context = EPFContextContainer.getContext();

        Mockito.when(dao.retrieveLoanAccountummary(context, key)).thenReturn(
                new AsyncResult<REASResponse>(reasResponse));

        Mockito.when(customerAccountsUtil.merge(reasResponse, reasResponse)).thenReturn(reasResponse);

        response = service.execute(customerAccountsRequest, context);
        assertNotNull(response);

    }

    @Test
    public void testExecute_Null_Request() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = null;
        Future<REASResponse> response = service.execute(customerAccountsRequest, null);
        assertNotNull(response);
    }

    @Test
    public void testExecute_Null_ReasSupportedSORID() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();

        List<String> reasSupportedSORID = null;
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        Future<REASResponse> response = service.execute(customerAccountsRequest, null);
        assertNotNull(response);
    }

    @Test
    public void testExecute_SORID_IM() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();

        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("16");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        Future<REASResponse> response = service.execute(customerAccountsRequest, null);
        assertNotNull(response);
    }

}
