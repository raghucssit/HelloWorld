package com.capitalone.api.customersaccounts.service.convert.response;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import java.math.BigDecimal;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.xestdais.v1.AcctInqISRs;
import com.capitalone.xestdais.v1.AcctInqISRs.Cmd;
import com.capitalone.xestdais.v1.AcctInqISRs.Cmd.TimeDepositAcctInq;
import com.capitalone.xestdais.v1.AcctInqISRs.Cmd.TimeDepositAcctInq.TimeDepositBalancesInfo;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class XESTDAISRsConverterTest {

    @InjectMocks
    private XESTDAISRsConverter xestdaisRsConverter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public void testConvert() {
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(new Cmd());
        TimeDepositAcctInq timeDepositAcctInq = new TimeDepositAcctInq();
        timeDepositAcctInq.setProdID("1234");
        timeDepositAcctInq.setProdDesc("abcd");
        timeDepositAcctInq.setTimeDepositBalancesInfo(new TimeDepositBalancesInfo());
        timeDepositAcctInq.getTimeDepositBalancesInfo().setCapOneCurrentBal(new BigDecimal(123));
        timeDepositAcctInq.getTimeDepositBalancesInfo().setAvailableBal(new BigDecimal(124));
        timeDepositAcctInq.setBankNum("678");
        Mockito.when(customerAccountsRefDataBean.getBankNumberDescription(Mockito.anyString())).thenReturn("678");
        timeDepositAcctInq.setAcctID("000");
        timeDepositAcctInq.setBankAcctStatusDesc("bnm");
        timeDepositAcctInq.setOpenDt(new Instant(20150624));
        timeDepositAcctInq.setRtirmntAcctInd(true);
        timeDepositAcctInq.setClosedDate(new Instant());
        acctInqISRs.getCmd().setTimeDepositAcctInq(timeDepositAcctInq);
        CustomerAccountsResponse customerAccountsResponse = xestdaisRsConverter.convert(acctInqISRs);
        assertThat(customerAccountsResponse.getProductId(), equalTo("1234"));
    }

    @Test
    public void testConvertWithNullValue() {
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(new Cmd());
        TimeDepositAcctInq timeDepositAcctInq = new TimeDepositAcctInq();
        timeDepositAcctInq.setProdID(null);
        timeDepositAcctInq.setProdDesc(null);
        timeDepositAcctInq.setTimeDepositBalancesInfo(new TimeDepositBalancesInfo());
        timeDepositAcctInq.getTimeDepositBalancesInfo().setCapOneCurrentBal(null);
        timeDepositAcctInq.getTimeDepositBalancesInfo().setAvailableBal(null);
        timeDepositAcctInq.setBankNum(null);
        Mockito.when(customerAccountsRefDataBean.getBankNumberDescription(Mockito.anyString())).thenReturn("678");
        timeDepositAcctInq.setAcctID(null);
        timeDepositAcctInq.setBankAcctStatusDesc(null);
        timeDepositAcctInq.setOpenDt(null);
        timeDepositAcctInq.setRtirmntAcctInd(null);
        timeDepositAcctInq.setClosedDate(null);
        acctInqISRs.getCmd().setTimeDepositAcctInq(timeDepositAcctInq);
        CustomerAccountsResponse customerAccountsResponse = xestdaisRsConverter.convert(acctInqISRs);
        assertNotNull(customerAccountsResponse);
    }

    @Test
    public void testConvertWithNullInput() {
        CustomerAccountsResponse customerAccountsResponse = xestdaisRsConverter.convert(null);
        assertNull(customerAccountsResponse);

    }

    @Test
    public void testConvertWithNullCmd() {
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(null);
        CustomerAccountsResponse customerAccountsResponse = xestdaisRsConverter.convert(acctInqISRs);
        assertNull(customerAccountsResponse);

    }

    @Test
    public void testConvertWithTimeDepositAcctInqNull() {
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(new Cmd());
        acctInqISRs.getCmd().setTimeDepositAcctInq(null);
        CustomerAccountsResponse customerAccountsResponse = xestdaisRsConverter.convert(acctInqISRs);
        assertNull(customerAccountsResponse);

    }

}
