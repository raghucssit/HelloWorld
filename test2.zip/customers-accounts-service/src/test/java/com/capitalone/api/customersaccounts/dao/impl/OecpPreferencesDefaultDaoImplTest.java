package com.capitalone.api.customersaccounts.dao.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.ReferenceIdEncoder;
import com.capitalone.api.customersaccounts.model.v1.Account;
import com.capitalone.api.customersaccounts.model.v1.AccountPreferences;
import com.capitalone.api.customersaccounts.model.v1.Accounts;
import com.capitalone.api.customersaccounts.service.api.CustomerAPIRESTException;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.OecpPreferResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.servicelocator.EndpointManager;
import com.capitalone.epf.servicelocator.model.EndpointProperties;
//import com.capitalone.api.customer.pref.model.v3.Account;
//import com.capitalone.api.customer.pref.model.v3.AccountPreferences;
//import com.capitalone.api.customer.pref.model.v3.Accounts;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class OecpPreferencesDefaultDaoImplTest {

    @InjectMocks
    private OecpPreferencesDefaultDaoImpl oecpPreferencesDaoImpl;

    @Mock
    private Client eapiRestClient;

    @Mock
    private EndpointManager endpointManager;

    @Mock
    private ReferenceIdEncoder encoder;

    @Mock
    private ConversionService conversionService;

    @Mock
    private WebTarget requestPath;

    @Mock
    private WebTarget target;

    @Mock
    private Builder builder;

    @Mock
    private EPFContext context;

    @Mock
    private Configuration config;

    @Mock
    private Response response;
    
    @Mock
    private EndpointProperties endpointProperties;
    
    @Mock
    private CustomerAccountsUtil customerAccountsUtil;
    
    @Mock
    private CustomerAPIRESTException e;

    @Test
    public void testRetrieveAccountNickname() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "ec-preference-accounts", null,
                null);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setConsumerId("888888888");
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        
        AccountPreferences acctpref = new AccountPreferences();
        acctpref.setAccountNickname("BNKMN");      
        
        Accounts accounts = new Accounts();
        List<Account> accts = new ArrayList<Account>();
        Account acct1 = new Account();
        acct1.setAccountId("12345678912");
        acct1.setSorId("2");
        acct1.setPreferences(acctpref);
        accts.add(acct1 );
        
        
        accounts.setAccounts(accts );
        
        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "ec-preference-accounts", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json;charset=UTF-8")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json;charset=UTF-8")).thenReturn(builder);
        Mockito.when(builder.get(Accounts.class)).thenReturn(accounts);
        ResponseBuilder responseBuilder = Response.ok();
        response = responseBuilder.build();       

        Future<List<OecpPreferResponse>> oecpresp = oecpPreferencesDaoImpl
                .retrieveAccountNickname(context, "888888888");
        
        assertNotNull(oecpresp);
    }

    @Test
    public void testRetrieveAccountNickname_Exception() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "ec-preference-accounts", null,
                null);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setConsumerId("888888888");
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "ec-preference-accounts", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json;charset=UTF-8")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json;charset=UTF-8")).thenReturn(builder);
        ResponseBuilder responseBuilder = Response.ok();
        response = responseBuilder.build();
       
        Future<List<OecpPreferResponse>> oecpresp = oecpPreferencesDaoImpl
                .retrieveAccountNickname(context, "888888888");
        assertNotNull(oecpresp);
    }

    @Test
    public void testRetrieveAccountNickname_nullPreferenceValue() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "ec-preference-accounts", null,
                null);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setConsumerId("888888888");
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        
        /*AccountPreferences acctpref = new AccountPreferences();
        acctpref.setAccountNickname("BNKMN");  */    
        
        Accounts accounts = new Accounts();
        List<Account> accts = new ArrayList<Account>();
        Account acct1 = new Account();
        acct1.setAccountId("12345678912");
        acct1.setSorId("2");
        //acct1.setPreferences(acctpref);
        accts.add(acct1 );        
        
        accounts.setAccounts(accts );
        
        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "ec-preference-accounts", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json;charset=UTF-8")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json;charset=UTF-8")).thenReturn(builder);
        Mockito.when(builder.get(Accounts.class)).thenReturn(accounts);
        ResponseBuilder responseBuilder = Response.ok();
        response = responseBuilder.build();       

        Future<List<OecpPreferResponse>> oecpresp = oecpPreferencesDaoImpl
                .retrieveAccountNickname(context, "888888888");
        
        assertNotNull(oecpresp);
    }
    
    @Test
    public void testRetrieveAccountNickname_nullAcctNickName() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "ec-preference-accounts", null,
                null);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setConsumerId("888888888");
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        
        AccountPreferences acctpref = new AccountPreferences();
        //acctpref.setAccountNickname("BNKMN");      
        
        Accounts accounts = new Accounts();
        List<Account> accts = new ArrayList<Account>();
        Account acct1 = new Account();
        acct1.setAccountId("12345678912");
        acct1.setSorId("2");
        acct1.setPreferences(acctpref);
        accts.add(acct1 );        
        
        accounts.setAccounts(accts );
        
        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "ec-preference-accounts", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json;charset=UTF-8")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json;charset=UTF-8")).thenReturn(builder);
        Mockito.when(builder.get(Accounts.class)).thenReturn(accounts);
        ResponseBuilder responseBuilder = Response.ok();
        response = responseBuilder.build();       

        Future<List<OecpPreferResponse>> oecpresp = oecpPreferencesDaoImpl
                .retrieveAccountNickname(context, "888888888");
        
        assertNotNull(oecpresp);
    }
    
    @Test
    public void testRetrieveAccountNickname_Execp() throws Exception {

        EndpointProperties endpointProperties = new EndpointProperties(null, null, "ec-preference-accounts", null,
                null);
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setConsumerId("888888888");
        customerAccountKey.setAccountNumber("12345678912");
        customerAccountKey.setSorId(new Short("2"));
        customerAccountKeyList.add(customerAccountKey);
        
        AccountPreferences acctpref = new AccountPreferences();
        //acctpref.setAccountNickname("BNKMN");      
        
        Accounts accounts = new Accounts();
        List<Account> accts = new ArrayList<Account>();
        Account acct1 = new Account();
        acct1.setAccountId("12345678912");
        acct1.setSorId("2");
        acct1.setPreferences(acctpref);
        accts.add(acct1 );        
        
        accounts.setAccounts(accts );
        
        Mockito.when(encoder.encode((ReferenceId) Mockito.anyObject())).thenReturn("12345678912");
        Mockito.when(endpointManager.getWSProperties(StringUtils.EMPTY, "ec-preference-accounts", null))
                .thenReturn(endpointProperties);
        Mockito.when(eapiRestClient.target((UriBuilder) Mockito.anyObject())).thenReturn(target);
        Mockito.when(target.request()).thenReturn(builder);
        Mockito.when(target.request().accept("application/json;charset=UTF-8")).thenReturn(builder);
        Mockito.when(target.request().header(HttpHeaders.CONTENT_TYPE, "application/json;charset=UTF-8")).thenReturn(builder);
        
        ErrorResponse errorResponse = new ErrorResponse();
        CustomerAPIRESTException e1 = new CustomerAPIRESTException(404,errorResponse);
        Mockito.when(e.getCause()).thenReturn(e1);
        e1.getErrorResponse().setDeveloperText("text");   
        e1.getErrorResponse().setId("TestID01");       
        e1.getErrorResponse().setText("Text");
        
        Mockito.when(builder.get(Accounts.class)).thenThrow(e);
        ResponseBuilder responseBuilder = Response.ok();
        response = responseBuilder.build();       

        Future<List<OecpPreferResponse>> oecpresp = oecpPreferencesDaoImpl
                .retrieveAccountNickname(context, "888888888");
        
        assertNotNull(oecpresp);
    }
    
    

}
