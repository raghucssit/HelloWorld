package com.capitalone.api.customersaccounts.service.convert.response;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerRoleTypes;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerSignersRs;
import com.capitalone.cstbusinesscustomeris.v1.BusinessCustomerSignersRs.Cmd;
import com.capitalone.cstbusinesscustomeris.v1.BusinessDetailsRs;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class CSTBusinessCustomerRsConverterTest {

    @InjectMocks
    private CSTBusinessCustomerRsConverter cstBusinessCustomerRsConverter;

    @Test
    public void convertTest() {

        BusinessCustomerRoleTypes businessCustomerRoleTypes = new BusinessCustomerRoleTypes();
        businessCustomerRoleTypes.setFullName("abc");
        businessCustomerRoleTypes.setOwnershipType("Sole");
        businessCustomerRoleTypes.setPrimaryCustomerID("123");

        BusinessCustomerSignersRs businessCustomerRs = new BusinessCustomerSignersRs();
        Cmd cmd = new Cmd();
        cmd.getBusinessCustomerRoleTypes().add(businessCustomerRoleTypes);
        businessCustomerRs.setCmd(cmd);

        BusinessDetailsRs businessDetailsRs = new BusinessDetailsRs();
        com.capitalone.cstbusinesscustomeris.v1.BusinessDetailsRs.Cmd cmd1 = new com.capitalone.cstbusinesscustomeris.v1.BusinessDetailsRs.Cmd();
        cmd1.setCustomerAccountRelationshipCode("1");
        businessDetailsRs.setCmd(cmd1);
        Pair<BusinessCustomerSignersRs, BusinessDetailsRs> inputPair = Pair.of(businessCustomerRs, businessDetailsRs);

        cstBusinessCustomerRsConverter.convert(inputPair);

    }

}
