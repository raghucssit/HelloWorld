package com.capitalone.api.customersaccounts.service.impl;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.scheduling.annotation.AsyncResult;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.dao.impl.CreditCardAccountSummaryDaoImpl;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CreditCardAccountSummaryOrchServiceTest {

    @InjectMocks
    private CreditCardAccountSummaryOrchService creditCardAccountSummaryOrchService;

    @Mock
    private CreditCardAccountSummaryDaoImpl creditCardAccountSummaryDaoImpl;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    private static final int ACCOUNT_LIMIT = 50;

    @Test
    public void testExecute() throws InterruptedException, ExecutionException {
        // Future<List<CustomerAccountsResponse>> response1;
        Future<REASResponse> response;
        REASResponse reasResponse = new REASResponse();
        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345678912");
        key.setSorId((short) 7);
        CustomerAccountKey key1 = new CustomerAccountKey();
        key.setAccountNumber("12345678913");
        key.setSorId((short) 7);
        // customerAccountKeyList.add(key);
        customerAccountKeyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("V3");
        String appVersion="V3";
        String appversionSwitch="V4";
        customerAccountsRequest.setEnableappVersionV4("V4");
        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("15");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);
        List<String> cachedVersion = new ArrayList<String>();
        cachedVersion.add("V5");
        
        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);       
        customerAccountsRequest.setCcOnlineCachedConfig(cachedVersion);
        List<CustomerAccountsResponse> customerAccountsResponses = new ArrayList<CustomerAccountsResponse>();
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("7");
        customerAccountsResponse.setAccountId("12345678912");
        customerAccountsResponse.setAvailableBalance(new BigDecimal("1200"));
        customerAccountsResponse.setBusinessLine("Cards");
        customerAccountsResponses.add(customerAccountsResponse);

        reasResponse.setCustomerAccountsResponseList(customerAccountsResponses);

        EPFContext context = EPFContextContainer.getContext();
        Mockito.when(creditCardAccountSummaryDaoImpl.retrieveCreditCardAccountSummary(context, customerAccountKeyList,appVersion,appversionSwitch))
                .thenReturn(new AsyncResult<REASResponse>(reasResponse));

        Object keyList = key1;
        List<Object> key1ObjectList = new ArrayList<Object>();
        key1ObjectList.add(keyList);
        List<List<Object>> splitAccountKeyList = new ArrayList<List<Object>>();
        splitAccountKeyList.add(key1ObjectList);
        List<Object> list = new ArrayList<Object>();
        list.add(key1);
        List<List<Object>> value = new ArrayList<List<Object>>();
        value.add(list);
        Mockito.when(customerAccountsUtil.split(list, ACCOUNT_LIMIT)).thenReturn(splitAccountKeyList);

        Mockito.when(customerAccountsUtil.findSORID(customerAccountsRequest, (short) 7)).thenReturn(true);

        response = creditCardAccountSummaryOrchService.execute(customerAccountsRequest, context);
        assertNotNull(response);
    }

    @Test
    public void testExecute_FailCase() throws InterruptedException, ExecutionException {
        EPFContext context = EPFContextContainer.getContext();
        Future<REASResponse> response;
        response = creditCardAccountSummaryOrchService.execute(null, context);
        assertNotNull(response);
    }

    @Test
    public void testExecute_FailCase1() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("v4");

        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();

        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        EPFContext context = EPFContextContainer.getContext();
        Future<REASResponse> response;
        response = creditCardAccountSummaryOrchService.execute(customerAccountsRequest, context);
        assertNotNull(response);

    }

    @Test
    public void testExecute_FailCase2() throws InterruptedException, ExecutionException {

        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("v4");

        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("7");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        EPFContext context = EPFContextContainer.getContext();
        Future<REASResponse> response;
        response = creditCardAccountSummaryOrchService.execute(customerAccountsRequest, context);
        assertNotNull(response);

    }

    @Test
    public void testExecute_FailCase3() throws InterruptedException, ExecutionException {

        Future<REASResponse> response;

        List<CustomerAccountKey> customerAccountKeyList = new ArrayList<CustomerAccountKey>();
        CustomerAccountKey key = new CustomerAccountKey();
        key.setAccountNumber("12345678912");
        key.setSorId((short) 2);

        customerAccountKeyList.add(key);
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setAppVersion("v4");

        customerAccountsRequest.setEnableModifiedOrchestrationSwitch(true);
        List<String> reasSupportedSORID = new ArrayList<String>();
        reasSupportedSORID.add("15");
        customerAccountsRequest.setReasSupportedSORID(reasSupportedSORID);

        customerAccountsRequest.setCustomerAccountKeyList(customerAccountKeyList);

        EPFContext context = EPFContextContainer.getContext();

        response = creditCardAccountSummaryOrchService.execute(customerAccountsRequest, context);
        assertNotNull(response);
    }

}
