package com.capitalone.api.customersaccounts.service.convert.response;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.joda.time.Instant;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.mockpolicies.Slf4jMockPolicy;
import org.powermock.core.classloader.annotations.MockPolicy;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.loans.homeloans.accounts.model.v3.Account;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
@MockPolicy(Slf4jMockPolicy.class)
public class HomeloanAPIResponseConverterTest {

    @InjectMocks
    private HomeloanAPIResponseConverter homeloanAPIResponseConverter;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @Test
    public void testConvert() {
        Account account = new Account();
        account.setProductName("ProductName");
        account.setProductTypeCode("ProductTypeCode");
        account.setAvailableCreditLimit(new BigDecimal(1234));
        account.setNextPaymentDueDate(new Instant(20150624));
        account.setPrincipalBalance(new BigDecimal(1200));
        account.setDisplayAccountNumber("12345");
        account.setReoStatusCode("0");
        account.setPaidInFullDate(new Instant(20150624));
        account.setPaidInFullStopCode("0");
        account.setBankruptcyStatusCode("A");
        account.setChapter7DischargeStatusCode("Y");
        account.setDelinquencyStatusCode("RG");
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription((Mockito.anyString()))).thenReturn(
                "ProductTypeDescription");
        Mockito.when(customerAccountsRefDataBean.getBusinessLine("ProductTypeCode", Constants.HOME_LOAN_SORID))
                .thenReturn("BusinessLine");
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(account);
        assertThat(response.getProductName(), equalTo("ProductName"));
        assertThat(response.getProductTypeCode(), equalTo("ProductTypeCode"));
        assertThat(response.getAvailableBalance(), equalTo(new BigDecimal(1234)));
        assertThat(response.getPaymentDueDate(), equalTo(new Instant(20150624)));
        assertThat(response.getProductTypeDescription(), equalTo("ProductTypeDescription"));
        assertThat(response.getBusinessLine(), equalTo("BusinessLine"));
        assertThat(response.getCurrentPrincipal(), equalTo(new BigDecimal(1200)));
    }

    @Test
    public void testConvert1() {
        Account account = new Account();
        account.setProductName("ProductName");
        account.setProductTypeCode("ProductTypeCode");
        account.setAvailableCreditLimit(new BigDecimal(1234));
        account.setNextPaymentDueDate(new Instant(20150624));
        account.setPrincipalBalance(new BigDecimal(1200));
        account.setDisplayAccountNumber("12345");
        account.setReoStatusCode("0");
        account.setReoSetUpDate(new Instant(20150624));
        // account.setPaidInFullDate(new Instant(20150624));
        account.setPaidInFullStopCode("0");
        account.setBankruptcyStatusCode("A");
        account.setChapter7DischargeStatusCode("Y");
        account.setDelinquencyStatusCode("RG");
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription((Mockito.anyString()))).thenReturn(
                "ProductTypeDescription");
        Mockito.when(customerAccountsRefDataBean.getBusinessLine("ProductTypeCode", Constants.HOME_LOAN_SORID))
                .thenReturn("BusinessLine");
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(account);
        assertThat(response.getProductName(), equalTo("ProductName"));
        assertThat(response.getProductTypeCode(), equalTo("ProductTypeCode"));
        assertThat(response.getAvailableBalance(), equalTo(new BigDecimal(1234)));
        assertThat(response.getPaymentDueDate(), equalTo(new Instant(20150624)));
        assertThat(response.getProductTypeDescription(), equalTo("ProductTypeDescription"));
        assertThat(response.getBusinessLine(), equalTo("BusinessLine"));
        assertThat(response.getCurrentPrincipal(), equalTo(new BigDecimal(1200)));
    }

    @Test
    public void testConvert2() {
        Account account = new Account();
        account.setProductName("ProductName");
        account.setProductTypeCode("ProductTypeCode");
        account.setAvailableCreditLimit(new BigDecimal(1234));
        account.setNextPaymentDueDate(new Instant(20150624));
        account.setPrincipalBalance(new BigDecimal(1200));
        account.setDisplayAccountNumber("12345");
        account.setReoStatusCode("0");
        // account.setPaidInFullDate(new Instant(20150624));
        account.setPaidInFullStopCode("0");
        account.setServicingSoldDate(new Instant(20150624));
        account.setBankruptcyStatusCode("A");
        account.setChapter7DischargeStatusCode("Y");
        account.setDelinquencyStatusCode("RG");
        Mockito.when(customerAccountsRefDataBean.getProductTypeDescription((Mockito.anyString()))).thenReturn(
                "ProductTypeDescription");
        Mockito.when(customerAccountsRefDataBean.getBusinessLine("ProductTypeCode", Constants.HOME_LOAN_SORID))
                .thenReturn("BusinessLine");
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(account);
        assertThat(response.getProductName(), equalTo("ProductName"));
        assertThat(response.getProductTypeCode(), equalTo("ProductTypeCode"));
        assertThat(response.getAvailableBalance(), equalTo(new BigDecimal(1234)));
        assertThat(response.getPaymentDueDate(), equalTo(new Instant(20150624)));
        assertThat(response.getProductTypeDescription(), equalTo("ProductTypeDescription"));
        assertThat(response.getBusinessLine(), equalTo("BusinessLine"));
        assertThat(response.getCurrentPrincipal(), equalTo(new BigDecimal(1200)));
    }

    @Test
    public void testConvert_NullResponse() {
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(null);
        assertNotNull(response);
    }

    @Test
    public void testConvert_EmptyResponse() {
        Account account = new Account();
        account.setReoStatusCode("");
        account.setPaidInFullStopCode("");

        account.setProductName(null);
        account.setProductTypeCode(null);
        account.setAvailableCreditLimit(new BigDecimal("0"));
        account.setNextPaymentDueDate(new Instant());
        account.setPrincipalBalance(new BigDecimal("0"));
        account.setDisplayAccountNumber(null);
        account.setNextPaymentDueDate(null);

        account.setBankruptcyStatusCode("B");
        account.setChapter7DischargeStatusCode("N");
        account.setDelinquencyStatusCode("");
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(account);
        assertNotNull(response);
    }

    @Test
    public void testConvert_AcctStatusOpen() {
        Account account = new Account();
        account.setReoStatusCode(null);
        account.setPaidInFullStopCode("0");

        account.setProductName(null);
        account.setProductTypeCode(null);
        account.setAvailableCreditLimit(new BigDecimal("0"));
        account.setNextPaymentDueDate(new Instant());
        account.setPrincipalBalance(new BigDecimal("0"));
        account.setDisplayAccountNumber(null);
        account.setNextPaymentDueDate(null);

        account.setBankruptcyStatusCode("B");
        account.setChapter7DischargeStatusCode("N");
        account.setDelinquencyStatusCode("");
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(account);
        assertNotNull(response);
    }

    @Test
    public void testConvert_AcctStatusBankruptcy() {
        Account account = new Account();
        account.setReoStatusCode(null);
        account.setPaidInFullStopCode("0");

        account.setProductName(null);
        account.setProductTypeCode(null);
        account.setAvailableCreditLimit(new BigDecimal("0"));
        account.setNextPaymentDueDate(new Instant());
        account.setPrincipalBalance(new BigDecimal("0"));
        account.setDisplayAccountNumber(null);
        account.setNextPaymentDueDate(null);

        account.setBankruptcyStatusCode("A");
        account.setChapter7DischargeStatusCode("N");
        account.setDelinquencyStatusCode("");
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(account);
        assertNotNull(response);
    }

    @Test
    public void testConvert_Chapter7DischargeStatusCode() {
        Account account = new Account();
        account.setReoStatusCode(null);
        account.setPaidInFullStopCode("0");

        account.setProductName(null);
        account.setProductTypeCode(null);
        account.setAvailableCreditLimit(new BigDecimal("0"));
        account.setNextPaymentDueDate(new Instant());
        account.setPrincipalBalance(new BigDecimal("0"));
        account.setDisplayAccountNumber(null);
        account.setNextPaymentDueDate(null);

        account.setBankruptcyStatusCode("B");
        account.setChapter7DischargeStatusCode("Y");
        account.setDelinquencyStatusCode("");
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(account);
        assertNotNull(response);
    }

    @Test
    public void testConvert_DelinquencyStatusCode() {
        Account account = new Account();
        account.setReoStatusCode(null);
        account.setPaidInFullStopCode("0");

        account.setProductName(null);
        account.setProductTypeCode(null);
        account.setAvailableCreditLimit(new BigDecimal("0"));
        account.setPrincipalBalance(new BigDecimal("0"));
        account.setDisplayAccountNumber(null);
        account.setNextPaymentDueDate(null);
        account.setAccountOpenDate(new Instant());
        account.setBorrowerType("borrower");
        account.setBankruptcyStatusCode("B");
        account.setChapter7DischargeStatusCode("N");
        account.setDelinquencyStatusCode("RG");
        account.setPaidInFullDate(new Instant());
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(account);
        assertNotNull(response);
    }

    @Test
    public void testConvert_settingNullResponse() {
        Account account = new Account();
        account.setReoStatusCode(null);
        account.setPaidInFullStopCode("0");

        account.setProductName(null);
        account.setProductTypeCode(null);
        // account.setAvailableCreditLimit(new BigDecimal());

        // account.setPrincipalBalance(new BigDecimal("0"));
        account.setDisplayAccountNumber(null);
        account.setNextPaymentDueDate(null);
        account.setAccountOpenDate(null);
        account.setBankruptcyStatusCode("B");
        account.setChapter7DischargeStatusCode("N");
        account.setDelinquencyStatusCode("RG");
        account.setReoSetUpDate(new Instant());
        CustomerAccountsResponse response = homeloanAPIResponseConverter.convert(account);
        assertNotNull(response);
    }

}
