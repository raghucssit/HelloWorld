package com.capitalone.api.customersaccounts.dao.impl;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountKey;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsResponse;
import com.capitalone.api.customersaccounts.service.pojo.OLBAttributes;
import com.capitalone.api.customersaccounts.service.pojo.REASResponse;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.xesddais.v1.AcctInqISRq;
import com.capitalone.xesddais.v1.AcctInqISRs;
import com.capitalone.xesddais.v1.AcctInqISRs.Cmd;
import com.capitalone.xesddais.v1.AcctInqISRs.Cmd.DemandDepositAcctInfo;
import com.capitalone.xesddais.v1.XESDDAISSoap;
import com.capitalone.xmlmsgset._2004._07.eil.SevrtyType;
import com.capitalone.xmlmsgset._2004._07.eil.StatType;

@RunWith(MockitoJUnitRunner.class)
public class XESDDAISDAOImplTest {

    @Mock
    private XESDDAISSoap xesddaisSoap;

    @Mock
    private ConversionService conversionService;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @InjectMocks
    private XESDDAISDAOImpl xesddaisdaoImpl;

    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Test
    public void testGetIMAccountDetails() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setCustomerAccountKeyList(new ArrayList<CustomerAccountKey>());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("16"));
        customerAccountsRequest.getCustomerAccountKeyList().add(customerAccountKey);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(new Cmd());
        acctInqISRs.getCmd().setDemandDepositAcctInfo(new DemandDepositAcctInfo());
        acctInqISRs.getCmd().getDemandDepositAcctInfo().setBankAcctTypeCd("111");
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("16");
        Map<String, Map<String, OLBAttributes>> mapProdDesc = new HashMap<String, Map<String, OLBAttributes>>();
        Mockito.when(xesddaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getDemandDepositAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = xesddaisdaoImpl.getIMAccountDetails(context, customerAccountKey, mapProdDesc);
        assertThat(result.get().getCustomerAccountsResponseList().get(0).getSorId(), equalTo("16"));
    }

    @Test
    public void testGetIMAccountDetails_FailCase() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setCustomerAccountKeyList(new ArrayList<CustomerAccountKey>());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("16"));
        customerAccountKey.setAccountNumber("12345");
        customerAccountsRequest.getCustomerAccountKeyList().add(customerAccountKey);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(new Cmd());
        acctInqISRs.getCmd().setDemandDepositAcctInfo(new DemandDepositAcctInfo());
        acctInqISRs.getCmd().getDemandDepositAcctInfo().setBankAcctTypeCd("111");
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("16");
        NullPointerException e = new NullPointerException();
        Mockito.when(xesddaisSoap.acctInq(acctInqISRq)).thenThrow(e);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getDemandDepositAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);

        Future<REASResponse> result = xesddaisdaoImpl.getIMAccountDetails(context, customerAccountKey, null);
        assertNotNull(result);

    }

    @Test
    public void testGetIMAccountDetails_SetStat() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setCustomerAccountKeyList(new ArrayList<CustomerAccountKey>());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("16"));
        customerAccountsRequest.getCustomerAccountKeyList().add(customerAccountKey);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(new Cmd());
        acctInqISRs.getCmd().setDemandDepositAcctInfo(new DemandDepositAcctInfo());
        acctInqISRs.getCmd().getDemandDepositAcctInfo().setBankAcctTypeCd("111");
        StatType stat = new StatType();

        stat.setSevrty(SevrtyType.ERROR);
        stat.setSrvrStatCd("TP2006");
        stat.setStatCd(0);
        acctInqISRs.getCmd().setStat(stat);
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("16");
        Map<String, Map<String, OLBAttributes>> mapProdDesc = new HashMap<String, Map<String, OLBAttributes>>();
        Mockito.when(xesddaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getDemandDepositAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = xesddaisdaoImpl.getIMAccountDetails(context, customerAccountKey, mapProdDesc);
        assertThat(result.get().getCustomerAccountsResponseList().get(0).getSorId(), equalTo("16"));
    }

    @Test
    public void testGetIMAccountDetails_SetStat1() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setCustomerAccountKeyList(new ArrayList<CustomerAccountKey>());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("16"));
        customerAccountsRequest.getCustomerAccountKeyList().add(customerAccountKey);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(new Cmd());
        acctInqISRs.getCmd().setDemandDepositAcctInfo(new DemandDepositAcctInfo());
        acctInqISRs.getCmd().getDemandDepositAcctInfo().setBankAcctTypeCd("111");
        StatType stat = new StatType();
        Map<String, Map<String, OLBAttributes>> mapProdDesc = new HashMap<String, Map<String, OLBAttributes>>();
        stat.setSevrty(SevrtyType.ERROR);
        stat.setStatCd(100);
        stat.setSrvrStatCd("TP2005");
        acctInqISRs.getCmd().setStat(stat);
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("16");
        Mockito.when(xesddaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getDemandDepositAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = xesddaisdaoImpl.getIMAccountDetails(context, customerAccountKey, mapProdDesc);
        assertThat(result.get().getCustomerAccountsResponseList().get(0).getSorId(), equalTo("16"));
    }

    @Test
    public void testGetIMAccountDetails_SetStat2() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setCustomerAccountKeyList(new ArrayList<CustomerAccountKey>());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("16"));
        customerAccountsRequest.getCustomerAccountKeyList().add(customerAccountKey);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(new Cmd());
        acctInqISRs.getCmd().setDemandDepositAcctInfo(new DemandDepositAcctInfo());
        acctInqISRs.getCmd().getDemandDepositAcctInfo().setBankAcctTypeCd("111");
        StatType stat = new StatType();

        stat.setSevrty(SevrtyType.INFO);
        stat.setSrvrStatCd("TP2006");
        stat.setStatCd(0);
        acctInqISRs.getCmd().setStat(stat);
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("16");
        Map<String, Map<String, OLBAttributes>> mapProdDesc = new HashMap<String, Map<String, OLBAttributes>>();
        Mockito.when(xesddaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getDemandDepositAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = xesddaisdaoImpl.getIMAccountDetails(context, customerAccountKey, mapProdDesc);
        assertThat(result.get().getCustomerAccountsResponseList().get(0).getSorId(), equalTo("16"));
    }
    
    @Test
    public void testGetIMAccountDetails_NotNullMap() throws InterruptedException, ExecutionException {
        EPFContext context = new EPFContext();
        CustomerAccountsRequest customerAccountsRequest = new CustomerAccountsRequest();
        customerAccountsRequest.setCustomerAccountKeyList(new ArrayList<CustomerAccountKey>());
        CustomerAccountKey customerAccountKey = new CustomerAccountKey();
        customerAccountKey.setSorId(new Short("16"));
        customerAccountsRequest.getCustomerAccountKeyList().add(customerAccountKey);
        AcctInqISRq acctInqISRq = new AcctInqISRq();
        Mockito.when(conversionService.convert(customerAccountKey, AcctInqISRq.class)).thenReturn(acctInqISRq);
        AcctInqISRs acctInqISRs = new AcctInqISRs();
        acctInqISRs.setCmd(new Cmd());
        acctInqISRs.getCmd().setDemandDepositAcctInfo(new DemandDepositAcctInfo());
        acctInqISRs.getCmd().getDemandDepositAcctInfo().setBankAcctTypeCd("111");
        acctInqISRs.getCmd().getDemandDepositAcctInfo().setProdID("prod_id");
        acctInqISRs.getCmd().getDemandDepositAcctInfo().setIntrnlRtgNum("");
        CustomerAccountsResponse customerAccountsResponse = new CustomerAccountsResponse();
        customerAccountsResponse.setSorId("16");
        Map<String, Map<String, OLBAttributes>> mapProdDesc = new HashMap<String, Map<String, OLBAttributes>>();
        Map<String, OLBAttributes> arg1 = new HashMap<String, OLBAttributes>();
        OLBAttributes arg2 = new OLBAttributes();
        arg2.setProdNm("1");
        arg2.setProdNm("prodname");
        arg1.put("map2", arg2 );
        mapProdDesc.put("map", arg1 );
        Mockito.when(xesddaisSoap.acctInq(acctInqISRq)).thenReturn(acctInqISRs);
        Mockito.when(
                customerAccountsRefDataBean.getProductTypeCode(Short.valueOf(customerAccountsResponse.getSorId()),
                        acctInqISRs.getCmd().getDemandDepositAcctInfo().getBankAcctTypeCd())).thenReturn("123");

        Mockito.when(conversionService.convert(acctInqISRs, CustomerAccountsResponse.class)).thenReturn(
                customerAccountsResponse);
        Future<REASResponse> result = xesddaisdaoImpl.getIMAccountDetails(context, customerAccountKey, mapProdDesc);
        assertThat(result.get().getCustomerAccountsResponseList().get(0).getSorId(), equalTo("16"));
    }

}
