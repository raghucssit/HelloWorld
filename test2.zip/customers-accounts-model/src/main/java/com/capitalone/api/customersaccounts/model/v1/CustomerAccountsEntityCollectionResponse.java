/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.model.v1;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.capitalone.api.commons.model.AbstractEntityCollectionResponse;
import com.capitalone.api.commons.model.EntityCollectionRequest;
import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModelProperty;

/**
 * Example model entity collection response object.
 * 
 * Write your own model objects.
 * 
 * @author Generated
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({CustomerAccount.class})
public class CustomerAccountsEntityCollectionResponse extends AbstractEntityCollectionResponse<CustomerAccount>
        implements Serializable {

    private static final long serialVersionUID = -8312285033981457843L;
    
    @Audited
	@ApiModelProperty(value = "This block contains the error details in case of a partial success (not a complete failure).")
    private CustomerApiErrorCode errorResponse;

    public CustomerAccountsEntityCollectionResponse() {
        super();
    }

    public CustomerAccountsEntityCollectionResponse(EntityCollectionRequest request, List<CustomerAccount> entries) {
        super(request, entries);
    }
    
    @ApiModelProperty(value = "This array contains the list of accounts.")
    @XmlElement(name = "entries")
    @Override
    public List<CustomerAccount> getPagedEntries(){
    	return super.getPagedEntries();
    }
    /**
     * @return the errorResponse
     */
    public CustomerApiErrorCode getErrorResponse() {
        return errorResponse;
    }

    /**
     * @param errorResponse the errorResponse to set
     */
    public void setErrorResponse(CustomerApiErrorCode errorResponse) {
        this.errorResponse = errorResponse;
    }
    
    
    
}