package com.capitalone.api.customersaccounts.model.v1;
import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.capitalone.api.customersaccounts.model.v1.AccountApplicantKey;
import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@Audited
@ApiModel(value = "Represents a customer's investing accounts model")
@XmlRootElement
@XmlType(propOrder = { "accountApplicantKey" })
@XmlAccessorType(XmlAccessType.FIELD)
public class AccountApplicants implements Serializable{
    
    /**
     * Default serialVersionUID.
     */
    private static final long serialVersionUID = -4527086105190036590L;
    
    @ApiModelProperty(value = "Represents a collection of AccountApplicantKey")
    private List<AccountApplicantKey> accountApplicantKey;

    public List<AccountApplicantKey> getAccountApplicantKey() {
        return accountApplicantKey;
    }

    public void setAccountApplicantKey(List<AccountApplicantKey> accountApplicantKey) {
        this.accountApplicantKey = accountApplicantKey;
    }

    /*@Override
    public String toString() {
        return "AccountApplicants [accountApplicantKey=" + accountApplicantKey + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((accountApplicantKey == null) ? 0 : accountApplicantKey.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AccountApplicants other = (AccountApplicants) obj;
        if (accountApplicantKey == null) {
            if (other.accountApplicantKey != null)
                return false;
        } else if (!accountApplicantKey.equals(other.accountApplicantKey))
            return false;
        return true;
    }
    */
    

}
