package com.capitalone.api.customersaccounts.model.v1;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@Audited
@ApiModel(value = "Represents a customer's account model")
@XmlRootElement
@XmlType(propOrder = { "accountNumber", "sorId", "preferences" }, namespace = "http://api.capitalone.com/v3/EC/")
@XmlAccessorType(XmlAccessType.FIELD)
public class Account implements Serializable {
	/**
	 * Default serialVersionUID.
	 */
	private static final long serialVersionUID = -4527086105190036590L;

	@ApiModelProperty(value = "Customer's account Id")
	private String accountNumber;

	@ApiModelProperty(value = "Unique customer's account source Id")
	private String sorId;

	@ApiModelProperty(value = "Customer's Account preferences")
	private AccountPreferences preferences;

	public String getSorId() {
		return sorId;
	}

	public void setSorId(final String sorId) {
		this.sorId = sorId;
	}

	/**
	 * @return the preferences
	 */
	public AccountPreferences getPreferences() {
		return preferences;
	}

	/**
	 * @param preferences the preferences to set
	 */
	public void setPreferences(final AccountPreferences preferences) {
		this.preferences = preferences;
	}

	/**
	 * @return the accountId
	 */
	public String getAccountId() {
		return accountNumber;
	}

	/**
	 * @param accountId the accountId to set
	 */
	public void setAccountId(final String accountId) {
		this.accountNumber = accountId;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object rhs) {
		return EqualsBuilder.reflectionEquals(this, rhs, false);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
