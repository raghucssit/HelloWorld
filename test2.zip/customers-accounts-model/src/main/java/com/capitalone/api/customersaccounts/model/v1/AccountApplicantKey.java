package com.capitalone.api.customersaccounts.model.v1;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@Audited
@ApiModel(value = "Represents a customer's investing accounts model")
@XmlRootElement
@XmlType(propOrder = { "investorId", "accountNumber" })
@XmlAccessorType(XmlAccessType.FIELD)
public class AccountApplicantKey implements Serializable {
    
    /**
     * Default serialVersionUID.
     */
    private static final long serialVersionUID = -4527086105190036590L;
    
    @ApiModelProperty(value = "Customer's investor Id")
    private long investorId ;
    
    @ApiModelProperty(value = "Customer's account Id")
    private String accountNumber ;

    public long getInvestorId() {
        return investorId;
    }

    public void setInvestorId(long investorId) {
        this.investorId = investorId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }   

}
