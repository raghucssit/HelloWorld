/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

package com.capitalone.api.customersaccounts.model.v1;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.joda.time.Instant;

import com.capitalone.api.annotations.NonPublicInformation;
import com.capitalone.api.commons.annotations.entitlement.AccountKeyIdentifier;
import com.capitalone.api.commons.model.MessagableResponse;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.api.model.link.Link;
import com.capitalone.api.model.product.Product;
import com.capitalone.api.xmladapter.InstantAdapter;
import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlType(name = "customerAccount", propOrder = {"businessLine", "product", "retirementIndicator", "cardFirstSix",
        "accountNumber", "displayAccountNumber", "accountReferenceId", "bankNumber", "bankNumberDescription",
        "accountStatus", "accountNickName", "accountNickname", "openDate", "currencyCode", "customerRole",
        "accountDetailsURL", "currentBalance", "availableBalance", "currentPrincipal", "presentBalance",
        "paymentDueDate", "paymentDueAmount", "marketingReferneceNumber", "accountUseType", "message", "closedDate",
        "validAsOfTimestamp", "isHighAvailabilityEnabled"})
@ApiModel(value = "Represents the customer account details.")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerAccount implements Serializable, MessagableResponse {

    private static final long serialVersionUID = -2605009118976871207L;

    @Audited
    @ApiModelProperty(value = "The special message assigned by the Entitlement engine based on the entitlement rule evaulation for V4")
    private String message;

    @Audited
    @ApiModelProperty(value = "High level product categorization with enumerated list of values defined at the enterprise level and in alignment with the API ontology. e.g.: Deposit, Loan, Credit-Card, Brokerage and Mortgage")
    private String businessLine;

    @ApiModelProperty(value = "This is an alternate identifier for an account generated to share with our marketing partners. It is required primarily to avoid sharing the Capital One's internal Account Identifiers with our partner systems to help them identify an account.")
    private BigDecimal marketingReferneceNumber;

    @Audited
    @ApiModelProperty(value = "Type of account requested. e.g. Checking, Savings, Brokerage, Credit-Card, etc.")
    private Product product;

    @ApiModelProperty(value = "Boolean indicator which indicates if account is of retirement type.")
    private Boolean retirementIndicator;

    @Audited
    @ApiModelProperty(value = "Actual customer recognizable Account Number")
    private String accountNumber;

    @Audited
    @ApiModelProperty(value = "Account number used for display purposes to the customer. Populate displayAccountNumber with accountNumber in case of non-availability of displayAccountNumber from backend. Note:This field will be 17 digits for COAF accounts in V3 only")
    private String displayAccountNumber;

    @Audited
    @NonPublicInformation
    @ApiModelProperty(value = "The unique identifier for the account resource that can be used to locate this resource.")
    @AccountKeyIdentifier
    private ReferenceId accountReferenceId;

    @Audited
    @ApiModelProperty(value = "This field is used to display to Bank Number for e.g. 81. This field is applicable for Deposits and Loans business lines")
    private String bankNumber;

    @Audited
    @ApiModelProperty(value = "This field is used to display the description of the Bank Number. This field is applicable for Deposits and Loans business lines.")
    private String bankNumberDescription;

    @Audited
    @ApiModelProperty(value = "Account Status Description Values include: open, closed, inactive etc.")
    private String accountStatus;

    @ApiModelProperty(value = "A customized name for the account as specified by the account holder, in V3")
    private String accountNickName;

    @ApiModelProperty(value = "A customized name for the account as specified by the account holder, in V4")
    private String accountNickname;

    @ApiModelProperty(value = "Date Account Opened")
    @XmlJavaTypeAdapter(InstantAdapter.class)
    private Instant openDate;

    @Audited
    @ApiModelProperty(value = "Represents the currency to be applied for the monetary values shown for a specific account. These will conform to the standard 3 digit international currency code standard. Default is USD.")
    private String currencyCode;

    @Audited
    @ApiModelProperty(value = "Represents the customer role within the scope of the account. e.g. Primary, Secondary, Authorized Signer, etc.")
    private String customerRole;

    @ApiModelProperty(value = "URL to redirect to account details")
    private Link accountDetailsURL;

    @Audited
    @ApiModelProperty(value = "Account Current Balance. This is the current balance on the account which includes any pending debit/credit transactions. This is ledgerBalance - totalPendingDebits + totalPendingCredits")
    private BigDecimal currentBalance;

    @Audited
    @ApiModelProperty(value = "Account Available Balance. This is the amount of money available to the customer for withdrawal or to pay bills, etc. This balance represents the ledger balance minus any hold/float amounts")
    private BigDecimal availableBalance;

    @Audited
    @ApiModelProperty(value = "The principal balance of the loan.")
    private BigDecimal currentPrincipal;

    @Audited
    @ApiModelProperty(value = "Monetary amount of the account balance")
    private BigDecimal presentBalance;

    @Audited
    @ApiModelProperty(value = "Payment Due date of the account. This field is applicable only for Loans and Credit-Cards business line")
    @XmlJavaTypeAdapter(InstantAdapter.class)
    private Instant paymentDueDate;

    @Audited
    @ApiModelProperty(value = "Payment Amount due for the account. This field is applicable only for Loans and Credit-Cards business line.")
    private BigDecimal paymentDueAmount;

    @ApiModelProperty(value = "First six digits of credit card.")
    private String cardFirstSix;

    @Audited
    @ApiModelProperty(value = "Defines if the account is for Personal, Business, or expense use")
    private String accountUseType;
    
    @Audited
    @ApiModelProperty(value = "This is the date when the account was closed. The value is populated only if the account is in closed status.")
    @XmlJavaTypeAdapter(InstantAdapter.class)
    private Instant closedDate;

    @Audited
    @ApiModelProperty(value = "Timestamp when a particular set of data being passed by RTM was loaded in in the backend.")
    @XmlJavaTypeAdapter(InstantAdapter.class)
    private Instant validAsOfTimestamp;

    @Audited
    @ApiModelProperty(value = "True � High availability mode is ON, which means the card data displayed are from the alternate source (ODS).False � High availability mode is OFF, which means the card data displayed are from the primary source (TSYS) .")
    private Boolean isHighAvailabilityEnabled;
    
    @Audited
    @ApiModelProperty(value = "Version of the API called by the client V3/V4/V5")
    @XmlTransient
    private String version;

	public String getBusinessLine() {
        return businessLine;
    }

    public void setBusinessLine(String value) {
        this.businessLine = value;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Boolean getRetirementIndicator() {
        return retirementIndicator;
    }

    public void setRetirementIndicator(Boolean retirementIndicator) {
        this.retirementIndicator = retirementIndicator;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String value) {
        this.accountNumber = value;
    }

    public String getDisplayAccountNumber() {
        return displayAccountNumber;
    }

    public void setDisplayAccountNumber(String value) {
        this.displayAccountNumber = value;
    }

    public ReferenceId getAccountReferenceId() {
        return accountReferenceId;
    }

    public void setAccountReferenceId(ReferenceId accountReferenceId) {
        this.accountReferenceId = accountReferenceId;
    }

    public String getBankNumber() {
        return bankNumber;
    }

    public void setBankNumber(String value) {
        this.bankNumber = value;
    }

    public String getBankNumberDescription() {
        return bankNumberDescription;
    }

    public void setBankNumberDescription(String value) {
        this.bankNumberDescription = value;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String value) {
        this.accountStatus = value;
    }

    public String getAccountNickName() {
        return accountNickName;
    }

    public void setAccountNickName(String value) {
        this.accountNickName = value;
    }

    public String getAccountNickname() {
        return accountNickname;
    }

    public void setAccountNickname(String accountNickname) {
        this.accountNickname = accountNickname;
    }

    public Instant getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Instant value) {
        this.openDate = value;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    public String getCustomerRole() {
        return customerRole;
    }

    public void setCustomerRole(String value) {
        this.customerRole = value;
    }

    public Link getAccountDetailsURL() {
        return accountDetailsURL;
    }

    public void setAccountDetailsURL(Link value) {
        this.accountDetailsURL = value;
    }

    public BigDecimal getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(BigDecimal value) {
        this.currentBalance = value;
    }

    public BigDecimal getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(BigDecimal value) {
        this.availableBalance = value;
    }

    public BigDecimal getCurrentPrincipal() {
        return currentPrincipal;
    }

    public void setCurrentPrincipal(BigDecimal value) {
        this.currentPrincipal = value;
    }

    public BigDecimal getPresentBalance() {
        return presentBalance;
    }

    public void setPresentBalance(BigDecimal value) {
        this.presentBalance = value;
    }

    public Instant getPaymentDueDate() {
        return paymentDueDate;
    }

    public void setPaymentDueDate(Instant value) {
        this.paymentDueDate = value;
    }

    public BigDecimal getPaymentDueAmount() {
        return paymentDueAmount;
    }

    public void setPaymentDueAmount(BigDecimal value) {
        this.paymentDueAmount = value;
    }

    public String getCardFirstSix() {
        return cardFirstSix;
    }

    public void setCardFirstSix(String cardFirstSix) {
        this.cardFirstSix = cardFirstSix;
    }

    public BigDecimal getMarketingReferneceNumber() {
        return marketingReferneceNumber;
    }

    public void setMarketingReferneceNumber(BigDecimal marketingReferneceNumber) {
        this.marketingReferneceNumber = marketingReferneceNumber;
    }

    public String getAccountUseType() {
        return accountUseType;
    }

    public void setAccountUseType(String accountUseType) {
        this.accountUseType = accountUseType;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this, false);
    }

    @Override
    public boolean equals(Object rhs) {
        return EqualsBuilder.reflectionEquals(this, rhs, false);
    }

    @Override
    public void addMessage(String message) {
        // TODO Auto-generated method stub
        this.message = message;

    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public Instant getClosedDate() {
        return closedDate;
    }

    public void setClosedDate(Instant value) {
        this.closedDate = value;
    }

    public Instant getValidAsOfTimestamp() {
        return validAsOfTimestamp;
    }

    public void setValidAsOfTimestamp(Instant validAsOfTimestamp) {
        this.validAsOfTimestamp = validAsOfTimestamp;
    }

    public Boolean getIsHighAvailabilityEnabled() {
        return isHighAvailabilityEnabled;
    }
    
    public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

    public void setIsHighAvailabilityEnabled(Boolean isHighAvailabilityEnabled) {
        this.isHighAvailabilityEnabled = isHighAvailabilityEnabled;
    }


}