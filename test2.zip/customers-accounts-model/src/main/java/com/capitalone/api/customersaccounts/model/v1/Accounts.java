package com.capitalone.api.customersaccounts.model.v1;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@Audited
@ApiModel(value = "Represents a customer's accounts model")
@XmlRootElement
@XmlType(propOrder = { "accounts" }, namespace = "http://api.capitalone.com/v3/EC/")
@XmlAccessorType(XmlAccessType.FIELD)
public class Accounts implements Serializable {
	/**
	 * Default serialVersionUID.
	 */
	private static final long serialVersionUID = -4527086105190036590L;
    

	@ApiModelProperty(value = "Represents a collection of customer accounts")
	private List<Account> accounts;

	/**
	 * @return the accounts
	 */
	public List<Account> getAccounts() {
		return accounts;
	}

	/**
	 * @param accounts
	 *            the accounts to set
	 */
	public void setAccounts(final List<Account> accounts) {
		this.accounts = accounts;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object rhs) {
		return EqualsBuilder.reflectionEquals(this, rhs, false);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
