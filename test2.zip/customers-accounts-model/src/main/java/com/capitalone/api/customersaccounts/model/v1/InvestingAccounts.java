package com.capitalone.api.customersaccounts.model.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "account"
})
@XmlRootElement(name = "Account")
public class InvestingAccounts implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 7160109599377934216L;

    @ApiModelProperty(value = "Represents a collection of investing accounts")
    private List<GetAccountResponse> account;

	public List<GetAccountResponse> getAccount() {
		if (account == null) {
			account = new ArrayList<GetAccountResponse>();
		}
		return this.account;
	}

	public void setAccount(List<GetAccountResponse> account) {
		this.account = account;
	}

    

}
