package com.capitalone.api.customersaccounts.model.v1;

import java.util.List;

import com.capitalone.api.commons.exception.ApiErrorCode;

public class CustomerApiErrorCode extends ApiErrorCode {
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    
    private String text;
    
	public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public CustomerApiErrorCode() {
        // TODO Auto-generated constructor stub
        super();
    }

    public CustomerApiErrorCode(String id) {
        super(id);
        // TODO Auto-generated constructor stub
    }

    public CustomerApiErrorCode(String id, String messagePropertyKey) {
        super(id, messagePropertyKey);
        // TODO Auto-generated constructor stub
    }

    public CustomerApiErrorCode(String id, List<String> messageParms) {
        super(id, messageParms);
        // TODO Auto-generated constructor stub
    }

    public CustomerApiErrorCode(String id, String messagePropertyKey, String developerTextId) {
        super(id, messagePropertyKey, developerTextId);
        // TODO Auto-generated constructor stub
    }

    public CustomerApiErrorCode(String id, List<String> messageParms, String messagePropertyKey) {
        super(id, messageParms, messagePropertyKey);
        // TODO Auto-generated constructor stub
    }

    public CustomerApiErrorCode(String id, List<String> messageParms, List<ApiErrorCode> errorDetails) {
        super(id, messageParms, errorDetails);
        // TODO Auto-generated constructor stub
    }
    
    @Override
    public String toString() {
        return text;
    }

}


/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of
 * Capital One and is protected by law. It may not be copied or distributed in
 * any form or medium, disclosed to third parties, reverse engineered or used in
 * any manner without prior written authorization from Capital One.
 */
