package com.capitalone.api.customersaccounts.model.v1;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@Audited
@ApiModel(value = "Represents a customer's account preferences model")
@XmlRootElement
@XmlType(propOrder = { "accountNickname" }, namespace = "http://api.capitalone.com/v3/EC/")
@XmlAccessorType(XmlAccessType.FIELD)
public class AccountPreferences implements Serializable {
	/**
	 * Default serialVersionUID.
	 */
	private static final long serialVersionUID = -4527086105190036590L;

	@ApiModelProperty(value = "This is nick name for a customer's account")
	private String accountNickname;

	/**
	 * @return the accountNickname
	 */
	public String getAccountNickname() {
		return accountNickname;
	}

	/**
	 * @param accountNickname the accountNickname to set
	 */
	public void setAccountNickname(final String accountNickname) {
		this.accountNickname = accountNickname;
	}
	
	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object rhs) {
		return EqualsBuilder.reflectionEquals(this, rhs, false);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
