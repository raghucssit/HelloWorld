package com.capitalone.api.customersaccounts.model.v1;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.joda.time.Instant;

import com.capitalone.api.xmladapter.InstantAdapter;
import com.wordnik.swagger.annotations.ApiModelProperty;

@XmlType(name = "getAccountResponse", propOrder = {"investorId", "accountNumber", "accountType", "accountNickname",
        "totalAccountValue", "availableBalance", "lastUpdateDate", "businessLine", "openDate", "accountDetailsUrl",
        "productName", "customerRole", "entitled", "error"})
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class GetAccountResponse implements Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = -8030325973966355306L;

    @ApiModelProperty(value = "This field contains the investor ID")
    private long investorId;

    @ApiModelProperty(value = "This field contains the Account ID")
    private String accountNumber;

    @ApiModelProperty(value = "Actual customer recognizable Account Number")
    private String accountType;

    @ApiModelProperty(value = "A customized name for the account as specified by the account holder")
    private String accountNickname;

    @ApiModelProperty(value = "This field contains the total account value. ")
    private BigDecimal totalAccountValue;

    @ApiModelProperty(value = "Account Available Balance. ")
    private BigDecimal availableBalance;

    @ApiModelProperty(value = "Last update date. ")
    @XmlJavaTypeAdapter(InstantAdapter.class)
    private Instant lastUpdateDate;

    @ApiModelProperty(value = "Business Line. ")
    private String businessLine;

    @ApiModelProperty(value = "Date Account Opened")
    @XmlJavaTypeAdapter(InstantAdapter.class)
    private Instant openDate;

    @ApiModelProperty(value = "Account Details URL. ")
    private String accountDetailsUrl;

    @ApiModelProperty(value = "Product Name. ")
    private String productName;

    @ApiModelProperty(value = "Customer Role. ")
    private CustomerRole customerRole;
    
    @ApiModelProperty(value = "Entitled. ")
    private Boolean entitled;
    
    @ApiModelProperty(value = "Error. ")
    private String error;

    public long getInvestorId() {
        return investorId;
    }

    public void setInvestorId(long investorId) {
        this.investorId = investorId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountNickname() {
        return accountNickname;
    }

    public void setAccountNickname(String accountNickname) {
        this.accountNickname = accountNickname;
    }

    public BigDecimal getTotalAccountValue() {
        return totalAccountValue;
    }

    public void setTotalAccountValue(BigDecimal totalAccountValue) {
        this.totalAccountValue = totalAccountValue;
    }

    public BigDecimal getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(BigDecimal availableBalance) {
        this.availableBalance = availableBalance;
    }

    public Instant getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Instant lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getBusinessLine() {
        return businessLine;
    }

    public void setBusinessLine(String businessLine) {
        this.businessLine = businessLine;
    }


    public String getAccountDetailsUrl() {
        return accountDetailsUrl;
    }

    public void setAccountDetailsUrl(String accountDetailsUrl) {
        this.accountDetailsUrl = accountDetailsUrl;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public CustomerRole getCustomerRole() {
        return customerRole;
    }

    public void setCustomerRole(CustomerRole customerRole) {
        this.customerRole = customerRole;
    }

    public Boolean getEntitled() {
        return entitled;
    }

    public void setEntitled(Boolean entitled) {
        this.entitled = entitled;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public Instant getOpenDate() {
        return openDate;
    }

    public void setOpenDate(Instant openDate) {
        this.openDate = openDate;
    }

}
