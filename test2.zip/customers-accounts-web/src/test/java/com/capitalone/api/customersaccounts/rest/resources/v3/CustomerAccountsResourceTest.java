package com.capitalone.api.customersaccounts.rest.resources.v3;

import static org.mockito.Mockito.when;

import javax.ws.rs.core.UriInfo;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.model.EntityCollectionRequest;
import com.capitalone.api.commons.services.response.ResponseData;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccountsEntityCollectionResponse;
import com.capitalone.api.customersaccounts.rest.resources.v4.auditproxy.CustomerAccountsNewResourceAuditProxy;
import com.capitalone.api.customersaccounts.service.api.CustomerAccountsService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CustomerAccountsResourceTest {

    @InjectMocks
    private CustomerAccountsResource customerAccountsResource;

    @Mock
    private CustomerAccountsNewResourceAuditProxy resource;

    @Mock
    private CustomerAccountsService service;

    @Mock
    private UriInfo uriInfo;

    @Before
    public void setUp() throws Exception {
        // resource = new CustomerAccountsResource();
        // Whitebox.setInternalState(resource, service);
    }

    @Test
    public void testGetMany() {
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        String profilereferenceID = "test";
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);

        ResponseData responseData = new ResponseData();

        when(
                service.fetchAccountsAndRelationShip((EntityCollectionRequest) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject())).thenReturn(
                customerAccountList);
        customerAccountsResource.getMany(uriInfo, request, cardRefId, profilereferenceID, "businessLine",
                "productTypeCode", "V3", responseData);
    }

    @Test
    public void testGetMany1() {
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        String profilereferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);

        ResponseData responseData = new ResponseData();

        when(
                service.fetchAccountsAndRelationShip((EntityCollectionRequest) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject())).thenReturn(
                customerAccountList);
        customerAccountsResource.getMany(uriInfo, request, cardRefId, profilereferenceID, "businessLine",
                "productTypeCode", "V3", responseData);
    }

    @Test
    public void testGetMany_EmptyProfRefID() {
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        String profilereferenceID = "";
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);
        ResponseData responseData = new ResponseData();
        when(
                service.fetchAccountsAndRelationShip((EntityCollectionRequest) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject())).thenReturn(
                customerAccountList);
        customerAccountsResource.getMany(uriInfo, request, cardRefId, profilereferenceID, "businessLine",
                "productTypeCode", "V3", responseData);
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */