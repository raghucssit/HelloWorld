package com.capitalone.api.customersaccounts.rest.filter;

import java.lang.reflect.Method;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ResourceInfo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.capitalone.api.customersaccounts.rest.filter.EntitlementContextFilter.EntitledBy;

@RunWith(PowerMockRunner.class)
@PrepareForTest({Method.class})
public class EntitlementContextFilterTest {   
    
    
    @InjectMocks
    private EntitlementContextFilter entitlementContextFilter;
    
    @Mock
    private ResourceInfo resourceInfo;
    
    @Mock
    private ContainerRequestContext requestContext;
    
    @Mock
    EntitledBy entitledBy ;   
    
    @Test
    public void testFilter() throws Exception{       
        
        //PowerMockito.mockStatic(Method.class);     
        
       // Mockito.when(Method.ge
        
        //Mockito.when(resourceInfo.getResourceMethod()).thenReturn((Method)Mockito.anyObject());
                
        //entitlementContextFilter.filter(requestContext) ; 
        
    }

}
