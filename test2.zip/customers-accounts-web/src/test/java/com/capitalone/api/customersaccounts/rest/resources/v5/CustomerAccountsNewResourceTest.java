package com.capitalone.api.customersaccounts.rest.resources.v5;

import static org.mockito.Mockito.when;

import javax.ws.rs.core.UriInfo;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;

import com.capitalone.api.commons.model.EntityCollectionRequest;
import com.capitalone.api.commons.model.entitlement.EntitlementDecisionResponse;
import com.capitalone.api.commons.services.response.ResponseData;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccountsEntityCollectionResponse;
import com.capitalone.api.customersaccounts.rest.resources.v4.auditproxy.CustomerAccountsNewResourceAuditProxy;
import com.capitalone.api.customersaccounts.service.api.CustomerAccountsService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.ReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class CustomerAccountsNewResourceTest {

    @InjectMocks
    private CustomerAccountsNewResource customerAccountsNewResource;

    @Mock
    private CustomerAccountsNewResourceAuditProxy resource;

    @Mock
    private CustomerAccountsService service;

    @Mock
    private UriInfo uriInfo;
    
    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Before
    public void setUp() throws Exception {
        Whitebox.setInternalState(resource, service);
    }

    @Test
    public void testGetNewMany() {
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();

        String profilereferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);

        ResponseData responseData = new ResponseData();
        when(service.fetchAccountsAndRelationShip((EntityCollectionRequest) Mockito.anyObject(),
                (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject()))
                        .thenReturn(customerAccountList);
        customerAccountsNewResource.getNewMany(uriInfo, request, cardRefId, profilereferenceID, "businessLine",
                "productTypeCode", "V5", responseData);

    }

    @Test
    public void testGetNewMany1() {
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        String profilereferenceID = "test";
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);

        ResponseData responseData = new ResponseData();
        when(service.fetchAccountsAndRelationShip((EntityCollectionRequest) Mockito.anyObject(),
                (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject()))
                        .thenReturn(customerAccountList);
        customerAccountsNewResource.getNewMany(uriInfo, request, cardRefId, profilereferenceID, "businessLine",
                "productTypeCode", "V5", responseData);

    }

    @Test
    public void testGetNewMany2() {
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();

        String profilereferenceID = "";
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);

        ResponseData responseData = new ResponseData();
        when(service.fetchAccountsAndRelationShip((EntityCollectionRequest) Mockito.anyObject(),
                (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject()))
                        .thenReturn(customerAccountList);
        customerAccountsNewResource.getNewMany(uriInfo, request, cardRefId, profilereferenceID, "businessLine",
                "productTypeCode", "V5", responseData);

    }

    @Test
    public void testGetHeader() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setUserId("1234");
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        EntitlementDecisionResponse entitlementDecisionResponse = new EntitlementDecisionResponse();
        entitlementDecisionResponse.setDeveloperText("text");
        customerAccountList.setEntitlementDecisionResponse(entitlementDecisionResponse);
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);
        // ProfileReferenceId profilereferenceID = new ProfileReferenceId("1234");
        String profilereferenceID = "";
        when(service.fetchCustomerRefID((EntityCollectionRequest) Mockito.anyObject(),
                (CustomerAccountsRequest) Mockito.anyObject())).thenReturn(customerAccountList);
        customerAccountsNewResource.getHeader(request, cardRefId, profilereferenceID, "businessLine", "productTypeCode",
                null);

    }

    @Test
    public void testGetHeader1() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setUserId("1234");

        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        EntitlementDecisionResponse entitlementDecisionResponse = new EntitlementDecisionResponse();
        entitlementDecisionResponse.setDeveloperText("text");
        customerAccountList.setEntitlementDecisionResponse(entitlementDecisionResponse);
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);
        // ProfileReferenceId profilereferenceID = null;
        String profilereferenceID = "test";
        when(service.fetchCustomerRefID((EntityCollectionRequest) Mockito.anyObject(),
                (CustomerAccountsRequest) Mockito.anyObject())).thenReturn(customerAccountList);
        customerAccountsNewResource.getHeader(request, cardRefId, profilereferenceID, "", "", null);

    }

    @Test
    public void testGetHeader2() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setUserId("1234");

        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        EntitlementDecisionResponse entitlementDecisionResponse = new EntitlementDecisionResponse();
        entitlementDecisionResponse.setDeveloperText("text");
        customerAccountList.setEntitlementDecisionResponse(entitlementDecisionResponse);
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);
        // ProfileReferenceId profilereferenceID = null;
        String profilereferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        when(service.fetchCustomerRefID((EntityCollectionRequest) Mockito.anyObject(),
                (CustomerAccountsRequest) Mockito.anyObject())).thenReturn(customerAccountList);
        customerAccountsNewResource.getHeader(request, cardRefId, profilereferenceID, "", "", null);

    }

    @Test
    public void testGetHeader_ProfileRefIdNull() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        EPFContext epfContext = new EPFContext();
        EPFContextContainer.getcurrentContext().set(epfContext);
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setUserId("1234");
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        EntitlementDecisionResponse entitlementDecisionResponse = new EntitlementDecisionResponse();
        entitlementDecisionResponse.setDeveloperText("text");
        customerAccountList.setEntitlementDecisionResponse(entitlementDecisionResponse);
        String customerReferenceID = "accountId=123456~~sorId=17~~lastFour=0024~~firstSix=510805";
        ReferenceId cardRefId = ReferenceId.valueOf(customerReferenceID);
        // ProfileReferenceId profilereferenceID = null;
        String profilereferenceID = null;
        when(service.fetchCustomerRefID((EntityCollectionRequest) Mockito.anyObject(),
                (CustomerAccountsRequest) Mockito.anyObject())).thenReturn(customerAccountList);
        customerAccountsNewResource.getHeader(request, cardRefId, profilereferenceID, "businessLine", "productTypeCode",
                null);

    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
