package com.capitalone.api.customersaccounts.rest.filter;

import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.services.message.ApiMessageService;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccountsEntityCollectionResponse;
import com.capitalone.api.customersaccounts.model.v1.CustomerApiErrorCode;

/**
 * Test class for {@link MessageResolverFilter}
 * 
 * @author hnr543 - pmehra
 * @since 1.0
 */
public class MessageResolverFilterTest {

    private MessageResolverFilter messageResolverFilter;

    @Mock
    private ApiMessageService apiMessageService;

    @Mock
    private ContainerRequestContext requestContext;

    @Mock
    private ContainerResponseContext responseContext;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        messageResolverFilter = new MessageResolverFilter(apiMessageService);
    }

    @Test
    public void shouldOnlyProcessCustomerAccountResponseTest() throws Exception {
        when(responseContext.getEntity()).thenReturn(mock(ErrorResponse.class));

        // invocation
        messageResolverFilter.filter(requestContext, responseContext);

        verify(responseContext, times(2)).getEntity();
        Mockito.verifyNoMoreInteractions(responseContext);

    }

    @Test
    public void shouldSkipLogicWhenHttpStatusIsNotOf_2XXX_seriesTest() throws Exception {
        CustomerAccountsEntityCollectionResponse custAccResponse = response();
        when(responseContext.getEntity()).thenReturn(custAccResponse);
        when(responseContext.getStatus()).thenReturn(300);

        messageResolverFilter.filter(requestContext, responseContext);

        verify(responseContext).getStatus();
        verify(responseContext, times(3)).getEntity();

        Mockito.verifyNoMoreInteractions(responseContext, custAccResponse);
    }

    @Test
    public void shouldResolveMessagesWhenHttpStatusOf_2XXX_seriesTest() throws Exception {
        String resolvedMsg_A = "A partial response from Cards Lob";
        String msgId_A = "201101";
        String[] params_A = {"param1", "param2"};

        String resolvedMsg_B = "Unable to access cards service.";
        String msgId_B = "21321";
        String[] params_B = {"param1", "param2"};

        CustomerAccountsEntityCollectionResponse response = response();
        CustomerApiErrorCode customerApiErrorCode_A = customerApiErrorCode(resolvedMsg_A, msgId_A, params_A, false);
        CustomerApiErrorCode customerApiErrorCode_B = customerApiErrorCode(resolvedMsg_B, msgId_B, params_B, false);

        List<ApiErrorCode> customerApiErrorCodes = new ArrayList<ApiErrorCode>();
        customerApiErrorCodes.add(customerApiErrorCode_B);

        when(customerApiErrorCode_A.getErrorDetails()).thenReturn(customerApiErrorCodes);
        when(apiMessageService.getMessage(msgId_A, params_A)).thenReturn(resolvedMsg_A);
        when(apiMessageService.getMessage(msgId_B, params_B)).thenReturn(resolvedMsg_B);
        when(responseContext.getEntity()).thenReturn(response);
        when(responseContext.getStatus()).thenReturn(203);
        when(response.getErrorResponse()).thenReturn(customerApiErrorCode_A);

        // invocation
        messageResolverFilter.filter(requestContext, responseContext);

        verify(responseContext).getStatus();
        verify(responseContext, times(3)).getEntity();
        verify(response).getErrorResponse();
        verifyCustomerApiErrorCode(customerApiErrorCode_A, resolvedMsg_A, false);
        verifyCustomerApiErrorCode(customerApiErrorCode_B, resolvedMsg_B, false);
        verify(customerApiErrorCode_A, times(2)).getErrorDetails();
        verify(apiMessageService).getMessage(msgId_A, params_A);
        verify(apiMessageService).getMessage(msgId_B, params_B);
    }

    @Test
    public void shouldHandleNullOrEmptyMessageIdTest() throws Exception {
        String resolvedMsg_A = "A partial response from Cards Lob";
        String msgId_A = "201101";
        String[] params_A = {"param1", "param2"};

        CustomerAccountsEntityCollectionResponse response = response();
        CustomerApiErrorCode customerApiErrorCode_A = customerApiErrorCode(resolvedMsg_A, msgId_A, params_A, false);

        // inner api error codes are set to null
        when(customerApiErrorCode_A.getErrorDetails()).thenReturn(null);
        when(apiMessageService.getMessage(msgId_A, params_A)).thenReturn(resolvedMsg_A);
        when(responseContext.getEntity()).thenReturn(response);
        when(responseContext.getStatus()).thenReturn(203);
        when(response.getErrorResponse()).thenReturn(customerApiErrorCode_A);

        // invocation
        messageResolverFilter.filter(requestContext, responseContext);

        verify(responseContext).getStatus();
        verify(responseContext, times(3)).getEntity();
        verify(response).getErrorResponse();
        verifyCustomerApiErrorCode(customerApiErrorCode_A, resolvedMsg_A, false);
        verify(customerApiErrorCode_A, times(1)).getErrorDetails();
        verify(apiMessageService).getMessage(msgId_A, params_A);
    }

    @Test
    public void shouldSilentlyIgnoreIfInvalidMessageIdFoundTest() throws Exception {

        String invalid_msgId = "201101";

        CustomerAccountsEntityCollectionResponse response = response();
        CustomerApiErrorCode customerApiErrorCode_A = mock(CustomerApiErrorCode.class);
        when(customerApiErrorCode_A.getId()).thenReturn(invalid_msgId);
        when(customerApiErrorCode_A.getMessageParmsArray()).thenReturn(null);
        when(customerApiErrorCode_A.getErrorDetails()).thenReturn(null);

        when(apiMessageService.getMessage(invalid_msgId)).thenThrow(new IllegalArgumentException());
        when(responseContext.getEntity()).thenReturn(response);
        when(responseContext.getStatus()).thenReturn(203);
        when(response.getErrorResponse()).thenReturn(customerApiErrorCode_A);

        // invocation
        messageResolverFilter.filter(requestContext, responseContext);

        verify(responseContext).getStatus();
        verify(responseContext, times(3)).getEntity();
        verify(response).getErrorResponse();
        verify(customerApiErrorCode_A, times(1)).getErrorDetails();
        verify(customerApiErrorCode_A, never()).setDeveloperText(Mockito.anyString());
        verify(apiMessageService).getMessage(invalid_msgId);
        verify(customerApiErrorCode_A, atLeastOnce()).getId();
        verify(customerApiErrorCode_A, times(1)).getMessageParmsArray();
    }

    @Test
    public void shouldUsePropertyKeyIfMessageIdIsNullTest() throws Exception {
        String resolvedMsg_A = "A partial response from Cards Lob";
        String msgKey_A = "201101";
        String[] params_A = {"param1", "param2"};

        CustomerAccountsEntityCollectionResponse response = response();
        CustomerApiErrorCode customerApiErrorCode_A = customerApiErrorCode(resolvedMsg_A, msgKey_A, params_A, true);

        // inner api error codes are set to null
        when(customerApiErrorCode_A.getErrorDetails()).thenReturn(null);
        when(apiMessageService.getMessage(msgKey_A, params_A)).thenReturn(resolvedMsg_A);
        when(responseContext.getEntity()).thenReturn(response);
        when(responseContext.getStatus()).thenReturn(203);
        when(response.getErrorResponse()).thenReturn(customerApiErrorCode_A);

        // invocation
        messageResolverFilter.filter(requestContext, responseContext);

        verify(responseContext).getStatus();
        verify(responseContext, times(3)).getEntity();
        verify(response).getErrorResponse();
        verifyCustomerApiErrorCode(customerApiErrorCode_A, resolvedMsg_A, true);
        verify(customerApiErrorCode_A, times(1)).getErrorDetails();
        verify(apiMessageService).getMessage(msgKey_A, params_A);
    }

    private CustomerApiErrorCode customerApiErrorCode(String resolvedMsg, String msgId, String[] params,
            boolean isSetMsgKey) {
        CustomerApiErrorCode customerApiErrorCode = mock(CustomerApiErrorCode.class);
        if (isSetMsgKey) {
            when(customerApiErrorCode.getMessagePropertyKey()).thenReturn(msgId);
        } else {
            when(customerApiErrorCode.getId()).thenReturn(msgId);
        }
        when(customerApiErrorCode.getMessageParmsArray()).thenReturn(params);
        doNothing().when(customerApiErrorCode).setText(resolvedMsg);
        return customerApiErrorCode;
    }

    private void verifyCustomerApiErrorCode(CustomerApiErrorCode customerApiErrorCode, String resolvedMsg,
            boolean isSetMsgKey) {
        if (isSetMsgKey) {
            verify(customerApiErrorCode, times(2)).getMessagePropertyKey();
        } else {
            verify(customerApiErrorCode, atLeastOnce()).getId();
        }
        verify(customerApiErrorCode, atLeastOnce()).setText(resolvedMsg);
        verify(customerApiErrorCode, atLeastOnce()).getMessageParmsArray();
    }

    private CustomerAccountsEntityCollectionResponse response() {
        CustomerAccountsEntityCollectionResponse response = mock(CustomerAccountsEntityCollectionResponse.class);
        return response;
    }

}

/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
