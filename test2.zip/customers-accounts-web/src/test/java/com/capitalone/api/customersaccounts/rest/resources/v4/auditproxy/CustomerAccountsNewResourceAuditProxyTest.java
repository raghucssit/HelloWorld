package com.capitalone.api.customersaccounts.rest.resources.v4.auditproxy;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration.Configuration;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.capitalone.api.commons.exception.RequestValidationException;
import com.capitalone.api.commons.model.EntityCollectionRequest;
import com.capitalone.api.commons.services.response.ResponseData;
import com.capitalone.api.commons.services.util.EPFContextAssist;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccountsEntityCollectionResponse;
import com.capitalone.api.customersaccounts.model.v1.CustomerApiErrorCode;
import com.capitalone.api.customersaccounts.service.api.CustomerAccountsService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.util.CustomerAccountsRefDataBean;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.CustomerReferenceId;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.epf.context.model.EPFContext;
import com.capitalone.epf.context.model.EPFContextContainer;

@Category(UnitTest.class)
@RunWith(PowerMockRunner.class)
@PrepareForTest({EPFContextAssist.class, EPFContextContainer.class})
public class CustomerAccountsNewResourceAuditProxyTest {

    @Mock
    private CustomerAccountsService customerAccountsService;

    @Mock
    private Configuration config;

    @Mock
    private CustomerAccountsRefDataBean customerAccountsRefDataBean;

    @InjectMocks
    private CustomerAccountsNewResourceAuditProxy resource;
    
    @Mock
    private CustomerAccountsUtil customerAccountsUtil;

    @Mock
    private EPFContext context;

    String responseListContent = "Select";

    @Test
    public void testGetMany() {

        EntityCollectionRequest request = new EntityCollectionRequest();
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        List<String> reasSorIdList = new ArrayList<String>();
        reasSorIdList.add("185");
        accountsRequest.setReasSupportedSORID(reasSorIdList );
        accountsRequest.setEnableModifiedOrchestrationSwitch(true);
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        Mockito.when(customerAccountsUtil.getIntProfileSwithDetails(accountsRequest)).thenReturn(accountsRequest);
        request.setApiKey("123");
        // request.setUserId("1234");
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        CustomerApiErrorCode errorResponse = new CustomerApiErrorCode();
        errorResponse.setDeveloperText("aaa");
        customerAccountList.setErrorResponse(errorResponse);
        CustomerReferenceId refereceID = new CustomerReferenceId("1234");
        ProfileReferenceId profilereferenceID = null;
        String businessLine = "DEPOSITE";
        String productTypeCode = "AL";
        ResponseData responseData = new ResponseData();
        responseData.setLocation("Loc");
        Boolean is360ApiKeyPresent = true;
        String appVersion = "V3";
        Map<String, Boolean> map = new HashMap<String, Boolean>();
        map.put("api360AllowedClient", true);
        map.put("is360ApiKeyPresent", true);

        PowerMockito.mockStatic(EPFContextAssist.class);
        when(EPFContextAssist.getContext()).thenReturn(context);

        when(
                customerAccountsService.fetchAccountsAndRelationShip((EntityCollectionRequest) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject())).thenReturn(
                customerAccountList);
        when(customerAccountsRefDataBean.getApiKeySupportedFor360(request.getApiKey(), is360ApiKeyPresent)).thenReturn(
                map);
        // CustomerAccountsNewResourceAuditProxy resource = null;
        assertNotNull(resource.getMany(request, refereceID, profilereferenceID, businessLine, productTypeCode,
                responseData, appVersion, responseListContent));
    }

    @Test
    public void testGetMany_1() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        Mockito.when(customerAccountsUtil.getIntProfileSwithDetails(accountsRequest)).thenReturn(accountsRequest);
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setApiKey("123");
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        CustomerApiErrorCode errorResponse = new CustomerApiErrorCode();
        errorResponse.setDeveloperText("aaa");
        customerAccountList.setErrorResponse(errorResponse);
        CustomerReferenceId refereceID = new CustomerReferenceId("");
        refereceID.getReferenceId().toMap().put("0", "1");
        ProfileReferenceId profilereferenceID = new ProfileReferenceId("1234");
        Boolean is360ApiKeyPresent = true;
        Map<String, Boolean> map = new HashMap<String, Boolean>();
        map.put("api360AllowedClient", true);
        map.put("is360ApiKeyPresent", true);

        String businessLine = "DEPOSITE";
        String productTypeCode = "AL";
        ResponseData responseData = new ResponseData();
        responseData.setLocation("Loc");
        String appVersion = "V4";
        PowerMockito.mockStatic(EPFContextContainer.class);
        when(EPFContextContainer.getContext()).thenReturn(context);
        PowerMockito.mockStatic(EPFContextAssist.class);
        when(EPFContextAssist.getContext()).thenReturn(context);

        when(customerAccountsRefDataBean.getApiKeySupportedFor360(request.getApiKey(), is360ApiKeyPresent)).thenReturn(
                map);
        when(
                customerAccountsService.fetchAccountwithEntitelments((EntityCollectionRequest) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject())).thenReturn(
                customerAccountList);


        assertNotNull(resource.getMany(request, refereceID, profilereferenceID, businessLine, productTypeCode,
                responseData, appVersion, responseListContent));

    }

    @Test
    public void testGetMany_EmptyBussinessLine() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        Mockito.when(customerAccountsUtil.getIntProfileSwithDetails(accountsRequest)).thenReturn(accountsRequest);
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setApiKey("123");

        CustomerReferenceId refereceID = new CustomerReferenceId("");
        refereceID.getReferenceId().toMap().put("0", "1");
        ProfileReferenceId profilereferenceID = new ProfileReferenceId("1234");
        ResponseData responseData = new ResponseData();
        responseData.setLocation("Loc");
        String appVersion = "V4";
        Boolean is360ApiKeyPresent = true;
        Map<String, Boolean> map = new HashMap<String, Boolean>();
        map.put("api360AllowedClient", true);
        map.put("is360ApiKeyPresent", true);

        PowerMockito.mockStatic(EPFContextContainer.class);
        when(EPFContextContainer.getContext()).thenReturn(context);
        PowerMockito.mockStatic(EPFContextAssist.class);
        when(EPFContextAssist.getContext()).thenReturn(context);

        when(customerAccountsRefDataBean.getApiKeySupportedFor360(request.getApiKey(), is360ApiKeyPresent)).thenReturn(
                map);

        assertNull(resource.getMany(request, refereceID, profilereferenceID, null, null, responseData, appVersion,
                responseListContent));

    }

    @Test
    public void testGetMany_WithEntitlementData() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        Mockito.when(customerAccountsUtil.getIntProfileSwithDetails(accountsRequest)).thenReturn(accountsRequest);
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setApiKey("123");

        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();

        CustomerReferenceId refereceID = new CustomerReferenceId("");
        refereceID.getReferenceId().toMap().put("0", "1");
        ProfileReferenceId profilereferenceID = new ProfileReferenceId("1234");
        ResponseData responseData = new ResponseData();
        responseData.setLocation("Loc");
        String appVersion = "V4";
        String businessLine = "DEPOSITE";

        Boolean is360ApiKeyPresent = true;
        Map<String, Boolean> map = new HashMap<String, Boolean>();
        map.put("api360AllowedClient", true);
        map.put("is360ApiKeyPresent", true);

        PowerMockito.mockStatic(EPFContextContainer.class);
        when(EPFContextContainer.getContext()).thenReturn(context);
        PowerMockito.mockStatic(EPFContextAssist.class);
        when(EPFContextAssist.getContext()).thenReturn(context);

        when(customerAccountsRefDataBean.getApiKeySupportedFor360(request.getApiKey(), is360ApiKeyPresent)).thenReturn(
                map);

        when(
                customerAccountsService.fetchAccountwithEntitelments((EntityCollectionRequest) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject())).thenReturn(
                customerAccountList);

        assertNotNull(resource.getMany(request, refereceID, profilereferenceID, businessLine, null, responseData,
                appVersion, responseListContent));

    }

    @Test
    public void testGetMany_NullResponse() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        Mockito.when(customerAccountsUtil.getIntProfileSwithDetails(accountsRequest)).thenReturn(accountsRequest);
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setApiKey("123");
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();

        CustomerReferenceId refereceID = new CustomerReferenceId("");
        refereceID.getReferenceId().toMap().put("0", "1");
        ProfileReferenceId profilereferenceID = new ProfileReferenceId("1234");

        String businessLine = "DEPOSITE";
        String productTypeCode = "AL";
        ResponseData responseData = new ResponseData();
        responseData.setLocation("Loc");
        String appVersion = "V4";
        Boolean is360ApiKeyPresent = true;
        Map<String, Boolean> map = new HashMap<String, Boolean>();
        map.put("api360AllowedClient", true);
        map.put("is360ApiKeyPresent", true);

        PowerMockito.mockStatic(EPFContextContainer.class);
        when(EPFContextContainer.getContext()).thenReturn(context);
        PowerMockito.mockStatic(EPFContextAssist.class);
        when(EPFContextAssist.getContext()).thenReturn(context);

        when(customerAccountsRefDataBean.getApiKeySupportedFor360(request.getApiKey(), is360ApiKeyPresent)).thenReturn(
                map);
        when(
                customerAccountsService.fetchAccountsAndRelationShip((EntityCollectionRequest) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject())).thenReturn(
                customerAccountList);

        assertNull(resource.getMany(request, refereceID, profilereferenceID, businessLine, productTypeCode, null,
                appVersion, responseListContent));

    }

    @Test(expected = RequestValidationException.class)
    public void testGetMany_profileReferenceIdEmpty() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setApiKey("123");
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        CustomerApiErrorCode errorResponse = new CustomerApiErrorCode();
        errorResponse.setDeveloperText("aaa");
        CustomerReferenceId refereceID = new CustomerReferenceId("");
        refereceID.getReferenceId().toMap().put("", "");
        String prof = null;
        ProfileReferenceId profilereferenceID = new ProfileReferenceId(prof);

        String businessLine = "DEPOSITE";
        String productTypeCode = "AL";
        ResponseData responseData = new ResponseData();
        responseData.setLocation("Loc");
        String appVersion = "V4";

        when(
                customerAccountsService.fetchAccountwithEntitelments((EntityCollectionRequest) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject())).thenReturn(
                customerAccountList);

        Boolean is360ApiKeyPresent = true;
        Map<String, Boolean> map = new HashMap<String, Boolean>();
        map.put("api360AllowedClient", true);
        map.put("is360ApiKeyPresent", true);

        PowerMockito.mockStatic(EPFContextContainer.class);
        when(EPFContextContainer.getContext()).thenReturn(context);
        PowerMockito.mockStatic(EPFContextAssist.class);
        when(EPFContextAssist.getContext()).thenReturn(context);

        when(customerAccountsRefDataBean.getApiKeySupportedFor360(request.getApiKey(), is360ApiKeyPresent)).thenReturn(
                map);

        assertNotNull(resource.getMany(request, refereceID, profilereferenceID, businessLine, productTypeCode,
                responseData, appVersion, responseListContent));

    }

    @Test
    public void testGetMany_profileReferenceIdNull() {
        CustomerAccountsRequest accountsRequest = new CustomerAccountsRequest();
        Mockito.when(customerAccountsUtil.loadConfigDetails()).thenReturn(accountsRequest);
        Mockito.when(customerAccountsUtil.getIntProfileSwithDetails(accountsRequest)).thenReturn(accountsRequest);
        EntityCollectionRequest request = new EntityCollectionRequest();
        request.setApiKey("123");
        CustomerAccountsEntityCollectionResponse customerAccountList = new CustomerAccountsEntityCollectionResponse();
        CustomerApiErrorCode errorResponse = new CustomerApiErrorCode();
        errorResponse.setDeveloperText("aaa");
        CustomerReferenceId refereceID = new CustomerReferenceId("");
        refereceID.getReferenceId().toMap().put("", "");

        ProfileReferenceId profilereferenceID = null;

        String businessLine = "DEPOSITE";
        String productTypeCode = "AL";
        ResponseData responseData = new ResponseData();
        responseData.setLocation("Loc");
        String appVersion = "V4";
        Boolean is360ApiKeyPresent = true;
        Map<String, Boolean> map = new HashMap<String, Boolean>();
        map.put("api360AllowedClient", true);
        map.put("is360ApiKeyPresent", true);

        PowerMockito.mockStatic(EPFContextContainer.class);
        when(EPFContextContainer.getContext()).thenReturn(context);
        PowerMockito.mockStatic(EPFContextAssist.class);
        when(EPFContextAssist.getContext()).thenReturn(context);

        when(customerAccountsRefDataBean.getApiKeySupportedFor360(request.getApiKey(), is360ApiKeyPresent)).thenReturn(
                map);
        when(
                customerAccountsService.fetchAccountwithEntitelments((EntityCollectionRequest) Mockito.anyObject(),
                        (CustomerAccountsRequest) Mockito.anyObject(), (String) Mockito.anyObject())).thenReturn(
                customerAccountList);

        assertNotNull(resource.getMany(request, refereceID, profilereferenceID, businessLine, productTypeCode,
                responseData, appVersion, responseListContent));

    }

}
