package com.capitalone.api.customersaccounts.rest.config;
 
import static org.hamcrest.Matchers.hasItemInArray;
import static org.hamcrest.Matchers.instanceOf;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.apache.commons.configuration.Configuration;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.epf.configuration.utils.EPFConfigurationUtils;
import com.capitalone.epf.servicelocator.JaxWsPortProxyFactoryBean;
import com.capitalone.epf.servicelocator.handlers.EPFJaxWsHandlerResolver;

@Category(UnitTest.class)
@RunWith(PowerMockRunner.class)
@PrepareForTest({SpringConfigTest.class, SpringConfig.class})
public class SpringConfigTest {

    private SpringConfig config;

    @Mock
    private SpringConfig mockedConfig;

    @Mock
    private EPFJaxWsHandlerResolver handlerResolver;

    @Mock
    private Configuration configuration;

    @Mock
    private EPFConfigurationUtils configUtils;

    @Mock
    private JaxWsPortProxyFactoryBean portProxyFactoryBean;

    @Before
    public void setUp() throws Exception {
        config = new SpringConfig();

        Whitebox.setInternalState(config, handlerResolver, configuration);
    }

    @Test
    public void testValidationMessages() {
        String basename = "somebasename";
        when(configuration.getString("validation.messages.basename")).thenReturn(basename);
        MessageSource validationMessages = config.validationMessages();
        assertThat(validationMessages, instanceOf(ReloadableResourceBundleMessageSource.class));
        assertThat((String[]) Whitebox.getInternalState(validationMessages, "basenames"), hasItemInArray(basename));
        verify(configuration).getString("validation.messages.basename");

    }

}
