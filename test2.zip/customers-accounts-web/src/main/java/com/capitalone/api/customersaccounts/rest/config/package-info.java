package com.capitalone.api.customersaccounts.rest.config;

/**
 * Spring and Jersey configuration classes for customers-accounts functionality.
 */
