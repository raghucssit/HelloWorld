package com.capitalone.api.customersaccounts.rest.resources.v4;

import java.net.HttpURLConnection;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.HEAD;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.server.JSONP;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.capitalone.api.annotations.NonPublicInformation;
import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.model.EntityCollectionRequest;
import com.capitalone.api.commons.services.response.ResponseData;
import com.capitalone.api.commons.web.resource.AbstractBaseResource;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccountsEntityCollectionResponse;
import com.capitalone.api.customersaccounts.rest.filter.EntitlementContextFilter.EntitledBy;
import com.capitalone.api.customersaccounts.rest.filter.EntitlementContextFilter.EntitledByType;
import com.capitalone.api.customersaccounts.rest.filter.EntitlementContextFilter.EntitledCustomerReferenceId;
import com.capitalone.api.customersaccounts.rest.filter.EntitlementContextFilter.EntitledProfileReferenceId;
import com.capitalone.api.customersaccounts.rest.resources.v4.auditproxy.CustomerAccountsNewResourceAuditProxy;
import com.capitalone.api.customersaccounts.service.api.CustomerAccountsService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.CustomerReferenceId;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.api.model.id.ReferenceId;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

@Named("v4_CustomerAccountsService")
@Trace
@Profile
@Path("/customers/{customerReferenceID}/accounts")
@Api(value = "/customers/{customerReferenceID}/accounts/v4", description = "Retrieve Customer Accounts Operations")
@Produces({"application/vnd.com.capitalone.api+v4+json", "application/vnd.com.capitalone.api+v4+xml"})
@Component
@SuppressWarnings("CPD-START")
public class CustomerAccountsNewResource extends AbstractBaseResource {
    private static final String SPLITTER = "\\|";

    @Inject
    private CustomerAccountsService customerAccountsService;

    @Inject
    private CustomerAccountsNewResourceAuditProxy customerAccountsNewResourceAuditProxy;
    
    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    @GET
    @JSONP(queryParam = JSONP.DEFAULT_QUERY)
    @EntitledCustomerReferenceId(paramName = "customerReferenceID")
    @EntitledProfileReferenceId(paramName = "profileReferenceID")
    @EntitledBy(EntitledByType.PROFILE_REFERENCE_ID)
    @ApiOperation(value = "Get all the accounts associated to a customer", notes = "Search for Capital One Customer Accounts.", position = 1, response = CustomerAccountsEntityCollectionResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = HttpURLConnection.HTTP_OK, message = "Success. All of the eligible accounts for the customer are returned successfully."),
            @ApiResponse(code = HttpURLConnection.HTTP_NOT_AUTHORITATIVE, message = "Partial Success. At least one of the eligible accounts for the customer is returned successfully."),
            @ApiResponse(code = HttpURLConnection.HTTP_FORBIDDEN, message = "Authorization failure. When entitlement rules are failed for a customer and no accounts are exposed."),
            @ApiResponse(code = HttpURLConnection.HTTP_NOT_FOUND, message = "The requested resource could not be found. In practice, this almost always means that a path parameter ID could not be resolved. For example, /customers/abc-12345 where abc-12345 does not correspond to a customer."),
            @ApiResponse(code = HttpURLConnection.HTTP_CONFLICT, message = "Conflict when a business logic rule was violated. E.g: Multiple ESCIDs found for a given SSOID."),
            @ApiResponse(code = HttpURLConnection.HTTP_INTERNAL_ERROR, message = "System error. API system error or all the backend calls made by the API failed due to system error.")})
    public CustomerAccountsEntityCollectionResponse getNewMany(
            @Context UriInfo uriInfo,
            @BeanParam EntityCollectionRequest request,
            @ApiParam(value = "Token used to identify the enterprise customer Reference ID which will be used to retrieve all serviceable accounts for that customer. (e.g. 340057). If profileReferenceID is present then this field should contain only ~", name = "customerReferenceID", defaultValue = "~") @NonPublicInformation @PathParam("customerReferenceID") ReferenceId customerReferenceID,
            @ApiParam(value = "This field will contain the SSO ID of a customer. If customerReferenceId is present then this field should not be present.", name = "profileReferenceID", defaultValue = "p5FKERwvp52PNPUYf%2BWF7A%3D%3D") @NonPublicInformation @QueryParam("profileReferenceID") String profileReferenceId,
            @ApiParam(value = "High level product categorization with enumerated list of values defined at the enterprise level and in alignment with the API ontology. This field supports filtering based on multiple Business Lines delimited by Symbol.", name = "businessLine") @QueryParam("businessLine") String businessLine,
            @ApiParam(value = "Product Type Code of accounts requested. This field supports filtering based on multiple product Type codes delimited by Symbol.", name = "productTypeCode") @QueryParam("productTypeCode") String productTypeCode,
            @QueryParam("select") String select, @BeanParam ResponseData responseData) {

        ProfileReferenceId prid = null;

        if (!StringUtils.isBlank(profileReferenceId)) {
            try { // three part key
                ReferenceId refId = ReferenceId.valueOf(profileReferenceId);
                prid = new ProfileReferenceId(refId);
            } catch (IllegalArgumentException e) {
                prid = new ProfileReferenceId(String.valueOf(Constants.PROFILE_SORID), profileReferenceId,
                        Constants.PROFILE_TYPE); // 1  part key it is just SSOID.
            }
        }

        return customerAccountsNewResourceAuditProxy.getMany(request, new CustomerReferenceId(customerReferenceID),
                prid, businessLine, productTypeCode, responseData, "V4", select);
    }

    @HEAD
    @JSONP(queryParam = JSONP.DEFAULT_QUERY)
    @ApiOperation(value = "Get all the accounts associated to a customer", notes = "Search for Capital One Customer Accounts.", position = 1, response = CustomerAccountsEntityCollectionResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = HttpURLConnection.HTTP_OK, message = "Success. All of the eligible accounts for the customer are returned successfully."),
            @ApiResponse(code = HttpURLConnection.HTTP_NOT_AUTHORITATIVE, message = "Partial Success. At least one of the eligible accounts for the customer is returned successfully."),
            @ApiResponse(code = HttpURLConnection.HTTP_FORBIDDEN, message = "Authorization failure. When entitlement rules are failed for a customer and no accounts are exposed."),
            @ApiResponse(code = HttpURLConnection.HTTP_NOT_FOUND, message = "The requested resource could not be found. In practice, this almost always means that a path parameter ID could not be resolved. For example, /customers/abc-12345 where abc-12345 does not correspond to a customer."),
            @ApiResponse(code = HttpURLConnection.HTTP_CONFLICT, message = "Conflict when a business logic rule was violated. E.g: Multiple ESCIDs found for a given SSOID."),
            @ApiResponse(code = HttpURLConnection.HTTP_INTERNAL_ERROR, message = "System error. API system error or all the backend calls made by the API failed due to system error.")})
    public void getHeader(
            @BeanParam EntityCollectionRequest request,
            @ApiParam(value = "Token used to identify the enterprise customer Reference ID which will be used to retrieve all serviceable accounts for that customer. (e.g. 340057). If profileReferenceID is present then this field should contain only ~", name = "customerReferenceID", defaultValue = "~") @NonPublicInformation @PathParam("customerReferenceID") ReferenceId customerReferenceID,
            @ApiParam(value = "This field will contain the SSO ID of a customer. If customerReferenceId is present then this field should not be present.", name = "profileReferenceID", defaultValue = "p5FKERwvp52PNPUYf%2BWF7A%3D%3D") @NonPublicInformation @QueryParam("profileReferenceID") String profileReferenceId,
            @ApiParam(value = "High level product categorization with enumerated list of values defined at the enterprise level and in alignment with the API ontology. This field supports filtering based on multiple Business Lines delimited by Symbol.", name = "businessLine") @QueryParam("businessLine") String businessLine,
            @ApiParam(value = "Product Type Code of accounts requested. This field supports filtering based on multiple product Type codes delimited by Symbol.", name = "productTypeCode") @QueryParam("productTypeCode") String productTypeCode,
            @BeanParam ResponseData responseData) {

        ProfileReferenceId prid = null;

        if (!StringUtils.isBlank(profileReferenceId)) {
            try {
                ReferenceId refId = ReferenceId.valueOf(profileReferenceId);
                prid = new ProfileReferenceId(refId);
            } catch (IllegalArgumentException e) {
                prid = new ProfileReferenceId("49", profileReferenceId, "LGIN");
            }
        }

        CustomerAccountsRequest customerAccountsRequest = customerAccountsUtil.loadConfigDetails();
        CustomerReferenceId customerReferID = new CustomerReferenceId(customerReferenceID);
        if ((null != customerReferID.getReferenceId() && !CollectionUtils.isEmpty(customerReferID.getReferenceId()
                .toMap()))) {
            customerAccountsRequest.setCustomerReferenceId(customerReferID);
        } else if (profileReferenceId != null) {
            customerAccountsRequest.setProfileReferenceId(prid);
        }

        Set<String> businessLineSet = null;
        Set<String> productTypeSet = null;
        String businessLine1 = null;
        if (StringUtils.isNotBlank(businessLine)) {
            businessLine1 = businessLine.toUpperCase();
            businessLineSet = new TreeSet<String>(Arrays.asList(businessLine1.split(SPLITTER)));
        }
        if (StringUtils.isNotBlank(productTypeCode)) {
            productTypeSet = new TreeSet<String>(Arrays.asList(productTypeCode.split(SPLITTER)));
        }

        customerAccountsRequest.setBusinessLineSet(businessLineSet);
        customerAccountsRequest.setProductTypeSet(productTypeSet);
        customerAccountsRequest.setApiKey(request.getApiKey());
        customerAccountsService.fetchCustomerRefID(request, customerAccountsRequest);

    }

}