package com.capitalone.api.customersaccounts.rest.resources.v4;
/**
 * Exposed REST resources for customers-accounts functionality.
 */