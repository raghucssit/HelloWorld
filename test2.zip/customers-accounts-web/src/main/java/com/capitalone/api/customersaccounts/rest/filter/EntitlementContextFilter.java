package com.capitalone.api.customersaccounts.rest.filter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.annotation.Priority;
import javax.inject.Named;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.container.ResourceInfo;
import javax.ws.rs.core.Context;
import javax.ws.rs.ext.Provider;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.services.util.EPFContextAssist;

@Named
@Provider
@Priority(Priorities.AUTHENTICATION)
public class EntitlementContextFilter implements ContainerRequestFilter {

    private static final String SSOID = "SSOID";

    private static final String URL_ENCODING = "UTF-8";

    protected Logger logger = LoggerFactory.getLogger(getClass());

    private static final String ENTITLEMENT_ID_TYPE_HEADER_PARAM_NAME = "ENTITLEMENT_ID_TYPE";

    private static final String ENTITLEMENT_ID_HEADER_PARAM_NAME = "ENTITLEMENT_ID";

    private static final String ENTITLEMENTS_ID_TYPE_CUSTREFID = "CustomerReferenceID";

    private static final String ENTITLEMENTS_ID_TYPE_PROFILEREFID = "ProfileReferenceID";

    @Context
    private ResourceInfo resourceInfo;

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {

        // Skip filter if headers exist
        if (containsEntitlementHeaders(requestContext)) {
            logger.debug("Entitlements headers are already set, so skipping Entitlements Context Filter");
            return;
        }

        Method resourceMethod = resourceInfo.getResourceMethod();
        EntitledBy entitledBy = resourceMethod.getAnnotation(EntitledBy.class);

        EntitledProfileReferenceId profileReferenceIdAnnotation = resourceMethod
                .getAnnotation(EntitledProfileReferenceId.class);

        EntitledCustomerReferenceId customerReferenceIdAnnotation = resourceMethod
                .getAnnotation(EntitledCustomerReferenceId.class);

        String ssoid = getSSOID(requestContext);

        EntitledByType entitledByType = null;
        String profileReferenceId = StringUtils.EMPTY;
        String customerReferenceId = StringUtils.EMPTY;

        if (profileReferenceIdAnnotation != null) {
            logger.debug("EntitledProfileReferenceId annotation value {}", profileReferenceIdAnnotation);
            profileReferenceId = getEntitledCustomerIdentifier(requestContext,
                    profileReferenceIdAnnotation.paramName(), profileReferenceIdAnnotation.paramType());
            entitledByType = EntitledByType.PROFILE_REFERENCE_ID;
        }

        if (customerReferenceIdAnnotation != null) {
            logger.debug("EntitledCustomerReferenceId annotation value {}", customerReferenceIdAnnotation);
            customerReferenceId = getEntitledCustomerIdentifier(requestContext,
                    customerReferenceIdAnnotation.paramName(), customerReferenceIdAnnotation.paramType());
            entitledByType = EntitledByType.CUSTOMER_REFERENCE_ID;
        }

        EntitledByType entitledByTypeReturned = getEntitledByType(entitledBy, profileReferenceIdAnnotation,
                customerReferenceIdAnnotation, ssoid, profileReferenceId, customerReferenceId);
        if (entitledByTypeReturned != null)

        {
            entitledByType = entitledByTypeReturned;
        }

        logger.debug("EntitledByType of   {}", entitledByType);

        if (entitledByType == null) {
            // Return without setting Entitlement headers
            logger.debug("Return without setting Entitlement headers");
            return;
        }

        switch (entitledByType) {
            case PROFILE_REFERENCE_ID:
                logger.debug("ProfileReferenceID is  {}, EntitlementIDType is {}", profileReferenceId,
                        EntitledProfileReferenceId.entitlementIdType);
                updateRequestHeader(requestContext, profileReferenceId, EntitledProfileReferenceId.entitlementIdType);
                break;

            case CUSTOMER_REFERENCE_ID:
                logger.debug("CustomerReferenceID is  {}, EntitlementIDType is {}", customerReferenceId,
                        EntitledCustomerReferenceId.entitlementIdType);
                updateRequestHeader(requestContext, customerReferenceId, EntitledCustomerReferenceId.entitlementIdType);
                break;

            case SSOID:
                updateRequestHeader(requestContext, ssoid, SSOID);
                break;

            default:
                logger.warn("Unsupporrted Entitlement Type {}", entitledByType);
                break;
        }

    }

    private EntitledByType getEntitledByType(EntitledBy entitledBy,
            EntitledProfileReferenceId profileReferenceIdAnnotation,
            EntitledCustomerReferenceId customerReferenceIdAnnotation, String ssoid, String profileReferenceId,
            String customerReferenceId) {
        EntitledByType entitledByTypeTemp = null;
        if (customerReferenceIdAnnotation != null && profileReferenceIdAnnotation != null) {
            entitledByTypeTemp = getValueEntitledByType(entitledBy, profileReferenceId, customerReferenceId);
        } else if (customerReferenceIdAnnotation == null && profileReferenceIdAnnotation == null
                && StringUtils.isNotBlank(ssoid)) {
            entitledByTypeTemp = EntitledByType.SSOID;
        }
        return entitledByTypeTemp;
    }

    private EntitledByType getValueEntitledByType(EntitledBy entitledBy, String profileReferenceId,
            String customerReferenceId) {
        EntitledByType entitledByTypeValue = null;
        if (StringUtils.isNotBlank(customerReferenceId) && StringUtils.isNotBlank(profileReferenceId)) {
            entitledByTypeValue = entitledBy != null ? entitledBy.value() : EntitledByType.CUSTOMER_REFERENCE_ID;
        } else if (StringUtils.isNotBlank(customerReferenceId)) {
            entitledByTypeValue = EntitledByType.CUSTOMER_REFERENCE_ID;
        } else if (StringUtils.isNotBlank(profileReferenceId)) {
            entitledByTypeValue = EntitledByType.PROFILE_REFERENCE_ID;
        }
        return entitledByTypeValue;
    }

    /**
     * Check for entitlement headers
     */
    private boolean containsEntitlementHeaders(ContainerRequestContext requestContext) {
        return StringUtils.isNotBlank(requestContext.getHeaderString(ENTITLEMENT_ID_TYPE_HEADER_PARAM_NAME))
                && StringUtils.isNotBlank(requestContext.getHeaderString(ENTITLEMENT_ID_HEADER_PARAM_NAME));
    }

    private Map<String, List<String>> getResourceMethodParams(ContainerRequestContext requestContext,
            EntitledIdentifierParamType paramType) {
        if (paramType == EntitledIdentifierParamType.PATH_PARAM) {
            return requestContext.getUriInfo().getPathParameters();
        } else if (paramType == EntitledIdentifierParamType.QUERY_PARAM) {
            return requestContext.getUriInfo().getQueryParameters();
        } else {
            return new HashMap<String, List<String>>();
        }
    }

    private String getEntitledCustomerIdentifier(ContainerRequestContext requestContext, String paramName,
            EntitledIdentifierParamType paramType) {
        Map<String, List<String>> resourceMethodParams = getResourceMethodParams(requestContext, paramType);
        String entitledCustomerIdentifier = StringUtils.EMPTY;
        if (MapUtils.isNotEmpty(resourceMethodParams)) {
            for (Entry<String, List<String>> param : resourceMethodParams.entrySet()) {
                if (StringUtils.equalsIgnoreCase(paramName, param.getKey())
                        && CollectionUtils.isNotEmpty(param.getValue()) && !"~".equals(param.getValue().get(0))) {
                    entitledCustomerIdentifier = param.getValue().get(0);
                    break;
                }
            }
        }
        return entitledCustomerIdentifier;
    }

    private String getSSOID(ContainerRequestContext requestContext) {
        String ssoid = StringUtils.EMPTY;
        List<String> valueList = requestContext.getHeaders().get(SSOID);
        if (CollectionUtils.isNotEmpty(valueList) && CollectionUtils.size(valueList) == 1) {
            if (StringUtils.isNotBlank(valueList.get(0))) {
                ssoid = valueList.get(0);
            }
        } else {
            logger.warn("The SSOID header contain zero or more parameters {}", valueList);
        }
        return ssoid;

    }

    private void updateRequestHeader(ContainerRequestContext requestContext, String customerIdentifier,
            String entitlementIdType) throws UnsupportedEncodingException {

        String encodedIdentifier = URLEncoder.encode(customerIdentifier, URL_ENCODING);
        requestContext.getHeaders().add(ENTITLEMENT_ID_HEADER_PARAM_NAME, encodedIdentifier);
        requestContext.getHeaders().add(ENTITLEMENT_ID_TYPE_HEADER_PARAM_NAME, entitlementIdType);
        Map<String, List<String>> headers = EPFContextAssist.getContext().getAllRequestHeaders();
        Map<String, List<String>> headerCopy = new TreeMap<String, List<String>>(String.CASE_INSENSITIVE_ORDER);
        headerCopy.putAll(headers);
        headerCopy.put(ENTITLEMENT_ID_HEADER_PARAM_NAME, Arrays.asList(encodedIdentifier));
        headerCopy.put(ENTITLEMENT_ID_TYPE_HEADER_PARAM_NAME, Arrays.asList(entitlementIdType));

        EPFContextAssist.getContext().setAllRequestHeaders(headerCopy);

        logger.debug("params {}", requestContext.getHeaders());
        logger.debug("EPF headers {}", EPFContextAssist.getContext().getAllRequestHeaders());
    }

    // Entitled Reference Id Annotations.
    // TODO: Move to separate classes.
    @Documented
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface EntitledCustomerReferenceId {

        String paramName() default "customerReferenceId";

        EntitledIdentifierParamType paramType() default EntitledIdentifierParamType.PATH_PARAM;

        static final String entitlementIdType = ENTITLEMENTS_ID_TYPE_CUSTREFID;

    }

    @Documented
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface EntitledProfileReferenceId {

        String paramName() default "profileReferenceId";

        EntitledIdentifierParamType paramType() default EntitledIdentifierParamType.QUERY_PARAM;

        public static final String entitlementIdType = ENTITLEMENTS_ID_TYPE_PROFILEREFID;
    }

    @Documented
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface EntitledBy {
        public EntitledByType value() default EntitledByType.CUSTOMER_REFERENCE_ID;
    }

    public enum EntitledIdentifierParamType {
        PATH_PARAM,
        QUERY_PARAM;
    }

    public enum EntitledByType {
        PROFILE_REFERENCE_ID("profileReferenceId"),
        CUSTOMER_REFERENCE_ID("customerReferenceId"),
        SSOID("SSOID");

        String type;

        public String getType() {
            return type;
        }

        EntitledByType(String type) {
            this.type = type;
        }

    }
}