package com.capitalone.api.customersaccounts.rest.filter;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;

import java.io.IOException;

import javax.annotation.Priority;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatus.Series;

import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.services.message.ApiMessageService;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccountsEntityCollectionResponse;
import com.capitalone.api.customersaccounts.model.v1.CustomerApiErrorCode;

/**
 * Class intercepts the customer accounts response and search for error code in object and resolves them into messages.
 * {@link ApiMessageService} resolves messages into text as per Locale set in 'Accept-language' header. In case Locale
 * header is missing it switches to default Locale i.e en_US. Look for <i>'request.header.locale.flag'</i> in property
 * and use it as toggle to switch On/Off multilingual support.This class silently ignores if messageId are not resolved
 * into text.
 * 
 * @author hnr543 - pmehra
 * @since 1.0
 */
@Named
@Provider
@Priority(Priorities.ENTITY_CODER)
public class MessageResolverFilter implements ContainerResponseFilter {

    private static final Logger LOG = LoggerFactory.getLogger(MessageResolverFilter.class);

    @Inject
    private ApiMessageService apiMessageService;

    public MessageResolverFilter() {
        super();
    }

    protected MessageResolverFilter(ApiMessageService apiMessageService) {
        this.apiMessageService = apiMessageService;
    }

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext)
            throws IOException {

        if (!isCustomerAccountResponse(responseContext)) {
            return;
        }

        CustomerAccountsEntityCollectionResponse response = (CustomerAccountsEntityCollectionResponse) responseContext
                .getEntity();

        Series httpSeries = HttpStatus.Series.valueOf(responseContext.getStatus());
        switch (httpSeries) {
            case SUCCESSFUL:
                resolveAndSetMessage(response.getErrorResponse());
                break;
            default:
        }
    }

    private void resolveAndSetMessage(ApiErrorCode apiErrorCode) {
        if (apiErrorCode == null) {
            return;
        }

        if (hasMessageID(apiErrorCode)) {
            setMessageText(apiErrorCode);
        }

        if (CollectionUtils.isEmpty(apiErrorCode.getErrorDetails())) {
            return;
        }

        for (ApiErrorCode apiErrCode : apiErrorCode.getErrorDetails()) {
            resolveAndSetMessage(apiErrCode);
        }
    }

    private boolean hasMessageID(ApiErrorCode apiErrorCode) {
        return apiErrorCode != null
                && (isNotEmpty(apiErrorCode.getId()) || isNotEmpty(apiErrorCode.getMessagePropertyKey()));
    }

    private void setMessageText(ApiErrorCode apiErrorCode) {
        if (apiErrorCode instanceof CustomerApiErrorCode) {
            CustomerApiErrorCode customerApiErrorCode = (CustomerApiErrorCode) apiErrorCode;

            String msgId = null;
            if (isNotEmpty(customerApiErrorCode.getId())) {
                msgId = customerApiErrorCode.getId();
            } else {
                msgId = customerApiErrorCode.getMessagePropertyKey();
            }

            customerApiErrorCode.setText(getMessage(msgId, customerApiErrorCode.getMessageParmsArray()));
        }
    }

    private boolean isCustomerAccountResponse(ContainerResponseContext responseContext) {
        return responseContext.getEntity() != null
                && (responseContext.getEntity() instanceof CustomerAccountsEntityCollectionResponse);
    }

    private String getMessage(String msgId, String[] msgParams) {
        try {
            if (msgParams == null || msgParams.length == 0) {
                return apiMessageService.getMessage(msgId);
            } else {
                return apiMessageService.getMessage(msgId, msgParams);
            }
        } catch (Exception e) {
            LOG.debug("Error resolving message for id {}", msgId);
            return null;
        }

    }

}

/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */