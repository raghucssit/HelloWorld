package com.capitalone.api.customersaccounts.rest.config;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.PostConstruct;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.capitalone.api.commons.web.config.CacheConfiguration;

/**
 * Defines the cache configuration required for reference data.
 * 
 * @author qtm848
 * 
 */
@Named
public class CustomersAccountsCacheConfig implements CacheConfiguration {
    private Set<String> cacheNames;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @PostConstruct
    public void initialize() {
        cacheNames = new HashSet<String>(Arrays.asList(
                "eapi-shortterm-integrationprofileaccountsdao-retrieveAccountDetails",
                "eapi-shortterm-loansautoLoansentity-getAccount", "eapi-shortterm-loanshomeloansentity-getAccount",
                "eapi-shortterm-ecrcustomerrelationshipsentity-custidentitymatchedaccountsinq",
                "eapi-mediumterm-customerInformationEntity-customerInformationInq"));
        logger.debug("Cache initialized : {}", cacheNames);
    }

    /*
     * (non-Javadoc)
     * @see com.capitalone.api.commons.web.config.CacheConfiguration#getCacheNames()
     */
    @Override
    public Set<String> getCacheNames() {
        logger.debug("Retrieve Cache Names : {}", cacheNames);
        return cacheNames;
    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
