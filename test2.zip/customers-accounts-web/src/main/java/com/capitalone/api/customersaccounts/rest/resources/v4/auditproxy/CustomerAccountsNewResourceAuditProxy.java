package com.capitalone.api.customersaccounts.rest.resources.v4.auditproxy;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.capitalone.api.commons.exception.RequestValidationException;
import com.capitalone.api.commons.model.EntityCollectionRequest;
import com.capitalone.api.commons.services.response.ResponseData;
import com.capitalone.api.commons.services.util.EPFContextAssist;
import com.capitalone.api.customersaccounts.constant.Constants;
import com.capitalone.api.customersaccounts.model.v1.CustomerAccountsEntityCollectionResponse;
import com.capitalone.api.customersaccounts.service.api.CustomerAccountsService;
import com.capitalone.api.customersaccounts.service.pojo.CustomerAccountsRequest;
import com.capitalone.api.customersaccounts.util.CustomerAccountsUtil;
import com.capitalone.api.model.id.CustomerReferenceId;
import com.capitalone.api.model.id.ProfileReferenceId;
import com.capitalone.epf.audit.annotation.Audit;
import com.capitalone.epf.context.model.EPFContextContainer;

@Named
public class CustomerAccountsNewResourceAuditProxy {

    @Inject
    private CustomerAccountsService customerAccountsService;

    @Inject
    private CustomerAccountsUtil customerAccountsUtil;

    private String partialSuccessMessage;
    
    @Inject
    @Named("upf-app-config")
    private Configuration config;

    @PostConstruct
    private void loadConfigDetails() {
        partialSuccessMessage = config.getString(Constants.API_PARTIAL_SUCCESS);
    }

    @Audit(builder = "apiAuditBuilder", value = "RetrieveCustomerAccounts")
    public CustomerAccountsEntityCollectionResponse getMany(EntityCollectionRequest request,
            CustomerReferenceId customerReferenceID, ProfileReferenceId profileReferenceId, String businessLine,
            String productTypeCode, ResponseData responseData, String appVersion, String select) {
        loadConfigDetails(); // This is to load all the properties from Config.
        CustomerAccountsRequest customerAccountsRequest = customerAccountsUtil.loadConfigDetails();
        customerAccountsRequest.setAppVersion(appVersion);

        validateInputRequest(customerReferenceID, profileReferenceId);
        setReferenceIds(customerReferenceID, profileReferenceId, customerAccountsRequest, request);
        customerAccountsRequest = customerAccountsUtil.getIntProfileSwithDetails(customerAccountsRequest);

        if (customerAccountsRequest.isEnableModifiedOrchestrationSwitch()
                && customerAccountsRequest.getReasSupportedSORID().contains(Constants.SORID_360)) {
            createHeaderParamforDGWAccounts(Boolean.TRUE);
        } else {
            createHeaderParamforDGWAccounts(!customerAccountsRequest.isApi360AllowedClient());
        }

        Set<String> businessLineSet = null;
        Set<String> productTypeSet = null;
        String businessLine1 = null;

        if (StringUtils.isNotBlank(businessLine)) {
            businessLine1 = businessLine.toUpperCase();
            businessLineSet = new TreeSet<String>(Arrays.asList(businessLine1.split("\\|")));
        }
        if (StringUtils.isNotBlank(productTypeCode)) {
            productTypeSet = new TreeSet<String>(Arrays.asList(productTypeCode.split("\\|")));
        }

        customerAccountsRequest.setBusinessLineSet(businessLineSet);
        customerAccountsRequest.setProductTypeSet(productTypeSet);
        customerAccountsRequest.setApiKey(request.getApiKey());

        return getResponse(request, responseData, appVersion, customerAccountsRequest, select);
    }

    /**
     * getting response depending on versions
     * 
     * @param EntityCollectionRequest, ResponseData,appVersion,CustomerAccountsRequest
     * @return CustomerAccountsEntityCollectionResponse
     */
    private CustomerAccountsEntityCollectionResponse getResponse(EntityCollectionRequest request,
            ResponseData responseData, String appVersion, CustomerAccountsRequest customerAccountsRequest, String select) {
        CustomerAccountsEntityCollectionResponse response;

        if (Constants.APP_VERSION3.equalsIgnoreCase(appVersion)) {
            response = customerAccountsService.fetchAccountsAndRelationShip(request, customerAccountsRequest, select);
        } else {

            response = customerAccountsService.fetchAccountwithEntitelments(request, customerAccountsRequest, select);
        }

        if (response != null && response.getErrorResponse() != null && responseData != null) {
            responseData.setPartialContent(true);
            response.getErrorResponse().setId(Constants.API_PARTIAL_SUCCESS);
            response.getErrorResponse().setDeveloperText(partialSuccessMessage);
        }
        /*
         * if (entitlementData != null && entitlementData.wasDefaultAccountRedactEnforced() &&
         * response.getErrorResponse() == null && responseData != null) { CustomerApiErrorCode errorResponse = new
         * CustomerApiErrorCode(); response.setErrorResponse(errorResponse);
         * response.getErrorResponse().setId(Constants.API_PARTIAL_SUCCESS);
         * response.getErrorResponse().setText(partialSuccessMessage);
         * response.getErrorResponse().setDeveloperText(partialSuccessMessage); responseData.setPartialContent(true); }
         */
        return response;
    }

    private void setReferenceIds(CustomerReferenceId customerReferenceID, ProfileReferenceId profileReferenceId,
            CustomerAccountsRequest customerAccountsRequest, EntityCollectionRequest request) {
        if (!CollectionUtils.isEmpty(customerReferenceID.getReferenceId().toMap())) {
            customerAccountsRequest.setCustomerReferenceId(customerReferenceID);
        }

        if (null != profileReferenceId) {
            customerAccountsRequest.setProfileReferenceId(profileReferenceId);
        }

        if (request.getUserId() != null) {
            EPFContextContainer.getContext().setUserId(request.getUserId());
        } else if (request.getUserId() == null && profileReferenceId != null) {
            EPFContextContainer.getContext().setUserId(profileReferenceId.getSSOID());
        }

    }

    /**
     * validating input request
     * 
     * @param CustomerReferenceId, ProfileReferenceId
     * 
     */
    private void validateInputRequest(CustomerReferenceId customerReferenceId, ProfileReferenceId profileReferenceId) {

        if ((null == customerReferenceId.getReferenceId() || CollectionUtils.isEmpty(customerReferenceId
                .getReferenceId().toMap())) && null == profileReferenceId) {
            throw new RequestValidationException("Please provide CustomerReferenceID or ProfileReferenceID");
        }
        if (null != profileReferenceId && StringUtils.isBlank(profileReferenceId.getSSOID())) {
            throw new RequestValidationException("ProfileReferenceID should have SSOID");
        }

    }

    private void createHeaderParamforDGWAccounts(boolean fromDGW) {
        EPFContextAssist.getContext().setAttribute(Constants.IS360_ACCOUNTS_SOURCED_FROM_DGW, String.valueOf(fromDGW));
    }

}
