package com.capitalone.api.customersaccounts.rest.filter;

import java.io.IOException;

import javax.inject.Named;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.ext.Provider;

import com.capitalone.api.commons.services.util.EPFContextAssist;
import com.capitalone.api.customersaccounts.constant.Constants;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import com.capitalone.api.commons.services.util.EPFContextAssist;
import com.capitalone.api.customersaccounts.constant.Constants;

@Named
@Provider
public class SetHeaderFilter implements ContainerResponseFilter {

    // private Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext)
            throws IOException {

        if (null != EPFContextAssist.getContext().getAttribute("EntSvcgCustID")) {
            responseContext.getHeaders().add(HttpHeaders.CONTENT_LOCATION,
                    EPFContextAssist.getContext().getAttribute("EntSvcgCustID"));

            // logger.debug("Add header = {} with value {}", HttpHeaders.LOCATION,
            // EPFContextAssist.getContext().getAttribute("EntSvcgCustID"));
        }
        if (null != EPFContextAssist.getContext().getAttribute("CustID")) {
            responseContext.getHeaders().add("CustomerReferenceId",
                    EPFContextAssist.getContext().getAttribute("CustID"));
            // logger.debug("Add header = CustomerReferenceId  with value {}",
            // EPFContextAssist.getContext().getAttribute("CustID"));
        }
        
        if (null != EPFContextAssist.getContext().getAttribute(Constants.IS360_ACCOUNTS_SOURCED_FROM_DGW)) {
            responseContext.getHeaders().add(Constants.IS360_ACCOUNTS_SOURCED_FROM_DGW,
                    EPFContextAssist.getContext().getAttribute(Constants.IS360_ACCOUNTS_SOURCED_FROM_DGW));
            // logger.debug("Add header = CustomerReferenceId  with value {}",
            // EPFContextAssist.getContext().getAttribute("CustID"));
        }
    }

}
