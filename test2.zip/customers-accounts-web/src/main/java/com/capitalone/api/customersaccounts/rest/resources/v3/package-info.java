package com.capitalone.api.customersaccounts.rest.resources.v3;

/**
 * Exposed REST resources for customers-accounts functionality.
 */
