package com.capitalone.api.customersaccounts.rest.config;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.ext.MessageBodyReader;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.scheduling.annotation.EnableAsync;

import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.services.ws.rs.ext.InjectionEnabledMessageBodyReader;
import com.capitalone.api.loans.autoloans.accounts.model.v4.AutoLoanAccount;
import com.capitalone.cconlineservicingdls.v1.CCOnLineServicingDLSSoap;
import com.capitalone.cstbusinesscustomeris.v1.CSTBusinessCustomerSignersISSOAP;
import com.capitalone.customerinformationdls.v1.CustomerInformationDLSSoap;
import com.capitalone.ecrcustomerrelationshipsis.v1.ECRCustomerRelationshipsISSoap;
import com.capitalone.ecrcustomerrelationshipsisv2.v2.ECRCustomerRelationshipsISV2Soap;
import com.capitalone.enterpriseaccountsummarysyncorchs.v1.EnterpriseAccountSummarySyncOrchSSoap;
import com.capitalone.epf.servicelocator.JaxWsPortProxyFactoryBean;
import com.capitalone.epf.servicelocator.handlers.EPFJaxWsHandlerResolver;
import com.capitalone.odsbrokerageaccountsis.v1.ODSBrokerageAccountsISSoap;
import com.capitalone.olbaccountpreferencesis.v1.OLBAccountPreferencesISSoap;
import com.capitalone.olbrbankprodcodeis.v1.OLBRBankProdCodeISSoap;
import com.capitalone.profileaccountrelationshipsis.v1.ProfileAccountRelationshipsISSOAP;
import com.capitalone.xesddais.v1.XESDDAISSoap;
import com.capitalone.xesddaisv2.v2.XESDDAISV2Soap;
import com.capitalone.xesloanacctis.v1.XESLoanAcctISSoap;
import com.capitalone.xesrelatedacctis.v1.XESRelatedAcctISSoap;
import com.capitalone.xestdais.v1.XESTDAISSoap;

/**
 * Spring bean configuration class.
 * 
 * @author Generated
 * 
 */
@Configuration
@EnableAsync
@ComponentScan(basePackages = {"com.capitalone.api.customersaccounts"})
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class SpringConfig {

    private static final int MESSAGE_SOURCE_RELOAD_CACHE = 7200;

    @Inject
    private EPFJaxWsHandlerResolver handlerResolver;

    @Inject
    @Named("upf-app-config")
    private org.apache.commons.configuration.Configuration epfApplicationConfigUtil;

    @Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasenames(epfApplicationConfigUtil.getString("error.messages.basename"));
        messageSource.setCacheSeconds(MESSAGE_SOURCE_RELOAD_CACHE);
        return messageSource;
    }

    @Bean
    public MessageSource validationMessages() {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasenames(epfApplicationConfigUtil.getString("validation.messages.basename"));
        messageSource.setCacheSeconds(MESSAGE_SOURCE_RELOAD_CACHE);
        return messageSource;
    }

    /**
     * Repsonsible for creating the proxy factory bean for the location web service.
     * 
     * @return the port proxy factory bean.
     */
    @Bean
    public JaxWsPortProxyFactoryBean ecrCustomerRelationshipsISService() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(ECRCustomerRelationshipsISSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("/ECRCustomerRelationshipsIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/ECRCustomerRelationshipsIS/V1");
        bean.setServiceName("ECRCustomerRelationshipsIS");
        bean.setPortName("ECRCustomerRelationshipsISSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    /**
     * Responsible for returning the actual port type from the jaxws port proxy factory bean.
     * 
     * @return the port type for the locations service
     */
    @Bean(name = "ecrCustomerRelationshipsISSoap")
    public ECRCustomerRelationshipsISSoap ecrCustomerRelationshipsISPortType() {
        JaxWsPortProxyFactoryBean factory = ecrCustomerRelationshipsISService();
        return (ECRCustomerRelationshipsISSoap) factory.getObject();
    }
    
    /**
     * Repsonsible for creating the proxy factory bean for the location web service.
     * 
     * @return the port proxy factory bean.
     */
    @Bean
    public JaxWsPortProxyFactoryBean ecrCustomerRelationshipsISV2Service() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(ECRCustomerRelationshipsISV2Soap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("ECRCustomerRelationshipsISV2.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/ECRCustomerRelationshipsISV2/V2");
        bean.setServiceName("ECRCustomerRelationshipsISV2");
        bean.setPortName("ECRCustomerRelationshipsISV2Soap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    /**
     * Responsible for returning the actual port type from the jaxws port proxy factory bean.
     * 
     * @return the port type for the locations service
     */
    @Bean(name = "ecrCustomerRelationshipsISV2Soap")
    public ECRCustomerRelationshipsISV2Soap ecrCustomerRelationshipsISV2PortType() {
        JaxWsPortProxyFactoryBean factory = ecrCustomerRelationshipsISV2Service();
        return (ECRCustomerRelationshipsISV2Soap) factory.getObject();
    }

    /**
     * Repsonsible for creating the proxy factory bean for the location web service.
     * 
     * @return the port proxy factory bean.
     */
    @Bean
    public JaxWsPortProxyFactoryBean enterpriseAccountSummarySyncOrchSService() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(EnterpriseAccountSummarySyncOrchSSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("EnterpriseAccountSummarySyncOrchS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/EnterpriseAccountSummarySyncOrchS/V1");
        bean.setServiceName("EnterpriseAccountSummarySyncOrchS");
        bean.setPortName("EnterpriseAccountSummarySyncOrchSSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    /**
     * Responsible for returning the actual port type from the jaxws port proxy factory bean.
     * 
     * @return the port type for the locations service
     */
    @Bean(name = "enterpriseAccountSummarySyncOrchSSoap")
    public EnterpriseAccountSummarySyncOrchSSoap enterpriseAccountSummarySyncOrchSPortType() {
        JaxWsPortProxyFactoryBean factory = enterpriseAccountSummarySyncOrchSService();
        return (EnterpriseAccountSummarySyncOrchSSoap) factory.getObject();
    }

    /**
     * Responsible for returning the actual port type from the jaxws port proxy factory bean.
     * 
     * @return the port type for the locations service
     */
    @Bean(name = "xesRelatedAcctISSoap")
    public XESRelatedAcctISSoap xESRelatedAcctISPortType() {
        JaxWsPortProxyFactoryBean factory = xesRelatedAcctISService();
        return (XESRelatedAcctISSoap) factory.getObject();
    }

    /**
     * Responsible for creating the proxy factory bean for the location web service.
     * 
     * @return the port proxy factory bean.
     */
    @Bean
    public JaxWsPortProxyFactoryBean xesRelatedAcctISService() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(XESRelatedAcctISSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("/XESRelatedAcctIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/XESRelatedAcctIS/V1");
        bean.setServiceName("XESRelatedAcctIS");
        bean.setPortName("XESRelatedAcctISSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    /**
     * Responsible for returning the actual port type from the jaxws port proxy factory bean.
     * 
     * @return the port type for the locations service
     */
    @Bean(name = "profileAccountRelationshipsISSOAP")
    public ProfileAccountRelationshipsISSOAP profileAccountRelationshipsISPortType() {
        JaxWsPortProxyFactoryBean factory = profileAccountRelationshipsISService();
        return (ProfileAccountRelationshipsISSOAP) factory.getObject();
    }

    /**
     * Responsible for creating the proxy factory bean for the location web service.
     * 
     * @return the port proxy factory bean.
     */
    @Bean
    public JaxWsPortProxyFactoryBean profileAccountRelationshipsISService() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(ProfileAccountRelationshipsISSOAP.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("/ProfileAccountRelationshipsIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/ProfileAccountRelationshipsIS/V1");
        bean.setServiceName("ProfileAccountRelationshipsIS");
        bean.setPortName("ProfileAccountRelationshipsISSOAP");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    @Bean(name = "cstBusinessCustomerISService")
    public CSTBusinessCustomerSignersISSOAP cstBusinessCustomerISService() {
        JaxWsPortProxyFactoryBean factory = cstBusinessCustomerISServiceFactory();
        return (CSTBusinessCustomerSignersISSOAP) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean cstBusinessCustomerISServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(CSTBusinessCustomerSignersISSOAP.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("/CSTBusinessCustomerIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/CSTBusinessCustomerIS/V1");
        bean.setServiceName("CSTBusinessCustomerIS");
        bean.setPortName("CSTBusinessCustomerSignersISSOAP");
        return bean;
    }

    @Bean(name = "XESDDAISSoap")
    public XESDDAISSoap xesDDAISService() {
        JaxWsPortProxyFactoryBean factory = xesDDAISServiceFactory();
        return (XESDDAISSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean xesDDAISServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(XESDDAISSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("XESDDAIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/XESDDAIS/V1");
        bean.setServiceName("XESDDAIS");
        bean.setPortName("XESDDAISSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }
    
    @Bean(name = "XESDDAISV2Soap")
    public XESDDAISV2Soap xesDDAISV2Service() {
        JaxWsPortProxyFactoryBean factory = xesDDAISServiceV2Factory();
        return (XESDDAISV2Soap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean xesDDAISServiceV2Factory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(XESDDAISV2Soap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("XESDDAISV2.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/XESDDAISV2/V2");
        bean.setServiceName("XESDDAISV2");
        bean.setPortName("XESDDAISV2Soap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }
    
    @Bean(name = "ccOnLineServicingDLSV2Soap")
    public com.capitalone.cconlineservicingdlsv2.v2.CCOnLineServicingDLSSoap ccOnlineServicingDLSV2Service() {
        JaxWsPortProxyFactoryBean factory = ccOnlineServicingDLSV2ServiceFactory();
        return (com.capitalone.cconlineservicingdlsv2.v2.CCOnLineServicingDLSSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean ccOnlineServicingDLSV2ServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(com.capitalone.cconlineservicingdlsv2.v2.CCOnLineServicingDLSSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("CCOnLineServicingDLSV2.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/CCOnLineServicingDLSV2/V2");
        bean.setServiceName("CCOnLineServicingDLSV2");
        bean.setPortName("CCOnLineServicingDLSSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    @Bean(name = "ccOnLineServicingDLSSoap")
    public CCOnLineServicingDLSSoap ccOnlineServicingDLSService() {
        JaxWsPortProxyFactoryBean factory = ccOnlineServicingDLSVServiceFactory();
        return (CCOnLineServicingDLSSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean ccOnlineServicingDLSVServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(CCOnLineServicingDLSSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("CCOnLineServicingDLSV1.0.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/CCOnLineServicingDLS/V1");
        bean.setServiceName("CCOnLineServicingDLS");
        bean.setPortName("CCOnLineServicingDLSSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }
    
    @Bean(name = "CCOnLineServicingDLSV3Soap")
    public com.capitalone.cconlineservicingdlsv3.v3.CCOnLineServicingDLSSoap ccOnlineServicingDLSV3Service() {
        JaxWsPortProxyFactoryBean factory = ccOnlineServicingDLSV3ServiceFactory();
        return (com.capitalone.cconlineservicingdlsv3.v3.CCOnLineServicingDLSSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean ccOnlineServicingDLSV3ServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(com.capitalone.cconlineservicingdlsv3.v3.CCOnLineServicingDLSSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("CCOnLineServicingDLSV3.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/CCOnLineServicingDLSV3/V3");
        bean.setServiceName("CCOnLineServicingDLSV3");
        bean.setPortName("CCOnLineServicingDLSSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    @Bean(name = "XESLoanAcctIS")
    public XESLoanAcctISSoap xesLoanAcctISSoap() {
        JaxWsPortProxyFactoryBean factory = xesLoanAcctISService();
        return (XESLoanAcctISSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean xesLoanAcctISService() {

        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();

        bean.setServiceInterface(XESLoanAcctISSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("XESLoanAcctIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/XESLoanAcctIS/V1");
        bean.setServiceName("XESLoanAcctIS");
        bean.setPortName("XESLoanAcctISSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    @Bean(name = "XESTDAISSoap")
    public XESTDAISSoap xesTDAISService() {
        JaxWsPortProxyFactoryBean factory = xesTDAISServiceFactory();
        return (XESTDAISSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean xesTDAISServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(XESTDAISSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("XESTDAIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/XESTDAIS/V1");
        bean.setServiceName("XESTDAIS");
        bean.setPortName("XESTDAISSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    @Bean(name = "ODSBrokerageAccountsISSoap")
    public ODSBrokerageAccountsISSoap odsBrokerageAccountsISService() {
        JaxWsPortProxyFactoryBean factory = odsBrokerageAccountsISServiceFactory();
        return (ODSBrokerageAccountsISSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean odsBrokerageAccountsISServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(ODSBrokerageAccountsISSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("ODSBrokerageAccountsIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/ODSBrokerageAccountsIS/V1");

        bean.setServiceName("ODSBrokerageAccountsIS");
        bean.setPortName("ODSBrokerageAccountsISSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    @Bean(name = "OLBAccountPreferencesISSoap")
    public OLBAccountPreferencesISSoap olbAccountPreferencesISService() {
        JaxWsPortProxyFactoryBean factory = olbAccountPreferencesISServiceFactory();
        return (OLBAccountPreferencesISSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean olbAccountPreferencesISServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(OLBAccountPreferencesISSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("OLBAccountPreferencesIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/OLBAccountPreferencesIS/V1");

        bean.setServiceName("OLBAccountPreferencesIS");
        bean.setPortName("OLBAccountPreferencesISSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }
    
    
    @Bean(name = "OLBRBankProdCodeISSoap")
    public OLBRBankProdCodeISSoap olbrBankProdCodeISService() {
        JaxWsPortProxyFactoryBean factory = olbrBankProdCodeISServiceFactory();
        return (OLBRBankProdCodeISSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean olbrBankProdCodeISServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(OLBRBankProdCodeISSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("OLBRBankProdCodeIS.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/OLBRBankProdCodeIS/V1");
        bean.setServiceName("OLBRBankProdCodeIS");
        bean.setPortName("OLBRBankProdCodeISSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    @Bean(name = "customerInformationDLSSoap")
    public CustomerInformationDLSSoap customerInformationDLSSoapService() {
        JaxWsPortProxyFactoryBean factory = customerInformationDLSSoapServiceFactory();
        return (CustomerInformationDLSSoap) factory.getObject();
    }

    @Bean
    public JaxWsPortProxyFactoryBean customerInformationDLSSoapServiceFactory() {
        JaxWsPortProxyFactoryBean bean = new JaxWsPortProxyFactoryBean();
        bean.setServiceInterface(CustomerInformationDLSSoap.class);
        bean.setWsdlDocumentUrl(getClass().getClassLoader().getResource("CustomerInformationDLS_V1.0.wsdl"));
        bean.setNamespaceUri("http://capitalone.com/CustomerInformationDLS/V1");
        bean.setServiceName("CustomerInformationDLS");
        bean.setPortName("CustomerInformationDLSSoap");
        bean.setHandlerResolver(handlerResolver);
        return bean;
    }

    @Bean
    public MessageBodyReader<AutoLoanAccount> autoLoanAccountMessageBodyReader() { /*
                                                                                    * Note the trailing {} to create the
                                                                                    * inline class
                                                                                    */
        return new InjectionEnabledMessageBodyReader<AutoLoanAccount>(AutoLoanAccount.class) {
        };
    }

    @Bean
    public MessageBodyReader<ErrorResponse> autoLoanAccountErrorMessageBodyReader() { /*
                                                                                       * Note the trailing {} to create
                                                                                       * the inline class
                                                                                       */
        return new InjectionEnabledMessageBodyReader<ErrorResponse>(ErrorResponse.class) {
        };
    }

}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
