package com.capitalone.api.integration.profile.accounts.service.util;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;

import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.exception.UnauthorizedException;
import com.capitalone.api.commons.security.ApiSecurityContext;
import com.capitalone.api.integration.profile.accounts.service.constants.Constants;

@Named
public class ProfileAccountsServiceUtil {

    @Inject
    private ApiSecurityContext apiSecurityContext;

    /**
     * Checks to ensure that for a CLIENT role (internal application), a UserId is passed in.
     * 
     * @param userId
     */
    public void authorize(String userId) {
        if (apiSecurityContext.isUserInRole(ApiSecurityContext.CLIENT_ROLE) && StringUtils.isBlank(userId)) {
            throw new UnauthorizedException(new ApiErrorCode(ApiErrorCode.AUTHORIZATION_FAILURE,
                    ApiErrorCode.AUTHORIZATION_FAILURE, Constants.DEVTEXTID_NOUSERID));
        }
    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
