package com.capitalone.api.integration.profile.accounts.service.api;

import com.capitalone.api.integration.profile.accounts.model.v3.UpdateProfileAccountDetailsRequest;

/**
 * This service written for updating the account nickname which is called from int-amq-account-nickname-lobsync
 * 
 * @author flm467 - Raghavendra Rao Julakanti
 *
 */
public interface UpdateProfileAccountsService {

    /**
     * SetAccountDetails
     * 
     * @param accountNumber
     * @param cif
     * @param updateDetails {@link UpdateProfileAccountDetails}
     */
    void setAccountDetails(String accountNumber, String cif,
            UpdateProfileAccountDetailsRequest updateProfileAccountDetailsRequest);
}
/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

