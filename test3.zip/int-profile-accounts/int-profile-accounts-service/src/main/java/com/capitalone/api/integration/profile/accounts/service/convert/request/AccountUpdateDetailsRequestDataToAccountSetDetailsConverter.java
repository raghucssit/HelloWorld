package com.capitalone.api.integration.profile.accounts.service.convert.request;

import javax.inject.Named;

import com.capitalone.api.bank.lib.profile.accounts.dao.model.AccountUpdateRequest;
import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.integration.profile.accounts.model.v3.AccountUpdateDetailsRequestData;

/**
 * This is a converter from IS(LibraryAccountRequest) request to library request(AccountUpdateRequest).
 * 
 * @author flm467 - Raghavendra Rao Julakanti
 *
 */
@Named
@Trace
@Profile
public class AccountUpdateDetailsRequestDataToAccountSetDetailsConverter extends
        ConversionServiceAwareConverter<AccountUpdateDetailsRequestData, AccountUpdateRequest> {

    /**
     * To convert the api request data to library input data.
     * 
     * @param source of type <code>LibraryAccountRequest</code>
     * @return <code>AccountUpdateRequest</code>
     */
    @Override
    public AccountUpdateRequest convert(AccountUpdateDetailsRequestData accountUpdateDetailsRequestData) {

        AccountUpdateRequest accountUpdateRequest = new AccountUpdateRequest();
        accountUpdateRequest.setCif(accountUpdateDetailsRequestData.getCif());
        accountUpdateRequest.setAccountNumber(accountUpdateDetailsRequestData.getAccountNumber());
        accountUpdateRequest.setAccountNickname(accountUpdateDetailsRequestData.getAccountNickname());
        return accountUpdateRequest;
    }

}
