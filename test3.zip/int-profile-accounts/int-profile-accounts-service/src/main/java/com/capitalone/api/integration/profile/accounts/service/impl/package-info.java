/**
 * These are the implementations for the service interfaces {@link com.capitalone.api.integration.profile.accounts.service.api} for the int-profile-accounts functionality.
 */
package com.capitalone.api.integration.profile.accounts.service.impl;