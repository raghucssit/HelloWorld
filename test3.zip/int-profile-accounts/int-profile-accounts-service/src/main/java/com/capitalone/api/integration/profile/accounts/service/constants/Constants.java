package com.capitalone.api.integration.profile.accounts.service.constants;

public class Constants {

    public static final String DEVTEXTID_ACCTNOTFOUND = "900001";

    public static final String DEVTEXTID_INVALIDACCTNUMBER = "900002";

    public static final String DEVTEXTID_NOUSERID = "900003";

    /**
     * Added to suppress avaialable balance based on Restriction Code by Max Moise [yib519] Team GSD -- 10/02/2015
     */
    public static final String RESTRICTION_CODE_38 = "0038";
    public static final String RESTRICTION_CODE_17 = "0017";

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
