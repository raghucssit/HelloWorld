package com.capitalone.api.integration.profile.accounts.service.impl;

import com.capitalone.api.bank.lib.profile.accounts.dao.ProfileAccountsDAO;
import com.capitalone.api.bank.lib.profile.accounts.dao.model.ProfileAccount;
import com.capitalone.api.bank.lib.profile.accounts.dao.model.RestrictionCodes;
import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.services.base.AbstractBaseService;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.integration.profile.accounts.model.v3.RetrieveProfileAccountDetailsRequest;
import com.capitalone.api.integration.profile.accounts.service.api.ProfileAccountsService;
import com.capitalone.api.integration.profile.accounts.service.constants.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import java.math.BigDecimal;
import java.util.ArrayList;

@Profile
@Trace
@Named
public class ProfileAccountServiceImpl extends AbstractBaseService implements ProfileAccountsService {

    private static final Logger logger = LoggerFactory.getLogger(ProfileAccountsService.class);

    @Inject
    private ProfileAccountsDAO profileAccountDAO;

    /**
     * {@inheritDoc}
     */
    @Override
    public ProfileAccountDetail retrieveProfileAccountDetails(RetrieveProfileAccountDetailsRequest request) {
        logger.debug("Fetching account details from Profile ..");

        ProfileAccount accountDetail = profileAccountDAO.retrieveAccountDetails(request.getAccountNumber());
        boolean suppressFlag = suppressBalance(accountDetail);
        ProfileAccountDetail profileAccountDetail = conversionService.convert(accountDetail, ProfileAccountDetail.class);

        //Suppress the available balance if the applicable restriction is present
        if(suppressFlag) {
            profileAccountDetail.setAvailableBalance(BigDecimal.ZERO);
        }

        return profileAccountDetail;
    }
    
    @Override
    public void health() {
    	profileAccountDAO.health();
    }

    public boolean suppressBalance(ProfileAccount accountDetail)
    {
        ArrayList<RestrictionCodes> restrictionList = accountDetail.getRestrictionCode();
        for(RestrictionCodes restriction : restrictionList)
        {
            if(restriction.getRestrictionCode() != null && restriction.getRestrictionCode()
                    .equals(Constants.RESTRICTION_CODE_17)) {
                return true;
            }
        }
        return false;
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
