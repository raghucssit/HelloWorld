package com.capitalone.api.integration.profile.accounts.service.convert.response;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Map;

import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import com.capitalone.api.bank.lib.profile.accounts.dao.model.ProfileAccount;
import com.capitalone.api.bank.lib.profile.accounts.dao.model.RestrictionCodes;
import com.capitalone.api.commons.services.convert.ConversionServiceAwareConverter;
import com.capitalone.api.commons.services.referencedata.ReferenceDataService;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.integration.profile.accounts.model.v3.RestrictionCode;

@Named
public class ToProfileAccountDetailResponseConverter extends
        ConversionServiceAwareConverter<ProfileAccount, ProfileAccountDetail> {

    private static final String PRODUCT_ID_360_CHECKING = "4000";

    private static final String PRODUCT_ID_BUSINESS_CHECKING = "4500";

    private static final String BALANCE_ZERO = "0.00";

    private static final String OWNERSHIP_TYPE_TRUST = "Trust";

    private static final String HYPHEN = "-";

    private static final String CATNAME_NATIVETOAPIPRODTYPES = "NativeProdTypetoAPIProdType";

    private static final String ATTRNAME_APIPRODTYPECODE = "APIProductTypeCode";

    private static final String ATTRNAME_APIPRODTYPEDESC = "APIProductTypeDesc";

    @Inject
    private ReferenceDataService<String> referenceDataService;

    @Override
    public ProfileAccountDetail convert(ProfileAccount source) {
        ProfileAccountDetail profileAccountDetail = new ProfileAccountDetail();

        profileAccountDetail.setAccountNumber(source.getAccountNumber());
        profileAccountDetail.setAccountNickname(source.getAccountNickname());
        profileAccountDetail.setAccountStatus(source.getAccountStatus());
        profileAccountDetail.setLedgerBalance(source.getLedgerBalance());
        profileAccountDetail.setAvailableBalance(computeAvailableBalance(source));
        profileAccountDetail.setOpenDate(source.getOpenDate());
        profileAccountDetail.setClosedDate(source.getClosedDate());
        profileAccountDetail.setRestrictionsIndicator(source.getRestrictionsIndicator());
        profileAccountDetail.setRetirementAccountIndicator(source.getRetirementAccountIndicator());
        profileAccountDetail.setRetirementAccountType(source.getRetirementAccountType());
        profileAccountDetail.setIsUnderBankruptcyIndicator(source.getUnderBankruptcyIndicator());
        profileAccountDetail.setPaymentDueDate(source.getLoanPaymentDueDate());
        profileAccountDetail.setDueDate(source.getOverdraftDueDate());
        profileAccountDetail.setLastPaymentDt(source.getLastPaymentDt());
        profileAccountDetail.setLoanAmountDue(source.getLoanAmountDue());
        profileAccountDetail.setTotalDue(source.getTotalDue());
        profileAccountDetail.setPrincipalBalance(source.getLoanPrincipalBalance());
        profileAccountDetail.setNonAccrualIndicator(source.getNonAccuralIndicator());
        profileAccountDetail.setIsCheckFreeBillPayProcessingComplete(source.isCheckFreeBillPayProcessingComplete());
        profileAccountDetail.setPrimaryCustomerNumber(ObjectUtils.toString(source.getPrimaryCustomerNumber(), null));
        profileAccountDetail
                .setSecondaryCustomerNumber(ObjectUtils.toString(source.getSecondaryCustomerNumber(), null));
        profileAccountDetail.setIsKsaAccount(source.isKsaAccount());
        profileAccountDetail.setOverdraftCreditLimit(source.getOverdraftCreditLimit());
        profileAccountDetail.setOverdraftLedgerBalance(source.getOverdraftCreditUsed());
        profileAccountDetail.setMonthlyWithdrawalCount(source.getMonthlyWithdrawalCount());

        ArrayList<RestrictionCode> restrictionCodes = null;
        if (source.getRestrictionCode().size() > 0) {
            restrictionCodes = new ArrayList<RestrictionCode>();
            for (RestrictionCodes codes : source.getRestrictionCode()) {
                RestrictionCode code = new RestrictionCode();
                code.setRestrictionCode(codes.getRestrictionCode());
                code.setRestrictionDescription(codes.getRestrictionDescription());
                restrictionCodes.add(code);
            }
        }
        profileAccountDetail.setRestrictions(restrictionCodes);

        // Set Product Details
        setProductDetails(source, profileAccountDetail);

        return profileAccountDetail;
    }

    /**
     * Set Product Details
     * 
     * @param source
     * @param profileAccountDetail
     */
    private void setProductDetails(ProfileAccount source, ProfileAccountDetail profileAccountDetail) {
        profileAccountDetail.setProduct(source.getProduct());

        if (StringUtils.equalsIgnoreCase(source.getOwnershipType(), OWNERSHIP_TYPE_TRUST)) {
            StringBuffer productName = new StringBuffer(profileAccountDetail.getProduct().getProductName());
            productName.append(StringUtils.SPACE).append(HYPHEN).append(StringUtils.SPACE).append(OWNERSHIP_TYPE_TRUST);
            profileAccountDetail.getProduct().setProductName(productName.toString());
        }

        // Setting ProductTypeCode and Description from NativeProdTypetoAPIProdType ReferenceData
        Map<String, String> attributeMap = referenceDataService.getEntity(CATNAME_NATIVETOAPIPRODTYPES, 1,
                source.getProduct().getProductTypeCode()).getAttributeMap();

        if (!attributeMap.isEmpty()) {
            profileAccountDetail.getProduct().setProductTypeCode(attributeMap.get(ATTRNAME_APIPRODTYPECODE));
            profileAccountDetail.getProduct().setProductTypeDescription(attributeMap.get(ATTRNAME_APIPRODTYPEDESC));
        }
    }

    /**
     * Compute available balance based on the type of the account.
     * 
     * @param profileAccountAvailableBalance
     * @return
     */
    private BigDecimal computeAvailableBalance(ProfileAccount profileAccountDetail) {
        BigDecimal effectiveAvailableBalance = profileAccountDetail.getIndividualAccountAvailableBalance() != null ? profileAccountDetail
                .getIndividualAccountAvailableBalance() : NumberUtils.createBigDecimal(BALANCE_ZERO);

        // Perform below computation only in the case of a 360 Regular / Business Checking so that overdraftCreditUsed
        // is always subtracted from individual account available balance.
        if (profileAccountDetail.getOverdraftCreditUsed() != null
                && (PRODUCT_ID_360_CHECKING.equalsIgnoreCase(profileAccountDetail.getProduct().getProductId()) || PRODUCT_ID_BUSINESS_CHECKING
                        .equalsIgnoreCase(profileAccountDetail.getProduct().getProductId()))) {
            effectiveAvailableBalance = effectiveAvailableBalance.subtract(profileAccountDetail
                    .getOverdraftCreditUsed());
        }

        return effectiveAvailableBalance;
    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
