package com.capitalone.api.integration.profile.accounts.service.api;

import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.integration.profile.accounts.model.v3.RetrieveProfileAccountDetailsRequest;

public interface ProfileAccountsService {

    /**
     * Retrieves Profile Account Details via the account number.
     * 
     * @param request
     * @return
     */
    ProfileAccountDetail retrieveProfileAccountDetails(RetrieveProfileAccountDetailsRequest request);
    
    void health();
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
