/**
 * These are the exposed service interfaces for the int-profile-accounts functionality.
 */
package com.capitalone.api.integration.profile.accounts.service.api;