package com.capitalone.api.integration.profile.accounts.service.impl;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.bank.lib.profile.accounts.dao.ProfileAccountsDAO;
import com.capitalone.api.bank.lib.profile.accounts.dao.model.AccountUpdateRequest;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.integration.profile.accounts.model.v3.AccountUpdateDetailsRequestData;
import com.capitalone.api.integration.profile.accounts.model.v3.UpdateProfileAccountDetailsRequest;

@RunWith(MockitoJUnitRunner.class)
@Category(UnitTest.class)
public class UpdateProfileAccountsServiceImplTest {

    @InjectMocks
    private UpdateProfileAccountsServiceImpl updateProfileAccountsServiceImpl;

    @Mock
    private ConversionService conversionService;

    @Mock
    private AccountUpdateDetailsRequestData accountUpdateDetailsRequestData;

    @Mock
    private UpdateProfileAccountDetailsRequest updateProfileAccountDetailsRequest;

    @Mock
    private AccountUpdateRequest accUpRq;

    @Mock
    private ProfileAccountsDAO profileAccountDAO;

    @Test
    public void testSetAccountDetails() {

        Mockito.when(
                conversionService.convert(any(AccountUpdateDetailsRequestData.class), eq(AccountUpdateRequest.class)))
                .thenReturn(accUpRq);
        updateProfileAccountsServiceImpl.setAccountDetails("34532523", "2345234", updateProfileAccountDetailsRequest);
        Mockito.verify(profileAccountDAO).setAccountDetail(accUpRq);
    }
}
