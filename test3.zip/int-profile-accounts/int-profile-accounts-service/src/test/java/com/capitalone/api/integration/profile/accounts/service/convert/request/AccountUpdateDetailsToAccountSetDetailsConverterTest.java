package com.capitalone.api.integration.profile.accounts.service.convert.request;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.convert.converter.Converter;

import com.capitalone.api.bank.lib.profile.accounts.dao.model.AccountUpdateRequest;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.integration.profile.accounts.model.v3.AccountUpdateDetailsRequestData;

@RunWith(MockitoJUnitRunner.class)
@Category(UnitTest.class)
public class AccountUpdateDetailsToAccountSetDetailsConverterTest {

	private Converter<AccountUpdateDetailsRequestData, AccountUpdateRequest> converter;
	
	@Before
    public void setUp() {
        converter = new AccountUpdateDetailsRequestDataToAccountSetDetailsConverter();
    }
	
		
	
	
	@Test
	public void testConvert(){
		AccountUpdateDetailsRequestData source = new AccountUpdateDetailsRequestData();
		source.setAccountNickname("TeamOnyx");
		source.setCif("432343");
		source.setAccountNumber("528288857852822");
		
		AccountUpdateRequest output = converter.convert(source);
		assertNotNull(output);
		assertNotNull(output.getAccountNickname());
		assertNotNull(output.getCif());
		assertNotNull(output.getAccountNumber());
	}
	
}
