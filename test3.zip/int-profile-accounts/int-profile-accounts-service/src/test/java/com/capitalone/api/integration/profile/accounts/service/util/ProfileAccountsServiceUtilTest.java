package com.capitalone.api.integration.profile.accounts.service.util;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.exception.UnauthorizedException;
import com.capitalone.api.commons.security.ApiSecurityContext;

@RunWith(MockitoJUnitRunner.class)
public class ProfileAccountsServiceUtilTest {
    @InjectMocks
    private ProfileAccountsServiceUtil profileAccountsServiceUtil;

    @Mock
    private ApiSecurityContext apiSecurityContext;

    @Mock
    private UnauthorizedException unauthorizedException;

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testauthorizesuccess() {
        Mockito.when(apiSecurityContext.isUserInRole(ApiSecurityContext.CLIENT_ROLE)).thenReturn(true);
        profileAccountsServiceUtil.authorize("abcd");
    }

    @Test(expected = UnauthorizedException.class)
    public void testauthorizefails() {
        Mockito.when(apiSecurityContext.isUserInRole(ApiSecurityContext.CLIENT_ROLE)).thenReturn(true);
        profileAccountsServiceUtil.authorize("");
    }

}
