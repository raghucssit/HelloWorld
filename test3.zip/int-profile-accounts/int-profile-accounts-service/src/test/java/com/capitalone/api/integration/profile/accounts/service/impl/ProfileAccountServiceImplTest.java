package com.capitalone.api.integration.profile.accounts.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;

import java.util.ArrayList;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.LoggerFactory;
import org.springframework.core.convert.ConversionService;

import com.capitalone.api.bank.lib.profile.accounts.dao.ProfileAccountsDAO;
import com.capitalone.api.bank.lib.profile.accounts.dao.model.ProfileAccount;
import com.capitalone.api.bank.lib.profile.accounts.dao.model.RestrictionCodes;
import com.capitalone.api.commons.model.referencedata.ReferenceDataEntity;
import com.capitalone.api.commons.services.referencedata.ReferenceDataService;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.integration.profile.accounts.model.v3.RetrieveProfileAccountDetailsRequest;

@RunWith(MockitoJUnitRunner.class)
public class ProfileAccountServiceImplTest {

    private org.slf4j.Logger logger = LoggerFactory.getLogger(getClass());

    @InjectMocks
    private ProfileAccountServiceImpl profileAccountServiceImpl;

    @Mock
    private ProfileAccountsDAO profileAccountsDAO;

    @Mock
    private ProfileAccountDetail profileAccountDetail;

    @Mock
    private RetrieveProfileAccountDetailsRequest request;

    @Mock
    private ProfileAccount accountDetail;

    @Mock
    private ConversionService conversionService;

    @Mock
    private ReferenceDataService<String> referenceDataService;

    @Mock
    private ReferenceDataEntity<String> referenceDataEntity;

    @Mock
    private Map<String, String> attributeMap;

    private static final String MOCK_STRING = "MOCK_STRING";

    @Before
    public void setUp() throws Exception {
        Mockito.when(referenceDataService.getEntity(anyString(), anyInt(), anyString()))
                .thenReturn(referenceDataEntity);
        Mockito.when(referenceDataEntity.getAttributeMap()).thenReturn(attributeMap);
        Mockito.when(attributeMap.isEmpty()).thenReturn(false);
        Mockito.when(attributeMap.get(anyString())).thenReturn(MOCK_STRING);
    }

    @Test
    public void testretrieveProfileAccountDetails() {

        Mockito.when(request.getAccountNumber()).thenReturn("123");
        logger.info(request.getAccountNumber());
        Mockito.when(profileAccountsDAO.retrieveAccountDetails(request.getAccountNumber())).thenReturn(accountDetail);
        Mockito.when(conversionService.convert(accountDetail, ProfileAccountDetail.class)).thenReturn(
                profileAccountDetail);
        ArrayList<RestrictionCodes> restrictionCodesList = new ArrayList<RestrictionCodes>();
        Mockito.when(accountDetail.getRestrictionCode()).thenReturn(restrictionCodesList);

        profileAccountDetail = profileAccountServiceImpl.retrieveProfileAccountDetails(request);

        assertNotNull(profileAccountDetail);

    }

    @Test
    public void testsuppressBalance() {

        RestrictionCodes restrictionCode = new RestrictionCodes();
        restrictionCode.setRestrictionCode("0011");

        ArrayList<RestrictionCodes> restrictionCodesList = new ArrayList<RestrictionCodes>();
        restrictionCodesList.add(restrictionCode);

        ProfileAccount profAccntDetail = new ProfileAccount();
        profAccntDetail.setRestrictionCode(restrictionCodesList);

        boolean suppressedFlg = profileAccountServiceImpl.suppressBalance(profAccntDetail);
        assertFalse(suppressedFlg);

        restrictionCode.setRestrictionCode("0017");
        suppressedFlg = profileAccountServiceImpl.suppressBalance(profAccntDetail);
        assertTrue(suppressedFlg);
    }

    @Test
    public void health() {
        profileAccountServiceImpl.health();
        Mockito.verify(profileAccountsDAO).health();
    }


}
