package com.capitalone.api.integration.profile.accounts.service.convert.response;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.joda.time.LocalDate;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.bank.lib.profile.accounts.dao.model.ProfileAccount;
import com.capitalone.api.bank.lib.profile.accounts.dao.model.RestrictionCodes;
import com.capitalone.api.commons.model.referencedata.ReferenceDataEntity;
import com.capitalone.api.commons.services.referencedata.ReferenceDataService;
import com.capitalone.api.commons.test.categories.UnitTest;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.model.product.Product;

/**
 * @author UTP596 - Hariharbalaji Vadivel
 * @since 1.0
 */
@Category(UnitTest.class)
@RunWith(MockitoJUnitRunner.class)
public class ToProfileAccountDetailResponseConverterTest {

    @InjectMocks
    private ToProfileAccountDetailResponseConverter converter;

    @Mock
    private ProfileAccount account;

    @Mock
    private Product product;

    private LocalDate localDate;

    @Mock
    private RestrictionCodes restrictionCode;

    private static final String MOCK_STRING = "MOCK_STRING";

    private static final String MOCK_STRING_1 = "MOCK_STRING_1";

    private static final BigDecimal MOCK_DECIMAL = BigDecimal.ONE;

    private static final boolean MOCK_BOOLEAN_TRUE = true;

    private static final boolean MOCK_BOOLEAN_FALSE = false;

    private static final int MOCK_CUSTOMER_NUMBER = 123654;

    private static final String MOCK_OWNERSHIP_SINGLE = "Single";

    private static final String MOCK_OWNERSHIP_TRUST = "Trust";

    private static final String PRODUCT_ID_360_CHECKING = "4000";

    private static final String PRODUCT_ID_BUSINESS_CHECKING = "4500";

    @Mock
    private ReferenceDataService<String> referenceDataService;

    @Mock
    private ReferenceDataEntity<String> referenceDataEntity;

    @Mock
    private Map<String, String> attributeMap;

    @Before
    public void setUp() {

        localDate = new LocalDate(new Date());
        Mockito.when(account.getAccountNickname()).thenReturn(MOCK_STRING);

        Mockito.when(account.getProduct()).thenReturn(product);

        Mockito.when(account.getAccountStatus()).thenReturn(MOCK_STRING);
        Mockito.when(account.getLedgerBalance()).thenReturn(MOCK_DECIMAL);

        Mockito.when(account.getIndividualAccountAvailableBalance()).thenReturn(MOCK_DECIMAL);
        Mockito.when(account.getOverdraftCreditUsed()).thenReturn(MOCK_DECIMAL);

        Mockito.when(account.getOpenDate()).thenReturn(localDate);
        Mockito.when(account.getClosedDate()).thenReturn(localDate);
        Mockito.when(account.getRestrictionsIndicator()).thenReturn(MOCK_BOOLEAN_TRUE);
        Mockito.when(account.getRetirementAccountIndicator()).thenReturn(MOCK_BOOLEAN_FALSE);
        Mockito.when(account.getRetirementAccountType()).thenReturn(MOCK_STRING);
        Mockito.when(account.getUnderBankruptcyIndicator()).thenReturn(MOCK_BOOLEAN_FALSE);
        Mockito.when(account.getLoanPaymentDueDate()).thenReturn(localDate);
        Mockito.when(account.getOverdraftDueDate()).thenReturn(localDate);
        Mockito.when(account.getLastPaymentDt()).thenReturn(localDate);
        Mockito.when(account.getLoanAmountDue()).thenReturn(MOCK_DECIMAL);
        Mockito.when(account.getTotalDue()).thenReturn(MOCK_DECIMAL);
        Mockito.when(account.getLoanPrincipalBalance()).thenReturn(MOCK_DECIMAL);
        Mockito.when(account.getNonAccuralIndicator()).thenReturn(0);
        Mockito.when(account.isCheckFreeBillPayProcessingComplete()).thenReturn(MOCK_BOOLEAN_FALSE);
        Mockito.when(account.getPrimaryCustomerNumber()).thenReturn(MOCK_CUSTOMER_NUMBER);
        Mockito.when(account.getSecondaryCustomerNumber()).thenReturn(MOCK_CUSTOMER_NUMBER);
        Mockito.when(account.isKsaAccount()).thenReturn(MOCK_BOOLEAN_FALSE);

        ArrayList<RestrictionCodes> restrictionCodes = new ArrayList<RestrictionCodes>();
        restrictionCodes.add(restrictionCode);
        Mockito.when(account.getRestrictionCode()).thenReturn(restrictionCodes);

        Mockito.when(account.getOwnershipType()).thenReturn(MOCK_OWNERSHIP_SINGLE);

        Mockito.when(referenceDataService.getEntity(anyString(), anyInt(), anyString()))
                .thenReturn(referenceDataEntity);
        Mockito.when(referenceDataEntity.getAttributeMap()).thenReturn(attributeMap);
        Mockito.when(attributeMap.isEmpty()).thenReturn(false);
        Mockito.when(attributeMap.get(anyString())).thenReturn(MOCK_STRING);
    }

    @Test
    public void testSuccess() {
        ProfileAccountDetail accountDetail = converter.convert(account);
        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance(), Matchers.is(BigDecimal.ONE));
        MatcherAssert.assertThat(accountDetail.getRestrictions(), Matchers.hasSize(1));
    }

    @Test
    public void testCheckingacct() {
        Mockito.when(product.getProductId()).thenReturn(PRODUCT_ID_360_CHECKING);
        ProfileAccountDetail accountDetail = converter.convert(account);
        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance(), Matchers.is(BigDecimal.ZERO));
    }

    @Test
    public void testBusinessCheckingacct() {
        Mockito.when(product.getProductId()).thenReturn(PRODUCT_ID_BUSINESS_CHECKING);
        ProfileAccountDetail accountDetail = converter.convert(account);
        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance(), Matchers.is(BigDecimal.ZERO));
    }

    @Test
    public void testBalanceZero() {
        Mockito.when(account.getIndividualAccountAvailableBalance()).thenReturn(null);
        ProfileAccountDetail accountDetail = converter.convert(account);
        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance().intValue(),
                Matchers.is(BigDecimal.ZERO.intValue()));
    }

    @Test
    public void testOverdraftCreditUsed() {
        Mockito.when(account.getOverdraftCreditUsed()).thenReturn(null);
        ProfileAccountDetail accountDetail = converter.convert(account);
        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance(), Matchers.is(BigDecimal.ONE));
    }

    @Test
    public void testNorestriction() {
        Mockito.when(account.getRestrictionsIndicator()).thenReturn(MOCK_BOOLEAN_FALSE);

        ArrayList<RestrictionCodes> restrictionCodes = new ArrayList<RestrictionCodes>();
        Mockito.when(account.getRestrictionCode()).thenReturn(restrictionCodes);

        ProfileAccountDetail accountDetail = converter.convert(account);
        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance(), Matchers.is(BigDecimal.ONE));
        MatcherAssert.assertThat(accountDetail.getRestrictions(), Matchers.nullValue());
    }

    @Test
    public void testTrustAccount() {

        Mockito.when(account.getOwnershipType()).thenReturn(MOCK_OWNERSHIP_TRUST);
        Mockito.when(product.getProductName()).thenReturn(MOCK_STRING);

        ProfileAccountDetail accountDetail = converter.convert(account);
        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance(), Matchers.is(BigDecimal.ONE));
        MatcherAssert.assertThat(accountDetail.getRestrictions(), Matchers.hasSize(1));
        MatcherAssert.assertThat(accountDetail.getProduct().getProductName(), Matchers.containsString(MOCK_STRING));
    }

    @Test
    public void testAttributeMapEmpty() {

        Mockito.when(product.getProductName()).thenReturn(MOCK_STRING);
        Mockito.when(product.getProductTypeCode()).thenReturn(MOCK_STRING);
        Mockito.when(product.getProductTypeDescription()).thenReturn(MOCK_STRING);
        Mockito.when(attributeMap.isEmpty()).thenReturn(true);

        ProfileAccountDetail accountDetail = converter.convert(account);
        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance(), Matchers.is(BigDecimal.ONE));
        MatcherAssert.assertThat(accountDetail.getRestrictions(), Matchers.hasSize(1));
        MatcherAssert.assertThat(accountDetail.getProduct().getProductName(), Matchers.containsString(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getProduct().getProductTypeCode(), Matchers.containsString(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getProduct().getProductTypeDescription(),
                Matchers.containsString(MOCK_STRING));
    }

    @Test
    public void testAttributeMapNotEmpty() {

        Mockito.when(product.getProductName()).thenReturn(MOCK_STRING);
        Mockito.when(product.getProductTypeCode()).thenReturn(MOCK_STRING_1);
        Mockito.when(product.getProductTypeDescription()).thenReturn(MOCK_STRING_1);

        ProfileAccountDetail accountDetail = converter.convert(account);
        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance(), Matchers.is(BigDecimal.ONE));
        MatcherAssert.assertThat(accountDetail.getRestrictions(), Matchers.hasSize(1));
        MatcherAssert.assertThat(accountDetail.getProduct().getProductName(), Matchers.containsString(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getProduct().getProductTypeCode(), Matchers.containsString(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getProduct().getProductTypeDescription(),
                Matchers.containsString(MOCK_STRING));
    }

    @Test
    public void testOLOCAccountResponse() {

        Mockito.when(account.getOverdraftCreditLimit()).thenReturn(BigDecimal.TEN);
        Mockito.when(account.getOverdraftCreditUsed()).thenReturn(BigDecimal.ONE);

        ProfileAccountDetail accountDetail = converter.convert(account);

        MatcherAssert.assertThat(accountDetail, Matchers.notNullValue());
        MatcherAssert.assertThat(accountDetail.getAccountNickname(), Matchers.is(MOCK_STRING));
        MatcherAssert.assertThat(accountDetail.getAvailableBalance(), Matchers.is(BigDecimal.ONE));
        MatcherAssert.assertThat(accountDetail.getRestrictions(), Matchers.hasSize(1));
        MatcherAssert.assertThat(accountDetail.getOverdraftCreditLimit(), Matchers.is(BigDecimal.TEN));
        MatcherAssert.assertThat(accountDetail.getOverdraftLedgerBalance(), Matchers.is(BigDecimal.ONE));
    }

}

/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
