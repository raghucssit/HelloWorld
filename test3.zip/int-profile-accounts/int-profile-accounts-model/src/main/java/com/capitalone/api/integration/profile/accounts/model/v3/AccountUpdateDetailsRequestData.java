package com.capitalone.api.integration.profile.accounts.model.v3;

import java.io.Serializable;

/**
 * This class for DGW library call purpose  
 * 
 * @author flm467 - Raghavendra Rao Julakanti
 *
 */
public class AccountUpdateDetailsRequestData implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Holds accountNumber
	 */
	private String accountNumber;
	
	/**
	 * Holds CIF
	 */
	private String cif;
	
	/**
	 * Holds account Nickname
	 */
	private String accountNickname;
	
	/**
	 * To  get the account number
	 * 
	 * @return
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	
	/**
	 * To set the account number
	 * 
	 * @param accountNumber
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * To get the CIF 
	 * 
	 * @return
	 */
	public String getCif() {
		return cif;
	}

	/**
	 * To set the CIF
	 * 
	 * @param cif
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * To get the account nickname
	 * 
	 * @return
	 */
	public String getAccountNickname() {
		return accountNickname;
	}

	/**
	 * To set the account nickname
	 * 
	 * @param accountNickname
	 */
	public void setAccountNickname(String accountNickname) {
		this.accountNickname = accountNickname;
	}
}
/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
