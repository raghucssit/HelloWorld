package com.capitalone.api.integration.profile.accounts.model.v3;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

/**
 * This is for to call the   
 * 
 * @author flm467 - Raghavendra Rao Julakanti
 *
 */
@ApiModel(value = "Represents a customer's account model")
@XmlType(name = "", propOrder = { "accountNickname"})
public class UpdateProfileAccountDetailsRequest implements Serializable{

	/**
	 * SerialVersionUID for the class 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Holds account nickname
	 */
	@ApiModelProperty("This is the account nickname to be set by the customer for an LOB account.")
    @Audited
	private String accountNickname;
	
	/**
	 * To get the account nickname
	 * 
	 * @return
	 */
	public String getAccountNickname() {
		return accountNickname;
	}

	/**
	 * To set the account nickname 
	 * 
	 * @param accountNickname
	 */
	public void setAccountNickname(String accountNickname) {
		this.accountNickname = accountNickname;
	}
}
/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
