package com.capitalone.api.integration.profile.accounts.model.v3;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

/**
 * Restriction Codes
 * 
 * @since 1.0
 */
@ApiModel(value = "Represents a Restriction Codes for Capital One")
@XmlRootElement(name = "RestrictionCodes", namespace = "http://api.capitalone.com/v3/integration/profile/accounts")
@XmlType(propOrder = {}, namespace = "http://api.capitalone.com/v3/integration/profile/accounts")
public class RestrictionCode implements Serializable {

    private static final long serialVersionUID = 2L;

    @ApiModelProperty("The customer recognizable account number that is present on the check and is also displayed online and on customer service applications.")
    @Audited
    private String restrictionCode;

    @ApiModelProperty("Enterprise representation of the product for the account.")
    @Audited
    private String restrictionDescription;

    /**
     * @return the restrictionCode
     */
    public String getRestrictionCode() {
        return restrictionCode;
    }

    /**
     * @param restrictionCode the restrictionCode to set
     */
    public void setRestrictionCode(String restrictionCode) {
        this.restrictionCode = restrictionCode;
    }

    /**
     * @return the restrictionDescription
     */
    public String getRestrictionDescription() {
        return restrictionDescription;
    }

    /**
     * @param restrictionDescription the restrictionDescription to set
     */
    public void setRestrictionDescription(String restrictionDescription) {
        this.restrictionDescription = restrictionDescription;
    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
