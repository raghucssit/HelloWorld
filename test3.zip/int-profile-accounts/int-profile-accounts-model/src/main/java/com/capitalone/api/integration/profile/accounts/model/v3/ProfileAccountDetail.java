package com.capitalone.api.integration.profile.accounts.model.v3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.joda.time.LocalDate;

import com.capitalone.api.model.product.Product;
import com.capitalone.api.xmladapter.LocalDateAdapter;
import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

/**
 * Profile Account Detail
 * 
 * @since 1.0
 */
@ApiModel(value = "Represents a Profile Account for Capital One")
@XmlRootElement(name = "ProfileAccountDetail", namespace = "http://api.capitalone.com/v3/integration/profile/accounts")
@XmlType(propOrder = {}, namespace = "http://api.capitalone.com/v3/integration/profile/accounts")
public class ProfileAccountDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("The customer recognizable account number that is present on the check and is also displayed online and on customer service applications.")
    @Audited
    private String accountNumber;

    @ApiModelProperty("Enterprise representation of the product for the account.")
    @Audited
    private Product product;

    @ApiModelProperty("A nickname for the account provided by a customer used on their online/mobile profile.")
    private String accountNickname;

    @ApiModelProperty("The current status of the account. eg. Active, Closed, etc.")
    @Audited
    private String accountStatus;

    @ApiModelProperty("The date when the account was opened.")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate openDate;

    @ApiModelProperty("The date when the account was closed if the status of the account is Closed.")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate closedDate;

    @ApiModelProperty("The date when the next payment on the account is set to be made.")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate nextPaymentDate;

    @ApiModelProperty("The estimated date of the last contact.")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate estimatedLastContactDate;

    @ApiModelProperty("The amount to be made towards the next payment.")
    private BigDecimal nextPaymentAmount;

    @ApiModelProperty("The total amount in a customer's account. This does not include any holds/floats/pending transactions.")
    @Audited
    private BigDecimal ledgerBalance;

    @ApiModelProperty("The amount of BigDecimal available to the customer for withdrawal, paying bills, etc. This balance represents the ledger balance minus any hold/float amount.")
    @Audited
    private BigDecimal availableBalance;

    @ApiModelProperty("Balance loan amount of the customer.")
    @Audited
    private BigDecimal principalBalance;

    @ApiModelProperty("An indicator to represent whether an account is flagged as a retirement (IRA) account.")
    @Audited
    private Boolean retirementAccountIndicator;

    @ApiModelProperty("The type of retirement account that this account is flagged as. eg. Traditional, Roth, etc.")
    @Audited
    private String retirementAccountType;

    @ApiModelProperty("An indicator to represent whether there are any restrictions placed on the account.")
    @Audited
    private Boolean restrictionsIndicator;

    @ApiModelProperty("An indicator to represent whether the accont is of type Bankruptcy.")
    @Audited
    private Boolean isUnderBankruptcyIndicator;

    @ApiModelProperty("Payment Due Date")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate paymentDueDate;

    @ApiModelProperty("Due Date")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate dueDate;

    @ApiModelProperty("Last Payment Date")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate lastPaymentDt;

    @ApiModelProperty("The  amount which has to pay.")
    private BigDecimal loanAmountDue;

    @ApiModelProperty("The  total amount which has to pay.")
    private BigDecimal totalDue;

    @ApiModelProperty("Restriction code for the customer.")
    @Audited
    private List<RestrictionCode> restrictions;

    @ApiModelProperty("Non-accrual Indicator.")
    private int nonAccrualIndicator;

    @ApiModelProperty("An indicator to denote as to whether CheckFree BillPay DAF processing is complete.")
    private Boolean isCheckFreeBillPayProcessingComplete;

    @ApiModelProperty("Represents the primary customer number of the 360 account.")
    private String primaryCustomerNumber;

    @ApiModelProperty("Represents the secondary customer number of the 360 account.")
    private String secondaryCustomerNumber;

    @ApiModelProperty("Indicates as to whether the account under consideration is a KSA account.")
    private Boolean isKsaAccount;

    @ApiModelProperty("EO Overdraft Credit Limit.")
    private BigDecimal overdraftCreditLimit;

    @ApiModelProperty("EO Overdraft Ledger Balance")
    private BigDecimal overdraftLedgerBalance;

    @ApiModelProperty("Monthly withdrawal count for each account.")
    private Integer monthlyWithdrawalCount;

    /**
     * @return the accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * @param accountNumber the accountNumber to set
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * @return the product
     */
    public Product getProduct() {
        return product;
    }

    /**
     * @param product the product to set
     */
    public void setProduct(Product product) {
        this.product = product;
    }

    /**
     * @return the accountNickname
     */
    public String getAccountNickname() {
        return accountNickname;
    }

    /**
     * @param accountNickname the accountNickname to set
     */
    public void setAccountNickname(String accountNickname) {
        this.accountNickname = accountNickname;
    }

    /**
     * @return the accountStatus
     */
    public String getAccountStatus() {
        return accountStatus;
    }

    /**
     * @param accountStatus the accountStatus to set
     */
    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    /**
     * @return the openDate
     */
    public LocalDate getOpenDate() {
        return openDate;
    }

    /**
     * @param openDate the openDate to set
     */
    public void setOpenDate(LocalDate openDate) {
        this.openDate = openDate;
    }

    /**
     * @return the closedDate
     */
    public LocalDate getClosedDate() {
        return closedDate;
    }

    /**
     * @param closedDate the closedDate to set
     */
    public void setClosedDate(LocalDate closedDate) {
        this.closedDate = closedDate;
    }

    /**
     * @return the nextPaymentDate
     */
    public LocalDate getNextPaymentDate() {
        return nextPaymentDate;
    }

    /**
     * @param nextPaymentDate the nextPaymentDate to set
     */
    public void setNextPaymentDate(LocalDate nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    /**
     * @return the estimatedLastContactDate
     */
    public LocalDate getEstimatedLastContactDate() {
        return estimatedLastContactDate;
    }

    /**
     * @param estimatedLastContactDate the estimatedLastContactDate to set
     */
    public void setEstimatedLastContactDate(LocalDate estimatedLastContactDate) {
        this.estimatedLastContactDate = estimatedLastContactDate;
    }

    /**
     * @return the nextPaymentAmount
     */
    public BigDecimal getNextPaymentAmount() {
        return nextPaymentAmount;
    }

    /**
     * @param nextPaymentAmount the nextPaymentAmount to set
     */
    public void setNextPaymentAmount(BigDecimal nextPaymentAmount) {
        this.nextPaymentAmount = nextPaymentAmount;
    }

    /**
     * @return the availableBalance
     */
    public BigDecimal getAvailableBalance() {
        return availableBalance;
    }

    /**
     * @param availableBalance the availableBalance to set
     */
    public void setAvailableBalance(BigDecimal availableBalance) {
        this.availableBalance = availableBalance;
    }

    /**
     * @return the principalBalance
     */
    public BigDecimal getPrincipalBalance() {
        return principalBalance;
    }

    /**
     * @param principalBalance the principalBalance to set
     */
    public void setPrincipalBalance(BigDecimal principalBalance) {
        this.principalBalance = principalBalance;
    }

    /**
     * @return the retirementAccountIndicator
     */
    public Boolean getRetirementAccountIndicator() {
        return retirementAccountIndicator;
    }

    /**
     * @param retirementAccountIndicator the retirementAccountIndicator to set
     */
    public void setRetirementAccountIndicator(Boolean retirementAccountIndicator) {
        this.retirementAccountIndicator = retirementAccountIndicator;
    }

    /**
     * @return the retirementAccountType
     */
    public String getRetirementAccountType() {
        return retirementAccountType;
    }

    /**
     * @param retirementAccountType the retirementAccountType to set
     */
    public void setRetirementAccountType(String retirementAccountType) {
        this.retirementAccountType = retirementAccountType;
    }

    /**
     * @return the restrictionsIndicator
     */
    public Boolean getRestrictionsIndicator() {
        return restrictionsIndicator;
    }

    /**
     * @param restrictionsIndicator the restrictionsIndicator to set
     */
    public void setRestrictionsIndicator(Boolean restrictionsIndicator) {
        this.restrictionsIndicator = restrictionsIndicator;
    }

    /**
     * @return the underBankruptcyProtection
     */
    public Boolean isIsUnderBankruptcyIndicator() {
        return isUnderBankruptcyIndicator;
    }

    /**
     * @param underBankruptcyProtection the underBankruptcyProtection to set
     */
    public void setIsUnderBankruptcyIndicator(Boolean isUnderBankruptcyIndicator) {
        this.isUnderBankruptcyIndicator = isUnderBankruptcyIndicator;
    }

    /**
     * @return the paymentDueDate
     */
    public LocalDate getPaymentDueDate() {
        return paymentDueDate;
    }

    /**
     * @param paymentDueDate the paymentDueDate to set
     */
    public void setPaymentDueDate(LocalDate paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
    }

    /**
     * @return the dueDate
     */
    public LocalDate getDueDate() {
        return dueDate;
    }

    /**
     * @param dueDate the dueDate to set
     */
    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * @return the lastPaymentDt
     */
    public LocalDate getLastPaymentDt() {
        return lastPaymentDt;
    }

    /**
     * @param lastPaymentDt the lastPaymentDt to set
     */
    public void setLastPaymentDt(LocalDate lastPaymentDt) {
        this.lastPaymentDt = lastPaymentDt;
    }

    /**
     * @return the loanAmountDue
     */
    public BigDecimal getLoanAmountDue() {
        return loanAmountDue;
    }

    /**
     * @param loanAmountDue the loanAmountDue to set
     */
    public void setLoanAmountDue(BigDecimal loanAmountDue) {
        this.loanAmountDue = loanAmountDue;
    }

    /**
     * @return the totalDue
     */
    public BigDecimal getTotalDue() {
        return totalDue;
    }

    /**
     * @param totalDue the totalDue to set
     */
    public void setTotalDue(BigDecimal totalDue) {
        this.totalDue = totalDue;
    }

    /**
     * @return the restrictions
     */
    public List<RestrictionCode> getRestrictions() {
        return restrictions;
    }

    /**
     * @param restrictions the restrictions to set
     */
    public void setRestrictions(List<RestrictionCode> restrictions) {
        this.restrictions = restrictions;
    }

    /**
     * @return the nonAccrualIndicator
     */
    public int getNonAccrualIndicator() {
        return nonAccrualIndicator;
    }

    /**
     * @param nonAccrualIndicator the nonAccrualIndicator to set
     */
    public void setNonAccrualIndicator(int nonAccrualIndicator) {
        this.nonAccrualIndicator = nonAccrualIndicator;
    }

    /**
     * @return the isCheckFreeBillPayProcessingComplete
     */
    public Boolean isIsCheckFreeBillPayProcessingComplete() {
        return isCheckFreeBillPayProcessingComplete;
    }

    /**
     * @param isCheckFreeBillPayProcessingComplete the isCheckFreeBillPayProcessingComplete to set
     */
    public void setIsCheckFreeBillPayProcessingComplete(Boolean isCheckFreeBillPayProcessingComplete) {
        this.isCheckFreeBillPayProcessingComplete = isCheckFreeBillPayProcessingComplete;
    }

    /**
     * @return the ledgerBalance
     */
    public BigDecimal getLedgerBalance() {
        return ledgerBalance;
    }

    /**
     * @param ledgerBalance the ledgerBalance to set
     */
    public void setLedgerBalance(BigDecimal ledgerBalance) {
        this.ledgerBalance = ledgerBalance;
    }

    /**
     * @return the primaryCustomerNumber
     */
    public String getPrimaryCustomerNumber() {
        return primaryCustomerNumber;
    }

    /**
     * @param primaryCustomerNumber the primaryCustomerNumber to set
     */
    public void setPrimaryCustomerNumber(String primaryCustomerNumber) {
        this.primaryCustomerNumber = primaryCustomerNumber;
    }

    /**
     * @return the secondaryCustomerNumber
     */
    public String getSecondaryCustomerNumber() {
        return secondaryCustomerNumber;
    }

    /**
     * @param secondaryCustomerNumber the secondaryCustomerNumber to set
     */
    public void setSecondaryCustomerNumber(String secondaryCustomerNumber) {
        this.secondaryCustomerNumber = secondaryCustomerNumber;
    }

    public Boolean getIsKsaAccount() {
        return isKsaAccount;
    }

    public void setIsKsaAccount(Boolean isKsaAccount) {
        this.isKsaAccount = isKsaAccount;
    }

    /**
     * @param overdraftCreditLimit the overdraftCreditLimit to set
     */
    public BigDecimal getOverdraftCreditLimit() {
        return overdraftCreditLimit;
    }

    public void setOverdraftCreditLimit(BigDecimal overdraftCreditLimit) {
        this.overdraftCreditLimit = overdraftCreditLimit;
    }

    /**
     * @param overdraftLedgerBalance the overdraftLedgerBalance to set
     */
    public BigDecimal getOverdraftLedgerBalance() {
        return overdraftLedgerBalance;
    }

    public void setOverdraftLedgerBalance(BigDecimal overdraftLedgerBalance) {
        this.overdraftLedgerBalance = overdraftLedgerBalance;
    }

    /**
     * @return
     */
    public Integer getMonthlyWithdrawalCount() {
        return monthlyWithdrawalCount;
    }

    /**
     * @param monthlyWithdrawalCount
     */
    public void setMonthlyWithdrawalCount(Integer monthlyWithdrawalCount) {
        this.monthlyWithdrawalCount = monthlyWithdrawalCount;
    }
}



/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
