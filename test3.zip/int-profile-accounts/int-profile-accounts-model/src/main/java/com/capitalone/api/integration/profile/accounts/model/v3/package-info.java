/**
 * Model classes for int-profile-accounts functionality.
 */
package com.capitalone.api.integration.profile.accounts.model.v3;