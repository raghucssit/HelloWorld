package com.capitalone.api.integration.profile.accounts.model.v3;

import javax.xml.bind.annotation.XmlRegistry;

/**
 * Default object factory for JAXB.
 * 
 * @author ovh781 - Generated
 * @since 1.0
 */
@XmlRegistry
public class ObjectFactory {
}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
