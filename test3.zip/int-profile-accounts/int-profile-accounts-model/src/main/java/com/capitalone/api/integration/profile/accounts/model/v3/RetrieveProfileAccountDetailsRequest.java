package com.capitalone.api.integration.profile.accounts.model.v3;

import javax.ws.rs.PathParam;

import com.capitalone.api.commons.model.EntityRequest;
import com.capitalone.epf.audit.annotation.Audited;
import com.wordnik.swagger.annotations.ApiParam;

public class RetrieveProfileAccountDetailsRequest extends EntityRequest {

    private static final long serialVersionUID = 1L;

    @Audited
    @ApiParam(value = "The unique identifier for the Profile account resource that can be used to locate this resource.", name = "accountNumber", required = true, allowMultiple = false, defaultValue = "42771702")
    @PathParam("accountNumber")
    private String accountNumber;

    /**
     * @return the accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * @param accountNumber the accountNumber to set
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
