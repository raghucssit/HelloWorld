int-profile-accounts
====================

Bank Internal API for purposes of interacting with Profile with an operation to retrieve account information back to the caller.
