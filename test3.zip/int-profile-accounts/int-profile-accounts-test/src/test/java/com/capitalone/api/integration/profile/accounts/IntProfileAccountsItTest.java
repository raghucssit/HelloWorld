package com.capitalone.api.integration.profile.accounts;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty", "html:target/cucumber-html-report", "json:target/cucumber-results.json"}, features = {"src/test/java/com/capitalone/api/integration/profile/accounts/features"}, glue = "classpath:com/capitalone/api/integration/profile/accounts/stepdefinitions")
public class IntProfileAccountsItTest {
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
