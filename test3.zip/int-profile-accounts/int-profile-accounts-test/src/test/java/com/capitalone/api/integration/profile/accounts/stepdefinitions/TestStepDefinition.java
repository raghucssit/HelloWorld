package com.capitalone.api.integration.profile.accounts.stepdefinitions;

import static org.hamcrest.MatcherAssert.assertThat;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.hamcrest.Matchers;
import org.hamcrest.text.IsEqualIgnoringCase;

import com.capitalone.api.integration.profile.accounts.model.AccountStatus;
import com.capitalone.api.integration.profile.accounts.model.ProfileAccountDetailResponse;
import com.capitalone.bankoao.cucumber.db.DBManager;
import com.capitalone.bankoao.cucumber.rest.AbstractRESTStepDefinition;
import com.capitalone.bankoao.cucumber.rest.managers.JsonRequestResponseManager;
import com.capitalone.bankoao.cucumber.rest.model.RESTRequest;
import com.capitalone.bankoao.cucumber.rest.model.RESTResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestStepDefinition extends AbstractRESTStepDefinition {

    private static final String COLUMN_RFLG = "RFLG";

    private static final String COLUMN_ACN = "ACN";

    private static final String COLUMN_STAT = "STAT";

    private static final String COLUMN_BALAVL = "BALAVL-ZOODAMT";

    private static final String COLUMN_DEPOSIT_ZPRDDESC = "DEP.ZPRDDESC";

    private static final String COLUMN_DEP_TYPE = "DEP.TYPE";

    private static final String COLUMN_PRODCTL_DES = "PRODCTL.DES";

    private static final String COLUMN_PRODCTL_TRUST = "DEP.ZTRUST";

    private static final String COLUMN_CLS = "CLS";

    private static final String COLUMN_LN_ZPRDDESC = "LN.ZPRDDESC";

    private static final String COLUMN_LN_TYPE = "LN.TYPE";

    private static final String QUERY_RETRIEVE_RESTRICTION_INDICATOR = "retrieveRestrictionIndicator";

    private static final String QUERY_RETRIEVE_CUSTOMER_NUMBER = "retrieveCustomerNumber";

    private static final String QUERY_RETRIEVE_ACCOUNT_STATUS = "retrieveAccountStatus";

    private static final String QUERY_RETRIEVE_AVAILABLE_BALANCE = "retrieveAvailableBalance";

    private static final String QUERY_RETRIEVE_ACCOUNT_CLASS = "retrieveAccountClass";

    private static final String QUERY_DEPOSIT_RETRIEVE_PRODUCT_DETIALS = "retrieveDepositProductDetails";

    private static final String QUERY_LOAN_RETRIEVE_PRODUCT_DETIALS = "retrieveLoanProductDetails";

    private static final String ACCOUNT_NUMBER = "<accountNumber>";

    private static final String ENV = System.getProperty("env") != null ? System.getProperty("env") : "QA";

    private RESTRequest request;

    private RESTResponse response;

    private JsonRequestResponseManager manager = JsonRequestResponseManager.instance();

    private ProfileAccountDetailResponse detailResponse;

    private DBManager dbManager = DBManager.instance();

    private Connection profileConnection;

    private Map<String, String> profileQueryMap;

    @Before
    public void setUp() throws Throwable {
        // Open connection for Profile
        profileConnection = dbManager.getConnection(DBManager.PROFILE_DRIVER_CLASSNAME,
                dataFor(ENV).get("profile_url"), (dataFor(ENV).get("profile_uid")), (dataFor(ENV).get("profile_pwd")));

        // Loading YAML file, which has profile queries
        loadYmlFile("/service-requests/profileQueries.yml");
        profileQueryMap = dataFor("intProfileAccountsFeature");
        ReferenceDataUtil.getInstance().loadCsvFile("/service-requests/NativeProdTypetoAPIProdType_v1.csv");

    }

    @Given("^A valid \"([^\"]*)\" account is provided to the API$")
    public void a_valid_account_is_provided_to_the_API(String arg1) throws Throwable {

    }

    @When("^a \"([^\"]*)\" account number (\\d+) is passed to API$")
    public void an_account_number_is_passed_to_API(String arg1, long accNum) throws Throwable {
        executeEAPI(accNum);
    }

    @Then("^API returned (\\d+)$")
    public void api_returned(int arg1) throws Throwable {

        // JSON from String to Object
        if (200 == response.getStatusCode()) {
            detailResponse = new ObjectMapper().readValue(response.getResponseString(),
                    ProfileAccountDetailResponse.class);
        }

        // Write code here that turns the phrase above into concrete actions
        assertThat("Incorrect HTTP Resoponse", arg1, Matchers.is(response.getStatusCode()));
    }

    @Then("^validate product details from profile for account number (\\d+)$")
    public void validate_product_id_from_profile_for_account_number(long accountNumber) throws Throwable {

        String[] productDetails = null;
        String prodDesc = null;
        String accountType = null;

        String accountClassQuery = profileQueryMap.get(QUERY_RETRIEVE_ACCOUNT_CLASS).replace(ACCOUNT_NUMBER,
                String.valueOf(accountNumber));
        String acctClass = dbManager.executeSelectQuery(profileConnection, accountClassQuery).get(0).get(COLUMN_CLS);

        if (StringUtils.equalsIgnoreCase(acctClass, "L")) {
            String productDetailQuery = profileQueryMap.get(QUERY_LOAN_RETRIEVE_PRODUCT_DETIALS).replace(
                    ACCOUNT_NUMBER, String.valueOf(accountNumber));
            List<Map<String, String>> result = dbManager.executeSelectQuery(profileConnection, productDetailQuery);

            productDetails = StringUtils.split(result.get(0).get(COLUMN_LN_ZPRDDESC), "|");

            prodDesc = result.get(0).get(COLUMN_PRODCTL_DES);

            accountType = result.get(0).get(COLUMN_LN_TYPE);
        } else {
            String productDetailQuery = profileQueryMap.get(QUERY_DEPOSIT_RETRIEVE_PRODUCT_DETIALS).replace(
                    ACCOUNT_NUMBER, String.valueOf(accountNumber));
            List<Map<String, String>> result = dbManager.executeSelectQuery(profileConnection, productDetailQuery);
            productDetails = StringUtils.split(result.get(0).get(COLUMN_DEPOSIT_ZPRDDESC), "|");

            prodDesc = result.get(0).get(COLUMN_PRODCTL_DES);

            if (StringUtils.equalsIgnoreCase(result.get(0).get(COLUMN_PRODCTL_TRUST), "2")) {
                prodDesc = prodDesc + " - Trust";
            }

            accountType = result.get(0).get(COLUMN_DEP_TYPE);
        }

        Map<String, String> referenceData = ReferenceDataUtil.getInstance().getEntity("NativeProdTypetoAPIProdType",
                productDetails[0]);

        assertThat("Incorrect ProductId", detailResponse.getProduct().getProductId(),
                Matchers.is(IsEqualIgnoringCase.equalToIgnoringCase(accountType)));

        assertThat("Incorrect Product Name", detailResponse.getProduct().getProductName(),
                Matchers.is(IsEqualIgnoringCase.equalToIgnoringCase(prodDesc)));

        assertThat("Incorrect Product Type Code", detailResponse.getProduct().getProductTypeCode(),
                Matchers.is(IsEqualIgnoringCase.equalToIgnoringCase(referenceData.get("APIProductTypeCode"))));

        assertThat("Incorrect Product Type Description", detailResponse.getProduct().getProductTypeDescription(),
                Matchers.is(IsEqualIgnoringCase.equalToIgnoringCase(referenceData.get("APIProductTypeDesc"))));

    }

    @Then("^validate available balance from profile for account number (\\d+)$")
    public void validate_available_balance_from_profile_for_account_number(long accountNumber) throws Throwable {
        String query = profileQueryMap.get(QUERY_RETRIEVE_AVAILABLE_BALANCE).replace(ACCOUNT_NUMBER,
                String.valueOf(accountNumber));
        List<Map<String, String>> result = dbManager.executeSelectQuery(profileConnection, query);
        assertThat("Incorrect Available balance", detailResponse.getAvailableBalance().doubleValue(),
                Matchers.is(NumberUtils.toDouble(result.get(0).get(COLUMN_BALAVL))));
    }

    @Then("^validate account status from profile for account number (\\d+)$")
    public void validate_account_status_from_profile_for_account_number(long accountNumber) throws Throwable {
        String query = profileQueryMap.get(QUERY_RETRIEVE_ACCOUNT_STATUS).replace(ACCOUNT_NUMBER,
                String.valueOf(accountNumber));
        List<Map<String, String>> result = dbManager.executeSelectQuery(profileConnection, query);
        String acctStatus = AccountStatus.fromString(result.get(0).get(COLUMN_STAT)).toString();
        assertThat("Incorrect account status", detailResponse.getAccountStatus(),
                Matchers.is(IsEqualIgnoringCase.equalToIgnoringCase(acctStatus)));
    }

    @Then("^validate customer number from profile for account number (\\d+)$")
    public void validate_customer_number_from_profile_for_account_number(long accountNumber) throws Throwable {
        String query = profileQueryMap.get(QUERY_RETRIEVE_CUSTOMER_NUMBER).replace(ACCOUNT_NUMBER,
                String.valueOf(accountNumber));
        List<Map<String, String>> result = dbManager.executeSelectQuery(profileConnection, query);
        assertThat("Incorrect customer Id", detailResponse.getPrimaryCustomerNumber(),
                Matchers.is(IsEqualIgnoringCase.equalToIgnoringCase(result.get(0).get(COLUMN_ACN))));
    }

    @Then("^validate restrictions for the account number (\\d+) from profile$")
    public void validate_restrictions_for_the_account_number_from_profile(long accountNumber) throws Throwable {
        String query = profileQueryMap.get(QUERY_RETRIEVE_RESTRICTION_INDICATOR).replace(ACCOUNT_NUMBER,
                String.valueOf(accountNumber));
        List<Map<String, String>> result = dbManager.executeSelectQuery(profileConnection, query);
        String data = (result.get(0).get(COLUMN_RFLG));
        boolean hasRestriction = false;
        if (null != data) {
            hasRestriction = BooleanUtils.toBooleanObject(data);
        }
        assertThat("Error while validating restriction", detailResponse.getRestrictionsIndicator(),
                Matchers.is(hasRestriction));

    }

    @Given("^A Invalid account is provided to the API$")
    public void a_Invalid_account_is_provided_to_the_API() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^an account number (\\d+) is passed to API$")
    public void an_account_number_is_passed_to_API(long accNum) throws Throwable {
        executeEAPI(accNum);
    }

    private void executeEAPI(long accNum) throws Exception {
        // Retrieve API URL
        String intProfileAccountsUrl = getServiceBaseUrl()
                + dataFor(ENV).get("intProfileAccountsUrl").replace("{accontNumber}", String.valueOf(accNum));
        request = manager.readRequestJsonFromFile("/service-requests/request.json");
        response = executeEAPIRESTRequest(intProfileAccountsUrl, request);
    }

    @After
    public void tearDown() throws Throwable {
        profileConnection.close();
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
