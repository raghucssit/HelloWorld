package com.capitalone.api.integration.profile.accounts.model;

import org.apache.commons.lang3.StringUtils;

/**
 * Enumeration class to list the different type of account status
 * 
 * @author utp596 - Hariharbalaji Vadivel
 * @since 1.0
 */
public enum AccountStatus {

    ACTIVE("0"),
    INACTIVE("1"),
    DORMANT("2"),
    ESCHEAT("3"),
    CLOSED("4"),
    CLOSEDOUTINPROGRESS("5");

    private String value;

    private AccountStatus(String value) {
        this.value = value;
    }

    /**
     * @param creditTransactionType
     * @return
     */
    public static AccountStatus fromString(String accountStatus) {

        for (AccountStatus type : AccountStatus.values()) {
            if (StringUtils.equalsIgnoreCase(accountStatus, type.getValue())) {
                return type;
            }
        }
        return null;
    }

    public String getValue() {
        return value;
    }

}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */

/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
