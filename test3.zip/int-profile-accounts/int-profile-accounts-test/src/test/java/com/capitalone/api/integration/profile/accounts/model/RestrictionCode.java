package com.capitalone.api.integration.profile.accounts.model;

import java.io.Serializable;

/**
 * Restriction Codes
 * 
 * @since 1.0
 */
public class RestrictionCode implements Serializable {

    private static final long serialVersionUID = 2L;

    private String restrictionCode;

    private String restrictionDescription;

    /**
     * @return the restrictionCode
     */
    public String getRestrictionCode() {
        return restrictionCode;
    }

    /**
     * @param restrictionCode the restrictionCode to set
     */
    public void setRestrictionCode(String restrictionCode) {
        this.restrictionCode = restrictionCode;
    }

    /**
     * @return the restrictionDescription
     */
    public String getRestrictionDescription() {
        return restrictionDescription;
    }

    /**
     * @param restrictionDescription the restrictionDescription to set
     */
    public void setRestrictionDescription(String restrictionDescription) {
        this.restrictionDescription = restrictionDescription;
    }
}

/*
 * Copyright 2015 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
