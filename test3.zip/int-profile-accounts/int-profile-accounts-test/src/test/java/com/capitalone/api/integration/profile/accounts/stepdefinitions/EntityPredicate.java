package com.capitalone.api.integration.profile.accounts.stepdefinitions;

import org.apache.commons.collections4.Predicate;
import org.apache.commons.lang3.StringUtils;

import com.capitalone.api.integration.profile.accounts.model.ReferenceData;

/**
 * @author utp596 - Hariharbalaji Vadivel
 * @since  1.0
 */
public class EntityPredicate implements Predicate<ReferenceData> {

    private String entity;

    private String categoryName;

    public EntityPredicate(String entity, String categoryName) {
        super();
        this.entity = entity;
        this.categoryName = categoryName;
    }

    public boolean evaluate(ReferenceData data) {

        if (StringUtils.equalsIgnoreCase(data.getEntityName(), entity)
                && StringUtils.equalsIgnoreCase(data.getFileName(), categoryName)) {
            return true;
        }
        return false;
    }

}

/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
