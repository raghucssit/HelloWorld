package com.capitalone.api.integration.profile.accounts.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

public class ProfileAccountDetailResponse {

    private String accountNumber;

    private Product product;

    private String accountNickname;

    private String accountStatus;

    private Date openDate;

    private Date closedDate;

    private Date nextPaymentDate;

    private Date estimatedLastContactDate;

    private BigDecimal nextPaymentAmount;

    private BigDecimal ledgerBalance;

    private BigDecimal availableBalance;

    private BigDecimal principalBalance;

    private Boolean retirementAccountIndicator;

    private String retirementAccountType;

    private Boolean restrictionsIndicator;

    private Boolean isUnderBankruptcyIndicator;

    private Date paymentDueDate;

    private Date dueDate;

    private Date lastPaymentDt;

    private BigDecimal loanAmountDue;

    private BigDecimal totalDue;

    private ArrayList<RestrictionCode> restrictions;

    private int nonAccrualIndicator;

    private Boolean isCheckFreeBillPayProcessingComplete;

    private String primaryCustomerNumber;

    private String secondaryCustomerNumber;

    private Boolean isKsaAccount;

    private BigDecimal overdraftCreditLimit;

    private BigDecimal overdraftLedgerBalance;

    /**
     * @return the accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * @param accountNumber the accountNumber to set
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * @return the product
     */
    public Product getProduct() {
        return product;
    }

    /**
     * @param product the product to set
     */
    public void setProduct(Product product) {
        this.product = product;
    }

    /**
     * @return the accountNickname
     */
    public String getAccountNickname() {
        return accountNickname;
    }

    /**
     * @param accountNickname the accountNickname to set
     */
    public void setAccountNickname(String accountNickname) {
        this.accountNickname = accountNickname;
    }

    /**
     * @return the accountStatus
     */
    public String getAccountStatus() {
        return accountStatus;
    }

    /**
     * @param accountStatus the accountStatus to set
     */
    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    /**
     * @return the openDate
     */
    public Date getOpenDate() {
        return openDate;
    }

    /**
     * @param openDate the openDate to set
     */
    public void setOpenDate(Date openDate) {
        this.openDate = openDate;
    }

    /**
     * @return the closedDate
     */
    public Date getClosedDate() {
        return closedDate;
    }

    /**
     * @param closedDate the closedDate to set
     */
    public void setClosedDate(Date closedDate) {
        this.closedDate = closedDate;
    }

    /**
     * @return the nextPaymentDate
     */
    public Date getNextPaymentDate() {
        return nextPaymentDate;
    }

    /**
     * @param nextPaymentDate the nextPaymentDate to set
     */
    public void setNextPaymentDate(Date nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    /**
     * @return the estimatedLastContactDate
     */
    public Date getEstimatedLastContactDate() {
        return estimatedLastContactDate;
    }

    /**
     * @param estimatedLastContactDate the estimatedLastContactDate to set
     */
    public void setEstimatedLastContactDate(Date estimatedLastContactDate) {
        this.estimatedLastContactDate = estimatedLastContactDate;
    }

    /**
     * @return the nextPaymentAmount
     */
    public BigDecimal getNextPaymentAmount() {
        return nextPaymentAmount;
    }

    /**
     * @param nextPaymentAmount the nextPaymentAmount to set
     */
    public void setNextPaymentAmount(BigDecimal nextPaymentAmount) {
        this.nextPaymentAmount = nextPaymentAmount;
    }

    /**
     * @return the ledgerBalance
     */
    public BigDecimal getLedgerBalance() {
        return ledgerBalance;
    }

    /**
     * @param ledgerBalance the ledgerBalance to set
     */
    public void setLedgerBalance(BigDecimal ledgerBalance) {
        this.ledgerBalance = ledgerBalance;
    }

    /**
     * @return the availableBalance
     */
    public BigDecimal getAvailableBalance() {
        return availableBalance;
    }

    /**
     * @param availableBalance the availableBalance to set
     */
    public void setAvailableBalance(BigDecimal availableBalance) {
        this.availableBalance = availableBalance;
    }

    /**
     * @return the principalBalance
     */
    public BigDecimal getPrincipalBalance() {
        return principalBalance;
    }

    /**
     * @param principalBalance the principalBalance to set
     */
    public void setPrincipalBalance(BigDecimal principalBalance) {
        this.principalBalance = principalBalance;
    }

    /**
     * @return the retirementAccountIndicator
     */
    public Boolean getRetirementAccountIndicator() {
        return retirementAccountIndicator;
    }

    /**
     * @param retirementAccountIndicator the retirementAccountIndicator to set
     */
    public void setRetirementAccountIndicator(Boolean retirementAccountIndicator) {
        this.retirementAccountIndicator = retirementAccountIndicator;
    }

    /**
     * @return the retirementAccountType
     */
    public String getRetirementAccountType() {
        return retirementAccountType;
    }

    /**
     * @param retirementAccountType the retirementAccountType to set
     */
    public void setRetirementAccountType(String retirementAccountType) {
        this.retirementAccountType = retirementAccountType;
    }

    /**
     * @return the restrictionsIndicator
     */
    public Boolean getRestrictionsIndicator() {
        return restrictionsIndicator;
    }

    /**
     * @param restrictionsIndicator the restrictionsIndicator to set
     */
    public void setRestrictionsIndicator(Boolean restrictionsIndicator) {
        this.restrictionsIndicator = restrictionsIndicator;
    }

    /**
     * @return the isUnderBankruptcyIndicator
     */
    public Boolean getIsUnderBankruptcyIndicator() {
        return isUnderBankruptcyIndicator;
    }

    /**
     * @param isUnderBankruptcyIndicator the isUnderBankruptcyIndicator to set
     */
    public void setIsUnderBankruptcyIndicator(Boolean isUnderBankruptcyIndicator) {
        this.isUnderBankruptcyIndicator = isUnderBankruptcyIndicator;
    }

    /**
     * @return the paymentDueDate
     */
    public Date getPaymentDueDate() {
        return paymentDueDate;
    }

    /**
     * @param paymentDueDate the paymentDueDate to set
     */
    public void setPaymentDueDate(Date paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
    }

    /**
     * @return the dueDate
     */
    public Date getDueDate() {
        return dueDate;
    }

    /**
     * @param dueDate the dueDate to set
     */
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * @return the lastPaymentDt
     */
    public Date getLastPaymentDt() {
        return lastPaymentDt;
    }

    /**
     * @param lastPaymentDt the lastPaymentDt to set
     */
    public void setLastPaymentDt(Date lastPaymentDt) {
        this.lastPaymentDt = lastPaymentDt;
    }

    /**
     * @return the loanAmountDue
     */
    public BigDecimal getLoanAmountDue() {
        return loanAmountDue;
    }

    /**
     * @param loanAmountDue the loanAmountDue to set
     */
    public void setLoanAmountDue(BigDecimal loanAmountDue) {
        this.loanAmountDue = loanAmountDue;
    }

    /**
     * @return the totalDue
     */
    public BigDecimal getTotalDue() {
        return totalDue;
    }

    /**
     * @param totalDue the totalDue to set
     */
    public void setTotalDue(BigDecimal totalDue) {
        this.totalDue = totalDue;
    }

    /**
     * @return the restrictions
     */
    public ArrayList<RestrictionCode> getRestrictions() {
        return restrictions;
    }

    /**
     * @param restrictions the restrictions to set
     */
    public void setRestrictions(ArrayList<RestrictionCode> restrictions) {
        this.restrictions = restrictions;
    }

    /**
     * @return the nonAccrualIndicator
     */
    public int getNonAccrualIndicator() {
        return nonAccrualIndicator;
    }

    /**
     * @param nonAccrualIndicator the nonAccrualIndicator to set
     */
    public void setNonAccrualIndicator(int nonAccrualIndicator) {
        this.nonAccrualIndicator = nonAccrualIndicator;
    }

    /**
     * @return the isCheckFreeBillPayProcessingComplete
     */
    public Boolean getIsCheckFreeBillPayProcessingComplete() {
        return isCheckFreeBillPayProcessingComplete;
    }

    /**
     * @param isCheckFreeBillPayProcessingComplete the isCheckFreeBillPayProcessingComplete to set
     */
    public void setIsCheckFreeBillPayProcessingComplete(Boolean isCheckFreeBillPayProcessingComplete) {
        this.isCheckFreeBillPayProcessingComplete = isCheckFreeBillPayProcessingComplete;
    }

    /**
     * @return the primaryCustomerNumber
     */
    public String getPrimaryCustomerNumber() {
        return primaryCustomerNumber;
    }

    /**
     * @param primaryCustomerNumber the primaryCustomerNumber to set
     */
    public void setPrimaryCustomerNumber(String primaryCustomerNumber) {
        this.primaryCustomerNumber = primaryCustomerNumber;
    }

    /**
     * @return the secondaryCustomerNumber
     */
    public String getSecondaryCustomerNumber() {
        return secondaryCustomerNumber;
    }

    /**
     * @param secondaryCustomerNumber the secondaryCustomerNumber to set
     */
    public void setSecondaryCustomerNumber(String secondaryCustomerNumber) {
        this.secondaryCustomerNumber = secondaryCustomerNumber;
    }

    /**
     * @return the isKsaAccount
     */
    public Boolean getIsKsaAccount() {
        return isKsaAccount;
    }

    /**
     * @param isKsaAccount the isKsaAccount to set
     */
    public void setIsKsaAccount(Boolean isKsaAccount) {
        this.isKsaAccount = isKsaAccount;
    }

    /**
     * @return the overdraftCreditLimit
     */
    public BigDecimal getOverdraftCreditLimit() {
        return overdraftCreditLimit;
    }

    /**
     * @param overdraftCreditLimit the overdraftCreditLimit to set
     */
    public void setOverdraftCreditLimit(BigDecimal overdraftCreditLimit) {
        this.overdraftCreditLimit = overdraftCreditLimit;
    }

    /**
     * @return the overdraftLedgerBalance
     */
    public BigDecimal getOverdraftLedgerBalance() {
        return overdraftLedgerBalance;
    }

    /**
     * @param overdraftLedgerBalance the overdraftLedgerBalance to set
     */
    public void setOverdraftLedgerBalance(BigDecimal overdraftLedgerBalance) {
        this.overdraftLedgerBalance = overdraftLedgerBalance;
    }

}
/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
