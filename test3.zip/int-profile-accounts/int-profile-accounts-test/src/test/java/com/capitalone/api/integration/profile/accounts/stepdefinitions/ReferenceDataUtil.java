package com.capitalone.api.integration.profile.accounts.stepdefinitions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import com.capitalone.api.integration.profile.accounts.model.ReferenceData;
import com.capitalone.bankoao.cucumber.utils.GeneralUtils;

/**
 * @author utp596 - Hariharbalaji Vadivel
 * @since 1.0
 */
public class ReferenceDataUtil {

    private static final ReferenceDataUtil INSTANCE = new ReferenceDataUtil();

    private ConcurrentMap<String, List<ReferenceData>> referenceDataMap = new ConcurrentHashMap<String, List<ReferenceData>>();

    public void loadCsvFile(String filePath) throws FileNotFoundException, IOException {

        File csvFile = GeneralUtils.getFile(filePath);

        String category = StringUtils.substringBefore(csvFile.getName(), "_");

        if (!referenceDataMap.containsKey(category)) {

            List<ReferenceData> referenceDataList = new ArrayList<ReferenceData>();

            List<String> inputLines = IOUtils.readLines(new FileInputStream(csvFile));
            /*
             * Read first line then remove it.
             */
            String header = inputLines.get(0);
            inputLines.remove(0);

            /*
             * Split up the header into the column names
             */
            String[] columns = StringUtils.split(header, ",");

            for (String valueString : inputLines) {
                if (valueString.contains("\"")) {
                    continue;
                }
                /*
                 * Split up the values
                 */
                String[] values = StringUtils.split(valueString, ",");
                for (int x = 1; null != values && x < values.length; x++) {

                    ReferenceData referenceData = new ReferenceData(category, values[0], columns[x], values[x]);
                    referenceDataList.add(referenceData);
                }
            }
            referenceDataMap.put(category, referenceDataList);
        }

    }

    public Map<String, String> getEntity(String categoryName, String entityName) {

        Map<String, String> entityMap = new HashMap<String, String>();
        List<ReferenceData> referenceDataList = referenceDataMap.get(categoryName);
        if (CollectionUtils.isNotEmpty(referenceDataList)) {
            List<ReferenceData> entity = (List<ReferenceData>) CollectionUtils.select(referenceDataList,
                    new EntityPredicate(entityName, categoryName));

            for (ReferenceData referenceData : entity) {
                entityMap.put(referenceData.getAttributeName(), referenceData.getAttributeValue());
            }
        }

        return entityMap;
    }

    public static ReferenceDataUtil getInstance() {
        return INSTANCE;

    }

}

/*
 * Copyright 2016 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */
