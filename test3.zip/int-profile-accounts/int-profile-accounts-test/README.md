int-profile-accounts-test
=========================

This is ATDD test project for int-profile-accounts API.

Run Test
--------
Please execute the below command from  int-profile-accounts-test

~~~~~~
mvn -P cucumber-int-test -DserviceBaseUrl="https://awseapirddev3.kdc.capitalone.com:11210" test
~~~~~~

-DserviceBaseUrl : Target server name, where the API is deployed

Basic reports can be found in the below path

int-profile-accounts-test\target\cucumber-html-report
int-profile-accounts-test\target\cucumber-results.json

Cucumber Sandwich Report 
-------------------------

please execute the below command from  int-profile-accounts-test

~~~~~
mvn -P cucumber-report -DserviceBaseUrl="https://awseapirddev3.kdc.capitalone.com:11210" clean test
~~~~~

-DserviceBaseUrl : Target server name, where the API is deployed

Cucumber Sandwich reports can be found in the below path

int-profile-accounts-test\target\cucumber-sandwich-report


NOTE
----
1. Need JDK 7 to build the project

