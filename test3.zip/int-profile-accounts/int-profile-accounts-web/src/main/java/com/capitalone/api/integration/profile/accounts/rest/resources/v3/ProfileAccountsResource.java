package com.capitalone.api.integration.profile.accounts.rest.resources.v3;

import java.net.HttpURLConnection;

import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.Valid;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.server.JSONP;

import com.capitalone.api.commons.annotations.logging.Profile;
import com.capitalone.api.commons.annotations.logging.Trace;
import com.capitalone.api.commons.exception.ApiErrorCode;
import com.capitalone.api.commons.exception.NotFoundException;
import com.capitalone.api.commons.model.error.ErrorResponse;
import com.capitalone.api.commons.web.resource.AbstractBaseResource;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.integration.profile.accounts.model.v3.RetrieveProfileAccountDetailsRequest;
import com.capitalone.api.integration.profile.accounts.model.v3.UpdateProfileAccountDetailsRequest;
import com.capitalone.api.integration.profile.accounts.service.api.ProfileAccountsService;
import com.capitalone.api.integration.profile.accounts.service.api.UpdateProfileAccountsService;
import com.capitalone.api.integration.profile.accounts.service.constants.Constants;
import com.capitalone.api.integration.profile.accounts.service.util.ProfileAccountsServiceUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

/**
 * Integration Resource for Profile Accounts (Deposits, CDs, OLA and miscellaneous account information).
 * 
 * @since 1.0
 * 
 * @modified flm467 - Raghavendra Rao Julakanti
 */
@Named("profileAccountsResourceV3")
@Trace
@Profile
@Path("/integration/profile/accounts")
@Api(value = "/v3/integration/profile/accounts", description = "Deposit Account Operations")
@Produces({"application/vnd.com.capitalone.api+v3+json", "application/vnd.com.capitalone.api+v3+xml",
        "application/vnd.com.capitalone.api+v3+javascript"})
public class ProfileAccountsResource extends AbstractBaseResource {

    @Inject
    private ProfileAccountsService profileAccountsService;

    @Inject
    @Named("profileAccountsServiceUtil")
    private ProfileAccountsServiceUtil profileAccountsServiceUtil;
    
    @Inject
    private UpdateProfileAccountsService updateProfileAccountsService;

    /**
     * Search for a single deposit account
     * 
     * @param request {@link RetrieveDetailsRequest} - Standard EntityRequest fields along with accountReferenceId
     * 
     * @return A deposit account
     */
    @GET
    @Path("/{accountNumber}")
    @JSONP(queryParam = JSONP.DEFAULT_QUERY)
    @ApiOperation(value = "Get a single Profile Account (Deposit, CD, OLA and miscellaneous account information) resource.", notes = "Get a single Profile Account (Deposit, CD, OLA and miscellaneous account information) resource using the provided account number.", response = ProfileAccountDetail.class)
    @ApiResponses({
            @ApiResponse(code = HttpURLConnection.HTTP_OK, message = "Successful.", response = ProfileAccountDetail.class),
            @ApiResponse(code = HttpURLConnection.HTTP_NOT_FOUND, message = "No deposit accounts found for the given account reference identifier.", response = ErrorResponse.class),
            @ApiResponse(code = HttpURLConnection.HTTP_INTERNAL_ERROR, message = "Internal Server Error : The server encountered an unexpected condition which prevented it from fulfilling the request.", response = ErrorResponse.class)})
    public ProfileAccountDetail retrieveAccountDetails(@BeanParam RetrieveProfileAccountDetailsRequest request) {

        profileAccountsServiceUtil.authorize(request.getUserId());

        if (StringUtils.isBlank(request.getAccountNumber())) {
            throw new NotFoundException(new ApiErrorCode(ApiErrorCode.NOT_FOUND, ApiErrorCode.NOT_FOUND,
                    Constants.DEVTEXTID_INVALIDACCTNUMBER));
        }

        return profileAccountsService.retrieveProfileAccountDetails(request);

    }
    
    @Override
    public void health() {
    	profileAccountsService.health();
    }
    
    /**
     * This method updates the nickname of the account holder in DGW profile database. 
     * 
     * @param updateRequest
     */
    @POST
    @Path("/{accountNumber}/cif/{cif}")
    @ApiOperation(value = "This is to update account nickname in DGW system")
    @ApiResponses({
            @ApiResponse(code = HttpURLConnection.HTTP_OK, message = "Successful." ),
            @ApiResponse(code = HttpURLConnection.HTTP_NOT_FOUND, message = "No deposit accounts found for the given account reference identifier.", response = ErrorResponse.class),
            @ApiResponse(code = HttpURLConnection.HTTP_INTERNAL_ERROR, message = "Internal Server Error : The server encountered an unexpected condition which prevented it from fulfilling the request.", response = ErrorResponse.class)})
    public void updateAccountDetails(
    		@PathParam(value = "accountNumber") String accountNumber,@PathParam(value = "cif") String cif,@Valid UpdateProfileAccountDetailsRequest updateProfileAccountDetailsRequest){
    	
    	updateProfileAccountsService.setAccountDetails(accountNumber,cif,updateProfileAccountDetailsRequest);
    }
}

/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
 */