package com.capitalone.api.integration.profile.accounts.rest.resources.v3;

/**
 * Exposed REST resources for int-profile-accounts functionality.
 */