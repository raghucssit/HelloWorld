package com.capitalone.api.integration.profile.accounts.rest.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

/**
 * Spring bean configuration class.
 * 
 * @author Generated
 * 
 */
@Configuration
@ComponentScan(basePackages = {"com.capitalone.api.integration.profile.accounts"})
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class SpringConfig {
	@Bean
    public MessageSource messageSource(@Value("${message.reload.timeout}") Integer messageReloadTimeout,
            @Value("${error.messages.basename}") String baseNames) {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasenames(baseNames);
        messageSource.setCacheSeconds(messageReloadTimeout);
        return messageSource;
    }

    @Bean
    public MessageSource validationMessages(@Value("${message.reload.timeout}") Integer messageReloadTimeout,
            @Value("${validation.messages.basename}") String baseNames) {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasenames(baseNames);
        messageSource.setCacheSeconds(messageReloadTimeout);
        return messageSource;
    }
}
/*
 * Copyright 2014 Capital One Financial Corporation All Rights Reserved.
 * 
 * This software contains valuable trade secrets and proprietary information of Capital One and is protected by law. It
 * may not be copied or distributed in any form or medium, disclosed to third parties, reverse engineered or used in any
 * manner without prior written authorization from Capital One.
*/