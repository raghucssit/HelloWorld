package com.capitalone.api.integration.profile.accounts.rest.config;

/**
 * Spring and Jersey configuration classes for int-profile-accounts functionality.
 */