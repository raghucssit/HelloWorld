package com.capitalone.api.integration.profile.accounts.rest.resources.v3;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.capitalone.api.commons.exception.NotFoundException;
import com.capitalone.api.integration.profile.accounts.model.v3.ProfileAccountDetail;
import com.capitalone.api.integration.profile.accounts.model.v3.RetrieveProfileAccountDetailsRequest;
import com.capitalone.api.integration.profile.accounts.model.v3.UpdateProfileAccountDetailsRequest;
import com.capitalone.api.integration.profile.accounts.service.api.ProfileAccountsService;
import com.capitalone.api.integration.profile.accounts.service.api.UpdateProfileAccountsService;
import com.capitalone.api.integration.profile.accounts.service.util.ProfileAccountsServiceUtil;

@RunWith(MockitoJUnitRunner.class)
public class ProfileAccountsResourceTest {
    @InjectMocks
    private ProfileAccountsResource profileAccountsResource;

    @Mock
    private ProfileAccountsService profileAccountsService;

    @Mock
    private ProfileAccountsServiceUtil profileAccountsServiceUtil;

    @Mock
    private ProfileAccountDetail profileAccountDetail;

    @Mock
    private UpdateProfileAccountsService updateProfileAccountsService;

    @Mock
    private UpdateProfileAccountDetailsRequest accountDetailsRequest;

    @Mock
    private UpdateProfileAccountDetailsRequest request;

    private static final String MOCK_STRING = "MOCK_STRING";

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testretrieveAccountDetails() {
        RetrieveProfileAccountDetailsRequest request = new RetrieveProfileAccountDetailsRequest();
        request.setUserId("test1");
        request.setAccountNumber("AccNum1");
        Mockito.doNothing().when(profileAccountsServiceUtil).authorize(request.getUserId());
        Mockito.when(profileAccountsService.retrieveProfileAccountDetails(request)).thenReturn(profileAccountDetail);
        profileAccountDetail = profileAccountsResource.retrieveAccountDetails(request);
        assertNotNull(profileAccountDetail);
    }

    @Test(expected = NotFoundException.class)
    public void testretrieveAccountDetailsFailure() {
        RetrieveProfileAccountDetailsRequest request = new RetrieveProfileAccountDetailsRequest();
        request.setUserId("");
        request.setAccountNumber("");
        Mockito.doNothing().when(profileAccountsServiceUtil).authorize(request.getUserId());
        Mockito.when(profileAccountsService.retrieveProfileAccountDetails(request)).thenReturn(profileAccountDetail);
        profileAccountDetail = profileAccountsResource.retrieveAccountDetails(request);
        assertNotNull(profileAccountDetail);
    }

    @Test
    public void testHealth() {
        profileAccountsResource.health();
        Mockito.verify(profileAccountsService).health();
    }

    @Test
    public void testUpdateAccountDetails() {
        profileAccountsResource.updateAccountDetails(MOCK_STRING, MOCK_STRING, request);
        Mockito.verify(updateProfileAccountsService).setAccountDetails(MOCK_STRING, MOCK_STRING, request);
    }

}
